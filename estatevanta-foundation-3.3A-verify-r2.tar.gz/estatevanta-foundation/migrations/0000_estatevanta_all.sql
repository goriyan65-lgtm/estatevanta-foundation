-- =====================================================================
-- EstateVanta CRM — 0000_estatevanta_all.sql   (installer, revision 2)
-- COMBINED INSTALLER for a COMPLETELY FRESH Supabase project.
-- Contents, in dependency order:
--   0001_foundation  0002_crm_core  0003_properties  0004_pipeline
--   0005_platform    0006_audit     0007_rls         0008_system_config
--   0009_confirmed_decisions
-- Each section below is a byte-for-byte copy of the matching file in
-- supabase/migrations/ (those files are the source of truth).
--
-- ATOMICITY: this script contains NO BEGIN / COMMIT / ROLLBACK on purpose.
-- Supabase's SQL Editor sends the whole script to PostgreSQL as one
-- multi-statement query, and PostgreSQL runs such a query as a single
-- implicit transaction: if any statement fails, everything is rolled back.
--
-- Paste into a NEW, EMPTY SQL Editor tab. Run ONCE.
-- Inserts system configuration only. NO demo/business data.
-- =====================================================================

-- ######################################################################
-- ## SECTION 0001_foundation.sql
-- ######################################################################

-- =====================================================================
-- EstateVanta CRM — 0001_foundation.sql
-- Extensions, enums, helpers, reference tables, auth profile + RBAC.
-- NO DEMO DATA. System configuration lives in 0008_system_config.sql.
-- Target: PostgreSQL 15+ (Supabase). Not yet executed against a live DB.
-- =====================================================================

create extension if not exists pgcrypto;
create extension if not exists citext;
create extension if not exists pg_trgm;

create schema if not exists app;      -- helper functions, sequences (not exposed via API)

-- ---------------------------------------------------------------------
-- ENUM STRATEGY
-- Postgres ENUMs  = stable lifecycle states the code branches on.
-- Reference tables = business-configurable lists (statuses, sources,
--                    property types, area units, amenities).
-- ---------------------------------------------------------------------
create type lead_type            as enum ('buy','sell','rent','invest');
create type priority_level       as enum ('low','medium','high','urgent');
create type transaction_type     as enum ('sale','rent','lease');
create type property_status      as enum ('available','reserved','under_negotiation','sold','rented','inactive');
create type furnishing_type      as enum ('unfurnished','semi_furnished','furnished');
create type facing_direction     as enum ('north','south','east','west','north_east','north_west','south_east','south_west');
create type construction_status  as enum ('ready_to_move','under_construction','not_applicable');
create type inventory_source     as enum ('owner_direct','broker','developer','existing_database','external_authorized_import','other');
create type verification_status  as enum ('unverified','pending','verified','rejected');
create type ownership_doc_status as enum ('not_collected','collected','under_review','verified','disputed');
create type exclusivity_type     as enum ('exclusive','non_exclusive');
create type brokerage_type       as enum ('percentage','fixed','none');
create type media_kind           as enum ('image','video','floor_plan');
create type document_category    as enum ('ownership','identity','agreement','tax','utility','other');
create type seller_relationship  as enum ('new','contacted','active_client','repeat_client','inactive','blacklisted');
create type financing_status     as enum ('cash','loan_approved','loan_in_process','loan_needed','undecided');
create type purchase_timeline    as enum ('immediate','within_1_month','one_to_three_months','three_to_six_months','over_six_months','undecided');
create type purpose_type         as enum ('self_use','investment','both');
create type requirement_status   as enum ('active','on_hold','fulfilled','closed');
create type importance_level     as enum ('must_have','nice_to_have');
create type match_status         as enum ('suggested','shared','interested','rejected','visited','dismissed');
create type match_criterion      as enum ('budget','location','property_type','area','bhk','preferences');
create type appointment_type     as enum ('site_visit','call','meeting','follow_up');
create type appointment_status   as enum ('scheduled','confirmed','completed','rescheduled','cancelled','no_show');
create type interest_level       as enum ('low','medium','high','very_high');
create type task_status          as enum ('pending','in_progress','completed','cancelled');
create type activity_type        as enum ('note','call','whatsapp','email','meeting','site_visit','status_change','system');
create type deal_status          as enum ('negotiation','token','documentation','agreement','registration','closed','cancelled');
create type deal_payment_status  as enum ('unpaid','partial','paid');
create type payment_purpose      as enum ('token','part_payment','final_payment','commission','refund','other');
create type payment_method       as enum ('cash','bank_transfer','upi','cheque','other');
create type payment_record_status as enum ('pending','received','failed','refunded');
create type commission_party     as enum ('buyer','seller');
create type commission_status    as enum ('expected','partially_received','received','waived');
create type market_data_kind     as enum ('asking_price','verified_transaction','estimate','third_party');
create type demand_indicator     as enum ('low','medium','high');
create type import_entity        as enum ('properties','leads','buyers','sellers','market_data');
create type import_format        as enum ('csv','xlsx','json');
create type import_status        as enum ('uploaded','mapped','validated','confirmed','importing','completed','failed','cancelled');
create type import_row_decision  as enum ('pending','import','skip','merge');
create type message_channel      as enum ('in_app','email','whatsapp','sms');
create type message_status       as enum ('queued','sending','sent','delivered','failed','cancelled');
create type duplicate_status     as enum ('pending','same_person','different_person');

-- ---------------------------------------------------------------------
-- HELPERS
-- ---------------------------------------------------------------------
create or replace function app.set_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

-- Human-readable codes (LD-000001, PR-000001 ...). Gaps are acceptable.
create sequence app.lead_code_seq;
create sequence app.buyer_code_seq;
create sequence app.seller_code_seq;
create sequence app.property_code_seq;
create sequence app.deal_code_seq;
create sequence app.requirement_code_seq;

create or replace function app.next_code(prefix text, seq regclass) returns text
language sql volatile as $$
  select prefix || '-' || lpad(nextval(seq)::text, 6, '0')
$$;

-- ---------------------------------------------------------------------
-- REFERENCE TABLES (business-configurable; text code PK = stable FK target)
-- is_system = seeded by the application, cannot be deleted (only deactivated)
-- ---------------------------------------------------------------------
create table lead_statuses (
  code        text primary key,
  label       text not null,
  sort_order  smallint not null default 0,
  is_terminal boolean not null default false,
  is_active   boolean not null default true,
  is_system   boolean not null default false,
  created_at  timestamptz not null default now()
);

create table lead_sources (
  code       text primary key,
  label      text not null,
  sort_order smallint not null default 0,
  is_active  boolean not null default true,
  is_system  boolean not null default false,
  created_at timestamptz not null default now()
);

create table property_types (
  code       text primary key,
  label      text not null,
  sort_order smallint not null default 0,
  is_active  boolean not null default true,
  is_system  boolean not null default false,
  created_at timestamptz not null default now()
);

-- sq_ft_factor is NULL when not configured. Regional units (marla, kanal,
-- bigha) vary by state/locale, so the owner must set them; nothing is assumed.
create table area_units (
  code         text primary key,
  label        text not null,
  sq_ft_factor numeric(14,6) check (sq_ft_factor is null or sq_ft_factor > 0),
  is_active    boolean not null default true,
  is_system    boolean not null default false
);

create table amenities (
  id         uuid primary key default gen_random_uuid(),
  name       citext not null unique,
  is_active  boolean not null default true,
  created_at timestamptz not null default now()
);

create table localities (
  id         uuid primary key default gen_random_uuid(),
  city       text not null,
  name       text not null,
  is_active  boolean not null default true,
  created_at timestamptz not null default now(),
  unique (city, name)
);
create index localities_name_trgm on localities using gin (name gin_trgm_ops);

-- ---------------------------------------------------------------------
-- AUTH: roles, permissions, profiles
-- Passwords/sessions live in Supabase auth.users. Never duplicated here.
-- ---------------------------------------------------------------------
create table roles (
  id          smallint generated always as identity primary key,
  code        text not null unique,          -- admin | manager | agent | viewer (+ custom)
  label       text not null,
  is_system   boolean not null default false,
  created_at  timestamptz not null default now()
);

create table permissions (
  id          smallint generated always as identity primary key,
  code        text not null unique,          -- '<module>.<action>' e.g. leads.read_all
  description text
);

create table role_permissions (
  role_id       smallint not null references roles(id) on delete cascade,
  permission_id smallint not null references permissions(id) on delete cascade,
  primary key (role_id, permission_id)
);

-- A row is created automatically for each auth user (trigger below) but
-- is INACTIVE with NO role until an admin approves it. Public signup can
-- therefore never grant access by itself.
create table profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  full_name   text,
  phone       text,
  role_id     smallint references roles(id),
  is_active   boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  deleted_at  timestamptz
);
create index profiles_role_idx on profiles(role_id) where deleted_at is null;
create trigger profiles_updated_at before update on profiles
  for each row execute function app.set_updated_at();

create or replace function app.handle_new_auth_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', new.email));
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function app.handle_new_auth_user();

-- Permission helpers used by every RLS policy. SECURITY DEFINER so they can
-- read profiles/role_permissions regardless of the caller's own RLS.
create or replace function app.current_role_code() returns text
language sql stable security definer set search_path = public as $$
  select r.code from profiles p join roles r on r.id = p.role_id
  where p.id = auth.uid() and p.is_active and p.deleted_at is null
$$;

create or replace function app.can(perm text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1
    from profiles p
    join role_permissions rp on rp.role_id = p.role_id
    join permissions pm on pm.id = rp.permission_id
    where p.id = auth.uid() and p.is_active and p.deleted_at is null
      and pm.code = perm
  )
$$;

create or replace function app.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(app.current_role_code() = 'admin', false)
$$;

-- One-time bootstrap: promotes the FIRST auth user to admin, only if no
-- active admin exists. Run manually once from the SQL editor.
create or replace function app.bootstrap_first_admin(target_user uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if exists (select 1 from profiles p join roles r on r.id = p.role_id
             where r.code = 'admin' and p.is_active) then
    raise exception 'An active admin already exists';
  end if;
  update profiles
     set role_id = (select id from roles where code = 'admin'), is_active = true
   where id = target_user;
  if not found then raise exception 'No profile for user %', target_user; end if;
end $$;
revoke all on function app.bootstrap_first_admin(uuid) from public, anon, authenticated;

-- ## END SECTION 0001_foundation.sql

-- ######################################################################
-- ## SECTION 0002_crm_core.sql
-- ######################################################################

-- =====================================================================
-- EstateVanta CRM — 0002_crm_core.sql
-- contacts (person master) → buyers / sellers / leads
-- Person details (name/phone/WhatsApp/email) live ONCE in contacts.
-- =====================================================================

-- ---------------------------------------------------------------------
-- CONTACTS: one row per real person. Buyer/Seller/Lead point here, so no
-- duplicate data entry and duplicate detection has one place to look.
-- phone_key = last 10 digits (ASSUMES Indian numbers; adjust if
-- international numbers become common). Deliberately NOT unique: the
-- spec requires the agent to decide on possible duplicates.
-- ---------------------------------------------------------------------
create table contacts (
  id               uuid primary key default gen_random_uuid(),
  full_name        text not null check (length(btrim(full_name)) > 0),
  phone            text,
  phone_key        text generated always as (
                     nullif(right(regexp_replace(coalesce(phone,''), '\D', '', 'g'), 10), '')
                   ) stored,
  whatsapp         text,
  whatsapp_key     text generated always as (
                     nullif(right(regexp_replace(coalesce(whatsapp,''), '\D', '', 'g'), 10), '')
                   ) stored,
  email            citext check (email is null or email::text ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  address          text,
  notes            text,
  merged_into_id   uuid references contacts(id),       -- set when two records are confirmed same person
  created_by       uuid references profiles(id),
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  deleted_at       timestamptz,
  deleted_by       uuid references profiles(id),
  check (phone is not null or whatsapp is not null or email is not null),
  check (merged_into_id is null or merged_into_id <> id)
);
create index contacts_phone_key_idx    on contacts(phone_key)    where phone_key is not null and deleted_at is null;
create index contacts_whatsapp_key_idx on contacts(whatsapp_key) where whatsapp_key is not null and deleted_at is null;
create index contacts_email_idx        on contacts(email)        where email is not null and deleted_at is null;
create index contacts_name_trgm        on contacts using gin (full_name gin_trgm_ops);
create trigger contacts_updated_at before update on contacts
  for each row execute function app.set_updated_at();

-- Possible duplicates awaiting a human decision (agent confirms or rejects).
create table duplicate_candidates (
  id             uuid primary key default gen_random_uuid(),
  contact_a_id   uuid not null references contacts(id),
  contact_b_id   uuid not null references contacts(id),
  matched_on     text[] not null,                        -- {'phone','whatsapp','email'}
  status         duplicate_status not null default 'pending',
  resolved_by    uuid references profiles(id),
  resolved_at    timestamptz,
  created_at     timestamptz not null default now(),
  check (contact_a_id < contact_b_id),                   -- store each pair once
  unique (contact_a_id, contact_b_id)
);
create index duplicate_candidates_pending_idx on duplicate_candidates(status) where status = 'pending';

-- Read-only helper used by the API/lead-capture service.
create or replace function find_contact_matches(p_phone text, p_whatsapp text, p_email text)
returns table (contact_id uuid, matched_on text[])
language sql stable security invoker as $$
  with keys as (
    select nullif(right(regexp_replace(coalesce(p_phone,''), '\D','','g'),10),'')    as pk,
           nullif(right(regexp_replace(coalesce(p_whatsapp,''), '\D','','g'),10),'') as wk,
           nullif(btrim(p_email),'')::citext                                        as em
  )
  select c.id,
         array_remove(array[
           case when k.pk is not null and (c.phone_key = k.pk or c.whatsapp_key = k.pk) then 'phone' end,
           case when k.wk is not null and (c.phone_key = k.wk or c.whatsapp_key = k.wk) then 'whatsapp' end,
           case when k.em is not null and c.email = k.em then 'email' end
         ], null)
  from contacts c, keys k
  where c.deleted_at is null and c.merged_into_id is null
    and ( (k.pk is not null and (c.phone_key = k.pk or c.whatsapp_key = k.pk))
       or (k.wk is not null and (c.phone_key = k.wk or c.whatsapp_key = k.wk))
       or (k.em is not null and c.email = k.em) )
$$;

-- ---------------------------------------------------------------------
-- BUYERS  (profile-level facts only; budget/locations/BHK live in
-- buyer_requirements so a buyer can hold several — see 0004)
-- ---------------------------------------------------------------------
create table buyers (
  id                 uuid primary key default gen_random_uuid(),
  code               text not null unique default app.next_code('BY','app.buyer_code_seq'),
  contact_id         uuid not null references contacts(id),
  financing_status   financing_status not null default 'undecided',
  purchase_timeline  purchase_timeline not null default 'undecided',
  purpose            purpose_type,
  is_active          boolean not null default true,
  assigned_to        uuid references profiles(id),
  last_contact_at    timestamptz,
  notes              text,
  created_by         uuid references profiles(id),
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now(),
  deleted_at         timestamptz,
  deleted_by         uuid references profiles(id)
);
create unique index buyers_contact_uq on buyers(contact_id) where deleted_at is null;
create index buyers_assigned_idx on buyers(assigned_to) where deleted_at is null;
create index buyers_active_idx   on buyers(is_active)   where deleted_at is null;
create trigger buyers_updated_at before update on buyers
  for each row execute function app.set_updated_at();

-- ---------------------------------------------------------------------
-- SELLERS / OWNERS  (number_of_properties is derived: see v_seller_summary)
-- ---------------------------------------------------------------------
create table sellers (
  id                    uuid primary key default gen_random_uuid(),
  code                  text not null unique default app.next_code('SL','app.seller_code_seq'),
  contact_id            uuid not null references contacts(id),
  relationship_status   seller_relationship not null default 'new',
  assigned_to           uuid references profiles(id),
  last_contact_at       timestamptz,
  notes                 text,
  created_by            uuid references profiles(id),
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now(),
  deleted_at            timestamptz,
  deleted_by            uuid references profiles(id)
);
create unique index sellers_contact_uq on sellers(contact_id) where deleted_at is null;
create index sellers_assigned_idx on sellers(assigned_to) where deleted_at is null;
create index sellers_rel_idx      on sellers(relationship_status) where deleted_at is null;
create trigger sellers_updated_at before update on sellers
  for each row execute function app.set_updated_at();

-- ---------------------------------------------------------------------
-- LEADS  (Lead → Buyer/Seller via buyer_id / seller_id once qualified)
-- ---------------------------------------------------------------------
create table leads (
  id                  uuid primary key default gen_random_uuid(),
  code                text not null unique default app.next_code('LD','app.lead_code_seq'),
  contact_id          uuid not null references contacts(id),
  lead_type           lead_type not null,
  source_code         text not null references lead_sources(code),
  status_code         text not null references lead_statuses(code),
  priority            priority_level not null default 'medium',
  property_type_code  text references property_types(code),
  budget_min          numeric(14,2) check (budget_min is null or budget_min >= 0),
  budget_max          numeric(14,2) check (budget_max is null or budget_max >= 0),
  preferred_location  text,
  requirement         text,
  assigned_to         uuid references profiles(id),
  buyer_id            uuid references buyers(id),
  seller_id           uuid references sellers(id),
  last_contact_at     timestamptz,
  next_follow_up_at   timestamptz,
  lost_reason         text,
  notes               text,
  source_meta         jsonb not null default '{}'::jsonb,   -- UTM, form id, page URL (website leads)
  created_by          uuid references profiles(id),         -- NULL = created by system/API
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  deleted_at          timestamptz,
  deleted_by          uuid references profiles(id),
  check (budget_max is null or budget_min is null or budget_max >= budget_min)
);
create index leads_contact_idx    on leads(contact_id);
create index leads_status_idx     on leads(status_code)   where deleted_at is null;
create index leads_source_idx     on leads(source_code)   where deleted_at is null;
create index leads_type_idx       on leads(lead_type)     where deleted_at is null;
create index leads_assigned_idx   on leads(assigned_to)   where deleted_at is null;
create index leads_priority_idx   on leads(priority)      where deleted_at is null;
create index leads_followup_idx   on leads(next_follow_up_at) where next_follow_up_at is not null and deleted_at is null;
create index leads_created_idx    on leads(created_at desc);
create index leads_buyer_idx      on leads(buyer_id)  where buyer_id  is not null;
create index leads_seller_idx     on leads(seller_id) where seller_id is not null;
create trigger leads_updated_at before update on leads
  for each row execute function app.set_updated_at();

-- ## END SECTION 0002_crm_core.sql

-- ######################################################################
-- ## SECTION 0003_properties.sql
-- ######################################################################

-- =====================================================================
-- EstateVanta CRM — 0003_properties.sql
-- Seller/Owner → Properties (1:N). Owner phone is NOT stored on the
-- property; it is read through sellers → contacts (no duplicate entry).
-- =====================================================================

create table properties (
  id                   uuid primary key default gen_random_uuid(),
  code                 text not null unique default app.next_code('PR','app.property_code_seq'),
  title                text not null check (length(btrim(title)) > 0),
  property_type_code   text not null references property_types(code),
  transaction_type     transaction_type not null,
  price                numeric(14,2) check (price is null or price >= 0),   -- asking price
  min_price            numeric(14,2) check (min_price is null or min_price >= 0),
  area_value           numeric(12,2) check (area_value is null or area_value > 0),
  area_unit            text references area_units(code),
  bhk                  smallint check (bhk is null or bhk between 0 and 20),
  bathrooms            smallint check (bathrooms is null or bathrooms >= 0),
  floor_no             smallint,
  total_floors         smallint check (total_floors is null or total_floors >= 0),
  facing               facing_direction,
  furnishing           furnishing_type,
  construction_status  construction_status,
  status               property_status not null default 'available',
  city                 text not null,
  locality_id          uuid references localities(id),
  address              text,
  latitude             numeric(9,6) check (latitude  is null or latitude  between -90  and 90),
  longitude            numeric(9,6) check (longitude is null or longitude between -180 and 180),
  owner_id             uuid references sellers(id),                          -- nullable: broker/developer/import inventory
  description          text,
  -- provenance (mandatory for externally sourced records)
  source               inventory_source not null,
  source_name          text,                                                 -- e.g. broker/developer name or authorized provider
  source_url           text,
  source_date          date,
  import_batch_id      uuid,                                                 -- FK added in 0005 (import_batches)
  -- verification
  verification_status  verification_status not null default 'unverified',
  last_verified_at     timestamptz,
  verified_by          uuid references profiles(id),
  assigned_to          uuid references profiles(id),
  created_by           uuid references profiles(id),
  created_at           timestamptz not null default now(),
  updated_at           timestamptz not null default now(),
  deleted_at           timestamptz,
  deleted_by           uuid references profiles(id),
  check (min_price is null or price is null or min_price <= price),
  check ((area_value is null) = (area_unit is null)),
  check (floor_no is null or total_floors is null or floor_no <= total_floors),
  check (source <> 'owner_direct' or owner_id is not null),                  -- owner-direct must name an owner
  check (source not in ('external_authorized_import') or (source_name is not null and source_date is not null)),
  check (verification_status <> 'verified' or last_verified_at is not null)
);
create index properties_status_idx    on properties(status)               where deleted_at is null;
create index properties_type_idx      on properties(property_type_code)   where deleted_at is null;
create index properties_txn_idx       on properties(transaction_type)     where deleted_at is null;
create index properties_price_idx     on properties(price)                where deleted_at is null;
create index properties_city_loc_idx  on properties(city, locality_id)    where deleted_at is null;
create index properties_owner_idx     on properties(owner_id)             where deleted_at is null;
create index properties_source_idx    on properties(source)               where deleted_at is null;
create index properties_verif_idx     on properties(verification_status, last_verified_at) where deleted_at is null;
create index properties_bhk_idx       on properties(bhk)                  where deleted_at is null;
create index properties_title_trgm    on properties using gin (title gin_trgm_ops);
create index properties_address_trgm  on properties using gin (address gin_trgm_ops);
create index properties_geo_idx       on properties(latitude, longitude)  where latitude is not null;
-- Prevent re-importing the same external listing twice.
create unique index properties_source_url_uq on properties(source_url)
  where source_url is not null and deleted_at is null;
create trigger properties_updated_at before update on properties
  for each row execute function app.set_updated_at();

-- Owner-direct commercial terms (1:1, only for properties that need them)
create table property_owner_terms (
  property_id           uuid primary key references properties(id) on delete cascade,
  is_negotiable         boolean,
  ownership_doc_status  ownership_doc_status not null default 'not_collected',
  exclusivity           exclusivity_type,
  brokerage_kind        brokerage_type not null default 'none',
  brokerage_value       numeric(12,2) check (brokerage_value is null or brokerage_value >= 0),
  owner_verified        boolean not null default false,
  owner_verified_at     timestamptz,
  owner_verified_by     uuid references profiles(id),
  updated_at            timestamptz not null default now(),
  check (brokerage_kind = 'none' or brokerage_value is not null),
  check (not owner_verified or owner_verified_at is not null)
);
create trigger property_owner_terms_updated_at before update on property_owner_terms
  for each row execute function app.set_updated_at();

create table property_amenities (
  property_id uuid not null references properties(id) on delete cascade,
  amenity_id  uuid not null references amenities(id),
  primary key (property_id, amenity_id)
);
create index property_amenities_amenity_idx on property_amenities(amenity_id);

-- Media: files live in a PRIVATE Supabase Storage bucket; this table stores
-- only the object path. Access is via short-lived signed URLs.
create table property_media (
  id            uuid primary key default gen_random_uuid(),
  property_id   uuid not null references properties(id) on delete cascade,
  kind          media_kind not null,
  storage_path  text not null unique,
  file_name     text,
  mime_type     text,
  size_bytes    bigint check (size_bytes is null or size_bytes >= 0),
  sort_order    integer not null default 0,
  is_primary    boolean not null default false,
  caption       text,
  uploaded_by   uuid references profiles(id),
  created_at    timestamptz not null default now(),
  deleted_at    timestamptz,
  check (not is_primary or kind = 'image')
);
create index property_media_property_idx on property_media(property_id, kind, sort_order) where deleted_at is null;
-- exactly one primary image per property
create unique index property_media_one_primary_uq on property_media(property_id)
  where is_primary and deleted_at is null;

create table property_documents (
  id            uuid primary key default gen_random_uuid(),
  property_id   uuid not null references properties(id) on delete cascade,
  category      document_category not null,
  title         text not null,
  storage_path  text not null unique,
  mime_type     text,
  size_bytes    bigint check (size_bytes is null or size_bytes >= 0),
  is_verified   boolean not null default false,
  uploaded_by   uuid references profiles(id),
  created_at    timestamptz not null default now(),
  deleted_at    timestamptz
);
create index property_documents_property_idx on property_documents(property_id) where deleted_at is null;

-- Derived views (security_invoker => the caller's RLS still applies)
create view v_seller_summary with (security_invoker = true) as
select s.id as seller_id,
       count(p.id) filter (where p.deleted_at is null) as number_of_properties
from sellers s
left join properties p on p.owner_id = s.id
group by s.id;

-- NOTE: v_properties_due_verification is defined in 0005 (needs the settings table).

-- ## END SECTION 0003_properties.sql

-- ######################################################################
-- ## SECTION 0004_pipeline.sql
-- ######################################################################

-- =====================================================================
-- EstateVanta CRM — 0004_pipeline.sql
-- Buyer → Requirements → Matches → Site Visits → Deals → Payments/Commission
-- =====================================================================

-- ---------------------------------------------------------------------
-- BUYER REQUIREMENTS (a buyer may hold many active requirements)
-- ---------------------------------------------------------------------
create table buyer_requirements (
  id                uuid primary key default gen_random_uuid(),
  code              text not null unique default app.next_code('RQ','app.requirement_code_seq'),
  buyer_id          uuid not null references buyers(id),
  lead_id           uuid references leads(id),
  transaction_type  transaction_type not null,
  budget_min        numeric(14,2) check (budget_min is null or budget_min >= 0),
  budget_max        numeric(14,2) check (budget_max is null or budget_max >= 0),
  bhk_min           smallint check (bhk_min is null or bhk_min >= 0),
  bhk_max           smallint check (bhk_max is null or bhk_max >= 0),
  area_min          numeric(12,2) check (area_min is null or area_min > 0),
  area_max          numeric(12,2) check (area_max is null or area_max > 0),
  area_unit         text references area_units(code),
  purpose           purpose_type,
  timeline          purchase_timeline not null default 'undecided',
  status            requirement_status not null default 'active',
  notes             text,
  created_by        uuid references profiles(id),
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  deleted_at        timestamptz,
  deleted_by        uuid references profiles(id),
  check (budget_max is null or budget_min is null or budget_max >= budget_min),
  check (bhk_max is null or bhk_min is null or bhk_max >= bhk_min),
  check (area_max is null or area_min is null or area_max >= area_min),
  check ((area_min is null and area_max is null) or area_unit is not null)
);
create index buyer_requirements_buyer_idx  on buyer_requirements(buyer_id) where deleted_at is null;
create index buyer_requirements_active_idx on buyer_requirements(status, transaction_type) where deleted_at is null;
create index buyer_requirements_lead_idx   on buyer_requirements(lead_id) where lead_id is not null;
create trigger buyer_requirements_updated_at before update on buyer_requirements
  for each row execute function app.set_updated_at();

create table requirement_property_types (
  requirement_id      uuid not null references buyer_requirements(id) on delete cascade,
  property_type_code  text not null references property_types(code),
  primary key (requirement_id, property_type_code)
);
create table requirement_localities (
  requirement_id uuid not null references buyer_requirements(id) on delete cascade,
  locality_id    uuid not null references localities(id),
  primary key (requirement_id, locality_id)
);
create index requirement_localities_loc_idx on requirement_localities(locality_id);

-- Free-form preferences (must-have vs nice-to-have). amenity_id when the
-- preference maps to a known amenity; otherwise key/value (e.g. facing=east).
create table requirement_preferences (
  id              uuid primary key default gen_random_uuid(),
  requirement_id  uuid not null references buyer_requirements(id) on delete cascade,
  importance      importance_level not null,
  amenity_id      uuid references amenities(id),
  pref_key        text,
  pref_value      text,
  check (amenity_id is not null or pref_key is not null)
);
create index requirement_preferences_req_idx on requirement_preferences(requirement_id);

-- ---------------------------------------------------------------------
-- MATCHING CONFIGURATION (weights are DATA, not code/SQL logic)
-- Exactly one active config. Editing = create a new version, so old
-- match scores stay explainable.
-- ---------------------------------------------------------------------
create table matching_configs (
  id                  uuid primary key default gen_random_uuid(),
  name                text not null,
  version             integer not null default 1,
  is_active           boolean not null default false,
  min_score_to_store  numeric(5,2) not null default 0 check (min_score_to_store between 0 and 100),
  budget_tolerance_pct numeric(5,2) not null default 0 check (budget_tolerance_pct >= 0),
  notes               text,
  created_by          uuid references profiles(id),
  created_at          timestamptz not null default now(),
  unique (name, version)
);
create unique index matching_configs_one_active_uq on matching_configs(is_active) where is_active;

create table matching_weights (
  config_id  uuid not null references matching_configs(id) on delete cascade,
  criterion  match_criterion not null,
  weight     numeric(5,2) not null check (weight >= 0 and weight <= 100),
  primary key (config_id, criterion)
);

-- Weights of a config must total 100 (checked when a config is activated).
create or replace function app.enforce_active_weights() returns trigger
language plpgsql as $$
declare total numeric;
begin
  if new.is_active then
    select coalesce(sum(weight),0) into total from matching_weights where config_id = new.id;
    if total <> 100 then
      raise exception 'Matching weights must total 100 to activate (got %)', total;
    end if;
  end if;
  return new;
end $$;
create trigger matching_configs_weights_ck before insert or update of is_active on matching_configs
  for each row execute function app.enforce_active_weights();

-- Match results. Hard filters (transaction type, available status) are applied
-- by the engine before scoring; the score is an INTERNAL rule-based number,
-- never presented as objective truth.
create table property_matches (
  id               uuid primary key default gen_random_uuid(),
  requirement_id   uuid not null references buyer_requirements(id) on delete cascade,
  property_id      uuid not null references properties(id) on delete cascade,
  config_id        uuid not null references matching_configs(id),
  score            numeric(5,2) not null check (score between 0 and 100),
  criteria_results jsonb not null,           -- {criterion:{weight, earned, matched:bool, detail}}
  status           match_status not null default 'suggested',
  computed_at      timestamptz not null default now(),
  shared_at        timestamptz,
  status_changed_by uuid references profiles(id),
  updated_at       timestamptz not null default now(),
  unique (requirement_id, property_id, config_id)
);
create index property_matches_req_score_idx on property_matches(requirement_id, score desc);
create index property_matches_property_idx  on property_matches(property_id);
create index property_matches_status_idx    on property_matches(status);
create trigger property_matches_updated_at before update on property_matches
  for each row execute function app.set_updated_at();

-- ---------------------------------------------------------------------
-- APPOINTMENTS (calls, meetings, follow-ups, site visits) + SITE VISITS
-- Site visit = appointment (type 'site_visit') + 1:1 detail row.
-- Owner is derived: site_visits → properties.owner_id.
-- ---------------------------------------------------------------------
create table appointments (
  id            uuid primary key default gen_random_uuid(),
  type          appointment_type not null,
  status        appointment_status not null default 'scheduled',
  title         text,
  starts_at     timestamptz not null,
  ends_at       timestamptz,
  location      text,
  assigned_to   uuid references profiles(id),
  lead_id       uuid references leads(id),
  buyer_id      uuid references buyers(id),
  seller_id     uuid references sellers(id),
  notes         text,
  created_by    uuid references profiles(id),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  deleted_at    timestamptz,
  deleted_by    uuid references profiles(id),
  check (ends_at is null or ends_at >= starts_at)
);
create index appointments_start_idx    on appointments(starts_at) where deleted_at is null;
create index appointments_assigned_idx on appointments(assigned_to, starts_at) where deleted_at is null;
create index appointments_type_status_idx on appointments(type, status) where deleted_at is null;
create index appointments_buyer_idx    on appointments(buyer_id) where buyer_id is not null;
create trigger appointments_updated_at before update on appointments
  for each row execute function app.set_updated_at();

create table site_visits (
  appointment_id    uuid primary key references appointments(id) on delete cascade,
  buyer_id          uuid not null references buyers(id),
  property_id       uuid not null references properties(id),
  requirement_id    uuid references buyer_requirements(id),
  match_id          uuid references property_matches(id),
  buyer_feedback    text,
  interest_level    interest_level,
  next_action       text,
  next_follow_up_at timestamptz,
  updated_at        timestamptz not null default now()
);
create index site_visits_buyer_idx    on site_visits(buyer_id);
create index site_visits_property_idx on site_visits(property_id);
create trigger site_visits_updated_at before update on site_visits
  for each row execute function app.set_updated_at();

-- ---------------------------------------------------------------------
-- DEALS (Buyer + Seller + Property) — created before tasks/activities
-- so they can reference deal_id.
-- ---------------------------------------------------------------------
create table deals (
  id                 uuid primary key default gen_random_uuid(),
  code               text not null unique default app.next_code('DL','app.deal_code_seq'),
  lead_id            uuid references leads(id),
  buyer_id           uuid not null references buyers(id),
  seller_id          uuid not null references sellers(id),
  property_id        uuid not null references properties(id),
  requirement_id     uuid references buyer_requirements(id),
  status             deal_status not null default 'negotiation',
  final_price        numeric(14,2) check (final_price is null or final_price >= 0),
  token_amount       numeric(14,2) check (token_amount is null or token_amount >= 0),
  agreement_date     date,
  registration_date  date,
  commission_pct     numeric(5,2) check (commission_pct is null or commission_pct between 0 and 100),
  -- calculated from the real deal record; NULL until both inputs exist
  commission_amount  numeric(14,2) generated always as (round(final_price * commission_pct / 100, 2)) stored,
  payment_status     deal_payment_status not null default 'unpaid',
  closed_at          timestamptz,
  cancelled_reason   text,
  assigned_to        uuid references profiles(id),
  notes              text,
  created_by         uuid references profiles(id),
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now(),
  deleted_at         timestamptz,
  deleted_by         uuid references profiles(id),
  check (registration_date is null or agreement_date is null or registration_date >= agreement_date),
  check (status <> 'closed' or (final_price is not null and closed_at is not null)),
  check (status <> 'cancelled' or cancelled_reason is not null)
);
-- one live deal per buyer+property pair
create unique index deals_live_pair_uq on deals(buyer_id, property_id)
  where status <> 'cancelled' and deleted_at is null;
create index deals_status_idx   on deals(status)      where deleted_at is null;
create index deals_property_idx on deals(property_id) where deleted_at is null;
create index deals_seller_idx   on deals(seller_id)   where deleted_at is null;
create index deals_assigned_idx on deals(assigned_to) where deleted_at is null;
create trigger deals_updated_at before update on deals
  for each row execute function app.set_updated_at();

create table deal_documents (
  id            uuid primary key default gen_random_uuid(),
  deal_id       uuid not null references deals(id) on delete cascade,
  category      document_category not null,
  title         text not null,
  storage_path  text not null unique,
  mime_type     text,
  size_bytes    bigint check (size_bytes is null or size_bytes >= 0),
  uploaded_by   uuid references profiles(id),
  created_at    timestamptz not null default now(),
  deleted_at    timestamptz
);
create index deal_documents_deal_idx on deal_documents(deal_id) where deleted_at is null;

-- ---------------------------------------------------------------------
-- COMMISSIONS: expected commission per party (buyer side / seller side)
-- PAYMENTS: every money movement actually recorded.
-- Received = sum(payments where commission_id = X and status = 'received').
-- ---------------------------------------------------------------------
create table commissions (
  id               uuid primary key default gen_random_uuid(),
  deal_id          uuid not null references deals(id),
  party            commission_party not null,
  expected_amount  numeric(14,2) not null check (expected_amount >= 0),
  status           commission_status not null default 'expected',
  due_date         date,
  notes            text,
  created_by       uuid references profiles(id),
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  unique (deal_id, party)
);
create index commissions_status_idx on commissions(status);
create trigger commissions_updated_at before update on commissions
  for each row execute function app.set_updated_at();

create table payments (
  id            uuid primary key default gen_random_uuid(),
  deal_id       uuid not null references deals(id),
  commission_id uuid references commissions(id),
  purpose       payment_purpose not null,
  status        payment_record_status not null default 'pending',
  amount        numeric(14,2) not null check (amount > 0),
  paid_on       date,
  method        payment_method,
  reference_no  text,
  received_by   uuid references profiles(id),
  notes         text,
  created_by    uuid references profiles(id),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  check (purpose <> 'commission' or commission_id is not null),
  check (status <> 'received' or paid_on is not null)
);
create index payments_deal_idx       on payments(deal_id);
create index payments_commission_idx on payments(commission_id) where commission_id is not null;
create index payments_status_idx     on payments(status, paid_on);
create trigger payments_updated_at before update on payments
  for each row execute function app.set_updated_at();

-- Money view: Expected / Received / Pending — computed only from real rows.
create view v_commission_summary with (security_invoker = true) as
select c.id as commission_id, c.deal_id, c.party, c.expected_amount,
       coalesce(sum(p.amount) filter (where p.status = 'received'), 0) as received_amount,
       c.expected_amount - coalesce(sum(p.amount) filter (where p.status = 'received'), 0) as pending_amount
from commissions c
left join payments p on p.commission_id = c.id and p.purpose = 'commission'
where c.status <> 'waived'
group by c.id;

-- ---------------------------------------------------------------------
-- TASKS & ACTIVITIES (Lead → Activities/Tasks)
-- ---------------------------------------------------------------------
create table tasks (
  id           uuid primary key default gen_random_uuid(),
  title        text not null check (length(btrim(title)) > 0),
  status       task_status not null default 'pending',
  priority     priority_level not null default 'medium',
  due_at       timestamptz,
  assigned_to  uuid references profiles(id),
  lead_id      uuid references leads(id),
  buyer_id     uuid references buyers(id),
  seller_id    uuid references sellers(id),
  property_id  uuid references properties(id),
  deal_id      uuid references deals(id),
  notes        text,
  system_key   text,                          -- e.g. 'reverify:<property_id>' to avoid duplicate auto-tasks
  completed_at timestamptz,
  created_by   uuid references profiles(id),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  deleted_at   timestamptz,
  deleted_by   uuid references profiles(id),
  check (status <> 'completed' or completed_at is not null)
);
create index tasks_assigned_due_idx on tasks(assigned_to, due_at) where status in ('pending','in_progress') and deleted_at is null;
create index tasks_lead_idx     on tasks(lead_id)     where lead_id     is not null;
create index tasks_buyer_idx    on tasks(buyer_id)    where buyer_id    is not null;
create index tasks_seller_idx   on tasks(seller_id)   where seller_id   is not null;
create index tasks_property_idx on tasks(property_id) where property_id is not null;
create index tasks_deal_idx     on tasks(deal_id)     where deal_id     is not null;
create unique index tasks_system_key_uq on tasks(system_key)
  where system_key is not null and status in ('pending','in_progress') and deleted_at is null;
create trigger tasks_updated_at before update on tasks
  for each row execute function app.set_updated_at();

create view v_overdue_tasks with (security_invoker = true) as
select * from tasks
where deleted_at is null and status in ('pending','in_progress') and due_at < now();

create table activities (
  id           uuid primary key default gen_random_uuid(),
  type         activity_type not null,
  summary      text not null,
  details      jsonb not null default '{}'::jsonb,
  occurred_at  timestamptz not null default now(),
  contact_id   uuid references contacts(id),
  lead_id      uuid references leads(id),
  buyer_id     uuid references buyers(id),
  seller_id    uuid references sellers(id),
  property_id  uuid references properties(id),
  deal_id      uuid references deals(id),
  created_by   uuid references profiles(id),
  created_at   timestamptz not null default now(),
  check (num_nonnulls(contact_id, lead_id, buyer_id, seller_id, property_id, deal_id) >= 1)
);
create index activities_lead_idx     on activities(lead_id, occurred_at desc)     where lead_id     is not null;
create index activities_buyer_idx    on activities(buyer_id, occurred_at desc)    where buyer_id    is not null;
create index activities_seller_idx   on activities(seller_id, occurred_at desc)   where seller_id   is not null;
create index activities_property_idx on activities(property_id, occurred_at desc) where property_id is not null;
create index activities_deal_idx     on activities(deal_id, occurred_at desc)     where deal_id     is not null;

-- ## END SECTION 0004_pipeline.sql

-- ######################################################################
-- ## SECTION 0005_platform.sql
-- ######################################################################

-- =====================================================================
-- EstateVanta CRM — 0005_platform.sql
-- settings, notifications, messaging outbox, market intelligence,
-- authorized import system, saved filters.
-- =====================================================================

create table settings (
  key         text primary key,               -- namespaced: 'property.reverify_days'
  value       jsonb not null,
  description text,
  updated_by  uuid references profiles(id),
  updated_at  timestamptz not null default now()
);
create trigger settings_updated_at before update on settings
  for each row execute function app.set_updated_at();

-- Re-verification reminders driven by settings (fallback 90 days only if the
-- setting row is missing; the seeded setting is the source of truth).
create view v_properties_due_verification with (security_invoker = true) as
select p.id, p.code, p.title, p.owner_id, p.assigned_to, p.last_verified_at
from properties p
where p.deleted_at is null
  and p.status in ('available','reserved','under_negotiation')
  and ( p.last_verified_at is null
        or p.last_verified_at < now() - make_interval(
             days => coalesce((select (value #>> '{}')::int from settings where key = 'property.reverify_days'), 90)) );

-- ---------------------------------------------------------------------
-- NOTIFICATIONS (in-app) and provider-agnostic MESSAGE OUTBOX
-- The outbox is the ONLY thing WhatsApp/email/SMS adapters read from.
-- Providers are swappable; only official/authorized APIs are permitted.
-- ---------------------------------------------------------------------
create table notifications (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references profiles(id) on delete cascade,
  type         text not null,                 -- 'lead.new', 'task.overdue', 'property.reverify'...
  title        text not null,
  body         text,
  entity_table text,
  entity_id    uuid,
  read_at      timestamptz,
  created_at   timestamptz not null default now()
);
create index notifications_user_unread_idx on notifications(user_id, created_at desc) where read_at is null;

create table message_outbox (
  id                  uuid primary key default gen_random_uuid(),
  channel             message_channel not null,
  provider            text,                            -- adapter name, set by the sender worker
  to_contact_id       uuid references contacts(id),
  to_address          text not null,                   -- phone/email at send time
  template_key        text,
  payload             jsonb not null default '{}'::jsonb,
  status              message_status not null default 'queued',
  attempts            smallint not null default 0,
  last_error          text,
  provider_message_id text,
  related_lead_id     uuid references leads(id),
  related_property_id uuid references properties(id),
  related_visit_id    uuid references appointments(id),
  scheduled_for       timestamptz,
  sent_at             timestamptz,
  created_by          uuid references profiles(id),
  created_at          timestamptz not null default now()
);
create index message_outbox_queue_idx on message_outbox(status, scheduled_for) where status in ('queued','failed');
create index message_outbox_contact_idx on message_outbox(to_contact_id);

-- ---------------------------------------------------------------------
-- AUTHORIZED IMPORT SYSTEM (CSV / Excel / JSON)
-- Flow: upload → map → validate → duplicate check → confirm → import.
-- No scraper exists anywhere in this schema. Every batch must state, in
-- writing, why EstateVanta is authorized to use the data.
-- ---------------------------------------------------------------------
create table import_batches (
  id                  uuid primary key default gen_random_uuid(),
  entity              import_entity not null,
  format              import_format not null,
  file_name           text not null,
  storage_path        text not null,                   -- private bucket
  source_name         text not null,                   -- who supplied the data
  source_url          text,
  source_date         date,
  authorization_note  text not null check (length(btrim(authorization_note)) >= 10),
  status              import_status not null default 'uploaded',
  field_mapping       jsonb,
  total_rows          integer not null default 0,
  valid_rows          integer not null default 0,
  error_rows          integer not null default 0,
  duplicate_rows      integer not null default 0,
  imported_rows       integer not null default 0,
  confirmed_by        uuid references profiles(id),
  confirmed_at        timestamptz,
  created_by          uuid references profiles(id),
  created_at          timestamptz not null default now(),
  completed_at        timestamptz,
  check (status not in ('confirmed','importing','completed') or (confirmed_by is not null and confirmed_at is not null))
);
create index import_batches_status_idx on import_batches(status, created_at desc);

alter table properties
  add constraint properties_import_batch_fk foreign key (import_batch_id) references import_batches(id);
create index properties_import_batch_idx on properties(import_batch_id) where import_batch_id is not null;

create table import_rows (
  id                 uuid primary key default gen_random_uuid(),
  batch_id           uuid not null references import_batches(id) on delete cascade,
  row_number         integer not null,
  raw                jsonb not null,                   -- untouched source row
  mapped             jsonb,                            -- after field mapping
  validation_errors  jsonb not null default '[]'::jsonb,
  duplicate_of_table text,
  duplicate_of_id    uuid,
  decision           import_row_decision not null default 'pending',
  created_entity_id  uuid,                             -- set when imported
  unique (batch_id, row_number)
);
create index import_rows_batch_decision_idx on import_rows(batch_id, decision);

-- ---------------------------------------------------------------------
-- MARKET INTELLIGENCE (structure only; starts EMPTY)
-- data_kind keeps asking prices, verified transactions, estimates and
-- third-party data permanently distinguishable.
-- ---------------------------------------------------------------------
create table market_data (
  id                   uuid primary key default gen_random_uuid(),
  locality_id          uuid references localities(id),
  city                 text not null,
  property_type_code   text references property_types(code),
  transaction_type     transaction_type,
  data_kind            market_data_kind not null,
  price                numeric(14,2) check (price is null or price >= 0),
  price_per_sqft       numeric(12,2) check (price_per_sqft is null or price_per_sqft >= 0),
  price_per_gaj        numeric(12,2) check (price_per_gaj  is null or price_per_gaj  >= 0),
  inventory_count      integer check (inventory_count is null or inventory_count >= 0),
  demand               demand_indicator,
  source_name          text not null,
  source_url           text,
  collected_on         date not null,
  verification_status  verification_status not null default 'unverified',
  import_batch_id      uuid references import_batches(id),
  notes                text,
  created_by           uuid references profiles(id),
  created_at           timestamptz not null default now(),
  updated_at           timestamptz not null default now(),
  deleted_at           timestamptz,
  deleted_by           uuid references profiles(id),
  check (price is not null or price_per_sqft is not null or price_per_gaj is not null or inventory_count is not null)
);
create index market_data_lookup_idx on market_data(city, locality_id, property_type_code, collected_on desc) where deleted_at is null;
create index market_data_kind_idx   on market_data(data_kind) where deleted_at is null;
create trigger market_data_updated_at before update on market_data
  for each row execute function app.set_updated_at();

-- ---------------------------------------------------------------------
-- SAVED FILTERS (per-user or shared)
-- ---------------------------------------------------------------------
create table saved_filters (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references profiles(id) on delete cascade,
  module      text not null,                     -- 'leads' | 'properties' | ...
  name        text not null,
  filters     jsonb not null,
  is_shared   boolean not null default false,
  created_at  timestamptz not null default now(),
  unique (user_id, module, name)
);

-- ## END SECTION 0005_platform.sql

-- ######################################################################
-- ## SECTION 0006_audit.sql
-- ######################################################################

-- =====================================================================
-- EstateVanta CRM — 0006_audit.sql
-- One generic trigger writes to audit_logs for every audited table.
-- Append-only: no UPDATE/DELETE grants; RLS limits reads to admin/manager.
-- =====================================================================

create table audit_logs (
  id             bigint generated always as identity primary key,
  occurred_at    timestamptz not null default now(),
  actor_id       uuid,                          -- auth.uid(); NULL = system / service role
  actor_context  text,                          -- 'api' | 'import' | 'job:<name>' (set via app.actor_context)
  action         text not null check (action in ('insert','update','delete','soft_delete','restore')),
  entity_table   text not null,
  entity_id      text,                          -- text so composite/text keys (settings.key) fit
  changed_fields text[],                        -- for updates: which columns changed
  old_values     jsonb,
  new_values     jsonb,
  request_id     text                           -- correlation id from the API layer (optional)
);
create index audit_logs_entity_idx  on audit_logs(entity_table, entity_id, occurred_at desc);
create index audit_logs_actor_idx   on audit_logs(actor_id, occurred_at desc);
create index audit_logs_time_brin   on audit_logs using brin (occurred_at);
create index audit_logs_fields_idx  on audit_logs using gin (changed_fields);
-- Growth note: if volume warrants, convert to monthly range partitions later.

create or replace function app.audit_row() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  pk_col   text := coalesce(tg_argv[0], 'id');
  old_j    jsonb;
  new_j    jsonb;
  changed  text[];
  act      text;
  noise    text[] := array['updated_at'];
  eid      text;
begin
  if tg_op = 'INSERT' then
    new_j := to_jsonb(new); act := 'insert'; eid := new_j ->> pk_col;
  elsif tg_op = 'DELETE' then
    old_j := to_jsonb(old); act := 'delete'; eid := old_j ->> pk_col;
  else
    old_j := to_jsonb(old); new_j := to_jsonb(new); eid := new_j ->> pk_col;
    select array_agg(k order by k) into changed
    from jsonb_object_keys(new_j) k
    where k <> all (noise) and (old_j -> k) is distinct from (new_j -> k);
    if changed is null then return null; end if;      -- nothing meaningful changed
    act := case
      when old_j ? 'deleted_at' and old_j->>'deleted_at' is null and new_j->>'deleted_at' is not null then 'soft_delete'
      when old_j ? 'deleted_at' and old_j->>'deleted_at' is not null and new_j->>'deleted_at' is null then 'restore'
      else 'update' end;
    -- store only the changed columns to keep the log small
    old_j := (select jsonb_object_agg(k, old_j -> k) from unnest(changed) k);
    new_j := (select jsonb_object_agg(k, new_j -> k) from unnest(changed) k);
  end if;

  insert into audit_logs(actor_id, actor_context, action, entity_table, entity_id,
                         changed_fields, old_values, new_values, request_id)
  values (auth.uid(),
          nullif(current_setting('app.actor_context', true), ''),
          act, tg_table_name,
          eid,
          changed, old_j, new_j,
          nullif(current_setting('app.request_id', true), ''));
  return null;
end $$;

-- Attach to every table whose changes matter. Second arg = primary-key column.
do $$
declare
  t record;
begin
  for t in
    select * from (values
      ('profiles','id'),('roles','id'),('role_permissions','role_id'),
      ('contacts','id'),('duplicate_candidates','id'),
      ('leads','id'),('buyers','id'),('sellers','id'),
      ('properties','id'),('property_owner_terms','property_id'),
      ('property_media','id'),('property_documents','id'),
      ('buyer_requirements','id'),
      ('matching_configs','id'),('matching_weights','config_id'),
      ('appointments','id'),('site_visits','appointment_id'),
      ('tasks','id'),
      ('deals','id'),('deal_documents','id'),('commissions','id'),('payments','id'),
      ('market_data','id'),('import_batches','id'),('settings','key')
    ) as v(tbl, pk)
  loop
    execute format(
      'create trigger audit_%1$s after insert or update or delete on %1$I
         for each row execute function app.audit_row(%2$L)', t.tbl, t.pk);
  end loop;
end $$;

-- Append-only enforcement (belt and braces on top of RLS)
revoke update, delete, truncate on audit_logs from public, anon, authenticated;

-- ## END SECTION 0006_audit.sql

-- ######################################################################
-- ## SECTION 0007_rls.sql
-- ######################################################################

-- =====================================================================
-- EstateVanta CRM — 0007_rls.sql
-- RLS on EVERY table. Default = deny. Access is granted by permission
-- codes (roles → role_permissions → permissions), never by role names
-- hard-coded in policies, so permissions stay configurable.
--
-- Permission naming:  <module>.read | read_all | write | delete
--   read      = see rows assigned to me (or created by me)
--   read_all  = see every row in the module
-- Service-role connections (server jobs) bypass RLS by design and are used
-- only in server-only code; never shipped to the browser.
-- =====================================================================

-- ---------------------------------------------------------------------
-- Generators
-- ---------------------------------------------------------------------
-- Rows scoped to an assignee (agent sees own; manager sees all via read_all)
create or replace function app.apply_scoped_policies(tbl text, module text, assign_col text)
returns void language plpgsql as $$
begin
  execute format('alter table %I enable row level security', tbl);
  execute format($p$create policy %1$s_select on %1$I for select to authenticated using (
      (deleted_at is null or app.is_admin())
      and ( app.can(%2$L) or (app.can(%3$L) and (%4$I = auth.uid() or created_by = auth.uid())) ) )$p$,
      tbl, module||'.read_all', module||'.read', assign_col);
  execute format($p$create policy %1$s_insert on %1$I for insert to authenticated
      with check (app.can(%2$L))$p$, tbl, module||'.write');
  execute format($p$create policy %1$s_update on %1$I for update to authenticated
      using ( app.can(%2$L) and ( app.can(%3$L) or %4$I = auth.uid() or created_by = auth.uid() ) )
      with check ( app.can(%2$L) )$p$, tbl, module||'.write', module||'.read_all', assign_col);
  execute format($p$create policy %1$s_delete on %1$I for delete to authenticated
      using (app.is_admin())$p$, tbl);
end $$;

-- Unscoped module tables (permission only)
create or replace function app.apply_global_policies(tbl text, module text)
returns void language plpgsql as $$
begin
  execute format('alter table %I enable row level security', tbl);
  execute format($p$create policy %1$s_select on %1$I for select to authenticated
      using (app.can(%2$L))$p$, tbl, module||'.read');
  execute format($p$create policy %1$s_insert on %1$I for insert to authenticated
      with check (app.can(%2$L))$p$, tbl, module||'.write');
  execute format($p$create policy %1$s_update on %1$I for update to authenticated
      using (app.can(%2$L)) with check (app.can(%2$L))$p$, tbl, module||'.write');
  execute format($p$create policy %1$s_delete on %1$I for delete to authenticated
      using (app.is_admin())$p$, tbl);
end $$;

-- Child tables: visible/writable only if the parent row is visible to the caller
-- (the EXISTS subquery is itself filtered by the parent's RLS).
create or replace function app.apply_child_policies(tbl text, module text, parent text, fk text, parent_pk text default 'id')
returns void language plpgsql as $$
begin
  execute format('alter table %I enable row level security', tbl);
  execute format($p$create policy %1$s_select on %1$I for select to authenticated
      using ( (app.can(%2$L) or app.can(%3$L)) and exists (select 1 from %4$I par where par.%5$I = %1$I.%6$I) )$p$,
      tbl, module||'.read', module||'.read_all', parent, parent_pk, fk);
  execute format($p$create policy %1$s_insert on %1$I for insert to authenticated
      with check ( app.can(%2$L) and exists (select 1 from %3$I par where par.%4$I = %1$I.%5$I) )$p$,
      tbl, module||'.write', parent, parent_pk, fk);
  execute format($p$create policy %1$s_update on %1$I for update to authenticated
      using ( app.can(%2$L) and exists (select 1 from %3$I par where par.%4$I = %1$I.%5$I) )
      with check ( app.can(%2$L) )$p$, tbl, module||'.write', parent, parent_pk, fk);
  execute format($p$create policy %1$s_delete on %1$I for delete to authenticated
      using ( app.can(%2$L) and exists (select 1 from %3$I par where par.%4$I = %1$I.%5$I) )$p$,
      tbl, module||'.write', parent, parent_pk, fk);
end $$;
-- ---------------------------------------------------------------------
-- Soft-delete guard: setting deleted_at requires <module>.delete
-- ---------------------------------------------------------------------
create or replace function app.guard_soft_delete() returns trigger
language plpgsql as $$
begin
  if auth.uid() is null then return new; end if;           -- server/system context
  if old.deleted_at is null and new.deleted_at is not null
     and not app.can(tg_argv[0] || '.delete') then
    raise exception 'permission denied: % required', tg_argv[0] || '.delete' using errcode = '42501';
  end if;
  if new.deleted_at is not null and new.deleted_by is null then
    new.deleted_by := auth.uid();
  end if;
  return new;
end $$;

-- ---------------------------------------------------------------------
-- Apply: scoped modules
-- ---------------------------------------------------------------------
select app.apply_scoped_policies('leads',        'leads',        'assigned_to');
select app.apply_scoped_policies('buyers',       'buyers',       'assigned_to');
select app.apply_scoped_policies('sellers',      'sellers',      'assigned_to');
select app.apply_scoped_policies('properties',   'properties',   'assigned_to');
select app.apply_scoped_policies('appointments', 'appointments', 'assigned_to');
select app.apply_scoped_policies('tasks',        'tasks',        'assigned_to');
select app.apply_scoped_policies('deals',        'deals',        'assigned_to');

do $$
declare r record;
begin
  for r in select * from (values
    ('leads','leads'),('buyers','buyers'),('sellers','sellers'),('properties','properties'),
    ('appointments','appointments'),('tasks','tasks'),('deals','deals'),
    ('buyer_requirements','buyers'),('contacts','contacts'),('market_data','market')
  ) v(tbl,module)
  loop
    execute format('create trigger guard_soft_delete_%1$s before update of deleted_at on %1$I
                    for each row execute function app.guard_soft_delete(%2$L)', r.tbl, r.module);
  end loop;
end $$;

-- ---------------------------------------------------------------------
-- Apply: child tables (inherit visibility from parent)
-- ---------------------------------------------------------------------
select app.apply_child_policies('buyer_requirements',       'buyers',       'buyers',             'buyer_id');
select app.apply_child_policies('requirement_property_types','buyers',      'buyer_requirements', 'requirement_id');
select app.apply_child_policies('requirement_localities',   'buyers',       'buyer_requirements', 'requirement_id');
select app.apply_child_policies('requirement_preferences',  'buyers',       'buyer_requirements', 'requirement_id');
select app.apply_child_policies('property_matches',         'matching',     'buyer_requirements', 'requirement_id');
select app.apply_child_policies('property_owner_terms',     'properties',   'properties',         'property_id');
select app.apply_child_policies('property_amenities',       'properties',   'properties',         'property_id');
select app.apply_child_policies('property_media',           'properties',   'properties',         'property_id');
select app.apply_child_policies('property_documents',       'properties',   'properties',         'property_id');
select app.apply_child_policies('site_visits',              'appointments', 'appointments',       'appointment_id');
select app.apply_child_policies('deal_documents',           'deals',        'deals',              'deal_id');
select app.apply_child_policies('commissions',              'finance',      'deals',              'deal_id');
select app.apply_child_policies('payments',                 'finance',      'deals',              'deal_id');

-- ---------------------------------------------------------------------
-- Apply: global (permission-only) tables
-- ---------------------------------------------------------------------
select app.apply_global_policies('market_data',          'market');
select app.apply_global_policies('matching_configs',     'matching');
select app.apply_global_policies('matching_weights',     'matching');
select app.apply_global_policies('message_outbox',       'messaging');
select app.apply_global_policies('import_batches',       'imports');
select app.apply_global_policies('duplicate_candidates', 'contacts');

-- import_rows follow their batch
select app.apply_child_policies('import_rows', 'imports', 'import_batches', 'batch_id');

-- ---------------------------------------------------------------------
-- Special cases
-- ---------------------------------------------------------------------
-- contacts: visible when the person is attached to a lead/buyer/seller the caller can see
alter table contacts enable row level security;
create policy contacts_select on contacts for select to authenticated using (
  (deleted_at is null or app.is_admin()) and (
    app.can('contacts.read_all') or created_by = auth.uid()
    or exists (select 1 from leads   l where l.contact_id = contacts.id)
    or exists (select 1 from buyers  b where b.contact_id = contacts.id)
    or exists (select 1 from sellers s where s.contact_id = contacts.id) ) );
create policy contacts_insert on contacts for insert to authenticated with check (app.can('contacts.write'));
create policy contacts_update on contacts for update to authenticated
  using (app.can('contacts.write') and (app.can('contacts.read_all') or created_by = auth.uid()
     or exists (select 1 from leads l where l.contact_id = contacts.id)
     or exists (select 1 from buyers b where b.contact_id = contacts.id)
     or exists (select 1 from sellers s where s.contact_id = contacts.id)))
  with check (app.can('contacts.write'));
create policy contacts_delete on contacts for delete to authenticated using (app.is_admin());

-- activities: timeline visible if any parent entity is visible
alter table activities enable row level security;
create policy activities_select on activities for select to authenticated using (
  app.can('activities.read_all') or created_by = auth.uid()
  or (lead_id     is not null and exists (select 1 from leads      x where x.id = activities.lead_id))
  or (buyer_id    is not null and exists (select 1 from buyers     x where x.id = activities.buyer_id))
  or (seller_id   is not null and exists (select 1 from sellers    x where x.id = activities.seller_id))
  or (property_id is not null and exists (select 1 from properties x where x.id = activities.property_id))
  or (deal_id     is not null and exists (select 1 from deals      x where x.id = activities.deal_id)) );
create policy activities_insert on activities for insert to authenticated
  with check (app.can('activities.write') and created_by = auth.uid());
-- activities are a history: no update/delete policy => immutable for users

-- audit log: read-only for holders of audit.read; no write policies at all
alter table audit_logs enable row level security;
create policy audit_logs_select on audit_logs for select to authenticated using (app.can('audit.read'));

-- profiles: everyone active can see colleagues (names for assignment dropdowns);
-- editing others / changing role or activation needs users.manage
alter table profiles enable row level security;
create policy profiles_select on profiles for select to authenticated
  using ( id = auth.uid() or app.current_role_code() is not null );
create policy profiles_update on profiles for update to authenticated
  using ( id = auth.uid() or app.can('users.manage') )
  with check ( id = auth.uid() or app.can('users.manage') );

create or replace function app.guard_profile_privileges() returns trigger
language plpgsql as $$
begin
  if auth.uid() is null then return new; end if;
  if (new.role_id is distinct from old.role_id or new.is_active is distinct from old.is_active)
     and not app.can('users.manage') then
    raise exception 'permission denied: users.manage required to change role or activation' using errcode='42501';
  end if;
  return new;
end $$;
create trigger guard_profile_privileges before update on profiles
  for each row execute function app.guard_profile_privileges();

-- roles / permissions: readable by active users, changed only with users.manage
alter table roles enable row level security;
alter table permissions enable row level security;
alter table role_permissions enable row level security;
create policy roles_select on roles for select to authenticated using (app.current_role_code() is not null);
create policy permissions_select on permissions for select to authenticated using (app.current_role_code() is not null);
create policy role_permissions_select on role_permissions for select to authenticated using (app.current_role_code() is not null);
create policy roles_write on roles for all to authenticated using (app.can('users.manage')) with check (app.can('users.manage'));
create policy role_permissions_write on role_permissions for all to authenticated using (app.can('users.manage')) with check (app.can('users.manage'));
-- permissions rows are defined by migrations only (no user write policy)

-- reference tables + settings: read by any active user, write with settings.manage
do $$
declare t text;
begin
  foreach t in array array['lead_statuses','lead_sources','property_types','area_units','amenities','localities'] loop
    execute format('alter table %I enable row level security', t);
    execute format('create policy %1$s_select on %1$I for select to authenticated using (app.current_role_code() is not null)', t);
    execute format('create policy %1$s_write on %1$I for all to authenticated using (app.can(%2$L)) with check (app.can(%2$L))', t, 'settings.manage');
  end loop;
end $$;

alter table settings enable row level security;
create policy settings_select on settings for select to authenticated using (app.current_role_code() is not null);
create policy settings_write  on settings for all to authenticated using (app.can('settings.manage')) with check (app.can('settings.manage'));

-- personal tables
alter table notifications enable row level security;
create policy notifications_own on notifications for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

alter table saved_filters enable row level security;
create policy saved_filters_select on saved_filters for select to authenticated
  using (user_id = auth.uid() or is_shared);
create policy saved_filters_write on saved_filters for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ---------------------------------------------------------------------
-- STORAGE: private buckets; object access is derived from table visibility.
-- Path convention: <bucket>/<entity_id>/<uuid>.<ext>
-- The public site NEVER reads these buckets directly; it receives short-lived
-- signed URLs from a server route for properties that are published.
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public) values
  ('property-media','property-media', false),
  ('property-documents','property-documents', false),
  ('deal-documents','deal-documents', false),
  ('imports','imports', false)
on conflict (id) do nothing;

create policy storage_property_media_read on storage.objects for select to authenticated
  using (bucket_id = 'property-media'
         and exists (select 1 from property_media m where m.storage_path = storage.objects.name));
create policy storage_property_media_write on storage.objects for insert to authenticated
  with check (bucket_id = 'property-media' and app.can('properties.write'));
create policy storage_property_documents_read on storage.objects for select to authenticated
  using (bucket_id = 'property-documents'
         and exists (select 1 from property_documents d where d.storage_path = storage.objects.name));
create policy storage_property_documents_write on storage.objects for insert to authenticated
  with check (bucket_id = 'property-documents' and app.can('properties.write'));
create policy storage_deal_documents_read on storage.objects for select to authenticated
  using (bucket_id = 'deal-documents'
         and exists (select 1 from deal_documents d where d.storage_path = storage.objects.name));
create policy storage_deal_documents_write on storage.objects for insert to authenticated
  with check (bucket_id = 'deal-documents' and app.can('deals.write'));
create policy storage_imports_all on storage.objects for all to authenticated
  using (bucket_id = 'imports' and app.can('imports.write'))
  with check (bucket_id = 'imports' and app.can('imports.write'));

-- ---------------------------------------------------------------------
-- SAFETY NET: no table in public may exist without RLS, and the anonymous
-- role gets no table access at all (the public website talks to the CRM
-- only through server-side API routes, never straight to the database).
-- ---------------------------------------------------------------------
revoke all on all tables in schema public from anon;
revoke all on all sequences in schema public from anon;

do $$
declare missing text;
begin
  select string_agg(c.relname, ', ') into missing
  from pg_class c join pg_namespace n on n.oid = c.relnamespace
  where n.nspname = 'public' and c.relkind = 'r' and not c.relrowsecurity;
  if missing is not null then
    raise exception 'RLS is not enabled on: %', missing;
  end if;
end $$;

-- ## END SECTION 0007_rls.sql

-- ######################################################################
-- ## SECTION 0008_system_config.sql
-- ######################################################################

-- =====================================================================
-- EstateVanta CRM — 0008_system_config.sql
-- MINIMUM SYSTEM CONFIGURATION ONLY. No leads, buyers, sellers, properties,
-- deals, payments, market data, users or analytics are inserted here.
-- Everything below is editable later from Settings (is_system rows can be
-- deactivated but not deleted).
-- =====================================================================

-- ---------------------------------------------------------------------
-- Roles
-- ---------------------------------------------------------------------
insert into roles (code, label, is_system) values
  ('admin',   'Admin',   true),
  ('manager', 'Manager', true),
  ('agent',   'Agent',   true),
  ('viewer',  'Viewer',  true);

-- ---------------------------------------------------------------------
-- Permissions  (<module>.<action>)
--   read      = rows assigned to / created by the caller
--   read_all  = every row in the module
-- ---------------------------------------------------------------------
insert into permissions (code, description)
select m || '.' || a, initcap(replace(a,'_',' ')) || ' — ' || m
from unnest(array['leads','buyers','sellers','contacts','properties','appointments',
                  'tasks','deals','finance','matching','market','imports','messaging'])  as m,
     unnest(array['read','read_all','write','delete']) as a;

insert into permissions (code, description) values
  ('activities.read_all', 'Read every activity/timeline entry'),
  ('activities.write',    'Log activities'),
  ('analytics.read',      'View analytics'),
  ('audit.read',          'View the audit log'),
  ('users.manage',        'Manage users, roles and role permissions'),
  ('settings.manage',     'Manage settings and reference lists');

-- ---------------------------------------------------------------------
-- Default role → permission grants (configurable later in Settings)
-- ---------------------------------------------------------------------
-- Admin: everything
insert into role_permissions (role_id, permission_id)
select r.id, p.id from roles r cross join permissions p where r.code = 'admin';

-- Manager: CRM, properties, appointments, tasks, deals, finance, matching,
-- market, imports, messaging, analytics (no users/settings/audit)
insert into role_permissions (role_id, permission_id)
select r.id, p.id from roles r join permissions p
  on p.code ~ '^(leads|buyers|sellers|contacts|properties|appointments|tasks|deals|finance|matching|market|imports|messaging)\.'
  or p.code in ('activities.read_all','activities.write','analytics.read')
where r.code = 'manager';

-- Agent: assigned records only (no *_all), no finance/imports/settings
insert into role_permissions (role_id, permission_id)
select r.id, p.id from roles r join permissions p on p.code in (
  'leads.read','leads.write','buyers.read','buyers.write','sellers.read','sellers.write',
  'contacts.read','contacts.write','properties.read','properties.write',
  'appointments.read','appointments.write','tasks.read','tasks.write',
  'deals.read','matching.read','activities.write')
where r.code = 'agent';

-- Viewer: read-only across operational modules (no finance, imports, messaging, audit)
insert into role_permissions (role_id, permission_id)
select r.id, p.id from roles r join permissions p on p.code in (
  'leads.read_all','buyers.read_all','sellers.read_all','contacts.read_all',
  'properties.read_all','appointments.read_all','tasks.read_all','deals.read_all',
  'matching.read_all','market.read_all','market.read','activities.read_all','analytics.read')
where r.code = 'viewer';

-- ---------------------------------------------------------------------
-- Lead statuses (from the specification)
-- ---------------------------------------------------------------------
insert into lead_statuses (code, label, sort_order, is_terminal, is_system) values
  ('new',                    'New',                     10, false, true),
  ('contacted',              'Contacted',               20, false, true),
  ('qualified',              'Qualified',               30, false, true),
  ('requirement_captured',   'Requirement Captured',    40, false, true),
  ('property_matched',       'Property Matched',        50, false, true),
  ('site_visit_scheduled',   'Site Visit Scheduled',    60, false, true),
  ('site_visit_completed',   'Site Visit Completed',    70, false, true),
  ('negotiation',            'Negotiation',             80, false, true),
  ('deal_won',               'Deal Won',                90, true,  true),
  ('deal_lost',              'Deal Lost',              100, true,  true),
  ('follow_up',              'Follow-up',               85, false, true);

-- Lead sources
insert into lead_sources (code, label, sort_order, is_system) values
  ('website','Website',10,true), ('phone_call','Phone Call',20,true), ('walk_in','Walk-in',30,true),
  ('owner_direct','Owner Direct',40,true), ('whatsapp','WhatsApp',50,true), ('instagram','Instagram',60,true),
  ('facebook','Facebook',70,true), ('google','Google',80,true), ('referral','Referral',90,true),
  ('99acres','99acres',100,true), ('magicbricks','MagicBricks',110,true), ('housing_com','Housing.com',120,true),
  ('other','Other',999,true);

-- Property types
insert into property_types (code, label, sort_order, is_system) values
  ('independent_house','Independent House',10,true), ('villa','Villa',20,true),
  ('flat_apartment','Flat / Apartment',30,true), ('plot','Plot',40,true),
  ('commercial_shop','Commercial Shop',50,true), ('office','Office',60,true),
  ('showroom','Showroom',70,true), ('warehouse','Warehouse',80,true),
  ('industrial_property','Industrial Property',90,true), ('agricultural_land','Agricultural Land',100,true),
  ('farm_house','Farm House',110,true), ('other','Other',999,true);

-- Area units. Universal conversions only. Regional units (marla, kanal, bigha)
-- are created WITHOUT a factor: the owner must enter the correct local value
-- in Settings before area-based matching can use them.
insert into area_units (code, label, sq_ft_factor, is_system) values
  ('sq_ft','Square Feet',1,true),
  ('sq_yd','Square Yard (Gaj)',9,true),
  ('sq_m','Square Metre',10.763910,true),
  ('acre','Acre',43560,true),
  ('marla','Marla',null,true),
  ('kanal','Kanal',null,true),
  ('bigha','Bigha',null,true);

-- ---------------------------------------------------------------------
-- Default matching configuration (editable; weights total 100)
-- ---------------------------------------------------------------------
with cfg as (
  insert into matching_configs (name, version, is_active, notes)
  values ('Default rule-based matching', 1, false,
          'Internal rule-based score. Not an objective valuation. Edit by creating a new version.')
  returning id
)
insert into matching_weights (config_id, criterion, weight)
select cfg.id, w.criterion::match_criterion, w.weight
from cfg, (values ('budget',30),('location',25),('property_type',15),
                  ('area',10),('bhk',10),('preferences',10)) as w(criterion, weight);

update matching_configs set is_active = true where name = 'Default rule-based matching' and version = 1;

-- ---------------------------------------------------------------------
-- Settings (defaults; owner can change)
-- ---------------------------------------------------------------------
insert into settings (key, value, description) values
  ('app.timezone',               '"Asia/Kolkata"'::jsonb, 'Display timezone'),
  ('app.currency',               '"INR"'::jsonb,          'Currency code'),
  ('property.reverify_days',     '90'::jsonb,             'Days after which an active listing needs re-verification (default; change as needed)'),
  ('duplicates.match_fields',    '["phone","whatsapp","email"]'::jsonb, 'Fields checked for duplicate people'),
  ('leads.hot_priorities',       '["high","urgent"]'::jsonb, 'Priorities counted as Hot Leads on the dashboard (to be confirmed by owner)'),
  ('company.name',               '"EstateVanta"'::jsonb,  'Business name'),
  ('company.tagline',            '"Find Your Place. Build Your Future."'::jsonb, 'Tagline');

-- ## END SECTION 0008_system_config.sql

-- ######################################################################
-- ## SECTION 0009_confirmed_decisions.sql
-- ######################################################################

-- =====================================================================
-- EstateVanta CRM — 0009_confirmed_decisions.sql
-- Applies the owner-confirmed Phase 1 decisions ON TOP of 0001–0008
-- (originals are left untouched) and adds the API-role grants that the
-- earlier files did not include.  NO business data is inserted.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. GRANTS
-- RLS decides row access, but logged-in users first need schema/table/
-- sequence privileges. Without USAGE on schema "app", every RLS policy
-- and every code default (LD-000001…) would fail with "permission denied".
-- anon receives nothing (it was revoked in 0007 and is not re-granted).
-- ---------------------------------------------------------------------
grant usage on schema app to authenticated, service_role;
grant execute on all functions in schema app to authenticated, service_role;
grant usage, select on all sequences in schema app to authenticated, service_role;

grant select, insert, update, delete on all tables in schema public to authenticated;
grant all on all tables in schema public to service_role;
grant usage, select on all sequences in schema public to authenticated, service_role;

-- audit_logs stays append-only for everyone except the audit trigger
revoke insert, update, delete, truncate on audit_logs from authenticated;

-- the one-time admin bootstrap is callable only from the SQL editor
revoke execute on function app.bootstrap_first_admin(uuid) from authenticated, service_role;

-- ---------------------------------------------------------------------
-- 2. DECISION: viewers must not see financial fields
--    a) viewers lose access to deal rows (final price, token, commission)
--    b) "minimum price" (negotiation floor) moves from properties into
--       property_owner_terms, whose visibility is restricted (see 4).
--       Table is empty at this point, so no data moves.
-- ---------------------------------------------------------------------
delete from role_permissions
where role_id       = (select id from roles       where code = 'viewer')
  and permission_id = (select id from permissions where code = 'deals.read_all');

alter table property_owner_terms
  add column min_price numeric(14,2) check (min_price is null or min_price >= 0);
alter table properties drop column min_price;   -- also drops its check constraints

-- ---------------------------------------------------------------------
-- 3. DECISION: agents can VIEW all active inventory; edit/delete stays
--    assignment- or permission-based.
--    properties.read_active : view available / reserved / under-negotiation
--    properties.write_all   : edit/delete any property
-- ---------------------------------------------------------------------
insert into permissions (code, description) values
  ('properties.read_active', 'View all active property inventory (available, reserved, under negotiation)'),
  ('properties.write_all',   'Edit or delete any property, not only assigned/own ones');

insert into role_permissions (role_id, permission_id)
select r.id, p.id from roles r join permissions p on p.code in ('properties.read_active','properties.write_all')
where r.code in ('admin','manager');

insert into role_permissions (role_id, permission_id)
select r.id, p.id from roles r join permissions p on p.code = 'properties.read_active'
where r.code = 'agent';

-- Can the caller edit this property?  (SECURITY DEFINER so RLS on the
-- lookup itself cannot hide the row from the check.)
create or replace function app.can_edit_property(pid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select app.can('properties.write_all')
      or ( app.can('properties.write')
           and exists (select 1 from properties p
                       where p.id = pid and p.deleted_at is null
                         and (p.assigned_to = auth.uid() or p.created_by = auth.uid())) )
$$;
grant execute on function app.can_edit_property(uuid) to authenticated, service_role;

drop policy properties_select on properties;
drop policy properties_update on properties;

create policy properties_select on properties for select to authenticated using (
  (deleted_at is null or app.is_admin()) and (
       app.can('properties.read_all')
    or (app.can('properties.read_active') and status in ('available','reserved','under_negotiation'))
    or (app.can('properties.read') and (assigned_to = auth.uid() or created_by = auth.uid())) ) );

create policy properties_update on properties for update to authenticated
  using ( app.can('properties.write_all')
          or (app.can('properties.write') and (assigned_to = auth.uid() or created_by = auth.uid())) )
  with check ( app.can('properties.write') );

-- ---------------------------------------------------------------------
-- 4. Property child tables
--    media + amenities : visible wherever the property is visible (policy from
--                        0007 unchanged); WRITES now require edit rights on the property
--    documents         : visible only to editors of the property, or holders of properties.read_all
--    owner terms       : (brokerage, minimum price, ownership-doc status) visible only to
--                        editors of the property or holders of finance.read_all
-- ---------------------------------------------------------------------
do $$
declare t text;
begin
  foreach t in array array['property_media','property_amenities','property_documents','property_owner_terms'] loop
    execute format('drop policy if exists %I on %I', t||'_insert', t);
    execute format('drop policy if exists %I on %I', t||'_update', t);
    execute format('drop policy if exists %I on %I', t||'_delete', t);
    execute format('create policy %I on %I for insert to authenticated with check (app.can_edit_property(property_id))', t||'_insert', t);
    execute format('create policy %I on %I for update to authenticated using (app.can_edit_property(property_id)) with check (app.can_edit_property(property_id))', t||'_update', t);
    execute format('create policy %I on %I for delete to authenticated using (app.can_edit_property(property_id))', t||'_delete', t);
  end loop;
end $$;

drop policy property_documents_select on property_documents;
create policy property_documents_select on property_documents for select to authenticated using (
  (app.can('properties.read_all') or app.can_edit_property(property_id))
  and exists (select 1 from properties par where par.id = property_documents.property_id) );

drop policy property_owner_terms_select on property_owner_terms;
create policy property_owner_terms_select on property_owner_terms for select to authenticated using (
  (app.can('finance.read_all') or app.can_edit_property(property_id))
  and exists (select 1 from properties par where par.id = property_owner_terms.property_id) );

-- ---------------------------------------------------------------------
-- 5. DECISION: settings and units
-- ---------------------------------------------------------------------
update settings set value = '30'::jsonb,
       description = 'Days after which an active listing needs re-verification (configurable in Settings)'
 where key = 'property.reverify_days';

update settings set description = 'Priorities counted as Hot Leads on the dashboard (configurable in Settings)'
 where key = 'leads.hot_priorities';

update area_units set sq_ft_factor = 272.25  where code = 'marla';
update area_units set sq_ft_factor = 5445    where code = 'kanal';
-- bigha intentionally left NULL: the local definition varies; set it in Settings.

-- fallback in the reminder view now matches the new default
create or replace view v_properties_due_verification with (security_invoker = true) as
select p.id, p.code, p.title, p.owner_id, p.assigned_to, p.last_verified_at
from properties p
where p.deleted_at is null
  and p.status in ('available','reserved','under_negotiation')
  and ( p.last_verified_at is null
        or p.last_verified_at < now() - make_interval(
             days => coalesce((select (value #>> '{}')::int from settings where key = 'property.reverify_days'), 30)) );

-- ## END SECTION 0009_confirmed_decisions.sql
