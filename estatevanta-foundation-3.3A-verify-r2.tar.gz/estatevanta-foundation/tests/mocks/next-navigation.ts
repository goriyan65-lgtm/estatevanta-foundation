// Stand-in for next/navigation. redirect() throws like the real one so code after it never runs.
export class RedirectSignal extends Error {
  constructor(public readonly url: string) { super(`NEXT_REDIRECT ${url}`); this.name = "RedirectSignal"; }
}
export const redirect = (url: string): never => { throw new RedirectSignal(url); };
export const notFound = (): never => { throw new Error("NOT_FOUND"); };
export const usePathname = () => "/dashboard";
export const useRouter = () => ({ refresh() {}, push() {}, replace() {} });
