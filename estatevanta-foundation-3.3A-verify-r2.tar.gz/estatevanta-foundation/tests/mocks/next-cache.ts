export const revalidated: string[] = [];
export function revalidatePath(path: string, type?: string) { revalidated.push(`${path}|${type ?? ""}`); }
