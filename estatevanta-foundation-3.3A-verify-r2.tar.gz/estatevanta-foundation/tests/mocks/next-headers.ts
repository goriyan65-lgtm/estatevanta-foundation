// Stand-in for next/headers: an in-memory cookie jar that records every write.
export type Written = { name: string; value: string; options: Record<string, unknown> | undefined };
export const jar = new Map<string, string>();
export const writes: Written[] = [];
export const deletes: string[] = [];
export const failures = { set: false };

export function resetCookies() { jar.clear(); writes.length = 0; deletes.length = 0; failures.set = false; }

export async function cookies() {
  return {
    getAll: () => [...jar].map(([name, value]) => ({ name, value })),
    set: (name: string, value: string, options?: Record<string, unknown>) => {
      if (failures.set) throw new Error("Cookies can only be modified in a Server Action or Route Handler");
      jar.set(name, value); writes.push({ name, value, options });
    },
    delete: (name: string) => { jar.delete(name); deletes.push(name); },
  };
}
