// Stand-in for @supabase/ssr. NO network, no real Auth, no real PostgREST: every answer below is supplied by the
// test. This proves how OUR code reacts to answers of a given shape; it does not prove what real Supabase returns.
type CookieAdapter = { getAll(): unknown; setAll(list: { name: string; value: string; options?: Record<string, unknown> }[], headers?: Record<string, string>): void };
export type AuthErr = { name: string; status?: number; code?: string; message: string };

export const calls: string[] = [];             // order of calls, e.g. "auth.getUser", "rpc:my_access"
export const created: { url: string; key: string; cookies: CookieAdapter }[] = [];
export const rpcArgs: unknown[][] = [];

export const behavior: {
  getUser: () => Promise<{ data: { user: { id: string } | null }; error: AuthErr | null }>;
  getClaims: () => Promise<unknown>;
  signIn: (c: { email: string; password: string }) => Promise<{ data: { session: unknown | null; user: unknown | null }; error: AuthErr | null }>;
  signOut: () => Promise<{ error: AuthErr | null }>;
  rpc: (fn: string) => Promise<{ data: unknown; error: { code: string; message: string; details: string; hint: string } | null }>;
} = {
  getUser: async () => ({ data: { user: null }, error: { name: "AuthSessionMissingError", status: 400, message: "Auth session missing!" } }),
  getClaims: async () => ({ data: null, error: null }),
  signIn: async () => ({ data: { session: null, user: null }, error: { name: "AuthApiError", status: 400, code: "invalid_credentials", message: "Invalid login credentials" } }),
  signOut: async () => ({ error: null }),
  rpc: async () => ({ data: null, error: null }),
};

export function resetSsr() {
  calls.length = 0; created.length = 0; rpcArgs.length = 0;
  behavior.getUser = async () => ({ data: { user: null }, error: { name: "AuthSessionMissingError", status: 400, message: "Auth session missing!" } });
  behavior.getClaims = async () => ({ data: null, error: null });
  behavior.signIn = async () => ({ data: { session: null, user: null }, error: { name: "AuthApiError", status: 400, code: "invalid_credentials", message: "Invalid login credentials" } });
  behavior.signOut = async () => ({ error: null });
  behavior.rpc = async () => ({ data: null, error: null });
}

export function createServerClient(url: string, key: string, opts: { cookies: CookieAdapter }) {
  created.push({ url, key, cookies: opts.cookies });
  // NOTE: there is deliberately no auth.getSession here. Any code that used it would throw.
  return {
    auth: {
      getUser: () => { calls.push("auth.getUser"); return behavior.getUser(); },
      getClaims: () => { calls.push("auth.getClaims"); return behavior.getClaims(); },
      signInWithPassword: (c: { email: string; password: string }) => { calls.push("auth.signInWithPassword"); return behavior.signIn(c); },
      signOut: () => { calls.push("auth.signOut"); return behavior.signOut(); },
    },
    rpc: (fn: string, ...rest: unknown[]) => { calls.push(`rpc:${fn}`); rpcArgs.push([fn, ...rest]); return behavior.rpc(fn); },
  };
}
