// Stand-in for next/link.
export default function Link({ href, children, ...p }: { href: string; children?: unknown } & Record<string, unknown>) {
  return <a href={href} {...(p as object)}>{children as never}</a>;
}
