// Stand-in for next/server, enough for the session-refresh proxy.
export type NextRequest = {
  cookies: { getAll(): { name: string; value: string }[]; set(name: string, value: string): void };
  nextUrl: { pathname: string };
};
export class NextResponse {
  static created: NextResponse[] = [];
  cookieWrites: { name: string; value: string; options: Record<string, unknown> | undefined }[] = [];
  headers = new Headers();
  cookies = { set: (name: string, value: string, options?: Record<string, unknown>) => { this.cookieWrites.push({ name, value, options }); } };
  constructor(public passedRequest?: NextRequest) { NextResponse.created.push(this); }
  static next(init?: { request?: NextRequest }) { return new NextResponse(init?.request); }
}
