// Stand-in for the "server-only" package (it throws when imported from client code; tests run in plain Node).
export {};
