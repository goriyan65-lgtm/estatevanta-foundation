// Phase 3.3A — authentication foundation tests (node:test; run with `node tests/run.mjs`).
//
// WHAT THESE PROVE: how OUR code reacts to answers of a given shape (signed out, inactive, error, ready ...), that
// protected pages fail closed, that secrets stay out of the browser-facing paths, and that sign-in / sign-out behave.
// WHAT THEY DO NOT PROVE: anything about real Supabase. @supabase/ssr, next/* are stand-ins (tests/mocks); no network
// call is made. The shape of real Auth errors and of real PostgREST responses is an ASSUMPTION taken from
// documentation. A genuine sign-in test needs a real user and is NOT part of this phase.
//
// No user, profile, session or count below is real. They are fixtures that live only in this file.
import test, { beforeEach } from "node:test";
import assert from "node:assert/strict";
import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";
import { renderToStaticMarkup } from "react-dom/server";

import { canAccess } from "@/lib/access";
import { checkCredentials, MESSAGES, signInMessage, SIGN_IN_INITIAL } from "@/lib/auth/credentials";
import { parseMyAccess, resolveAccessState, safeRef, type AccessClient } from "@/lib/auth/resolve";
import { hardenCookieOptions, isSessionCookieName } from "@/lib/supabase/cookies";
import { getSupabasePublicEnv, looksLikeSecretKey, matchesPublicKeyAllowList, parseSupabasePublicEnv } from "@/lib/supabase/env";
import { updateSession } from "@/lib/supabase/proxy";
import { CARD_KEYS } from "@/lib/dashboard/cards";

import { getAccessState } from "@/server/auth/session";
import { signIn, signOut } from "@/server/auth/actions";
import AppLayout from "@/app/(app)/layout";
import DashboardPage from "@/app/(app)/dashboard/page";
import { getDashboard } from "@/server/dashboard/summary";
import LeadsPage from "@/app/(app)/leads/page";
import AnalyticsPage from "@/app/(app)/analytics/page";
import LoginPage from "@/app/(auth)/login/page";
import { proxy, config as proxyConfig } from "@/proxy";

import { RedirectSignal } from "./mocks/next-navigation";
import { jar, writes, deletes, failures, resetCookies } from "./mocks/next-headers";
import { revalidated } from "./mocks/next-cache";
import { NextResponse, type NextRequest } from "./mocks/next-server";
import { behavior, calls, created, resetSsr, rpcArgs } from "./mocks/supabase-ssr";

// ---------- fixtures (test-only) ----------------------------------------------------------------
// FAKE values. The project reference below is 20 made-up characters, not a real project. Nothing here is a real key.
const REF = "abcdefghijklmnopqrst";
const URL_OK = `https://${REF}.supabase.co`;
// A fake legacy "anon" key: JWT-shaped, payload role=anon. Not a real key.
const b64 = (o: object) => Buffer.from(JSON.stringify(o)).toString("base64url");
const jwt = (payload: object, header: object = { alg: "HS256", typ: "JWT" }) => `${b64(header)}.${b64(payload)}.signature-not-real`;
const ANON_KEY = jwt({ iss: "supabase", ref: REF, role: "anon" });
const SERVICE_KEY = jwt({ iss: "supabase", ref: REF, role: "service_role" });
const PUBLISHABLE_KEY = "sb_publishable_abcdefghijklmnopqrstuvwxyz012345";
const SENTINEL_SECRET = "SENTINEL_SERVICE_ROLE_VALUE_MUST_NEVER_APPEAR";

const UID = "11111111-2222-4333-8444-555555555555";
const OTHER_UID = "99999999-2222-4333-8444-555555555555";

const PERMS = {
  admin: ["analytics.read", "appointments.read", "appointments.read_all", "buyers.read", "buyers.read_all", "deals.read", "deals.read_all", "leads.read", "leads.read_all", "market.read", "matching.read", "matching.read_all", "properties.read", "properties.read_active", "properties.read_all", "sellers.read", "sellers.read_all", "settings.manage", "tasks.read", "tasks.read_all", "users.manage"],
  agent: ["appointments.read", "buyers.read", "deals.read", "leads.read", "matching.read", "properties.read", "properties.read_active", "sellers.read", "tasks.read"],
  viewer: ["appointments.read_all", "buyers.read_all", "leads.read_all", "matching.read_all", "properties.read_active", "properties.read_all", "sellers.read_all", "tasks.read_all"],
};
function myAccess(role: keyof typeof PERMS | null, over: Record<string, unknown> = {}) {
  return { user_id: UID, full_name: "Test Person", role, is_active: true, permissions: role ? PERMS[role] : [], ...over };
}
function summary(role: "admin" | "agent" | "viewer") {
  const cards: Record<string, unknown> = {};
  CARD_KEYS.forEach((k, i) => {
    cards[k] = role === "viewer" && k === "open_deals" ? { available: false, value: null, scope: null }
      : { available: true, value: i + 1, scope: role === "agent" && k !== "active_inventory" ? "assigned" : "all" };
  });
  return { schema_version: 1, generated_at: "2026-10-09T08:30:00+00:00", timezone: "Asia/Kolkata", warnings: [], cards };
}

const signedIn = () => { behavior.getUser = async () => ({ data: { user: { id: UID } }, error: null }); };
function serve(role: keyof typeof PERMS | null, over: Record<string, unknown> = {}, dash: "admin" | "agent" | "viewer" = "admin") {
  signedIn();
  behavior.rpc = async (fn) => {
    if (fn === "my_access") return { data: myAccess(role, over), error: null };
    if (fn === "dashboard_summary") return { data: summary(dash), error: null };
    return { data: null, error: { code: "42883", message: "no such function", details: "", hint: "" } };
  };
}
const child = "SECRET PAGE CONTENT";
const html = (node: unknown) => renderToStaticMarkup(node as never);
// Pages and the layout are async Server Components. This resolves the top-level one (and one level of async child, e.g.
// ModulePage) the way the server would, then renders the result. A redirect() thrown anywhere surfaces as RedirectSignal.
async function resolveServer(node: any): Promise<unknown> {
  let current = node;
  // Only ASYNC components are resolved here (they cannot be rendered by the static renderer); sync ones, including
  // client components with hooks, are left for the renderer.
  for (let i = 0; i < 4 && current && typeof current === "object" && typeof current.type === "function" && current.type.constructor?.name === "AsyncFunction"; i++) {
    current = await current.type(current.props);
  }
  return current;
}
const renderPage = async (Page: () => unknown) => html(await resolveServer(await Page()));
const renderLayout = async () => html(await resolveServer(await AppLayout({ children: child as never })));
async function redirectTarget(run: () => Promise<unknown>): Promise<string | null> {
  try { await run(); return null; } catch (e) { if (e instanceof RedirectSignal) return e.url; throw e; }
}

beforeEach(() => {
  resetSsr(); resetCookies(); revalidated.length = 0; NextResponse.created.length = 0;
  process.env.NEXT_PUBLIC_SUPABASE_URL = URL_OK;
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY = ANON_KEY;
  process.env.SUPABASE_SERVICE_ROLE_KEY = SENTINEL_SECRET;
});

// ---------- public environment guard -----------------------------------------------------------
test("env: missing, blank or malformed settings fail closed", () => {
  assert.equal(parseSupabasePublicEnv({}), null);
  assert.equal(parseSupabasePublicEnv({ url: URL_OK }), null);
  assert.equal(parseSupabasePublicEnv({ anonKey: ANON_KEY }), null);
  assert.equal(parseSupabasePublicEnv({ url: "  ", anonKey: ANON_KEY }), null);
  assert.equal(parseSupabasePublicEnv({ url: URL_OK, anonKey: "  " }), null);
  assert.equal(parseSupabasePublicEnv({ url: "not a url", anonKey: ANON_KEY }), null);
  assert.equal(parseSupabasePublicEnv({ url: URL_OK, anonKey: "short" }), null);
  assert.equal(parseSupabasePublicEnv({ url: URL_OK, anonKey: "has space in it so it is not a key" }), null);
});

test("env: accepted formats are exactly the expected ones, and values are normalised", () => {
  assert.deepEqual(parseSupabasePublicEnv({ url: URL_OK, anonKey: ANON_KEY }), { url: URL_OK, anonKey: ANON_KEY });
  assert.deepEqual(parseSupabasePublicEnv({ url: URL_OK, anonKey: PUBLISHABLE_KEY }), { url: URL_OK, anonKey: PUBLISHABLE_KEY });
  assert.deepEqual(parseSupabasePublicEnv({ url: `${URL_OK}/`, anonKey: ` ${ANON_KEY}\n` }), { url: URL_OK, anonKey: ANON_KEY }, "trailing slash, spaces and a newline are trimmed");
  assert.deepEqual(parseSupabasePublicEnv({ url: `HTTPS://${REF.toUpperCase()}.SUPABASE.CO`, anonKey: ANON_KEY }), { url: URL_OK, anonKey: ANON_KEY }, "scheme and host are case-insensitive by definition; the output is lower-case");
  assert.ok(parseSupabasePublicEnv({ url: "http://localhost:54321", anonKey: jwt({ iss: "supabase-demo", role: "anon" }) }), "local development: http, any port, no project reference in the key");
  assert.ok(parseSupabasePublicEnv({ url: "http://127.0.0.1:54321", anonKey: PUBLISHABLE_KEY }));
});

test("env: whitespace policy: surrounding whitespace is trimmed, whitespace anywhere inside a value is refused", () => {
  // Intended policy: a value read from an env file or a hosting dashboard often carries a trailing newline, CRLF or a stray
  // space. Those OUTER characters (as String.prototype.trim() defines them) are removed before validation; the validated,
  // trimmed value is the one returned and used. Anything inside the value is never touched and is refused.
  const surround = [" ", "  ", "\t", "\n", "\r\n", " \t\r\n "];
  for (const w of surround) {
    for (const key of [ANON_KEY, PUBLISHABLE_KEY]) {
      assert.deepEqual(parseSupabasePublicEnv({ url: `${w}${URL_OK}${w}`, anonKey: `${w}${key}${w}` }), { url: URL_OK, anonKey: key }, `both padded with ${JSON.stringify(w)}`);
      assert.deepEqual(parseSupabasePublicEnv({ url: URL_OK, anonKey: `${w}${key}` }), { url: URL_OK, anonKey: key }, "leading only");
      assert.deepEqual(parseSupabasePublicEnv({ url: URL_OK, anonKey: `${key}${w}` }), { url: URL_OK, anonKey: key }, "trailing only");
    }
  }
  assert.deepEqual(parseSupabasePublicEnv({ url: `\uFEFF${URL_OK}`, anonKey: `\u00A0${PUBLISHABLE_KEY}\u00A0` }), { url: URL_OK, anonKey: PUBLISHABLE_KEY }, "a byte-order mark and no-break spaces are whitespace to trim()");

  // What comes out never carries whitespace, so nothing downstream ever sees the padding.
  const out = parseSupabasePublicEnv({ url: ` ${URL_OK}/\n`, anonKey: `\t${PUBLISHABLE_KEY}\r\n` });
  assert.ok(out);
  assert.equal(/\s/.test(out.url) || /\s/.test(out.anonKey), false);
  assert.equal(out.anonKey, PUBLISHABLE_KEY);

  // Nothing but whitespace is the same as missing.
  for (const w of surround) {
    assert.equal(parseSupabasePublicEnv({ url: w, anonKey: ANON_KEY }), null);
    assert.equal(parseSupabasePublicEnv({ url: URL_OK, anonKey: w }), null);
  }

  // Whitespace INSIDE a value is refused, however it is arranged.
  const insideKey: [string, string][] = [
    ["space inside a publishable key", `${PUBLISHABLE_KEY.slice(0, 25)} ${PUBLISHABLE_KEY.slice(25)}`],
    ["tab inside a publishable key", `${PUBLISHABLE_KEY.slice(0, 25)}\t${PUBLISHABLE_KEY.slice(25)}`],
    ["newline inside a publishable key", `${PUBLISHABLE_KEY.slice(0, 25)}\n${PUBLISHABLE_KEY.slice(25)}`],
    ["space after the prefix", PUBLISHABLE_KEY.replace("sb_publishable_", "sb_publishable_ ")],
    ["space inside a JWT", ANON_KEY.replace(".", ". ")],
    ["space before a JWT dot", ANON_KEY.replace(".", " .")],
    ["newline between JWT segments", ANON_KEY.replace(".", "\n.")],
    ["two keys separated by a space", `${PUBLISHABLE_KEY} ${PUBLISHABLE_KEY}`],
    ["a key followed by a second line", `${PUBLISHABLE_KEY}\nsb_publishable_abcdefghijklmnopqrstuvwxyz012345`],
    ["no-break space inside", `${PUBLISHABLE_KEY.slice(0, 25)}\u00A0${PUBLISHABLE_KEY.slice(25)}`],
  ];
  for (const [why, anonKey] of insideKey) {
    assert.equal(parseSupabasePublicEnv({ url: URL_OK, anonKey }), null, why);
    assert.equal(parseSupabasePublicEnv({ url: URL_OK, anonKey: ` ${anonKey}\n` }), null, `${why} (and padded)`);
  }
  const insideUrl: [string, string][] = [
    ["space inside the host", `https://${REF.slice(0, 10)} ${REF.slice(10)}.supabase.co`],
    ["newline inside the URL", `https://${REF}.supabase\n.co`],
    ["a second token after a space", `${URL_OK} https://evil.example.com`],
    ["a second line", `${URL_OK}\nhttps://evil.example.com`],
  ];
  for (const [why, url] of insideUrl) assert.equal(parseSupabasePublicEnv({ url, anonKey: ANON_KEY }), null, why);

  // Characters that are NOT whitespace are not trimmed, and fail the allow-list instead.
  for (const invisible of ["\u200B", "\u0000", "\u200E"]) {
    assert.equal(parseSupabasePublicEnv({ url: URL_OK, anonKey: `${PUBLISHABLE_KEY}${invisible}` }), null, `trailing U+${invisible.charCodeAt(0).toString(16)}`);
    assert.equal(parseSupabasePublicEnv({ url: URL_OK, anonKey: `${invisible}${ANON_KEY}` }), null, `leading U+${invisible.charCodeAt(0).toString(16)} on a JWT`);
    // The URL is different: the WHATWG URL parser itself normalises some ignorable characters inside a host (it drops
    // U+200B, for example), exactly as it lower-cases a host. The guard validates and RETURNS the parser's canonical
    // origin, so such a value is either refused or comes out as the exact, pure-ASCII project origin. It can never come
    // out carrying the character, and the host allow-list is applied to the normalised host.
    const urlResult = parseSupabasePublicEnv({ url: `${URL_OK}${invisible}`, anonKey: ANON_KEY });
    assert.ok(urlResult === null || urlResult.url === URL_OK, `URL with U+${invisible.charCodeAt(0).toString(16)}: refused or canonical`);
    if (urlResult) assert.match(urlResult.url, /^[\x21-\x7E]+$/);
  }
});

test("env: every JWT segment, including the unverified signature, must be strict base64url", () => {
  const [h, p, sig] = ANON_KEY.split(".") as [string, string, string];
  const padB64 = (o: object) => Buffer.from(JSON.stringify(o)).toString("base64"); // standard base64, with "=" padding
  const payloadOk = { iss: "supabase", ref: REF, role: "anon" };
  const cases: [string, string][] = [
    ["signature with $ and %", `${h}.${p}.sig$%^&`],
    ["signature with !", `${h}.${p}.${sig}!`],
    ["signature with =", `${h}.${p}.${sig}=`],
    ["signature with a quote", `${h}.${p}."${sig}"`],
    ["signature with a semicolon", `${h}.${p}.${sig};drop`],
    ["signature with a plus sign (base64, not base64url)", `${h}.${p}.sig+not/url`],
    ["header with = padding", `${padB64({ alg: "HS256", typ: "JWT", pad: 1 })}.${p}.${sig}`],
    ["payload with = padding (standard base64)", `${h}.${padB64(payloadOk)}.${sig}`],
    ["payload with a character outside base64url", `${h}.${p}$.${sig}`],
    ["header with a character outside base64url", `${h}$.${p}.${sig}`],
  ];
  assert.ok(padB64(payloadOk).includes("="), "fixture really is padded");
  for (const [why, key] of cases) assert.equal(parseSupabasePublicEnv({ url: URL_OK, anonKey: key }), null, why);
  assert.deepEqual(parseSupabasePublicEnv({ url: URL_OK, anonKey: `${h}.${p}.${sig}` }), { url: URL_OK, anonKey: ANON_KEY }, "the unmodified key is still accepted");
});

test("env: padding with whitespace can never make a secret, other-role or wrong-case key acceptable", () => {
  const refused = [
    SERVICE_KEY,
    jwt({ ref: REF, role: "authenticated" }),
    jwt({ ref: REF, role: "supabase_admin" }),
    jwt({ ref: REF, role: "Anon" }),
    "sb_secret_abcdefghijklmnopqrstuvwxyz",
    "SB_SECRET_abcdefghijklmnopqrstuvwxyz",
    "sbp_0123456789abcdef0123456789abcdef01234567",
    "SB_PUBLISHABLE_abcdefghijklmnopqrstuvwxyz012345",
    "q7Zk2mX9vB4nL8cR1tY6wH3sD5fG0j",
  ];
  for (const key of refused) {
    for (const w of ["", " ", "\t", "\n", "\r\n", " \t\r\n "]) {
      assert.equal(parseSupabasePublicEnv({ url: URL_OK, anonKey: `${w}${key}${w}` }), null, `${JSON.stringify(w)}-padded refused key`);
    }
  }
  // The explicit secret-key check sees through padding too.
  assert.equal(looksLikeSecretKey(` ${SERVICE_KEY}\n`), true);
  assert.equal(looksLikeSecretKey(`\t SB_SECRET_abcdefghijklmnopqrstuvwxyz\r\n`), true);
  assert.equal(looksLikeSecretKey(` ${PUBLISHABLE_KEY}\n`), false);
});

test("env: the exported allow-list itself does NOT trim; trimming happens once, in parseSupabasePublicEnv", () => {
  assert.equal(matchesPublicKeyAllowList(PUBLISHABLE_KEY, null), true);
  for (const padded of [` ${PUBLISHABLE_KEY}`, `${PUBLISHABLE_KEY}\n`, `\t${ANON_KEY} `]) {
    assert.equal(matchesPublicKeyAllowList(padded, REF), false, JSON.stringify(padded.slice(0, 4)));
  }
});

test("env: URL is validated on its own (https required outside local development, exact hosted host)", () => {
  const bad: [string, string][] = [
    ["plain http to a remote host", `http://${REF}.supabase.co`],
    ["any other https host (review bypass)", "https://evil.example.com"],
    ["look-alike: localhost as a subdomain label (review bypass)", "http://localhost.evil.com"],
    ["look-alike: supabase host as a prefix of another host", `https://${REF}.supabase.co.evil.com`],
    ["look-alike: host in the path", `https://evil.com/${REF}.supabase.co`],
    ["credentials make the real host evil.com", `https://${REF}.supabase.co@evil.com`],
    ["credentials in the URL", `https://user:pass@${REF}.supabase.co`],
    ["reference too short", "https://abcdefghijklmnopqrs.supabase.co"],
    ["reference too long", "https://abcdefghijklmnopqrstu.supabase.co"],
    ["a subdomain of a project host", `https://x.${REF}.supabase.co`],
    ["apex supabase.co", "https://supabase.co"],
    ["other supabase TLD", `https://${REF}.supabase.com`],
    ["port on a hosted URL", `https://${REF}.supabase.co:8443`],
    ["a path", `${URL_OK}/rest/v1`],
    ["a query string", `${URL_OK}/?a=1`],
    ["a fragment", `${URL_OK}/#x`],
    ["a backslash", `https:\\\\${REF}.supabase.co`],
    ["embedded whitespace", `https://${REF}.supabase.co /`],
    ["other scheme, hosted", `ftp://${REF}.supabase.co`],
    ["other scheme, local", "ftp://localhost"],
    ["javascript scheme", "javascript:alert(1)"],
    ["private network host", "http://192.168.0.10:54321"],
    ["localhost with credentials", "http://u:p@localhost:54321"],
  ];
  for (const [why, url] of bad) assert.equal(parseSupabasePublicEnv({ url, anonKey: ANON_KEY }), null, why);
});

test("env: the exact bypass cases from the Phase 3.3A review are refused", () => {
  const padded = `${b64({ alg: "HS256" })}.${b64({ role: "service_role", ref: REF })}=.signature-not-real`;
  const cases: [string, string][] = [
    ["an sbp_ personal access token", "sbp_0123456789abcdef0123456789abcdef01234567"],
    ["a random 30-character string", "q7Zk2mX9vB4nL8cR1tY6wH3sD5fG0j"],
    ["an authenticated-role JWT", jwt({ iss: "supabase", ref: REF, role: "authenticated" })],
    ["a supabase_admin-role JWT", jwt({ iss: "supabase", ref: REF, role: "supabase_admin" })],
    ["an upper-case SB_SECRET_ key", "SB_SECRET_abcdefghijklmnopqrstuvwxyz"],
    ["a padded service_role JWT", padded],
    ["a whitespace-padded service_role JWT", ` ${SERVICE_KEY} `.replace(".", " .")],
  ];
  for (const [why, anonKey] of cases) assert.equal(parseSupabasePublicEnv({ url: URL_OK, anonKey }), null, why);
});

test("env: key is an allow-list; secret, other-role, malformed and wrong-case keys are all refused", () => {
  const bad: [string, string][] = [
    ["legacy service_role JWT", SERVICE_KEY],
    ["service_role in mixed case", jwt({ ref: REF, role: "Service_Role" })],
    ["role ANON in upper case", jwt({ ref: REF, role: "ANON" })],
    ["role Anon with a capital", jwt({ ref: REF, role: "Anon" })],
    ["role anon with a trailing space", jwt({ ref: REF, role: "anon " })],
    ["role is an array", jwt({ ref: REF, role: ["anon"] })],
    ["role is missing", jwt({ ref: REF })],
    ["role is a number", jwt({ ref: REF, role: 1 })],
    ["JWT for another project", jwt({ ref: "zzzzzzzzzzzzzzzzzzzz", role: "anon" })],
    ["ref is not a string", jwt({ ref: 1, role: "anon" })],
    ["JWT header has no alg", jwt({ ref: REF, role: "anon" }, { typ: "JWT" })],
    ["JWT with no signature", `${b64({ alg: "HS256" })}.${b64({ ref: REF, role: "anon" })}.`],
    ["JWT with four parts", `${ANON_KEY}.extra`],
    ["JWT whose payload is not JSON", `${b64({ alg: "HS256" })}.bm90LWpzb24.signature-not-real`],
    ["JWT whose payload is a JSON array", `${b64({ alg: "HS256" })}.${Buffer.from("[1]").toString("base64url")}.signature-not-real`],
    ["sb_secret_ key", "sb_secret_abcdefghijklmnopqrstuvwxyz"],
    ["SB_SECRET_ key", "SB_SECRET_abcdefghijklmnopqrstuvwxyz"],
    ["Sb_Secret_ key", "Sb_Secret_abcdefghijklmnopqrstuvwxyz"],
    ["upper-case publishable prefix", "SB_PUBLISHABLE_abcdefghijklmnopqrstuvwxyz012345"],
    ["mixed-case publishable prefix", "Sb_Publishable_abcdefghijklmnopqrstuvwxyz012345"],
    ["publishable prefix but too short", "sb_publishable_abc"],
    ["publishable prefix with a forbidden character", "sb_publishable_abcdefghijklmnop$qrstuvwxyz"],
    ["publishable key in quotes", `"${PUBLISHABLE_KEY}"`],
    ["anon key in quotes", `'${ANON_KEY}'`],
    ["a very long string", `sb_publishable_${"a".repeat(3000)}`],
  ];
  for (const [why, anonKey] of bad) assert.equal(parseSupabasePublicEnv({ url: URL_OK, anonKey }), null, why);
});

test("env: looksLikeSecretKey is case-insensitive and does not flag the accepted public formats", () => {
  assert.equal(looksLikeSecretKey(SERVICE_KEY), true);
  assert.equal(looksLikeSecretKey(jwt({ role: "SERVICE_ROLE" })), true);
  assert.equal(looksLikeSecretKey(jwt({ role: "supabase_admin" })), true);
  assert.equal(looksLikeSecretKey("sb_secret_abcdefghijklmnopqrstuvwxyz"), true);
  assert.equal(looksLikeSecretKey("SB_SECRET_abcdefghijklmnopqrstuvwxyz"), true);
  assert.equal(looksLikeSecretKey("sbp_0123456789abcdef0123456789abcdef01234567"), true);
  assert.equal(looksLikeSecretKey(ANON_KEY), false);
  assert.equal(looksLikeSecretKey(PUBLISHABLE_KEY), false);
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY = SERVICE_KEY;
  assert.equal(getSupabasePublicEnv(), null);
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY = PUBLISHABLE_KEY;
  assert.deepEqual(getSupabasePublicEnv(), { url: URL_OK, anonKey: PUBLISHABLE_KEY }, "the supported NEXT_PUBLIC_SUPABASE_ANON_KEY setting accepts a publishable key");
});

test("env: the secret-key refusal and the allow-list are two independent layers, and each refuses every secret sample on its own", () => {
  // Secret-family samples, including the review's bypass cases and case variants.
  const secrets = [
    SERVICE_KEY,
    jwt({ ref: REF, role: "Service_Role" }),
    jwt({ ref: REF, role: "SERVICE_ROLE" }),
    jwt({ ref: REF, role: "supabase_admin" }),
    "sb_secret_abcdefghijklmnopqrstuvwxyz",
    "SB_SECRET_abcdefghijklmnopqrstuvwxyz",
    "Sb_Secret_abcdefghijklmnopqrstuvwxyz",
    "sbp_0123456789abcdef0123456789abcdef01234567",
  ];
  for (const key of secrets) {
    assert.equal(looksLikeSecretKey(key), true, "layer 1 flags it by itself");
    assert.equal(matchesPublicKeyAllowList(key, REF), false, "layer 2 refuses it by itself (hosted)");
    assert.equal(matchesPublicKeyAllowList(key, null), false, "layer 2 refuses it by itself (local)");
    assert.equal(parseSupabasePublicEnv({ url: URL_OK, anonKey: key }), null);
  }
  // Only the allow-list covers other-role JWTs; the secret-key refusal does not claim to.
  const other = jwt({ ref: REF, role: "authenticated" });
  assert.equal(looksLikeSecretKey(other), false);
  assert.equal(matchesPublicKeyAllowList(other, REF), false);
  // And the allow-list accepts exactly the two public formats.
  assert.equal(matchesPublicKeyAllowList(ANON_KEY, REF), true);
  assert.equal(matchesPublicKeyAllowList(PUBLISHABLE_KEY, null), true);
  assert.equal(matchesPublicKeyAllowList(ANON_KEY, "zzzzzzzzzzzzzzzzzzzz"), false, "project mismatch");
});

test("env: refusing a value never reveals it (the function returns null and throws nothing)", () => {
  const seen: unknown[] = [];
  const original = { log: console.log, warn: console.warn, error: console.error, info: console.info };
  console.log = console.warn = console.error = console.info = (...a: unknown[]) => { seen.push(a); };
  try {
    for (const key of [SERVICE_KEY, "sb_secret_abcdefghijklmnopqrstuvwxyz", "garbage-garbage-garbage-garbage"]) {
      assert.equal(parseSupabasePublicEnv({ url: "https://evil.example.com", anonKey: key }), null);
      assert.equal(parseSupabasePublicEnv({ url: URL_OK, anonKey: key }), null);
    }
  } finally {
    Object.assign(console, original);
  }
  assert.deepEqual(seen, [], "nothing is logged");
});

test("cookies: session cookies are always HttpOnly, SameSite=Lax, path /, and Secure in production", () => {
  const prod = hardenCookieOptions({ httpOnly: false, sameSite: "none", secure: false, path: "/x", maxAge: 123 }, true);
  assert.deepEqual({ ...prod }, { httpOnly: true, sameSite: "lax", secure: true, path: "/", maxAge: 123 });
  assert.equal(hardenCookieOptions(undefined, false).secure, false);
  assert.equal(hardenCookieOptions(undefined, false).httpOnly, true);
  assert.equal(isSessionCookieName("sb-abc-auth-token"), true);
  assert.equal(isSessionCookieName("sb-abc-auth-token.1"), true);
  assert.equal(isSessionCookieName("theme"), false);
});

// ---------- my_access parsing ---------------------------------------------------------------------
test("my_access: accepts the real shape, rejects anything else", () => {
  const ok = parseMyAccess(myAccess("agent"));
  assert.ok(ok.ok && ok.value.role === "agent" && ok.value.permissions.length === PERMS.agent.length && ok.value.isActive);
  assert.ok(parseMyAccess({ ...myAccess("agent"), permissions: ["leads.read", "leads.read"] }).ok, "duplicates collapse");
  const bad: unknown[] = [
    null, undefined, "x", 5, [], {},
    { ...myAccess("agent"), user_id: "nope" },
    { ...myAccess("agent"), role: "Agent!" },
    { ...myAccess("agent"), is_active: "true" },
    { ...myAccess("agent"), is_active: undefined },
    { ...myAccess("agent"), permissions: "leads.read" },
    { ...myAccess("agent"), permissions: ["Leads.Read"] },
    { ...myAccess("agent"), permissions: [5] },
    { ...myAccess("agent"), permissions: Array.from({ length: 301 }, (_, i) => `a.b${"c".repeat(i % 3)}`) },
    { ...myAccess("agent"), full_name: 5 },
    { ...myAccess("agent"), extra: "field" },
    { ...myAccess("agent"), salary: 1 },
  ];
  for (const b of bad) assert.equal(parseMyAccess(b).ok, false, JSON.stringify(b));
  assert.equal(safeRef("42501"), "42501");
  assert.equal(safeRef("secret-host: bad"), "unknown");
  assert.equal(safeRef(undefined), "unknown");
});

// ---------- the verifier, with a stand-in client ---------------------------------------------------
function fake(opts: { user?: Awaited<ReturnType<AccessClient["auth"]["getUser"]>>; rpc?: Awaited<ReturnType<AccessClient["rpc"]>> | "throw"; getUserThrows?: boolean }) {
  const log: string[] = [];
  const client: AccessClient = {
    auth: { getUser: async () => { log.push("getUser"); if (opts.getUserThrows) throw new Error("secret-host timed out"); return opts.user ?? { data: { user: { id: UID } }, error: null }; } },
    rpc: async (fn) => { log.push(`rpc:${fn}`); if (opts.rpc === "throw") throw new Error("secret-host reset"); return opts.rpc ?? { data: myAccess("agent"), error: null }; },
  };
  return { client, log };
}

test("verifier: no session / invalid session -> signed_out, and the database is never asked", async () => {
  for (const user of [
    { data: { user: null }, error: { name: "AuthSessionMissingError", status: 400 } },
    { data: null, error: { name: "AuthApiError", status: 401, code: "bad_jwt" } },
    { data: null, error: { name: "AuthApiError", status: 403, code: "session_not_found" } },
    { data: { user: null }, error: null },
    { data: null, error: null },
    { data: { user: { id: "not-a-uuid" } }, error: null },
  ] as const) {
    const { client, log } = fake({ user: user as never });
    assert.deepEqual(await resolveAccessState(client), { status: "signed_out" }, JSON.stringify(user));
    assert.deepEqual(log, ["getUser"], "my_access must not be called without a verified user");
  }
});

test("verifier: Auth unreachable or failing is an error, never access, and never leaks the message", async () => {
  for (const user of [
    { data: null, error: { name: "AuthRetryableFetchError", status: 0 } },
    { data: null, error: { name: "AuthApiError", status: 500, code: "unexpected_failure" } },
    { data: null, error: { name: "AuthApiError", status: 429, code: "over_request_rate_limit" } },
    { data: null, error: { name: "AuthUnknownError" } },
  ] as const) {
    const state = await resolveAccessState(fake({ user: user as never }).client);
    assert.equal(state.status, "error", JSON.stringify(user));
    if (state.status === "error") assert.match(state.message, /^[A-Za-z0-9_]{1,40}$/);
  }
  const thrown = await resolveAccessState(fake({ getUserThrows: true }).client);
  assert.deepEqual(thrown, { status: "error", message: "auth_unavailable" });
  assert.equal(JSON.stringify(thrown).includes("secret-host"), false);
  const rpcThrown = await resolveAccessState(fake({ rpc: "throw" }).client);
  assert.deepEqual(rpcThrown, { status: "error", message: "profile_unavailable" });
  assert.equal(JSON.stringify(rpcThrown).includes("secret-host"), false);
});

test("verifier: signed in but no profile / inactive / no role -> inactive (fails closed)", async () => {
  for (const data of [null, undefined, myAccess("agent", { is_active: false }), myAccess(null), myAccess("agent", { role: null })]) {
    const state = await resolveAccessState(fake({ rpc: { data, error: null } }).client);
    assert.deepEqual(state, { status: "inactive" }, JSON.stringify(data));
  }
});

test("verifier: profile errors and malformed answers never become access", async () => {
  const e = (code: string) => ({ data: null, error: { code, message: "secret-host: password=hunter2" } });
  assert.deepEqual(await resolveAccessState(fake({ rpc: e("PGRST301") }).client), { status: "signed_out" });
  assert.deepEqual(await resolveAccessState(fake({ rpc: e("PGRST302") }).client), { status: "signed_out" });
  assert.deepEqual(await resolveAccessState(fake({ rpc: e("XX000") }).client), { status: "error", message: "profile_XX000" });
  assert.deepEqual(await resolveAccessState(fake({ rpc: e("42501") }).client), { status: "error", message: "profile_42501" });
  assert.deepEqual(await resolveAccessState(fake({ rpc: e("bad code!") }).client), { status: "error", message: "profile_unknown" });
  assert.deepEqual(await resolveAccessState(fake({ rpc: { data: { permissions: ["x.y"] }, error: null } }).client), { status: "error", message: "profile_bad_response" });
  // The profile must belong to the verified user.
  assert.deepEqual(await resolveAccessState(fake({ rpc: { data: myAccess("admin", { user_id: OTHER_UID }), error: null } }).client), { status: "error", message: "profile_mismatch" });
  for (const r of [e("XX000"), e("PGRST301")]) assert.equal(JSON.stringify(await resolveAccessState(fake({ rpc: r }).client)).includes("hunter2"), false);
});

test("verifier: an active user with a role is ready, with exactly the permissions the database returned", async () => {
  const { client, log } = fake({ rpc: { data: myAccess("viewer", { user_id: UID.toUpperCase() }), error: null } });
  const state = await resolveAccessState(client);
  assert.equal(state.status, "ready");
  if (state.status !== "ready") return;
  assert.equal(state.access.userId, UID);
  assert.equal(state.access.role, "viewer");
  assert.deepEqual([...state.access.permissions], PERMS.viewer);
  assert.deepEqual(log, ["getUser", "rpc:my_access"], "identity is verified first, then the profile is read");
  assert.equal(canAccess(state, ["deals.read", "deals.read_all"]), false, "viewer has no deals");
  assert.equal(canAccess(state, []), true);
});

// ---------- real wiring (session.ts + user-client.ts + resolve.ts) over stand-ins ------------------
test("session: missing environment -> unconfigured, and no client is ever created", async () => {
  delete process.env.NEXT_PUBLIC_SUPABASE_URL;
  assert.deepEqual(await getAccessState(), { status: "unconfigured" });
  assert.equal(created.length, 0);
  assert.deepEqual(calls, []);
});

test("session: a secret key in the public setting is treated as not configured", async () => {
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY = SERVICE_KEY;
  assert.deepEqual(await getAccessState(), { status: "unconfigured" });
  assert.equal(created.length, 0);
});

test("session: every review bypass value is 'not configured' end to end, and no client or call is made", async () => {
  const setups: [string, string, string][] = [
    ["foreign https host", "https://evil.example.com", ANON_KEY],
    ["localhost look-alike", "http://localhost.evil.com", ANON_KEY],
    ["authenticated-role JWT", URL_OK, jwt({ ref: REF, role: "authenticated" })],
    ["supabase_admin-role JWT", URL_OK, jwt({ ref: REF, role: "supabase_admin" })],
    ["personal access token", URL_OK, "sbp_0123456789abcdef0123456789abcdef01234567"],
    ["upper-case sb_secret", URL_OK, "SB_SECRET_abcdefghijklmnopqrstuvwxyz"],
  ];
  for (const [why, url, key] of setups) {
    resetSsr();
    process.env.NEXT_PUBLIC_SUPABASE_URL = url;
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY = key;
    assert.deepEqual(await getAccessState(), { status: "unconfigured" }, why);
    assert.equal(created.length, 0, why);
    assert.deepEqual(calls, [], why);
  }
});

test("session: padded public settings are trimmed once and the client gets the exact, whitespace-free values", async () => {
  process.env.NEXT_PUBLIC_SUPABASE_URL = `  ${URL_OK}\r\n`;
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY = `\t${PUBLISHABLE_KEY} \r\n`;
  serve("agent");
  assert.equal((await getAccessState()).status, "ready");
  assert.equal(created.length, 1);
  assert.equal(created[0]!.url, URL_OK);
  assert.equal(created[0]!.key, PUBLISHABLE_KEY);
});

test("session: a padded secret key, or a key with whitespace inside, is 'not configured' and no client is created", async () => {
  for (const key of [` ${SERVICE_KEY}\n`, `\r\nsb_secret_abcdefghijklmnopqrstuvwxyz `, `${PUBLISHABLE_KEY.slice(0, 25)} ${PUBLISHABLE_KEY.slice(25)}`]) {
    resetSsr();
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY = key;
    assert.deepEqual(await getAccessState(), { status: "unconfigured" });
    assert.equal(created.length, 0);
    assert.deepEqual(calls, []);
  }
});

test("session: no cookie -> signed_out; the database is not asked", async () => {
  assert.deepEqual(await getAccessState(), { status: "signed_out" });
  assert.deepEqual(calls, ["auth.getUser"]);
});

test("session: ready; the user client gets the public key only; the service-role value never reaches Supabase code", async () => {
  serve("agent");
  const state = await getAccessState();
  assert.equal(state.status, "ready");
  assert.deepEqual(calls, ["auth.getUser", "rpc:my_access"]);
  assert.deepEqual(rpcArgs, [["my_access"]], "my_access takes no arguments");
  assert.equal(created.length, 1);
  assert.equal(created[0]!.key, ANON_KEY);
  assert.equal(created[0]!.url, URL_OK);
  assert.equal(JSON.stringify({ created, calls, rpcArgs, writes }).includes(SENTINEL_SECRET), false);
});

test("session: the client never uses getSession (the stand-in has none, so any use would have thrown)", async () => {
  serve("admin");
  assert.equal((await getAccessState()).status, "ready");
  const sources = walk("src").map((f) => stripComments(readFileSync(f, "utf8"))).join("\n");
  assert.doesNotMatch(sources, /getSession\s*\(/);
});

test("session: cookies the client writes are hardened, and a read-only context does not crash", async () => {
  serve("agent");
  await getAccessState();
  const adapter = created[0]!.cookies;
  adapter.setAll([{ name: "sb-example-auth-token", value: "v1", options: { httpOnly: false, sameSite: "none", maxAge: 100 } }]);
  assert.equal(writes.length, 1);
  assert.deepEqual(writes[0]!.options, { httpOnly: true, sameSite: "lax", secure: false, path: "/", maxAge: 100 });
  failures.set = true;
  assert.doesNotThrow(() => adapter.setAll([{ name: "sb-example-auth-token", value: "v2" }]), "Server Components cannot set cookies");
});

// ---------- sign in --------------------------------------------------------------------------------
function form(email: unknown, password: unknown) {
  const f = new FormData();
  if (email !== undefined) f.set("email", email as string);
  if (password !== undefined) f.set("password", password as string);
  return f;
}

test("credentials: validation and messages", () => {
  assert.deepEqual(checkCredentials("  A.B@Example.COM ", " pass word "), { ok: true, email: "a.b@example.com", password: " pass word " });
  for (const [e, p] of [["", "x"], ["a@b.co", ""], ["not-an-email", "x"], ["a@b", "x"], [undefined, "x"], ["a@b.co", undefined], [5, 5], ["a@b.co", "x".repeat(1025)], ["a".repeat(300) + "@b.co", "x"]] as const) {
    assert.equal(checkCredentials(e, p).ok, false, `${String(e).slice(0, 20)} / ${String(p).slice(0, 5)}`);
  }
  assert.equal(checkCredentials("not-an-email", "x").email, "", "a non-email is never echoed back");
  assert.equal(signInMessage({ status: 400, code: "invalid_credentials" }), MESSAGES.invalid);
  assert.equal(signInMessage({ status: 422, code: "email_not_confirmed" }), MESSAGES.invalid, "no hint about whether the account exists");
  assert.equal(signInMessage({ status: 429 }), MESSAGES.rateLimited);
  assert.equal(signInMessage({ status: 500 }), MESSAGES.unavailable);
  assert.equal(signInMessage({ status: 0, name: "AuthRetryableFetchError" }), MESSAGES.unavailable);
  assert.equal(signInMessage(null), MESSAGES.unavailable);
});

test("signIn: invalid input never reaches Supabase", async () => {
  for (const f of [form("", ""), form("a@b.co", ""), form("nope", "pw"), form(undefined, undefined)]) {
    const state = await signIn(SIGN_IN_INITIAL, f);
    assert.equal(state.error, MESSAGES.missing);
  }
  assert.equal(created.length, 0);
  assert.deepEqual(calls, []);
});

test("signIn: wrong credentials give one generic message, no redirect, and the password is never returned", async () => {
  const state = await signIn(SIGN_IN_INITIAL, form("Person@Example.com", "correct horse battery staple"));
  assert.deepEqual(state, { error: MESSAGES.invalid, email: "person@example.com" });
  assert.equal(JSON.stringify(state).includes("correct horse"), false);
  assert.deepEqual(calls, ["auth.signInWithPassword"]);
  assert.equal(revalidated.length, 0);
});

test("signIn: rate limit, Auth outage, a thrown error and a missing session are all safe messages", async () => {
  behavior.signIn = async () => ({ data: { session: null, user: null }, error: { name: "AuthApiError", status: 429, code: "over_request_rate_limit", message: "secret-host rate" } });
  assert.equal((await signIn(SIGN_IN_INITIAL, form("a@b.co", "pw"))).error, MESSAGES.rateLimited);
  behavior.signIn = async () => ({ data: { session: null, user: null }, error: { name: "AuthRetryableFetchError", status: 0, message: "secret-host down" } });
  assert.equal((await signIn(SIGN_IN_INITIAL, form("a@b.co", "pw"))).error, MESSAGES.unavailable);
  behavior.signIn = async () => { throw new Error("secret-host: password=hunter2"); };
  const thrown = await signIn(SIGN_IN_INITIAL, form("a@b.co", "pw"));
  assert.equal(thrown.error, MESSAGES.unavailable);
  assert.equal(JSON.stringify(thrown).includes("hunter2"), false);
  behavior.signIn = async () => ({ data: { session: null, user: { id: UID } }, error: null }); // success without a session is not a sign-in
  assert.equal((await signIn(SIGN_IN_INITIAL, form("a@b.co", "pw"))).error, MESSAGES.unavailable);
});

test("signIn: not configured -> message, no client created", async () => {
  delete process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  assert.equal((await signIn(SIGN_IN_INITIAL, form("a@b.co", "pw"))).error, MESSAGES.notConfigured);
  assert.equal(created.length, 0);
});

test("signIn: success sends the trimmed, lower-cased email and the untouched password, then goes to /dashboard", async () => {
  let seen: { email: string; password: string } | null = null;
  behavior.signIn = async (c) => { seen = c; return { data: { session: { access_token: "x" }, user: { id: UID } }, error: null }; };
  const target = await redirectTarget(() => signIn(SIGN_IN_INITIAL, form("  Person@Example.COM ", " pw with spaces ")));
  assert.equal(target, "/dashboard", "a fixed destination: no 'next' parameter, so no open redirect");
  assert.deepEqual(seen, { email: "person@example.com", password: " pw with spaces " });
  assert.deepEqual(revalidated, ["/|layout"]);
});

// ---------- sign out -------------------------------------------------------------------------------
test("signOut: revokes the session, clears every session cookie, leaves other cookies, goes to /login", async () => {
  jar.set("sb-example-auth-token.0", "a"); jar.set("sb-example-auth-token.1", "b"); jar.set("sb-example-auth-token-code-verifier", "c"); jar.set("theme", "dark");
  const target = await redirectTarget(() => signOut());
  assert.equal(target, "/login");
  assert.ok(calls.includes("auth.signOut"));
  assert.deepEqual([...deletes].sort(), ["sb-example-auth-token-code-verifier", "sb-example-auth-token.0", "sb-example-auth-token.1"]);
  assert.deepEqual([...jar.keys()], ["theme"]);
  assert.deepEqual(revalidated, ["/|layout"]);
});

test("signOut: still clears the cookies and leaves when Supabase is unreachable or not configured", async () => {
  jar.set("sb-example-auth-token", "a");
  behavior.signOut = async () => { throw new Error("secret-host down"); };
  assert.equal(await redirectTarget(() => signOut()), "/login");
  assert.equal(jar.has("sb-example-auth-token"), false);

  jar.set("sb-example-auth-token", "a");
  delete process.env.NEXT_PUBLIC_SUPABASE_URL;
  assert.equal(await redirectTarget(() => signOut()), "/login");
  assert.equal(jar.has("sb-example-auth-token"), false);
});

// ---------- the proxy (session refresh only) ---------------------------------------------------------
function request(cookies: Record<string, string> = {}, pathname = "/dashboard"): NextRequest & { jar: Map<string, string> } {
  const j = new Map(Object.entries(cookies));
  return { jar: j, nextUrl: { pathname }, cookies: { getAll: () => [...j].map(([name, value]) => ({ name, value })), set: (n: string, v: string) => { j.set(n, v); } } };
}

test("proxy: refreshes through getClaims, writes the new cookies to request and response, hardened", async () => {
  const req = request({ "sb-example-auth-token": "old" });
  behavior.getClaims = async () => {
    created[0]!.cookies.setAll([{ name: "sb-example-auth-token", value: "new", options: { httpOnly: false, maxAge: 50 } }], { "cache-control": "private, no-store" });
    return { data: null, error: null };
  };
  const res = (await updateSession(req as never)) as unknown as NextResponse;
  assert.deepEqual(calls, ["auth.getClaims"], "only the cheap refresh runs here; it is not an access decision");
  assert.equal(req.jar.get("sb-example-auth-token"), "new");
  assert.equal(res.cookieWrites.length, 1);
  assert.deepEqual(res.cookieWrites[0]!.options, { httpOnly: true, sameSite: "lax", secure: false, path: "/", maxAge: 50 });
  assert.equal(res.headers.get("cache-control"), "private, no-store");
});

test("proxy: never redirects or blocks, even with no session; errors in Auth do not break the request", async () => {
  const res = (await updateSession(request() as never)) as unknown as NextResponse;
  assert.ok(res instanceof NextResponse);
  assert.equal(res.cookieWrites.length, 0);
  behavior.getClaims = async () => { throw new Error("secret-host down"); };
  assert.ok((await updateSession(request() as never)) instanceof NextResponse);
  const src = readFileSync("src/lib/supabase/proxy.ts", "utf8").replace(/\/\/[^\n]*/g, "");
  assert.doesNotMatch(src, /redirect|\.rewrite\(|status:\s*40[13]/);
});

test("proxy: not configured -> passes through and creates no client", async () => {
  delete process.env.NEXT_PUBLIC_SUPABASE_URL;
  assert.ok((await updateSession(request() as never)) instanceof NextResponse);
  assert.equal(created.length, 0);
});

test("proxy: file convention, export and matcher", async () => {
  assert.equal(typeof proxy, "function");
  assert.ok((await proxy(request() as never)) instanceof NextResponse);
  assert.equal(proxyConfig.matcher.length, 1);
  const re = new RegExp("^" + proxyConfig.matcher[0]!.replace(/\\\\/g, "\\") + "$");
  for (const p of ["/", "/dashboard", "/login", "/leads/123"]) assert.ok(re.test(p), `${p} runs the refresh`);
  for (const p of ["/_next/static/chunk.js", "/_next/image", "/favicon.ico", "/logo.png"]) assert.equal(re.test(p), false, `${p} is skipped`);
});

// ---------- route protection: the layout and the pages, driven by the REAL session code ----------------

test("layout: a verified active user gets the app; its menu lists only the sections the role may open", async () => {
  serve("agent");
  const out = await renderLayout();
  assert.match(out, /SECRET PAGE CONTENT/);
  assert.match(out, /Sign out/);
  assert.match(out, /Test Person/);
  assert.match(out, />Leads</);
  assert.doesNotMatch(out, />Analytics</);
  assert.doesNotMatch(out, />Settings</);
});

test("layout: every non-ready state keeps the page content out of the response", async () => {
  const cases: [string, () => void][] = [
    ["inactive: profile missing", () => { signedIn(); behavior.rpc = async () => ({ data: null, error: null }); }],
    ["inactive: not active", () => serve("agent", { is_active: false })],
    ["inactive: no role", () => serve(null)],
    ["profile error", () => { signedIn(); behavior.rpc = async () => ({ data: null, error: { code: "XX000", message: "secret-host", details: "", hint: "" } }); }],
    ["profile malformed", () => { signedIn(); behavior.rpc = async () => ({ data: { role: "admin", permissions: ["*.*"] }, error: null }); }],
    ["profile of another user", () => serve("admin", { user_id: OTHER_UID })],
    ["Auth down", () => { behavior.getUser = async () => { throw new Error("secret-host"); }; }],
    ["not configured", () => { delete process.env.NEXT_PUBLIC_SUPABASE_URL; }],
  ];
  for (const [name, setup] of cases) {
    resetSsr(); resetCookies(); process.env.NEXT_PUBLIC_SUPABASE_URL = URL_OK; setup();
    const out = await renderLayout();
    assert.doesNotMatch(out, /SECRET PAGE CONTENT/, name);
    assert.doesNotMatch(out, /secret-host/, name);
    assert.doesNotMatch(out, />Dashboard</, `${name}: no app navigation`);
  }
});

test("layout: signed out is sent to /login and renders nothing", async () => {
  assert.equal(await redirectTarget(() => renderLayout()), "/login");
});

test("layout: inactive shows a Sign out button, not a link back to the sign-in form", async () => {
  serve("agent", { is_active: false });
  const out = await renderLayout();
  assert.match(out, /Your account isn&#x27;t active|Your account isn't active/);
  assert.match(out, /Sign out/);
  assert.doesNotMatch(out, /Back to sign in/);
});

test("pages: a signed-out request to any page is sent to /login", async () => {
  for (const Page of [DashboardPage, LeadsPage, AnalyticsPage] as (() => unknown)[]) {
    assert.equal(await redirectTarget(() => renderPage(Page)), "/login");
  }
});

test("pages: the check runs again in each page (a layout is not re-run on client navigation)", async () => {
  // The layout would have passed earlier; now the account is not active. The page must still refuse by itself.
  serve("agent", { is_active: false });
  const refused = await renderPage(LeadsPage);
  assert.doesNotMatch(refused, /No leads yet/);
  assert.match(refused, /isn&#x27;t active|isn't active/);

  resetSsr(); resetCookies(); serve("agent");
  assert.match(await renderPage(LeadsPage), /No leads yet/);
  assert.match(await renderPage(AnalyticsPage), /don&#x27;t have access|don't have access/, "agent has no analytics.read");
});

test("pages: every page under (app) re-checks the session itself", () => {
  const exempt = new Set(["src/app/(app)/dev/states/page.tsx"]); // development gallery: notFound() in production, holds no data, still inside the layout gate
  const pages = walk("src/app/(app)").filter((f) => f.endsWith("page.tsx") && !exempt.has(f.replace(/\\/g, "/")));
  assert.equal(pages.length, 11, `expected the 11 section pages, found ${pages.length}`);
  for (const f of pages) {
    const s = readFileSync(f, "utf8");
    assert.ok(/getAccessState\(/.test(s) || /<ModulePage\s/.test(s), `${f} must call getAccessState() or render ModulePage`);
  }
  assert.match(readFileSync("src/components/modules/ModulePage.tsx", "utf8"), /getAccessState\(/);
  assert.match(readFileSync("src/app/(app)/dev/states/page.tsx", "utf8"), /NODE_ENV === "production"\) notFound\(\)/);
});

test("pages: no data page exists outside the (app) group", () => {
  const outside = walk("src/app").map((f) => f.replace(/\\/g, "/")).filter((f) => /\/(page|route)\.tsx?$/.test(f) && !f.includes("/(app)/"));
  assert.deepEqual(outside.sort(), ["src/app/(auth)/login/page.tsx", "src/app/page.tsx"].sort());
  assert.match(readFileSync("src/app/page.tsx", "utf8"), /redirect\("\/dashboard"\)/);
});

// ---------- dashboard on the authenticated session ------------------------------------------------------
test("dashboard: signed-in admin gets the figures from dashboard_summary, called once with no arguments", async () => {
  serve("admin", {}, "admin");
  const out = await renderPage(DashboardPage);
  assert.match(out, /Open deals/);
  assert.equal(calls.filter((c) => c === "rpc:dashboard_summary").length, 1);
  assert.deepEqual(rpcArgs.filter((a) => a[0] === "dashboard_summary"), [["dashboard_summary"]]);
  assert.equal(created.every((c) => c.key === ANON_KEY), true, "every client in the request used the public key");
  assert.equal(created.length, 2, "one for the session check, one for the data call; both user clients");
});

test("dashboard: role visibility is preserved end to end (viewer: deals unavailable, no money anywhere)", async () => {
  serve("viewer", {}, "viewer");
  const out = await renderPage(DashboardPage);
  assert.match(out, /data-card="open_deals"[^>]*data-state="unavailable"/);
  assert.match(out, /Not available for your role\./);
  assert.doesNotMatch(out, /₹|\$|crore|lakh|commission/i);
  assert.equal(created.length, 2);
});

test("dashboard: agent sees assigned-scope cards labelled as such", async () => {
  serve("agent", {}, "agent");
  const out = await renderPage(DashboardPage);
  assert.match(out, /Your records/);
});

test("dashboard: a viewer's tampered response still cannot show deals (UI-side permission gate)", async () => {
  signedIn();
  behavior.rpc = async (fn) => {
    if (fn === "my_access") return { data: myAccess("viewer"), error: null };
    const s = summary("admin"); // claims deals are available for a viewer
    return { data: s, error: null };
  };
  const out = await renderPage(DashboardPage);
  assert.match(out, /data-card="open_deals"[^>]*data-state="unavailable"/);
});

test("dashboard: no session or inactive account -> no data call is ever made", async () => {
  await redirectTarget(() => renderPage(DashboardPage));
  assert.equal(calls.includes("rpc:dashboard_summary"), false);
  resetSsr(); resetCookies(); serve("agent", { is_active: false });
  const out = await renderPage(DashboardPage);
  assert.match(out, /isn&#x27;t active|isn't active/);
  assert.equal(calls.includes("rpc:dashboard_summary"), false);
});

test("dashboard: getDashboard itself refuses every state except ready, before any client exists", async () => {
  for (const state of [{ status: "signed_out" }, { status: "inactive" }, { status: "error", message: "x" }] as const) {
    assert.deepEqual(await getDashboard(state), { kind: "unauthorized", reason: "signed_out" }, state.status);
  }
  assert.deepEqual(await getDashboard({ status: "unconfigured" }), { kind: "not_connected" });
  assert.equal(created.length, 0, "no Supabase client was created");
  assert.deepEqual(calls, [], "and nothing was called");
});

test("dashboard: the function failing shows a safe error with a reference code only", async () => {
  signedIn();
  behavior.rpc = async (fn) => fn === "my_access"
    ? { data: myAccess("admin"), error: null }
    : { data: null, error: { code: "57014", message: "secret-host statement timeout password=hunter2", details: "", hint: "" } };
  const out = await renderPage(DashboardPage);
  assert.match(out, /The dashboard couldn&#x27;t load|The dashboard couldn't load/);
  assert.match(out, /Reference: 57014/);
  assert.doesNotMatch(out, /secret-host|hunter2/);
});

test("dashboard: an authenticated caller the function rejects (42501) is shown as inactive, with no figures", async () => {
  signedIn();
  behavior.rpc = async (fn) => fn === "my_access"
    ? { data: myAccess("admin"), error: null }
    : { data: null, error: { code: "42501", message: "no active profile", details: "", hint: "" } };
  const out = await renderPage(DashboardPage);
  assert.match(out, /isn&#x27;t active|isn't active/);
  assert.doesNotMatch(out, /data-card=/);
});

// ---------- login page --------------------------------------------------------------------------------------
test("login: signed out shows the form; ready is sent on to the dashboard; inactive is offered Sign out", async () => {
  const out = await renderPage(LoginPage);
  assert.match(out, /type="email"/);
  assert.match(out, /type="password"/);
  assert.match(out, /autoComplete="current-password"|autocomplete="current-password"/i);
  assert.doesNotMatch(out, /sign up|register|forgot|create account/i, "no sign-up or reset in this phase");

  serve("agent");
  assert.equal(await redirectTarget(() => renderPage(LoginPage)), "/dashboard");

  resetSsr(); resetCookies(); serve("agent", { is_active: false });
  const inactive = await renderPage(LoginPage);
  assert.match(inactive, /Sign out/);
  assert.doesNotMatch(inactive, /type="password"/);
});

test("login: unconfigured and Auth-down states are explained without exposing anything", async () => {
  delete process.env.NEXT_PUBLIC_SUPABASE_URL;
  const a = await renderPage(LoginPage);
  assert.match(a, /isn&#x27;t configured|isn't configured/);
  assert.doesNotMatch(a, /type="password"/);
  resetSsr(); process.env.NEXT_PUBLIC_SUPABASE_URL = URL_OK;
  behavior.getUser = async () => { throw new Error("secret-host"); };
  const b = await renderPage(LoginPage);
  assert.match(b, /type="password"/, "the form stays available so a retry is possible");
  assert.match(b, /reference: auth_unavailable/);
  assert.doesNotMatch(b, /secret-host/);
});

// ---------- static guards ----------------------------------------------------------------------------------------
function walk(dir: string): string[] {
  return readdirSync(dir).flatMap((n) => {
    const p = join(dir, n);
    return statSync(p).isDirectory() ? walk(p) : /\.(ts|tsx)$/.test(n) ? [p] : [];
  });
}
const stripComments = (s: string) => s.replace(/\/\*[\s\S]*?\*\//g, "").replace(/(^|[^:])\/\/[^\n]*/g, "$1");
const AUTH_FILES = [
  "src/proxy.ts", "src/lib/supabase/proxy.ts", "src/lib/supabase/env.ts", "src/lib/supabase/cookies.ts", "src/lib/auth/resolve.ts", "src/lib/auth/credentials.ts",
  "src/server/auth/session.ts", "src/server/auth/actions.ts", "src/server/supabase/user-client.ts", "src/app/(app)/layout.tsx", "src/app/(auth)/login/page.tsx",
  "src/components/auth/LoginForm.tsx", "src/components/states/AccessDenied.tsx", "src/components/states/AccessGate.tsx", "src/components/states/UnauthorizedState.tsx",
];

test("static: auth code never touches the service-role key or admin client, and logs nothing", () => {
  for (const f of AUTH_FILES) {
    const code = stripComments(readFileSync(f, "utf8"));
    // env.ts names "service_role" only to REFUSE such a key; it must still never read the service-role variable.
    assert.doesNotMatch(code, f.endsWith("env.ts") ? /SUPABASE_SERVICE_ROLE_KEY|admin-client|createAdminClient/ : /SERVICE_ROLE|admin-client|createAdminClient|service_role/i, f);
    assert.doesNotMatch(code, /console\.|debugger/, f);
  }
  const allSrc = walk("src").map((f) => [f, stripComments(readFileSync(f, "utf8"))] as const);
  const users = allSrc.filter(([, c]) => /SUPABASE_SERVICE_ROLE_KEY|admin-client/.test(c)).map(([f]) => f.replace(/\\/g, "/"));
  assert.deepEqual(users.sort(), ["src/server/supabase/admin-client.ts"], "only the admin client itself may read the service-role key; nothing imports it yet");
});

test("static: no NEXT_PUBLIC variable carries a secret, and the example file lists only the two public ones", () => {
  const used = new Set(walk("src").flatMap((f) => [...readFileSync(f, "utf8").matchAll(/NEXT_PUBLIC_[A-Z0-9_]+/g)].map((m) => m[0])));
  assert.deepEqual([...used].sort(), ["NEXT_PUBLIC_SUPABASE_ANON_KEY", "NEXT_PUBLIC_SUPABASE_URL"]);
  const example = readFileSync(".env.example", "utf8");
  const names = [...example.matchAll(/^([A-Z0-9_]+)=/gm)].map((m) => m[1]);
  assert.deepEqual(names, ["NEXT_PUBLIC_SUPABASE_URL", "NEXT_PUBLIC_SUPABASE_ANON_KEY", "SUPABASE_SERVICE_ROLE_KEY"]);
  assert.doesNotMatch(example, /NEXT_PUBLIC_[A-Z_]*(SERVICE|SECRET)/);
  assert.doesNotMatch(example, /^[A-Z_]+=\S+/m, "the example file holds no values");
});

test("static: no development bypass, no stub, no session read for decisions", () => {
  for (const f of walk("src")) {
    const code = stripComments(readFileSync(f, "utf8"));
    assert.doesNotMatch(code, /shell_preview/, f);
    assert.doesNotMatch(code, /getSession\s*\(/, f);
    assert.doesNotMatch(code, /NODE_ENV\s*[!=]==?\s*["']development["']/, `${f}: no behaviour that differs in development`);
  }
  const session = stripComments(readFileSync("src/server/auth/session.ts", "utf8"));
  assert.match(session, /auth\.getUser\(\)/);
  assert.match(session, /rpc\(fn\)/);
});

test("static: server actions are async functions only; client files import no server code", () => {
  const actions = readFileSync("src/server/auth/actions.ts", "utf8");
  assert.match(actions, /^"use server";/);
  const exports = [...stripComments(actions).matchAll(/^export\s+(.*)$/gm)].map((m) => m[1]!);
  assert.deepEqual(exports.map((e) => e.replace(/\(.*$/, "")), ["async function signIn", "async function signOut"]);
  for (const f of walk("src")) {
    const s = readFileSync(f, "utf8");
    if (/^\s*(\/\/[^\n]*\n|\/\*[\s\S]*?\*\/\s*)*["']use client["']/.test(s)) {
      assert.doesNotMatch(s, /from\s+["']@\/server\//, `${f}: a client file must not import server code`);
      assert.doesNotMatch(s, /process\.env\.(?!NODE_ENV)/, `${f}: a client file must not read env`);
    }
  }
});

test("static: the sign-in form never puts a password into the page", () => {
  const form = readFileSync("src/components/auth/LoginForm.tsx", "utf8");
  assert.doesNotMatch(form, /defaultValue=\{[^}]*password/i);
  assert.doesNotMatch(form, /value=\{[^}]*password/i);
  const actions = stripComments(readFileSync("src/server/auth/actions.ts", "utf8"));
  assert.doesNotMatch(actions, /return\s*\{[^}]*password/);
});

test("static: no sign-up, reset, magic-link or OAuth call exists in the app", () => {
  for (const f of walk("src")) {
    assert.doesNotMatch(stripComments(readFileSync(f, "utf8")), /\.signUp\(|resetPasswordForEmail|signInWithOtp|signInWithOAuth|updateUser\(|admin\.createUser|inviteUserByEmail/, f);
  }
});
