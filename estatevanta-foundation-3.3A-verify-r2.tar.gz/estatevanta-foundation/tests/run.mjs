// Runs every tests/*.test.ts.
//
//   npm test            (after `npm install`; esbuild is a devDependency)
//   node tests/run.mjs  (same thing)
//
// It bundles each test with esbuild (so the "@/" alias and the stand-ins in tests/mocks work), then runs `node --test`.
// esbuild is found the way Node finds any package: in this project's node_modules. A global install (`npm i -g`) is NOT
// found by an ES module import, so do not rely on one. Offline fallback: point ESBUILD_MODULE at an esbuild copy, e.g.
//   ESBUILD_MODULE=/path/to/node_modules/esbuild/lib/main.js node tests/run.mjs
// (and TEST_NODE_PATHS=/dir/containing/node_modules, colon-separated, if react / react-dom live elsewhere).
// The stand-ins replace next/*, @supabase/ssr and server-only. NOTHING here talks to Supabase, and a pass is NOT a
// substitute for `next build` or for a test against real Supabase Auth.
import { spawnSync } from "node:child_process";
import { mkdtempSync, readdirSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
process.chdir(root); // some tests read source files by relative path

let esbuild;
try {
  esbuild = await import(process.env.ESBUILD_MODULE ? pathToFileURL(process.env.ESBUILD_MODULE).href : "esbuild");
} catch {
  console.error("esbuild was not found in this project. Run `npm install` in the project root (esbuild is a devDependency), or set ESBUILD_MODULE to the path of an esbuild lib/main.js. A global install is not found by this script.");
  process.exit(2);
}
const { build } = esbuild.build ? esbuild : esbuild.default;

const mocks = join(root, "tests", "mocks");
const alias = {
  "@": join(root, "src"),
  "server-only": join(mocks, "server-only.ts"),
  "next/navigation": join(mocks, "next-navigation.ts"),
  "next/link": join(mocks, "next-link.tsx"),
  "next/headers": join(mocks, "next-headers.ts"),
  "next/cache": join(mocks, "next-cache.ts"),
  "next/server": join(mocks, "next-server.ts"),
  "@supabase/ssr": join(mocks, "supabase-ssr.ts"),
};
const nodePaths = process.env.TEST_NODE_PATHS ? process.env.TEST_NODE_PATHS.split(":") : [];
const out = mkdtempSync(join(tmpdir(), "ev-tests-"));
const tests = readdirSync(join(root, "tests")).filter((f) => f.endsWith(".test.ts"));
const bundles = [];
for (const file of tests) {
  const outfile = join(out, file.replace(/\.ts$/, ".mjs"));
  await build({
    entryPoints: [join(root, "tests", file)], outfile, bundle: true, platform: "node", format: "esm", jsx: "automatic", alias, nodePaths, logLevel: "error",
    banner: { js: 'import {createRequire as __cr} from "module"; const require = __cr(import.meta.url);' },
  });
  bundles.push(outfile);
}
const result = spawnSync(process.execPath, ["--test", ...bundles], { stdio: "inherit", cwd: root });
process.exit(result.status ?? 1);
