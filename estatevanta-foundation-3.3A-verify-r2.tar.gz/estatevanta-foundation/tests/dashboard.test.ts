// Phase 3.2 Step 3 — logic tests for the dashboard data boundary (node:test; no extra dependency).
//
// The numbers below are TEST FIXTURES only. They mirror what public.dashboard_summary() returned in the local
// database replica for hand-built test data (supabase/tests/phase3_2_dashboard_tests.sql, 100/100 passing). They are
// never imported by the app. No call is made to Supabase; the "client" is a stand-in object that records its calls.
//
// Run (no test runner is installed in the repo because no dependency may be added yet). Bundle with any TS tool that
// understands the "@/" alias in tsconfig.json, then:  node --test <bundle>.mjs
import test from "node:test";
import assert from "node:assert/strict";
import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";
import { CARDS, CARD_KEYS, type CardKey } from "@/lib/dashboard/cards";
import { loadDashboard, type DashboardRpcClient } from "@/lib/dashboard/load";
import { isEmptyCrm, notLoadedCards, parseDashboardSummary, permits, resolveCards, describeWarning, type Scope } from "@/lib/dashboard/summary";
import { formatCount, formatGeneratedAt } from "@/lib/dashboard/format";
import type { Access } from "@/lib/access";

// ---------- fixtures ----------------------------------------------------------------------------
const SQL_ORDER: CardKey[] = [
  "active_inventory", "listings_due_verification", "open_leads", "new_leads_uncontacted", "hot_leads", "overdue_followups",
  "buyers_active_requirements", "sellers_awaiting_contact", "matches_ready_to_share", "appointments_today",
  "appointments_awaiting_outcome", "overdue_tasks", "open_deals",
];

function payload(values: (number | null)[], scopes: (Scope | null)[], warnings: string[] = []) {
  const cards: Record<string, unknown> = {};
  SQL_ORDER.forEach((key, i) => {
    const v = values[i] ?? null;
    cards[key] = v === null ? { available: false, value: null, scope: null } : { available: true, value: v, scope: scopes[i] };
  });
  return { schema_version: 1, generated_at: "2026-10-09T06:45:00.000Z", timezone: "Asia/Kolkata", warnings, cards };
}
const ALL: Scope[] = Array(13).fill("all");
const AGENT_SCOPES: Scope[] = ["all", ...Array<Scope>(12).fill("assigned")];

const ADMIN = payload([5, 3, 6, 1, 3, 2, 3, 2, 4, 2, 3, 2, 4], ALL);
const AGENT = payload([5, 1, 2, 1, 2, 1, 2, 1, 3, 1, 2, 1, 2], AGENT_SCOPES);
const VIEWER = payload([5, 3, 6, 1, 3, 2, 3, 2, 4, 2, 3, 2, null], ALL);
const EMPTY = payload(Array(13).fill(0), ALL);

// Permissions as seeded in the live database for the modules the dashboard uses.
const SEED = {
  admin: ["properties.read_all", "properties.read_active", "properties.read", "leads.read_all", "leads.read", "buyers.read_all", "buyers.read", "sellers.read_all", "sellers.read", "matching.read_all", "matching.read", "appointments.read_all", "appointments.read", "tasks.read_all", "tasks.read", "deals.read_all", "deals.read"],
  agent: ["properties.read_active", "properties.read", "leads.read", "buyers.read", "sellers.read", "matching.read", "appointments.read", "tasks.read", "deals.read"],
  viewer: ["properties.read_all", "leads.read_all", "buyers.read_all", "sellers.read_all", "matching.read_all", "appointments.read_all", "tasks.read_all"],
} as const;
const access = (role: string, permissions: readonly string[]): Access => ({ userId: "00000000-0000-4000-8000-000000000001", fullName: null, role, permissions });

function client(result: { data?: unknown; error?: { code?: string | null; message?: string | null } | null } | "throw") {
  const calls: unknown[][] = [];
  const c: DashboardRpcClient = {
    rpc: (...args: unknown[]) => {
      calls.push(args);
      if (result === "throw") return Promise.reject(new Error("connect ECONNREFUSED secret-host:5432"));
      return Promise.resolve({ data: result.data ?? null, error: result.error ?? null });
    },
  } as DashboardRpcClient;
  return { c, calls };
}

// ---------- the 13 cards ------------------------------------------------------------------------
test("exactly the 13 approved cards, unique, in two groups", () => {
  assert.equal(CARD_KEYS.length, 13);
  assert.equal(new Set(CARD_KEYS).size, 13);
  assert.equal(CARDS.length, 13);
  assert.deepEqual([...CARDS.map((c) => c.key)].sort(), [...SQL_ORDER].sort());
  assert.equal(CARDS.filter((c) => c.group === "attention").length, 6);
  assert.equal(CARDS.filter((c) => c.group === "pipeline").length, 7);
  assert.deepEqual(CARDS.filter((c) => c.dealData).map((c) => c.key), ["open_deals"]);
});

test("card definitions contain no money wording and no numbers", () => {
  const text = CARDS.map((c) => `${c.label} ${c.area} ${c.help}`).join(" ");
  assert.doesNotMatch(text, /(₹|\bRs\.?\b|\bINR\b|price|amount|commission|payment|revenue|brokerage)/i);
  assert.doesNotMatch(text, /\d/);
});

// ---------- strict parser -----------------------------------------------------------------------
test("parser accepts the real response shape for every role", () => {
  for (const p of [ADMIN, AGENT, VIEWER, EMPTY]) assert.equal(parseDashboardSummary(p).ok, true);
});

test("parser fails closed on anything unexpected (including any money field)", () => {
  const bad = (mutate: (p: any) => void, why?: string) => {
    const p = structuredClone(ADMIN) as any; mutate(p);
    const r = parseDashboardSummary(p);
    assert.equal(r.ok, false, why ?? "");
  };
  bad((p) => { p.total_commission = 1; }, "extra top-level field");
  bad((p) => { p.cards.open_deals.amount = 1; }, "extra field inside a card");
  bad((p) => { p.cards.open_deals.price = 1; }, "price field inside a card");
  bad((p) => { p.cards.revenue = { available: true, value: 1, scope: "all" }; }, "extra card");
  bad((p) => { delete p.cards.open_leads; }, "missing card");
  bad((p) => { p.cards.open_leads.value = -1; }, "negative");
  bad((p) => { p.cards.open_leads.value = 1.5; }, "fraction");
  bad((p) => { p.cards.open_leads.value = "6"; }, "string number");
  bad((p) => { p.cards.open_leads.value = Number.NaN; }, "NaN");
  bad((p) => { p.cards.open_leads.value = 2_000_000_000; }, "absurdly large");
  bad((p) => { p.cards.open_leads.value = null; }, "available but no value");
  bad((p) => { p.cards.open_leads.scope = "everyone"; }, "bad scope");
  bad((p) => { p.cards.open_leads.scope = null; }, "available without scope");
  bad((p) => { p.cards.open_deals = { available: false, value: 0, scope: null }; }, "unavailable card carrying 0");
  bad((p) => { p.cards.open_deals = { available: false, value: null, scope: "all" }; }, "unavailable card carrying scope");
  bad((p) => { p.cards.open_leads.available = "yes"; }, "non-boolean available");
  bad((p) => { p.schema_version = 2; }, "other schema version");
  bad((p) => { p.generated_at = "not a date"; }, "bad date");
  bad((p) => { p.timezone = ""; }, "empty timezone");
  bad((p) => { p.warnings = "none"; }, "warnings not array");
  bad((p) => { p.warnings = ["<script>"]; }, "warning code not a code");
  for (const junk of [null, undefined, 1, "x", [], [ADMIN]]) assert.equal(parseDashboardSummary(junk).ok, false);
});

// ---------- cards the page draws ----------------------------------------------------------------
test("an unavailable card has no value at all, and a loaded zero is a different state", () => {
  const parsed = parseDashboardSummary(VIEWER);
  assert.ok(parsed.ok);
  const cards = resolveCards(parsed.summary, SEED.viewer);
  const deals = cards.find((c) => c.def.key === "open_deals")!;
  assert.equal(deals.state, "unavailable");
  assert.equal("value" in deals, false, "an unavailable card must not even carry a value");

  const parsedEmpty = parseDashboardSummary(EMPTY);
  assert.ok(parsedEmpty.ok);
  const zero = resolveCards(parsedEmpty.summary, SEED.admin).find((c) => c.def.key === "open_leads")!;
  assert.equal(zero.state, "loaded");
  assert.equal((zero as { value: number }).value, 0);
});

test("role behaviour: admin/manager see 13, agent 13 (own scope), viewer 12 with deals unavailable", () => {
  const view = (p: unknown, perms: readonly string[]) => {
    const parsed = parseDashboardSummary(p); assert.ok(parsed.ok);
    return resolveCards(parsed.summary, perms);
  };
  const adm = view(ADMIN, SEED.admin);
  assert.equal(adm.filter((c) => c.state === "loaded").length, 13);
  assert.deepEqual(adm.map((c) => c.def.key), CARDS.map((c) => c.key), "display order follows the registry");

  const agt = view(AGENT, SEED.agent);
  assert.equal(agt.filter((c) => c.state === "loaded").length, 13);
  const scopes = Object.fromEntries(agt.map((c) => [c.def.key, c.state === "loaded" ? c.scope : null]));
  assert.equal(scopes.active_inventory, "all");
  for (const k of CARD_KEYS) if (k !== "active_inventory") assert.equal(scopes[k], "assigned", k);

  const vwr = view(VIEWER, SEED.viewer);
  assert.equal(vwr.filter((c) => c.state === "loaded").length, 12);
  assert.deepEqual(vwr.filter((c) => c.state === "unavailable").map((c) => c.def.key), ["open_deals"]);
});

test("defence in depth: a figure the role has no permission for is dropped even if the response says available", () => {
  // A (hypothetical) wrong response gives a viewer the deals figure. The UI still refuses to draw it.
  const tampered = structuredClone(VIEWER) as any;
  tampered.cards.open_deals = { available: true, value: 99, scope: "all" };
  const parsed = parseDashboardSummary(tampered);
  assert.ok(parsed.ok);
  const deals = resolveCards(parsed.summary, SEED.viewer).find((c) => c.def.key === "open_deals")!;
  assert.equal(deals.state, "unavailable");
  assert.equal(JSON.stringify(deals).includes("99"), false);
  // No permissions at all -> nothing is drawn.
  const none = resolveCards(parsed.summary, []);
  assert.equal(none.every((c) => c.state === "unavailable"), true);
  assert.equal(permits(CARDS.find((c) => c.key === "open_deals")!, SEED.viewer), false);
  assert.equal(permits(CARDS.find((c) => c.key === "open_deals")!, SEED.agent), true);
});

test("listings due: an agent with only read_active (no read) cannot see it, matching the SQL gate", () => {
  const def = CARDS.find((c) => c.key === "listings_due_verification")!;
  assert.equal(permits(def, ["properties.read_active"]), false);
  assert.equal(permits(def, ["properties.read"]), true);
  assert.equal(permits(def, ["properties.read_all"]), true);
});

test("empty-CRM detection", () => {
  const empty = parseDashboardSummary(EMPTY); assert.ok(empty.ok);
  assert.equal(isEmptyCrm(resolveCards(empty.summary, SEED.admin)), true);
  const admin = parseDashboardSummary(ADMIN); assert.ok(admin.ok);
  assert.equal(isEmptyCrm(resolveCards(admin.summary, SEED.admin)), false);
  assert.equal(isEmptyCrm(resolveCards(empty.summary, [])), false, "nothing loaded is not 'empty'");
  assert.equal(isEmptyCrm(notLoadedCards()), false, "not-connected is not 'empty'");
});

test("not-connected cards carry no figures", () => {
  const cards = notLoadedCards();
  assert.equal(cards.length, 13);
  for (const c of cards) { assert.equal(c.state, "not_loaded"); assert.equal("value" in c, false); }
});

// ---------- the fetch boundary ------------------------------------------------------------------
test("loadDashboard: calls dashboard_summary exactly once, with no arguments", async () => {
  const { c, calls } = client({ data: ADMIN });
  const r = await loadDashboard(c, access("admin", SEED.admin));
  assert.equal(r.kind, "ok");
  assert.equal(calls.length, 1);
  assert.deepEqual(calls[0], ["dashboard_summary"]);
});

test("loadDashboard: ok results for each role", async () => {
  for (const [p, perms] of [[ADMIN, SEED.admin], [AGENT, SEED.agent], [VIEWER, SEED.viewer]] as const) {
    const r = await loadDashboard(client({ data: p }).c, access("x", perms));
    assert.equal(r.kind, "ok");
    if (r.kind === "ok") { assert.equal(r.cards.length, 13); assert.equal(r.empty, false); }
  }
  const e = await loadDashboard(client({ data: EMPTY }).c, access("admin", SEED.admin));
  assert.equal(e.kind === "ok" && e.empty, true);
});

test("loadDashboard: warnings are passed through", async () => {
  const r = await loadDashboard(client({ data: payload(Array(13).fill(0), ALL, ["app_timezone_fallback"]) }).c, access("admin", SEED.admin));
  assert.equal(r.kind === "ok" && r.warnings[0], "app_timezone_fallback");
  assert.match(describeWarning("app_timezone_fallback"), /timezone/i);
  assert.match(describeWarning("something_new"), /default/i);
});

test("loadDashboard: errors map to safe states and never leak raw messages", async () => {
  const a = access("agent", SEED.agent);
  const inactive = await loadDashboard(client({ error: { code: "42501", message: "dashboard_summary: no active profile for this user" } }).c, a);
  assert.deepEqual(inactive, { kind: "unauthorized", reason: "inactive" });
  const expired = await loadDashboard(client({ error: { code: "PGRST301", message: "JWT expired" } }).c, a);
  assert.deepEqual(expired, { kind: "unauthorized", reason: "signed_out" });
  const other = await loadDashboard(client({ error: { code: "XX000", message: "SECRET internal detail table=deals" } }).c, a);
  assert.deepEqual(other, { kind: "error", code: "XX000" });
  assert.equal(JSON.stringify(other).includes("SECRET"), false);
  const weird = await loadDashboard(client({ error: { code: "bad code with spaces & a very long tail", message: "x" } }).c, a);
  assert.deepEqual(weird, { kind: "error", code: "unknown" });
  const nocode = await loadDashboard(client({ error: { message: "x" } }).c, a);
  assert.deepEqual(nocode, { kind: "error", code: "unknown" });
  const thrown = await loadDashboard(client("throw").c, a);
  assert.deepEqual(thrown, { kind: "error", code: "network" });
  assert.equal(JSON.stringify(thrown).includes("secret-host"), false);
});

test("loadDashboard: a malformed or money-carrying response is rejected whole", async () => {
  const a = access("admin", SEED.admin);
  for (const data of [null, {}, "ok", { ...ADMIN, total_commission: 1 }, { ...ADMIN, cards: { ...ADMIN.cards, open_deals: { available: true, value: 4, scope: "all", amount: 1 } } }]) {
    const r = await loadDashboard(client({ data }).c, a);
    assert.deepEqual(r, { kind: "error", code: "bad_response" });
  }
});

// ---------- formatting --------------------------------------------------------------------------
test("formatting", () => {
  assert.equal(formatCount(0), "0");
  assert.equal(formatCount(1234567), "12,34,567");
  assert.match(formatGeneratedAt("2026-10-09T06:45:00.000Z", "Asia/Kolkata"), /9 Oct.*12:15/);
  assert.match(formatGeneratedAt("2026-10-09T06:45:00.000Z", "Not/AZone"), /Oct/); // falls back, never throws
  assert.equal(formatGeneratedAt("garbage", "Asia/Kolkata"), "");
});

// ---------- static guards on the source ---------------------------------------------------------
function walk(dir: string): string[] {
  return readdirSync(dir).flatMap((n) => {
    const p = join(dir, n);
    return statSync(p).isDirectory() ? walk(p) : /\.(ts|tsx)$/.test(n) ? [p] : [];
  });
}
const DASH_FILES = [
  ...walk("src/lib/dashboard"), ...walk("src/components/dashboard"), ...walk("src/server/dashboard"), ...walk("src/app/(app)/dashboard"),
];

test("dashboard code never reaches the service-role client, a table, or any other RPC", () => {
  assert.ok(DASH_FILES.length >= 10);
  for (const f of DASH_FILES) {
    // Comments may mention the admin client to say it is NOT used; only code is checked.
    const s = readFileSync(f, "utf8").replace(/\/\*[\s\S]*?\*\/|(^|[^:])\/\/[^\n]*/g, "$1");
    assert.doesNotMatch(s, /SERVICE_ROLE|admin-client|createAdminClient/i, f);
    assert.doesNotMatch(s, /\.from\(\s*["'`]/, `${f}: direct table access`);
    assert.doesNotMatch(s, /\.sql\b|\bexecute_sql\b/, f);
    for (const m of s.matchAll(/\.rpc\(\s*([^),]*)/g)) assert.ok(["fn", "dashboard_summary"].includes(m[1]?.trim().replace(/["'`]/g, "") ?? ""), `${f}: unexpected rpc target ${m[1]}`);
  }
  const server = readFileSync("src/server/dashboard/summary.ts", "utf8");
  assert.match(server, /import "server-only"/);
  assert.match(server, /createUserClient/);
});

test("the only literal rpc name in the dashboard code is dashboard_summary", () => {
  const all = DASH_FILES.map((f) => readFileSync(f, "utf8")).join("\n");
  const names = new Set([...all.matchAll(/rpc\(\s*"([a-z_]+)"/g)].map((m) => m[1]));
  assert.deepEqual([...names], ["dashboard_summary"]);
});

test("no demo data: dashboard source holds no numeric figures for cards", () => {
  for (const f of DASH_FILES.filter((p) => p.includes("components/dashboard") || p.includes("lib/dashboard/cards"))) {
    const s = readFileSync(f, "utf8").replace(/\/\/[^\n]*|\/\*[\s\S]*?\*\//g, "");
    assert.doesNotMatch(s, /value:\s*\d|count:\s*\d|total:\s*\d/, f);
  }
});
