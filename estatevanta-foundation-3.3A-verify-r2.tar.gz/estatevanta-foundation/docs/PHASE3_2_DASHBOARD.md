# Phase 3.2 — `dashboard_summary()` (tested locally; APPLIED LIVE 2026-10-08 as migration `20261008052244 estatevanta_p3_2_dashboard_summary`)

> Live status: applied once to project `bmvozgfjrvdrfdhvfray` after read-only preflight; postflight confirmed only the new function
> changed (functions 23 → 24; policy/trigger/table-grant/role-permission/settings/row-count/sequence fingerprints identical; live body md5
> `981bda50…` equals the locally tested body). Real Supabase Auth / PostgREST-with-JWT happy-path calls are still UNVERIFIED (no users exist).
> The SQL file header still says "NOT APPLIED" because the file was applied byte-for-byte as tested; this note is the source of truth.
> The sections below were written before the live apply.

Status: migration `supabase/migrations/0012a_phase3_step2_dashboard_summary.sql`, rollback
`supabase/migrations/rollback/0012a_rollback.sql`, tests `supabase/tests/phase3_2_dashboard_tests.sql`,
driver `supabase/tests/phase3_2_local_run.sh`, read-only fingerprint `supabase/tests/phase3_2_fingerprint_readonly.sql`.
Live project state when this was written: 5 migrations (through 3.0), no `dashboard_summary`, 0 users / 0 profiles /
0 business rows, 170 audit rows. Nothing in this phase has been run against Supabase except read-only SELECTs.

## Authorization matrix (live RLS is the source of truth)

Permission seed (identical on the local replica and live, verified by checksum). A = admin, M = manager, G = agent, V = viewer.

| module | read_all | read | other |
|---|---|---|---|
| properties | A M V | A M G | read_active: A M G · write_all: A M · write: A M G |
| leads / buyers / sellers / appointments / tasks | A M V | A M G | |
| matching | A M V | A M G | |
| deals | A M | A M G | viewer: none |

Common row rule on leads, buyers, sellers, appointments, tasks, deals:
`(deleted_at IS NULL OR app.is_admin()) AND (<m>.read_all OR (<m>.read AND (assigned_to = auth.uid() OR created_by = auth.uid())))`.
Admin therefore also sees soft-deleted rows, which is why every count filters `deleted_at IS NULL` itself.

| # | Card | Source tables | Admin RLS | Manager RLS | Agent RLS | Viewer RLS | Function scope |
|---|---|---|---|---|---|---|---|
| 1 | active_inventory | properties | all (+deleted) | all | all active (read_active) + own | all | RLS rows, `deleted_at IS NULL`, status in available/reserved/under_negotiation. Agent scope label `all` |
| 2 | listings_due_verification | properties | all | all | all active + own | all | admin/manager/viewer: RLS rows. **Agent: additionally only `assigned_to`/`created_by` = self** (narrowing, never broader). Due = `last_verified_at` null or older than `property.reverify_days` |
| 3 | open_leads | leads, lead_statuses | all (+deleted) | all | own | all | RLS rows, not deleted, status not `is_terminal` |
| 4 | new_leads_uncontacted | leads | all | all | own | all | `status_code='new' AND last_contact_at IS NULL AND deleted_at IS NULL` |
| 5 | hot_leads | leads, lead_statuses, settings | all | all | own | all | open + `priority` in `leads.hot_priorities` |
| 6 | overdue_followups | leads, lead_statuses | all | all | own | all | open + `next_follow_up_at < now()` |
| 7 | buyers_active_requirements | buyers, buyer_requirements | all | all | own (needs buyers.read) | all | active buyer, not deleted, with ≥1 requirement `status='active'` and not deleted (distinct buyers) |
| 8 | sellers_awaiting_contact | sellers | all | all | own | all | `relationship_status='new'`, not deleted |
| 9 | matches_ready_to_share | property_matches → buyer_requirements → buyers, properties | via requirement→buyer | same | via visible requirement→own buyer | same | match `suggested`; requirement active+not deleted; buyer active+not deleted; property active+not deleted. `property_matches` has no `deleted_at` column |
| 10 | appointments_today | appointments, settings | all | all | own | all | `scheduled`/`confirmed` only, `starts_at` inside today's local day in `app.timezone` |
| 11 | appointments_awaiting_outcome | appointments | all | all | own | all | `scheduled`/`confirmed` only and `starts_at < now()` |
| 12 | overdue_tasks | tasks | all | all | own | all | status pending/in_progress, `due_at < now()`, not deleted |
| 13 | open_deals | deals | all (+deleted) | all | own | **none** | count of `status NOT IN (closed, cancelled)`, not deleted. Query is not run without deals.read/read_all. Count only |

## Contract

`public.dashboard_summary() returns jsonb` — no arguments, SECURITY INVOKER, STABLE, `search_path = public, extensions, pg_temp`,
EXECUTE for `authenticated` only (revoked from PUBLIC, anon, service_role).

```
{ "schema_version": 1, "generated_at": <timestamptz>, "timezone": "Asia/Kolkata",
  "warnings": [ "app_timezone_fallback" | "leads_hot_priorities_fallback" | "property_reverify_days_fallback" ],
  "cards": { "<key>": { "available": bool, "value": int|null, "scope": "all"|"assigned"|null }, ... 13 keys } }
```
`available:false` = caller lacks the permission (value and scope null) — never rendered as 0. Errors: signed-out/anon and
`service_role` → 42501 (no EXECUTE); authenticated without an active profile+role (unknown, inactive, role-less or soft-deleted) → 42501;
malformed JWT subject → 22P02. All counts come from one STABLE call, so they share one snapshot.

Settings are validated, never trusted: invalid/missing `app.timezone`, `leads.hot_priorities` or `property.reverify_days`
fall back to Asia/Kolkata / ["high","urgent"] / 30 and add a warning code instead of failing the dashboard
(`[]` for hot priorities is valid and means none). The existing `v_properties_due_verification` view is deliberately not reused:
it casts the setting to integer and would raise on a malformed value.

UI note (F5): Card 9 will be 0 until the Phase 6 engine writes suggestions; show "No ready matches yet", not an error state.

## Schema/proposal corrections found while verifying
1. `property_matches` has no `deleted_at`; soft-delete and active filters are applied to its parents (requirement, buyer, property).
2. `buyer_requirements` RLS checks only the parent buyer, not its own `deleted_at`; the function filters it.
3. `properties.owner_id` references a seller, not a user. "Owns" for agents therefore means `created_by`/`assigned_to`.
4. Viewer holds `.read_all` only (no `.read` / `read_active`); gates accept either permission, so this works.
5. `lead_statuses.is_active` exists; it is deliberately ignored: a lead sitting in a deactivated status is still open.
6. The proposal's "admin/manager = all, agent = assigned, viewer = all" was too coarse: agents see all active inventory, and the
   verification card is narrowed for agents on purpose (F1).

## Local test result (throwaway Postgres 16 replica, repo migrations replayed)
Replica fidelity vs live (same read-only fingerprint query on both): policies 139 identical, triggers 57 identical, RLS flags,
role_permissions 147, settings, lead_statuses identical. Differences: table grants differ only by PG17's extra MAINTAIN
privilege; `app.audit_row()` body on live differs from the repo file only by a stripped comment/whitespace (same logic).
Replica is Postgres 16.15; live is 17.6.

`phase3_2_local_run.sh`: migration applies; only the `functions` fingerprint changes (23 → 24); test suite 100 PASS / 0 FAIL;
state identical after the tests; rollback restores the baseline fingerprint exactly. Five deliberate mutations
(drop deleted filter, drop deals gate, drop agent scoping, include `rescheduled`, drop match-parent filter) were each caught.

Not covered by local tests: real Supabase Auth / PostgREST with a signed JWT, PG17-specific behaviour, performance on
realistic data volumes.
