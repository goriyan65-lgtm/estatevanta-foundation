# Phase 3.1: app shell (code only)

Status: code written; **not yet installed or built on a machine with npm access** (see "What was and was not verified").
No database change, no migration, no user, no data. Phase 3.2 (dashboard cards, `dashboard_summary()`) is not started.

## Routes

| Route | Purpose | Visible when the user has ANY of |
|---|---|---|
| `/` | redirects to `/dashboard` | n/a |
| `/dashboard` | empty state; cards come in Phase 3.2 | any active user |
| `/properties` | empty state | `properties.read`, `properties.read_all`, `properties.read_active` |
| `/buyers` | empty state | `buyers.read`, `buyers.read_all` |
| `/sellers` | empty state | `sellers.read`, `sellers.read_all` |
| `/leads` | empty state | `leads.read`, `leads.read_all` |
| `/matching` | empty state | `matching.read`, `matching.read_all` |
| `/appointments` | empty state | `appointments.read`, `appointments.read_all` |
| `/deals` | empty state | `deals.read`, `deals.read_all` |
| `/analytics` | empty state | `analytics.read` |
| `/market` | empty state | `market.read`, `market.read_all` |
| `/settings` | empty state | `settings.manage`, `users.manage` |
| `/login` | placeholder: no form, no credentials, no auth call | public |
| `/dev/states` | development-only gallery of the shared states; 404 in production | n/a |

The rules live in one file, `src/lib/nav.ts`. They mirror the permission codes seeded in the database. The browser only
uses them to decide what to show; Row Level Security stays the real authority.

## How access works in 3.1

`src/server/auth/session.ts` returns an `AccessState` and is the **only** place that will change when auth is connected.

> Superseded by Phase 3.3A. The development-only `shell_preview` state and the placeholder `/login` described in the original 3.1 text **no longer exist**. Development now fails closed exactly like production. Current behaviour: `docs/PHASE3_3A_AUTH.md`.

- `getAccessState()` verifies a real Supabase session and returns one of: `ready`, `signed_out`, `inactive`, `unconfigured`, `error`. Only `ready` renders section content. Each section can also be `forbidden` for a role without the permission.
- `signed_out` redirects to `/login`; every other non-ready state shows a gate screen and no navigation.

## Connecting authentication later (Phase 3.3, needs its own approval)

> Done in code in Phase 3.3A, with changes from this plan: see `docs/PHASE3_3A_AUTH.md`. Not verified against real Supabase.

Replace the body of `getAccessState()` only:

1. If `NEXT_PUBLIC_SUPABASE_URL` or `NEXT_PUBLIC_SUPABASE_ANON_KEY` is missing: `{ status: "unconfigured" }`.
2. `createUserClient()` (anon key + the user's cookie session) then `supabase.auth.getUser()`. This verifies the token with Supabase; never trust `getSession()` on the server. No user: `{ status: "signed_out" }`.
3. `supabase.rpc("my_access")` with that same client (`SECURITY INVOKER`, RLS applies, caller-only). No row or `is_active = false`: `{ status: "inactive" }`. RPC error: `{ status: "error", message }`.
4. Otherwise `{ status: "ready", access: { userId, fullName, role, permissions } }` from the RPC result.
5. Restore the signed-out wording in `UnauthorizedState`: title "Sign in to continue" with a link button to `/login` (the 3.1 wording deliberately offers no link).
6. Add `middleware.ts` to refresh the session cookie, a real `/login` page, and sign-out. The database `app` schema is not exposed to the Data API (confirmed), and `my_access` lives in `public`, so no exposed-schema change is needed.

The first-admin ceremony (arm and consume bootstrap) is a separate approval and stays out of the app code.

## Components

- Shell: `AppShell` (desktop rail from 1024px, phone top bar, phone bottom bar with four sections plus "More", slide-in menu with Escape to close, focus return, scroll lock, skip link), `icons`.
- States: `LoadingState`, `EmptyState` (with `PlotDrawing`), `ErrorState`, `UnauthorizedState` (signed out, forbidden, inactive), `AccessGate`.
- UI: `PageHeader`, `Button`, `LinkButton`.
- Modules: `ModulePage` (permission check, then the section's empty state).
- Boundaries: `(app)/loading.tsx`, `(app)/error.tsx`, `global-error.tsx`, `not-found.tsx`.

## Security notes

- No service-role key is read anywhere in this phase. `.env.example` documents that it must never use a `NEXT_PUBLIC_` name.
- Pages are `noindex`. `next.config.ts` adds baseline security headers (nosniff, frame deny, referrer policy, permissions policy, HSTS). A nonce-based Content-Security-Policy comes with the security phase.
- Fonts are the system stack, so nothing is fetched from a third party.

## What was and was not verified

Verified in the sandbox:
- TypeScript passes (`tsc`, strict, `noUncheckedIndexedAccess`) against stand-in type declarations for React and Next.
- The components were bundled with esbuild and server-rendered with React 19.2: for each of 8 access states (preview [state removed in Phase 3.3A], signed out, inactive, unconfigured, error, admin, agent, viewer) the visible navigation and the result of every section page were checked. Agent sees no Analytics, Market intel or Settings; viewer sees no Deals or Settings; non-ready states show no navigation and no section.
- A scan found no service-role reference, no Supabase call and no data fetch in the new UI code.

NOT verified (the sandbox's network blocks the npm registry, so `npm install` could not run):
- `npm install`, `next build`, real Tailwind v4 output, and the layout in a real browser at phone and desktop widths.
- `package.json` still uses `latest` ranges and there is no lockfile yet.
Run `npm install`, `npm run typecheck` and `npm run build`, then `npm run dev`, and report anything that fails.

## Post-review fixes (applied before Phase 3.2)

- `tsconfig.json`: `"types": ["node"]` (TypeScript 6 no longer includes `@types/*` automatically).
- `globals.css`: removed the global `:focus-visible { border-radius }` (it overrode component corners); the focus outline is unchanged. Removed the global `tabular-nums`; use Tailwind's `tabular-nums` class on genuinely numeric cells only (there are none in 3.1).
- `AppShell`: the open menu makes the skip link, sidebar, page and bottom bar `inert`; Escape closes; focus returns to the button that opened it (menu or "More"); growing to desktop width closes the menu.
- `AppShell` bottom bar: items can shrink (`min-w-0`), labels truncate as a safety net, labels are 10px below 375px wide.
- `/dev/states`: single-column grid uses `minmax(0,1fr)` so long text cannot widen the page.
- Signed-out wording made consistent with the placeholder `/login` (see above).
