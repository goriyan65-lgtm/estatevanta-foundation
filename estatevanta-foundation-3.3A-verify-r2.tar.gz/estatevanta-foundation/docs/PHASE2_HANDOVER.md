# Phase 2 — Final handover (read-only)

Prepared 2026-10-04 for the owner of EstateVanta. Target project: **Estate vanta crm** (`bmvozgfjrvdrfdhvfray`). The other Supabase project was never touched.
Nothing in this handover changes the database. Every live check below is a read-only query.

State of the live database right now: **0 auth users, 0 profiles, 0 business rows, bootstrap NOT armed and NOT consumed, no admin exists.**

---

## 1. Migrations applied to the live project

Source: `supabase_migrations.schema_migrations` on the live project (read just now) and `list_migrations`.

| # | Version | Name | Repo file | Status |
|---|---|---|---|---|
| 1 | 20261002090254 | estatevanta_phase1_installer | `migrations/0000_estatevanta_all.sql` (= 0001–0009) | APPLIED |
| 2 | 20261003104622 | estatevanta_p2_step1_audit_logger_access | `supabase/migrations/0010a_…` | APPLIED |
| 3 | 20261003105157 | estatevanta_p2_step2_bootstrap | `supabase/migrations/0010b_…` | APPLIED |
| 4 | 20261004102101 | estatevanta_p2_step3_admin_protection | `supabase/migrations/0010c_…` | APPLIED |

No other migration exists. Not applied and never applied: `supabase/migrations/superseded/0010_phase2_monolithic_NOT_APPLIED.sql`.
Note: the Step 3 text sent to the database is the repo file minus its comment header and with the header status line rewritten; the executable SQL is identical.

## 2. Live verification of the three Step 3 triggers and functions (read just now)

| Trigger | On table | Timing | Enabled | Function | SECURITY DEFINER | search_path | Owner | EXECUTE for anon / authenticated / service_role |
|---|---|---|---|---|---|---|---|---|
| `protect_last_admin` | `public.profiles` | BEFORE UPDATE OR DELETE, per row | yes (`O`) | `app.protect_last_admin()` | yes | `public` | postgres | no / no / no |
| `protect_system_roles` | `public.roles` | BEFORE UPDATE OR DELETE, per row | yes (`O`) | `app.protect_system_roles()` | yes | `public` | postgres | no / no / no |
| `protect_admin_permissions` | `public.role_permissions` | BEFORE UPDATE OR DELETE, per row | yes (`O`) | `app.protect_admin_permissions()` | yes | `public` | postgres | no / no / no |

Also confirmed live:
- `app.guard_profile_privileges()` contains the `deleted_at is distinct from old.deleted_at` check and is attached to `profiles` (`guard_profile_privileges`, enabled).
- Old `app.bootstrap_first_admin(uuid)` is still the disabled stub (raises 55000) and is not executable by any API role.
- `app.arm_bootstrap(text,text,int)` and `app.bootstrap_first_admin(uuid,text)`: not executable by anon / authenticated / service_role.
- `app.bootstrap_setup`: RLS on, no policies, 0 table grants to API roles, 0 rows.
- All 43 public tables have RLS; 139 public policies (unchanged by any Phase 2 step); 60 permissions; 147 role_permissions.
- `public.my_access()` executable by authenticated only; `public.security_log_event()` by service_role only; `public.find_contact_matches()` by authenticated + service_role.

## 3. Is `app` in "Exposed schemas"? — CANNOT BE VERIFIED FROM HERE

The exposed-schemas list is a Data API setting held by the Supabase platform, not by the database, so SQL cannot read it (`authenticator` role config shows no `pgrst.db_schemas`). My earlier attempt to call the REST endpoint from the sandbox was blocked by the network proxy. I therefore **cannot confirm** it. Please check: **Dashboard → Project Settings → API (or Integrations → Data API → Settings) → "Exposed schemas"**. It should list only `public` (and `graphql_public` if shown). If `app` is listed, remove it.

What the database itself shows (supporting evidence, not proof):
- anon has no USAGE on schema `app`; authenticated and service_role do (the RLS helper functions need it).
- No table in `app` has any grant to anon / authenticated / service_role.
- The three bootstrap functions and the three Step 3 trigger functions are not executable by any API role.
- The Supabase security advisor lists `app.*` objects in its findings, but that linter also scans non-exposed schemas, so this is inconclusive either way.

If `app` were exposed, the residual risk would be the Phase 1 helper functions that anon/authenticated can still execute (see gap S6).

## 4. Test results — live vs local

### LIVE (run against `bmvozgfjrvdrfdhvfray`, fully rolled back each time)
| Run | Script | Result | State afterwards |
|---|---|---|---|
| Before Step 3 | `phase2_security_tests.sql` (644-line version) | PASS 296 / FAIL 0 / GAP 3 | identical to pre-test; sequences restored |
| After Step 3 | `phase2_security_tests.sql` (717-line version) | **PASS 322 / FAIL 0 / GAP 2**, no fatal error | identical to pre-test; sequences restored |

Independent before/after row counts after the second run: auth.users 0, identities 0, profiles 0, audit_logs 170 (sequence 170), bootstrap_setup 0, roles 4 (sequence 4), permissions 60, role_permissions 147, settings 7, business rows 0, no leftover `zz_` roles or pg_temp functions, 0 `bootstrap_admin` audit rows.

The 2 remaining GAP lines are the known manager soft-delete defect on leads and properties (functional gap F1 below). All Step 3 checks (section 7 of the script) are PASS live.

### LOCAL ONLY (PostgreSQL 16 replica in the sandbox, not Supabase)
- Pre-Step-3 run of the 717-line script: PASS 307 / FAIL 1 (the intentional "Step 3 triggers installed" line) / GAP 16 (the unprotected baseline).
- Post-Step-3 scratch copy: PASS 322 / FAIL 0 / GAP 2.
- **Two real concurrent sessions** on committed data: two admins, each session deactivated one admin at the same time; one succeeded, the other was refused ("Cannot remove, demote or deactivate the last active admin"), leaving exactly one active admin.
- Rollback scripts 0010a / 0010b / 0010c and the original Step 3 SQL were validated on scratch copies only.
- Local replica differences from Supabase: mock `auth`/`storage` schemas, PG16 instead of PG17.

### NOT TESTED AT ALL
- Real sign-up through Supabase Auth (GoTrue) → profile trigger; the live tests insert `auth.users` rows directly.
- Calling `my_access()` / RLS through PostgREST with real JWTs (the tests emulate PostgREST claims).
- Email confirmation settings, redirect URLs and password policy in the Auth dashboard.

## 5. Remaining gaps

### Security
| ID | Gap | Impact / mitigation | Proposed handling |
|---|---|---|---|
| S1 | **Two-session race not tested on the live project.** Last-admin race: proven locally only. Bootstrap race: only single-session evidence (advisory lock held, shared lock key, `FOR UPDATE`, replay refused). | Design is sound and locally proven; live behaviour is the same code. Live proof needs committed temporary users. | Optional: with your explicit approval, a live two-session test using temporary users that are deleted afterwards (needs a cleanup plan; see Phase 3 step 3.6). |
| S2 | `users.manage` is effectively admin-equivalent. | Only admin holds it by default. Granting it to another role would let that role promote users to admin. | The admin UI (later phase) must not offer `users.manage` for non-admin roles. |
| S3 | No throttling on wrong bootstrap secrets. | Only the database owner can call the function. | Accept, or add attempt counter later. |
| S4 | `service_role` can write `audit_logs` directly. | By design (server-side only). Leaking the service-role key would allow forged audit rows. | Key only in server env, never in the browser or chat. |
| S5 | Viewers can read `property_documents` metadata (title, category, path), not the files. | Matches policy text from 0009. | Your decision: restrict later. |
| S6 | Phase 1 helper functions in schema `app` are executable by anon/authenticated/service_role: `apply_*_policies` (3), `next_code`, `can`, `is_admin`, `current_role_code`, `can_edit_property`, and trigger functions. | Only matters if `app` is exposed over the Data API. `apply_*` are SECURITY INVOKER (DDL fails for non-owner); trigger functions cannot be called directly; `next_code` could burn code numbers. | Phase 3 step 3.0 revokes `apply_*` and pins search_path. **I did not test calling these as authenticated.** |
| S7 | Advisor: 10 functions with mutable `search_path` (including `app.guard_profile_privileges`, which Step 3 re-created without one, as in Phase 1). | Low risk: bodies use schema-qualified names. | Phase 3 step 3.0. |
| S8 | Advisor: `citext` and `pg_trgm` live in `public`. | Moving them can break column types and indexes. | Leave as is; revisit with a tested plan. |
| S9 | The database owner can still disable a trigger or TRUNCATE; Step 3 protects against API roles and ordinary SQL, not a deliberate owner bypass. | Owner is trusted; recovery documented. | Accept. |
| S10 | "app" exposure unverified (section 3). | See above. | You check the Dashboard setting. |
| S11 | Auth settings unverified (email confirmation required, sign-ups allowed, password rules, leaked-password protection). | Bootstrap relies on a confirmed email. | Checklist in Phase 3 step 3.4. |

### Functional
| ID | Gap | Status |
|---|---|---|
| F1 | Managers holding `leads.delete` / `properties.delete` cannot soft-delete: RLS re-checks the SELECT policy on the updated row, which hides `deleted_at` rows from non-admins. Admins can. Not a security hole (it only denies). | Open. Not fixed in Phase 2 by your instruction. Proposed fix when leads/properties screens are built (Phase 4/5): SECURITY DEFINER archive/restore functions that check the `.delete` permission. |
| F2 | No admin exists and no one can log in yet; login, logout, session refresh and inactive-user block have no app code. | Phase 3. |
| F3 | `security_log_event()` has no caller yet (needs the server-side login/logout code). | Phase 3. |
| F4 | `src/` holds only helper stubs (`phone.ts`, Supabase clients); no pages. | Phase 3. |
| F5 | Existing website, lead capture from it, and any CSV import UI: REQUIRES SOURCE CODE / later phases; untouched. | Unchanged. |
| F6 | The 13 dashboard cards are not defined in the docs. | Needs your decision in step 3.2. |

## 6. Rollback scripts — not run on the live project
Evidence: the live migration list contains only the four forward migrations; all Step 1–3 objects exist and are enabled; the Step 3 guard still contains the `deleted_at` check; the old bootstrap stub and the new bootstrap objects are present. I have not executed `0010a_rollback.sql`, `0010b_rollback.sql` or `0010c_rollback.sql` anywhere except scratch copies of the local replica.

## 7. Proposed Phase 3 plan (Admin shell + dashboard) — nothing is started

Principles: one step at a time; for every step that touches the database, the exact SQL is shown to you first and I wait for your approval; each DB step gets a rollback, a live rolled-back test and a before/after count; no demo data; the service-role key is never given to me.

### 3.0 DB hardening (optional, no behaviour change)
Pins `search_path` and removes unneeded API execute rights. Proposed SQL:
```sql
alter function app.guard_profile_privileges()                set search_path = public, pg_temp;
alter function app.guard_soft_delete()                       set search_path = public, pg_temp;
alter function app.set_updated_at()                          set search_path = public, pg_temp;
alter function app.enforce_active_weights()                  set search_path = public, pg_temp;
alter function app.next_code(text, regclass)                 set search_path = public, pg_temp;
alter function app.bootstrap_first_admin(uuid)               set search_path = public, pg_temp;
alter function public.find_contact_matches(text, text, text) set search_path = public, pg_temp;

revoke execute on function app.apply_child_policies(text, text, text, text, text),
                           app.apply_global_policies(text, text),
                           app.apply_scoped_policies(text, text, text)
  from public, anon, authenticated, service_role;
```
Why safe: these bodies only use schema-qualified names (`auth.uid()`, `app.can()`) or tables in `public`; `apply_*` are used only by migrations run as owner. Not touched: `can`, `is_admin`, `current_role_code`, `can_edit_property`, `next_code` (RLS and defaults need them). Rollback: `alter function … reset search_path;` and `grant execute … to public`-equivalents (script provided at that step). Test: local replica first, then the live 322-test script again.

### 3.1 App shell (code only, no database change)
Next.js layout (sidebar on desktop, bottom nav at 360 px), login/logout pages, session refresh, route protection, "inactive/no role" screen using `public.my_access()`, empty-state components. Uses only the project URL and the publishable (anon) key. Gate checks: G1 (unauthenticated → redirect), G4, G5.

### 3.2 `dashboard_summary()` (one migration)
Decision for you first: which 13 cards. My proposal: open leads, new leads (7 days), buyers, sellers, active properties, properties due for verification, upcoming appointments, open tasks, overdue tasks, open deals, closed deals, expected commission, payments received (the last two only for finance roles).
Draft shape (final SQL will be shown after I check the enum values for deals/commissions/payments, which I have not guessed here):
```sql
create or replace function public.dashboard_summary() returns jsonb
language sql stable security invoker set search_path = public, pg_temp as $$
  select jsonb_build_object(
    'leads_open',  (select count(*) from leads l join lead_statuses s on s.code = l.status_code
                    where l.deleted_at is null and not s.is_terminal),
    'leads_new_7d',(select count(*) from leads where deleted_at is null and created_at >= now() - interval '7 days'),
    'buyers',      (select count(*) from buyers  where deleted_at is null),
    'sellers',     (select count(*) from sellers where deleted_at is null),
    'properties_active', (select count(*) from properties where deleted_at is null
                          and status in ('available','reserved','under_negotiation')),
    'properties_due_verification', (select count(*) from v_properties_due_verification),
    'appointments_upcoming', (select count(*) from appointments where deleted_at is null
                              and status = 'scheduled' and starts_at >= now()),
    'tasks_open',    (select count(*) from tasks where deleted_at is null and status in ('pending','in_progress')),
    'tasks_overdue', (select count(*) from v_overdue_tasks),
    'deals_open',    (select count(*) from deals where deleted_at is null and status not in ('closed','cancelled')),
    'deals_closed',  (select count(*) from deals where deleted_at is null and status = 'closed')
    -- 'commission_expected' and 'payments_received': added in the final SQL, finance roles only
  )
$$;
revoke all on function public.dashboard_summary() from public, anon, service_role;
grant execute on function public.dashboard_summary() to authenticated;
```
SECURITY INVOKER means RLS decides what each role counts (an agent sees only their own scope). Rollback: `drop function public.dashboard_summary();`. Test: rolled-back live test comparing the function with hand-written SQL on fixture rows, for admin / manager / agent / viewer (gate: all cards 0 on the empty DB; numbers equal hand-computed SQL).

### 3.3 Dashboard UI (code only)
Cards and charts calling `dashboard_summary()`, empty states, mobile card layout, G1–G7 checks.

### 3.4 Auth settings checklist + first-admin ceremony (real data, needs your presence)
Before: you confirm in the Dashboard that email confirmation is required and sign-ups behave as intended; I give you the checklist. Then: you create the one Auth user in the Supabase Dashboard (Authentication, Users, Add user, email confirmed; the app has no sign-up page, see `docs/PHASE3_3A_AUTH.md`); you (not me) run in the SQL Editor, with a secret only you know:
```sql
select app.arm_bootstrap('<your one-time secret>', '<your confirmed email>', 15);
select app.bootstrap_first_admin('<your auth user uuid>'::uuid, '<same secret>');
```
This creates the only real rows: 1 auth user, 1 admin profile, 1 `bootstrap_admin` audit row. I never see the secret. I verify afterwards with read-only queries.

### 3.5 Login audit wiring + real-session verification
Server code calls `public.security_log_event()` for login / logout / login_failed (service-role key stays in the server environment). Verify with your real admin: login, logout, session refresh, inactive-user block, and that the last-admin trigger refuses self-demotion.

### 3.6 Optional live two-session race test
Only with your explicit approval of a cleanup plan (temporary committed users, deleted afterwards, before/after fingerprint).

### 3.7 Phase 3 report
Verified vs not verified, state comparison, remaining gaps, then stop for your review.

---
Housekeeping: while preparing this handover only this file was added to the repo (the docs and test-script header were updated earlier, right after Step 3). No database object was changed during the handover.
