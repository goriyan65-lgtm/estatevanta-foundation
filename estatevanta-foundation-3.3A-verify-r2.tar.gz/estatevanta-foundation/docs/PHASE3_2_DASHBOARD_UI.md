# Phase 3.2, Step 3: Dashboard UI

> Update (Phase 3.3A): the `shell_preview` access state and the "not connected because sign-in is missing" wording described below no longer exist. `getAccessState()` now verifies a real Supabase session; see `docs/PHASE3_3A_AUTH.md`. The card, parsing and role behaviour described here is unchanged.

Status: code-only. No database object was created or changed in this step. Migration 0012a was applied once in Step 2 and was not touched.

## What was built

The dashboard page, drawn from the 13 approved cards, with loading, not-connected, unavailable, empty, error and unauthorized states. It reads `public.dashboard_summary()` through a narrow server-side boundary. As written in Step 3 that boundary was not connected to a real session; since Phase 3.3A it is (code only, never run against real Supabase). See `docs/PHASE3_3A_AUTH.md`.

## Files

New:

| File | Purpose |
|---|---|
| `src/lib/dashboard/cards.ts` | The 13 approved cards: label, area, help text, permission gate, link target, grouping. No numbers. |
| `src/lib/dashboard/summary.ts` | Strict, dependency-free parser for the function's response; `resolveCards` (UI-side permission gate); card states. |
| `src/lib/dashboard/load.ts` | The data-fetching boundary: one RPC call, error mapping, no raw messages leave it. |
| `src/lib/dashboard/format.ts` | en-IN count grouping; "Updated" time in the app's timezone. |
| `src/server/dashboard/summary.ts` | `server-only`. Creates the user (anon key + cookies) client and calls the loader. |
| `src/components/dashboard/StatCard.tsx` | One card, three states. |
| `src/components/dashboard/DashboardView.tsx` | Pure view of a `DashboardResult`; sections, notices. |
| `src/components/dashboard/RetryButton.tsx` | Client component, `router.refresh()`. |
| `src/app/(app)/dashboard/loading.tsx` | Skeleton, no numbers. |
| `tests/dashboard.test.ts` | 19 `node:test` tests (logic and static guards). |
| `docs/PHASE3_2_DASHBOARD_UI.md` | This file. |

Modified:

| File | Change |
|---|---|
| `src/app/(app)/dashboard/page.tsx` | Replaced the placeholder page. `force-dynamic`; access check; `getDashboard`; `DashboardView`. |
| `src/lib/nav.ts` | Dashboard empty-state wording only. |

Unchanged: `package.json` (md5 `d6d5b3ff…`), `tsconfig.json`, every migration, AppShell, `session.ts`, `admin-client.ts` (not imported by any dashboard file).

## Card to UI mapping

Display order (not SQL order). `Scope` is what the function returns; `Link` is the section opened from the card, shown only if the user may open it.

| # | Card | Group | Needs attention chip | Link | Gate (any of) |
|---|---|---|---|---|---|
| 1 | Appointments today | Today and needs attention | no | Appointments | appointments.read_all / read |
| 2 | Appointments awaiting outcome | Today… | yes, if > 0 | Appointments | appointments.read_all / read |
| 3 | Overdue lead follow-ups | Today… | yes | Leads | leads.read_all / read |
| 4 | Overdue tasks | Today… | yes | Appointments | tasks.read_all / read |
| 5 | New leads awaiting first contact | Today… | yes | Leads | leads.read_all / read |
| 6 | Listings due for re-verification | Today… | yes | Properties | properties.read_all / read (not read_active alone) |
| 7 | Open leads | Pipeline and inventory | no | Leads | leads.read_all / read |
| 8 | Hot leads | Pipeline… | no | Leads | leads.read_all / read |
| 9 | Buyers with active requirements | Pipeline… | no | Buyers | buyers.read_all / read |
| 10 | Sellers awaiting first contact | Pipeline… | no | Sellers | sellers.read_all / read |
| 11 | Matches ready to share | Pipeline… | no | Matching engine | matching.read_all / read |
| 12 | Active inventory | Pipeline… | no | Properties | properties.read_all / read_active / read |
| 13 | Open deals (count only) | Pipeline… | no | Deals | deals.read_all / read |

Matches ready to share with a real value of 0 shows "No ready matches yet" and "Suggested matches will appear here once the matching engine is running. It isn't built yet." (screen readers also hear "0 matches"). A value above 0 would show the number.

## Card states

| State | When | What is drawn | Can it show 0? |
|---|---|---|---|
| loaded | function said `available: true` and the role has the permission | the figure, scope text ("All records" / "Your records") | Only a real 0 returned by the database |
| unavailable | function said `available: false`, or the role lacks the permission | lock icon, "Not available for your role." | No: the type has no value |
| not_loaded | no data connection exists | plug icon, "Not loaded. The data connection isn't available yet." | No: the type has no value |

Page-level results: `not_connected` (notice + 13 not-loaded cards), `ok` (cards; "Nothing to count yet" notice when every loaded card is 0; settings-warning notice when the function returned warnings), `unauthorized` (inactive or signed out, via `UnauthorizedState`), `error` (safe reference code and a retry button).

## Data-fetching boundary

```
page.tsx  ->  getAccessState()            (session.ts: verifies the Supabase session, see docs/PHASE3_3A_AUTH.md)
          ->  getDashboard(state)         (src/server/dashboard/summary.ts, server-only)
                unconfigured   -> { kind: "not_connected" }   no client created, no cookie read, NO call
                any other non-ready state -> unauthorized     no client created, NO call
                ready          -> createUserClient() (anon key + the user's cookies, RLS applies)
                                  -> loadDashboard(adapter, access)
          ->  <DashboardView result openable />   (pure; fetches nothing)
```

- The adapter exposes only `rpc("dashboard_summary")` with no arguments.
- `loadDashboard` calls it exactly once. A thrown error becomes `error/network`. Code `42501` becomes unauthorized/inactive; `PGRST301`/`PGRST302` become unauthorized/signed_out; any other code is passed through only if it looks like a short code, otherwise `unknown`. Raw messages never leave the function.
- The response is parsed strictly. Any unknown field (for example a money field), a missing or extra card, a wrong `schema_version`, or a value that is not an integer from 0 to 1,000,000,000 rejects the whole response (`bad_response`). Nothing is drawn from a rejected response.
- The service-role client is not imported by any dashboard file (a test checks this).
- No `.from()` table access anywhere in the dashboard code.

## Role behavior

Verified against fixtures that mirror the Step 2 SQL test results (scratchpad only, never in `src`):

- Admin and manager: 13 cards loaded, all records.
- Agent: 13 cards loaded; Active inventory is "All records", the other 12 are "Your records", with an explanation line.
- Viewer: 12 cards loaded; Open deals is "Not available for your role", no figure, no link.
- Defence in depth: if a response ever said a viewer's deals card was available, the UI still refuses to draw it, because the role has no `deals.*` permission.
- Cards link only to sections the user can open (an agent has no links to Analytics, Market or Settings).
- No money value exists anywhere in the response contract or the UI. Open deals is a count.

## Verification: what was actually run

Run here, all passing:

1. **Static import and route check** (`tools/static_check.py`): 47 files, no unresolved imports, no server-only or env access reachable from client code, 14 routes, no broken links.
2. **Type check** (`tsc --strict --noUncheckedIndexedAccess`) over `src/lib`, `src/components`, `src/app`, `src/server`: exit 0. This used **hand-written stand-in typings** for `next`, `react`, `@supabase/*`, because the npm registry is unreachable here. It is not a substitute for `next build`.
3. **Logic and static-guard tests** (`tests/dashboard.test.ts`, bundled with esbuild, run with `node --test`): 19 of 19 pass. Two failed at first; both were mistakes in the test (a wrong property name, and a guard that matched a comment); the app code did not change. The service-role guard was mutation-checked: adding an admin-client import makes it fail.
4. **Chromium render checks** (Playwright with the system Chromium, Tailwind compiled from the real `globals.css`, the real `AppShell`, the real `DashboardView` fed by the real `loadDashboard` with stand-in RPC clients): **441 of 441 checks pass**.
   - Scenarios: admin, agent, viewer, empty CRM, zero matches, settings warnings, large number, not connected, error, rejected (money-carrying) response, inactive, signed out.
   - Widths: 320, 360, 412, 768, 1024, 1280 px, each in light and dark.
   - Checks: no horizontal scroll; no element past the viewport edge; 1 column below 560 px, 2 from 560 px, 3 at 1280 px; every link and button at least 44 px tall; focus ring visible on card links; no money wording or currency symbol in any rendered page; no digit at all in unavailable or not-loaded cards; raw error text never shown; en-IN grouping (`12,34,567`); "Updated" time in Asia/Kolkata.
   - Screenshots were looked at for admin, viewer and agent at 320, 768 and 1280.

## Not verified

- **`next build` has never run** (registry unreachable). Real `next`, `react` and `@supabase/*` typings have never been applied to this code. Expect the first real build to surface issues the stand-ins cannot.
- **No real Supabase Auth, JWT or PostgREST call has been made from the app.** The `ready` branch of `getDashboard` has only been exercised with stand-in clients. The mapping of `42501`, `PGRST301` and `PGRST302` through a real PostgREST is an assumption.
- The page title in `PageHeader` was not part of the Chromium harness; it is unchanged shell code.
- `tests/dashboard.test.ts` is not covered by the stand-in type check.
- Real-device and real-browser testing (Safari, Firefox) was not done.
- The Chromium harness lives in the session scratchpad (it depends on local tool paths) and is not in the repo.

To run the logic tests: `npm install`, then `npm test` (Phase 3.3A added `tests/run.mjs` and `esbuild` as a devDependency; the original Step 3 had no test runner).

## Status after Phase 3.3A (replaces the original "Blocked until Phase 3.3")

- The stub that returned `shell_preview` in development and `signed_out` in production was replaced in Phase 3.3A by real session verification. The `shell_preview` state was removed.
- There is still no user or profile (auth.users 0, profiles 0), so the live function has never been called as a user.
- First-admin creation and the bootstrap flow are not armed and were not touched.
- A signed-out visitor is redirected to `/login`; an inactive user sees a gate with a Sign out button.

## Not done by design

No migration, no database change, no RLS or setting change, no Firebase or website change, no demo data, no dependency or version change, no Phase 3.3 work.
