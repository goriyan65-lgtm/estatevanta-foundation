# EstateVanta CRM — 12-Phase Roadmap, Test Gates & Acceptance Criteria

Rule for every phase: no phase starts while a critical defect from the previous one is open. Every phase ends with a written report of what was verified and what was not.

**Standing gates (apply to every phase from 3 onward)**
- G1 Auth: unauthenticated request to any admin page/API → redirect / 401
- G2 Permission: each role (admin/manager/agent/viewer) tested against the phase's screens and endpoints
- G3 Validation: invalid input rejected server-side with a clear error (never only client-side)
- G4 Empty state: with zero rows every list, card and chart shows 0 / an empty message; no invented numbers
- G5 Responsive: works at 360 px (Android phone), 768 px (tablet), 1280 px (desktop); mobile uses card layouts, not shrunken tables
- G6 Audit: the phase's important changes appear in `audit_logs`
- G7 No demo data: `select count(*)` on business tables = 0 after a clean install

---

## Phase 1 — Inspection + architecture  *(this document set)*
Deliver: architecture, folder structure, schema, relationships, API plan, auth + RLS design, roadmap.
Accept when: you approve the ⚑ decisions in ARCHITECTURE §3; observed / new / needs-source split is clear.
Gate: none executable yet.

## Phase 2 — Database + authentication
Build: apply migrations 0001–0008 to a new Supabase project; login, logout, session refresh, inactive-user block, first-admin bootstrap; generate TS types.
Gates
- Migrations apply cleanly on an empty database, in order, twice-run safe via fresh project
- Business tables are empty; only roles, permissions, reference lists, default matching config and settings exist
- Every public table has RLS (migration fails otherwise)
- New signup → profile inactive, no role, sees nothing
- Two-step bootstrap (`arm_bootstrap` + `bootstrap_first_admin(uuid, secret)`) works once, refuses wrong secret / expiry / mismatch / unconfirmed e-mail / replay (Phase 2 Steps 1–2 applied; see docs/PHASE2_TESTING.md)
- Phase 2 Step 3 (last-admin, system-role and admin-permission protection, soft-delete guard) applied; live test PASS 322 / FAIL 0 / GAP 2 (known manager soft-delete defect, planned for a later phase)
- User cannot change own role/activation (expect error 42501)
- Viewer: `select` on deals, commissions, payments, property_owner_terms returns 0 rows / permission error
- Agent: can select all active properties; cannot update a property they are not assigned to; cannot read others' property documents
- Agent insert of a lead succeeds and assigns a `LD-…` code (proves sequence/schema grants)
- RLS matrix test: agent A cannot read agent B's lead; viewer cannot insert; anon reads nothing
- Constraint tests: owner_direct without owner rejected; two primary images rejected; weights ≠ 100 cannot be activated; closed deal without price rejected

## Phase 3 — Admin shell + dashboard
Build: responsive layout (sidebar / bottom-nav), route protection, dashboard cards + charts from real queries, empty states.
Gates
- All 13 dashboard cards return 0 on empty DB
- Dashboard numbers equal hand-computed SQL on test rows inserted **only inside automated tests and rolled back** (never committed to the real database)
- Layout usable one-handed at 360 px

## Phase 4 — Leads, Buyers, Sellers, Contacts
Build: CRUD, search, filters, sort, pagination, saved filters, duplicate detection UI, activity timeline, assignment.
Gates
- Same phone in different formats (+91 …, spaces, leading 0) is detected
- Email match case-insensitive
- Possible duplicate → shown to agent with existing record; agent decides
- Lead status change is audited; agent sees only assigned leads
- One contact cannot become two buyers

## Phase 5 — Properties, owner inventory, media
Build: property CRUD, owner-direct terms, amenities, upload/delete/reorder/primary for media, documents, verification + stale-listing reminders, filters.
Gates
- Owner with N properties shows N; soft-deleted properties excluded
- Price/status change audited (old → new)
- Only one primary image; reorder persists
- Private files unreachable without signed URL; another role's forbidden file → denied
- Reminder task created once per stale property (no duplicates)

## Phase 6 — Buyer requirements + matching engine
Build: requirements UI, rule-based engine reading weights from DB, match list with matched / unmatched criteria, match history, weights editor (new version on edit).
Gates
- Hard filters: sold/inactive or wrong transaction type never matched
- Score = Σ(weight × criterion result) reproducible by hand for 5 fixtures in unit tests
- Changing weights creates a new config version; old matches keep their original config_id
- Missing data (e.g. no area) handled and explained, not silently scored
- UI wording states it is an internal rule-based score

## Phase 7 — Appointments, site visits, tasks
Build: calendar/list views, visit lifecycle, feedback, next actions, tasks, overdue view.
Gates
- Visit links buyer + property; owner derived correctly
- Overdue tasks appear on dashboard
- Rescheduled/cancelled/no-show flow tested
- Agent limited to own appointments

## Phase 8 — Deals, commission, payments
Build: deal pipeline, documents, commission rows per party, payment recording, summary views.
Gates
- commission_amount = final_price × pct ÷ 100 to 2 decimals, NULL until both inputs exist
- Expected / received / pending computed only from real rows; zero rows → 0
- Duplicate live deal for same buyer + property rejected
- Closed requires final price + closed_at; cancelled requires reason
- Agent cannot see finance; manager can

## Phase 9 — Website API integration
Build: `/api/public/enquiries`, hardening, pipeline (dedupe → lead → requirement → match → notification), integration guide for the website.
Gates
- Honeypot, size limit, rate limit, CORS allow-list tested
- Repeat submission from same phone does not create a second contact
- No internal ids or existing-customer data returned to the public caller
- **Requires:** knowledge of the existing form (see ARCHITECTURE §10). Existing site is not modified in this phase without your explicit go-ahead.

## Phase 10 — Analytics + market intelligence
Build: reports from real records only; market_data screens; import UI (CSV/XLSX/JSON) with preview/validate/duplicates/confirm.
Gates
- Every metric traceable to a SQL query; metrics without data are labelled "not tracked", never estimated
- Asking price, verified transaction, estimate, third-party data visually distinct
- Import cannot commit without authorization note + explicit confirm; bad rows reported by row number

## Phase 11 — Security, testing, error handling
Build: full RLS/permission regression suite, dependency audit, security headers, error boundaries, logging, backup/restore drill, load sanity at expected small-business volume.
Gates
- No service-role key in client bundle (bundle grep)
- All API routes covered by auth + permission tests
- Injection / XSS attempts on text fields neutralised
- Backup restored to a scratch project successfully

## Phase 12 — Production deployment
Build: production Supabase project, hosting (simplest that fits — Vercel or equivalent), env secrets, domain (separate sub-domain, e.g. admin.), monitoring, runbook.
Gates
- Clean production DB contains only system configuration
- First admin created via bootstrap, not seeded
- Smoke test of every module on real phone
- Rollback plan tested
- Existing public website unchanged and still live
