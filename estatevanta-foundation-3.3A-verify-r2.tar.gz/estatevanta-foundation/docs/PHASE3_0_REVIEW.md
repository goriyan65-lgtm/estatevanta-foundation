# Phase 3.0 — function hardening: review package (NOT APPLIED)

Status: **proposal only.** Nothing has been applied to `bmvozgfjrvdrfdhvfray`. The only live queries run for this package were read-only SELECTs.
Files: `supabase/migrations/0011a_phase3_step0_function_hardening.sql`, `supabase/migrations/rollback/0011a_rollback.sql`, `supabase/tests/phase3_0_preflight_readonly.sql`, `supabase/tests/phase3_0_hardening_tests.sql`.

## 0. The SQL
**Superseded by round 2 (see the end of this file):** the migration is now one guarded `DO` block (precondition checks, the 10 `ALTER FUNCTION` + 3 `REVOKE` statements, postcondition checks) in `supabase/migrations/0011a_phase3_step0_function_hardening.sql` (120 lines). The statements themselves are the same as in the first package. Same for the rollback file.

## 1. Functions changed — current vs proposed EXECUTE (live, read just now)
Columns: anon / authenticated / service_role / postgres.

| Function | Current EXECUTE | Proposed EXECUTE | search_path |
|---|---|---|---|
| `app.guard_profile_privileges()` (trigger fn, invoker) | yes / yes / yes / yes (via PUBLIC) | unchanged | none → pinned |
| `app.guard_soft_delete()` (trigger fn, invoker) | yes / yes / yes / yes | unchanged | none → pinned |
| `app.set_updated_at()` (trigger fn, invoker) | yes / yes / yes / yes | unchanged | none → pinned |
| `app.enforce_active_weights()` (trigger fn, invoker) | yes / yes / yes / yes | unchanged | none → pinned |
| `app.next_code(text,regclass)` (invoker, column default) | yes / yes / yes / yes | unchanged | none → pinned |
| `app.bootstrap_first_admin(uuid)` (disabled stub) | no / no / no / yes | unchanged | none → pinned |
| `public.find_contact_matches(text,text,text)` (invoker) | no / yes / yes / yes | unchanged | none → pinned |
| `app.apply_child_policies(text,text,text,text,text)` | yes / yes / yes / yes | **no / no / no / yes** | none → pinned |
| `app.apply_global_policies(text,text)` | yes / yes / yes / yes | **no / no / no / yes** | none → pinned |
| `app.apply_scoped_policies(text,text,text)` | yes / yes / yes / yes | **no / no / no / yes** | none → pinned |

Only the three `apply_*` rows change EXECUTE. ("yes" for anon comes from the PUBLIC grant `=X/postgres` in the ACL.)

## 2. Exact search_path change
Each of the 10 functions goes from "no setting" (it runs with the caller's search_path) to `search_path = public, extensions, pg_temp`. `pg_catalog` is always searched first implicitly; `pg_temp` is last so a caller's temp objects can never shadow real ones.

Why `extensions` is included: live `citext` and `pg_trgm` are in `public`, and Supabase's default path is `"$user", public, extensions`. `find_contact_matches` casts to `citext`. The advisor suggests moving the extensions out of `public` later; with `extensions` already on the path nothing breaks when that happens. (My local replica had the extensions in `extensions` and a path without it, which made the first draft fail there; that is why this was caught.)

## 3. What calls these functions, and could the change break them?
Live dependency lookup (`pg_depend`) plus the function bodies:

| Function | Used by (live) | Names the body uses | Break risk |
|---|---|---|---|
| `guard_profile_privileges` | 1 trigger on `profiles` | `auth.uid()`, `app.can()` (qualified) | none |
| `guard_soft_delete` | 10 triggers (soft-delete tables) | `auth.uid()`, `app.can()` (qualified) | none |
| `set_updated_at` | 17 triggers | `now()` only | none (tiny per-call overhead from the SET clause) |
| `enforce_active_weights` | 1 trigger on `matching_configs` | `matching_weights` (public) | none; `public` is first |
| `next_code` | 6 column defaults (`code` of buyers, sellers, leads, properties, requirements, deals) | `nextval`, `lpad` (pg_catalog) | none |
| `find_contact_matches` | no policy/trigger; will be called from server code | `contacts`, type `citext` (public) | none while `public` and `extensions` are on the path |
| `bootstrap_first_admin(uuid)` | nothing (stub raises 55000) | none | none |
| `apply_*` (3) | nothing in the database (0 policies, triggers, functions, defaults); only migration scripts run as owner | unqualified table names (public) | none for the owner, who has `public` in the path; API roles lose access on purpose |

Other facts: the 139 policies depend on `app.can`, `app.is_admin`, `app.current_role_code`, `app.can_edit_property`, none of which is touched. Triggers do not check EXECUTE when they fire. A function with a SET clause can no longer be inlined by the planner (affects only `next_code` and `find_contact_matches`; negligible here). A later `CREATE OR REPLACE FUNCTION` without its own SET clause silently removes the setting again, so future migrations must repeat it.

## 4. After 3.0: who can still call what, and why
| Function(s) | anon / authenticated / service_role / postgres | Why |
|---|---|---|
| `apply_*` (3) | no / no / no / **yes** | DDL helpers for migrations, owner only |
| `arm_bootstrap`, `bootstrap_first_admin(uuid,text)`, `bootstrap_first_admin(uuid)`, `protect_last_admin`, `protect_system_roles`, `protect_admin_permissions` | no / no / no / yes | owner-only bootstrap; trigger functions (unchanged by 3.0) |
| `can`, `is_admin`, `current_role_code`, `can_edit_property` | yes / yes / yes / yes | RLS policies call them as the querying role; unchanged. anon has no USAGE on schema `app` and no table grants, so it cannot reach them |
| `next_code` | yes / yes / yes / yes | column defaults run with the inserting user's rights, so authenticated needs it; unchanged |
| `guard_profile_privileges`, `guard_soft_delete`, `set_updated_at`, `enforce_active_weights`, `audit_row`, `handle_new_auth_user` | yes / yes / yes / yes | trigger functions; unchanged. Calling them directly fails ("trigger functions can only be called as triggers", confirmed locally) |
| `find_contact_matches` | no / yes / yes / yes | lead-capture duplicate check; unchanged |
| `my_access` (public) | no / yes / no / yes | not touched |
| `security_log_event` (public) | no / no / yes / yes | not touched |

Deliberately not included: revoking the PUBLIC/anon grant on the helper and trigger functions above. It is probably safe but not needed for a no-behaviour-change step; it can be a separate optional step if you want it.

## 5. Read-only preflight
File: `supabase/tests/phase3_0_preflight_readonly.sql` (pure SELECT). It compares each function's body hash, search_path setting and EXECUTE rights with what this migration was designed against and prints `PRE-3.0 (as expected)`, `POST-3.0 (hardened)`, or `STOP` values.
**Live result just now: all 10 rows `PRE-3.0 (as expected)`, all bodies unchanged.** The same query is run again after applying; all 10 must read `POST-3.0 (hardened)`.

## 6. Rollback (`rollback/0011a_rollback.sql`, never run live)
Now also a single guarded `DO` block: stops without changes if any of the 10 functions is missing, runs `reset search_path` on all 10, re-grants EXECUTE on the three `apply_*` helpers to PUBLIC, authenticated and service_role, then verifies the ACLs and that no setting remains. Risks of using it: (1) it re-opens EXECUTE on the three DDL helpers to every API role; (2) it clears the pinning, so the 10 advisor warnings return; (3) if a later migration deliberately set a search_path on one of these functions it would be cleared too; (4) it fails as a whole (no partial state) if a function was dropped or renamed meanwhile; (5) it touches no data.

## 7. Local test results (PostgreSQL 16 replica; nothing here was run on the live project)
Replica notes: mock `auth`/`storage` schemas. I aligned the replica's default `search_path` with the live one (`"$user", public, extensions`). The replica holds citext in `extensions` while live holds it in `public`; the chosen path works for both.

| Test | Without 3.0 | With 3.0 |
|---|---|---|
| New `phase3_0_hardening_tests.sql` (31 checks: next_code defaults, set_updated_at, profile guard incl. Step 3 soft-delete check, soft-delete guard, weight trigger, find_contact_matches, hostile search_path, bootstrap end-to-end, last-admin block, apply_* rights) | PASS 28 / FAIL 0 / GAP 3 | **PASS 31 / FAIL 0 / GAP 0** |
| Full `phase2_security_tests.sql` | PASS 322 / FAIL 0 / GAP 2 (same as live) | **PASS 322 / FAIL 0 / GAP 2** |
| State after each rolled-back run | identical | identical |
| Catalogue fingerprint: 139 policies, 58 triggers, policy text, trigger set, table grants, function bodies, SECURITY DEFINER flags | — | **identical** to without-3.0 |
| Functions that differ | — | exactly the 10 listed (7 pinned only, 3 pinned + revoked) |
| Rollback applied after 3.0 | — | restores the without-3.0 state exactly (23 functions: ACL, config, body) |
| Final migration file on a fresh scratch copy | — | applies cleanly |

The 3 GAPs without 3.0 are exactly what 3.0 fixes: the functions are not pinned; `apply_*` are executable by API roles (calls by API roles already fail earlier on DDL ownership, so this was exposure of rights, not a working attack); and with a hostile caller `search_path` (a schema `zz_evil` with an empty `contacts` table first) `find_contact_matches` silently returns 0 matches instead of 1 — with 3.0 it returns 1.

Not tested: a live run, PostgREST with real JWTs, and a new two-session race after 3.0 (the hardening does not touch that logic).

## If you approve, the live sequence would be
1. Run the preflight (expect 10 × PRE). 2. Apply `0011a` as one migration (`estatevanta_p3_step0_function_hardening`). 3. Run the preflight again (expect 10 × POST). 4. Run `phase3_0_hardening_tests.sql` and `phase2_security_tests.sql` live (both fully rolled back; expect 31/0/0 and 322/0/2). 5. Re-run the security advisor (expect the 10 `function_search_path_mutable` findings gone; the `citext`/`pg_trgm` and `bootstrap_setup` notices stay) and compare counts: auth.users 0, profiles 0, audit_logs 170 (seq 170), bootstrap_setup 0, roles 4, permissions 60, role_permissions 147, settings 7, business rows 0. 6. Stop for your review.

---
# Round 2 — answers to the final verification points (2026-10-04)
Everything below on the live project was read-only. Scratch-copy tests used the local replica only.

## R1. `app.next_code(text, regclass)`
The six defaults (live `pg_attrdef`):
| Table.column | Default expression |
|---|---|
| `public.buyers.code` | `app.next_code('BY'::text, 'app.buyer_code_seq'::regclass)` |
| `public.sellers.code` | `app.next_code('SL'::text, 'app.seller_code_seq'::regclass)` |
| `public.leads.code` | `app.next_code('LD'::text, 'app.lead_code_seq'::regclass)` |
| `public.properties.code` | `app.next_code('PR'::text, 'app.property_code_seq'::regclass)` |
| `public.deals.code` | `app.next_code('DL'::text, 'app.deal_code_seq'::regclass)` |
| `public.buyer_requirements.code` | `app.next_code('RQ'::text, 'app.requirement_code_seq'::regclass)` |

Live facts: `authenticated` has INSERT on all six tables and an INSERT policy on each; it has USAGE on schema `app` and on all six sequences; it holds EXECUTE on `next_code` both directly (`authenticated=X`) and through PUBLIC (`=X`).
**Privilege behaviour (scratch replica, real `authenticated` role + JWT claims, rolled back):**
| Scenario | Agent inserts a lead without a code |
|---|---|
| A. as is (direct + PUBLIC grant) | works, code `LD-000001` |
| B. direct `authenticated` grant revoked, PUBLIC kept | works (inherited from PUBLIC) |
| C. direct grant AND PUBLIC revoked | **fails: `ERROR: permission denied for function next_code`** |
| D. as C, but the insert supplies an explicit `code` | works (default is not evaluated) |
| E. after Phase 3.0 is applied (grants untouched, path pinned) | works, `LD-000001` |
Conclusion: a column default runs with the inserting user's rights, so `authenticated` needs EXECUTE (direct or via PUBLIC). Phase 3.0 does not change any `next_code` grant. If PUBLIC is ever tightened, `authenticated` must keep the direct grant.

## R2. Unqualified references and why `public, extensions, pg_temp` resolves them
(live function bodies read just now)
| Function | Unqualified object references in the body | Resolved how |
|---|---|---|
| `guard_profile_privileges` | none (`auth.uid()` and `app.can()` are schema-qualified; `old`/`new` are trigger records) | n/a |
| `guard_soft_delete` | none (`auth.uid()`, `app.can()` qualified; `tg_argv` is a trigger variable) | n/a |
| `set_updated_at` | none (`now()` is pg_catalog) | n/a |
| `enforce_active_weights` | table `matching_weights` | `public` (first on the path) |
| `next_code` | none (`nextval`, `lpad`, `\|\|` are pg_catalog; `seq` arrives as an OID) | n/a |
| `bootstrap_first_admin(uuid)` | none (only `raise exception`) | n/a |
| `find_contact_matches` | table `contacts`; type `citext` and its `=` operator (extension `citext`, installed in `public`) | `public` |
| `apply_child/global/scoped_policies` | the table names passed in as arguments (`tbl`, `parent`) are used as unqualified identifiers in the generated DDL; generated policy text uses qualified `app.can`, `app.is_admin`, `auth.uid()` | `public` (all CRM tables are there); they run only as the owner |
Why safe: `pg_catalog` is always searched first, so built-ins cannot be replaced. `public` holds every table and type these bodies name. `pg_temp` is listed explicitly and last, which matters because PostgreSQL otherwise searches the temp schema FIRST for tables and types, letting a session's temp table shadow a real one. `extensions` is not needed by any body today.

## R3. Shadowing and why this order
Live: `extensions` holds 57 objects (functions, types, operators, relations); `public` holds 212; **0 same-name collisions**. Because `public` comes first, nothing in `extensions` can shadow anything in `public`; the reverse (an object in `public` hiding one in `extensions`) is not a concern for these bodies since none of them call an `extensions` object. Who can create objects: schema `public` — only `postgres` and `supabase_admin`; schema `extensions` — only `postgres`, `supabase_admin` and `dashboard_user`; `anon`, `authenticated`, `service_role` have no CREATE on either. Citext and pg_trgm are the only extension members in `public`. The order is intentional: `public` first (our objects win), `extensions` second only so `citext` keeps resolving if the advisor-recommended move of `citext`/`pg_trgm` out of `public` happens later, and because it matches Supabase's own default path `"$user", public, extensions`; `pg_temp` last. If you prefer the strictest form, `public, pg_temp` also works on live today (citext is in `public`) but would break `find_contact_matches` after such a move.

## R4. `apply_*` callers
Live checks: no other function in any schema mentions them; no view or rule does; `pg_depend` shows 0 policies, constraints, defaults or triggers depending on them; no trigger uses them; no event trigger calls them (the six event triggers are Supabase/PostgREST/graphql housekeeping); `pg_cron`, `pg_net` and `supabase_functions` are not installed, so there are no scheduled jobs or database webhooks; **0 Edge Functions** are deployed; the repo's `src/` has no `.rpc()` call and no reference. The only callers are the owner-run migration scripts (installer `0000`/`0001–0009`). Even if schema `app` were exposed to the Data API, no RPC call could reach them after 3.0 because no API role would hold EXECUTE.

## R5. Transactional and fail-safe
The file is one `DO $m$ … $m$;` statement, so it is a single transaction whatever submits it. Tested on scratch copies (fingerprint of ACL + settings + body of all 23 functions before and after):
| Case | Result | Changed anything? |
|---|---|---|
| Happy path | `NOTICE: Phase 3.0 hardening applied and verified`; preflight 10 × POST | yes, as designed |
| A signature missing (`next_code` renamed) | `ERROR: Phase 3.0 precondition failed: function app.next_code(text,regclass) does not exist` | no (fingerprint identical) |
| A body differs from the reviewed one | `ERROR: … body of app.guard_soft_delete() differs from the reviewed version` | no |
| A function already has a setting | `ERROR: … app.set_updated_at() already has function-level settings` | no |
| Postcondition fails (deliberately sabotaged copy) | `ERROR: Phase 3.0 postcondition failed …` after all 13 statements ran | no: all 13 changes rolled back |
| Another session holds a conflicting lock | `ERROR: canceling statement due to lock timeout` after 5 s | no |
Rollback script: same tests (happy path restores the original state exactly; a missing function stops it with no change).
The exact SQL is the file `supabase/migrations/0011a_phase3_step0_function_hardening.sql` (attached).

## R6. Postflight covers configuration AND grants
Two layers. (1) Inside the migration, before it commits: for each function, `proconfig` must equal `{search_path=public, extensions, pg_temp}`; for each `apply_*`, the complete ACL must be exactly `postgres:EXECUTE` and anon/authenticated/service_role must have no EXECUTE (PUBLIC included); for the 7 other functions the complete ACL must equal what it was before; policy count and trigger count must be unchanged. (2) `phase3_0_preflight_readonly.sql` (run before and after): per function it compares body hash, `proconfig`, and the full ACL string including PUBLIC against both the expected PRE and POST values; any other combination prints `UNEXPECTED - STOP`. **Live, just now, with this strict version: 10 × `PRE-3.0 (as expected)`.**

---

## Applied live — 2026-10-05 (project `bmvozgfjrvdrfdhvfray`, "Estate vanta crm")

- Migration `0011a_phase3_step0_function_hardening.sql` (file md5 `4088f972fc2a8385f5a2e8cdd486a1c0`, unchanged; its header still says "NOT APPLIED" on purpose so the reviewed hash stays valid) was applied **once** via `apply_migration` as `estatevanta_p3_step0_function_hardening` (version `20261005042512`).
- Pre-flight: 10 x `PRE-3.0 (as expected)`. Post-flight: 10 x `POST-3.0 (hardened)`; all bodies unchanged.
- Catalogue fingerprints (policy md5, trigger md5, table-grants md5), policy count (146 total / 139 public), trigger count (66) and all data counts are identical before and after. Functions with a function-level setting in app+public: 13 -> 23.
- `phase3_0_hardening_tests.sql`: PASS 31 / FAIL 0 / GAP 0, state identical. `phase2_security_tests.sql`: PASS 322 / FAIL 0 / GAP 2 (the two known manager soft-delete defects), state identical.
- Security Advisor: the 10 `function_search_path_mutable` findings are gone. Remaining: `extension_in_public` (citext, pg_trgm) and the INFO notice for `app.bootstrap_setup` (RLS on, no policy = intentional deny-all).
- Rollback `rollback/0011a_rollback.sql` was NOT run.
