# Phase 2 — Change inventory, status and rollback/recovery

Target: Supabase project **Estate vanta crm** (ref `bmvozgfjrvdrfdhvfray`) only. The other project is never touched.
Baseline before Phase 2 (captured 2026-10-03): 43 public tables, 139 public policies, 170 audit_logs rows (configuration inserts only), 0 business rows, 0 auth users.

Phase 2 is applied in **three steps**. (The original single-file plan is kept only in `supabase/migrations/superseded/`; it was never applied.)

| Step | File | Status | Rollback |
|---|---|---|---|
| 1 | `0010a_phase2_step1_audit_logger_access.sql` | **APPLIED** | `rollback/0010a_rollback.sql` |
| 2 | `0010b_phase2_step2_bootstrap.sql` | **APPLIED** | `rollback/0010b_rollback.sql` |
| 3 | `0010c_phase2_step3_admin_protection.sql` | **APPLIED 2026-10-04** (migration `estatevanta_p2_step3_admin_protection`) | `rollback/0010c_rollback.sql` |

Roll back in reverse order (c, b, a). None of the rollback scripts has been run on the live project; they were validated only on scratch copies of a local replica. Live test after Step 3: PASS 322 / FAIL 0 / GAP 2, state identical (see `PHASE2_TESTING.md`).

## Everything each step changes
| Step | Kind | Object | Change |
|---|---|---|---|
| 1 | Constraint | `audit_logs_action_check` | replaced: adds login, logout, login_failed, access_denied, invite, bootstrap_admin |
| 1 | Function | `public.security_log_event(text,uuid,jsonb)` | NEW; SECURITY DEFINER; EXECUTE for `service_role` only; validates event type, actor, detail keys |
| 1 | Function | `public.my_access()` | NEW; SECURITY **INVOKER**, no parameters; EXECUTE for `authenticated` only |
| 1 | Grants | `public.find_contact_matches(text,text,text)` | PUBLIC + anon EXECUTE revoked; authenticated + service_role kept |
| 2 | Function | `app.bootstrap_first_admin(uuid)` | **DISABLED, not dropped**: body only raises; SECURITY INVOKER; revoked from PUBLIC/anon/authenticated/service_role |
| 2 | Table | `app.bootstrap_setup` | NEW; single row; RLS on, no policies, no grants to any API role |
| 2 | Function | `app.arm_bootstrap(text,text,int)` | NEW; owner-only |
| 2 | Function | `app.bootstrap_first_admin(uuid,text)` | NEW; owner-only |
| 3 | Function | `app.guard_profile_privileges()` | REPLACED: also blocks `deleted_at` changes without `users.manage` |
| 3 | Triggers | `protect_last_admin` (profiles), `protect_system_roles` (roles), `protect_admin_permissions` (role_permissions) | NEW |
| — | Policies / table grants | — | **none changed in any step** |
| — | Phase 1 migrations 0001–0009 | — | untouched |

## Rollback
1. Export audit rows with the new action types if you want to keep them (query in `0010a_rollback.sql`).
2. Run the rollback script of the step in the SQL Editor (one script, atomic). Reverse order.
3. Verify: `select count(*) from pg_proc where proname in ('my_access','security_log_event','arm_bootstrap');` → 0 after 0010a+0010b rollbacks.
4. Optionally remove the matching rows from `supabase_migrations.schema_migrations`.

## Recovery situations
- **Locked out (no active admin; the Step 3 triggers are installed, so this needs a manual owner change):** project owner (SQL Editor, role postgres) runs `alter table profiles disable trigger protect_last_admin;` → fix the profile row → `alter table profiles enable trigger protect_last_admin;`.
- **Bootstrap window expired / wrong email:** if no admin exists and bootstrap is NOT consumed, run `app.arm_bootstrap` again (it overwrites the unconsumed arming). If it was consumed but no admin exists, use the procedure above.
- **No point-in-time backup on the free plan:** the exact pre-change function definitions are stored in the rollback scripts; all Phase 1 configuration is reproducible from `migrations/0000_estatevanta_all.sql`.
