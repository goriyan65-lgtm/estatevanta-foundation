# Phase 3.3A: Real authentication foundation (code only)

Status: implemented and tested against stand-ins. **Not verified against real Supabase Auth or PostgREST.** `next build` has not been run, `npm install` has not been run, and no lockfile exists. No database was touched, no user or profile was created, bootstrap was not armed.

A review-driven remediation pass (M1, M2, M3, L1, L2, L9) followed the original implementation. It changed the environment guard, `package.json` and the documentation. See "Remediation pass" at the end.

## What changed in behaviour

| Before (3.1 / 3.2) | Now |
|---|---|
| `getAccessState()` was a stub: `shell_preview` in development, `signed_out` in production | Verifies a real Supabase session on every request, then reads the user's profile and permissions |
| `/login` was a placeholder with no form | Email and password form; one Server Action to sign in, one to sign out |
| No session refresh | `src/proxy.ts` refreshes the session cookie (Next.js 16 file name; `middleware.ts` before 16) |
| Development showed the whole app with no sign-in | **Removed.** Development fails closed exactly like production |

## Request flow

```
browser ──► src/proxy.ts            refresh the session cookie only (getClaims). Never redirects, never decides access.
        ──► (app)/layout.tsx        getAccessState()
                                      unconfigured        -> gate: "Supabase isn't configured"
                                      signed_out          -> redirect /login
                                      inactive            -> gate with a Sign out button
                                      error               -> gate with a reference code and Try again
                                      ready               -> app shell + page
        ──► each page               getAccessState() AGAIN, then canAccess(). A layout is not re-run when a
                                    signed-in user moves between pages, so a page never trusts the layout.
        ──► dashboard               getDashboard(state) -> public.dashboard_summary() with the USER's session
```

`getAccessState()` (`src/server/auth/session.ts`, logic in `src/lib/auth/resolve.ts`):

1. Public environment missing or invalid (an allow-list, see "Environment guard" below), or the key is any secret/service-role/other-role key: `unconfigured`.
2. `auth.getUser()`, which asks Supabase Auth to verify the token. `getSession()` is never used (a test forbids it). A missing, invalid, expired or revoked session (client error from Auth): `signed_out`. Auth unreachable, 5xx or rate-limited: `error` with a short reference code.
3. `rpc("my_access")` with the user's own JWT (SECURITY INVOKER, RLS applies, no arguments). No row: `inactive`. Error: `error` (PGRST301/302 map to `signed_out`).
4. Strict parse of the answer. It must be the verified user's own profile (id match), `is_active = true` and have a role, otherwise `inactive` (a mismatch or malformed answer is `error`). Only then: `ready` with the permissions the database returned.

Anything not `ready` never renders page content, never reaches the dashboard function, and never shows a raw error message.

## Files

New: `src/proxy.ts`, `src/lib/supabase/{env,cookies,proxy}.ts`, `src/lib/auth/{resolve,credentials}.ts`, `src/server/auth/actions.ts`, `src/components/auth/LoginForm.tsx`, `src/components/states/AccessDenied.tsx`, `tests/auth.test.ts`, `tests/run.mjs`, `tests/tsconfig.json`, `tests/mocks/*` (7 stand-ins), this document.

Modified: `src/lib/access.ts` (removed `shell_preview`; `error.message` is now a reference code), `src/server/auth/session.ts` (real), `src/server/supabase/user-client.ts` (validated env, hardened cookies), `src/server/dashboard/summary.ts`, `src/app/(app)/layout.tsx`, `src/app/(app)/dashboard/page.tsx`, `src/app/(auth)/login/page.tsx`, `src/components/modules/ModulePage.tsx`, `src/components/states/{AccessGate,UnauthorizedState,ErrorState}.tsx`, `src/components/shell/{AppShell,icons}.tsx`, `src/components/dashboard/DashboardView.tsx` (wording), `tsconfig.json` (`tests` excluded from the app build; type-checked separately by `tests/tsconfig.json`), `.env.example` (comments only), `tests/dashboard.test.ts` (one type fix), notes in `docs/PHASE3_1_APP_SHELL.md` and `docs/PHASE3_2_DASHBOARD_UI.md`.

Not changed: `package.json`, `supabase/` (all migrations and tests), `admin-client.ts`, `next.config.ts`, the database, Firebase, the live website.

## Security implications

- **Tokens stay server-side.** The app has no browser Supabase client. Session cookies are written `HttpOnly`, `SameSite=Lax`, `Secure` in production, path `/`. If a browser Supabase client is ever added, this must be revisited.
- **Only the public key is used.** The environment guard is an allow-list: only a publishable key or a legacy `anon` JWT is accepted, and every secret, service-role or other-role key is refused. The service-role client is not imported by any auth, session or dashboard file (tested; a sentinel secret in the environment never reached any Supabase call).
- **Fails closed everywhere.** Missing config, missing/invalid/revoked session, unreachable Auth or database, malformed profile, someone else's profile, inactive account, account with no role: all block. There is no development exception.
- **Authorization is not in the proxy.** If `src/proxy.ts` is skipped (wrong Next version, matcher), nobody gains access; sessions expire sooner.
- **The database stays the authority.** The UI permission list only decides what to draw. Figures come from `dashboard_summary()` (own permission checks, RLS) and the dashboard response validation and role gating from 3.2 are unchanged.
- **Sign-in:** generic error messages (no hint whether an email exists; 429 gets its own "wait" message); the password is never returned, logged or stored; the redirect after sign-in is a fixed `/dashboard` (no `next` parameter, so no open redirect). Server Actions are POST-only with Next's Origin check.
- **Sign-out:** revokes the session with Supabase and also deletes every `sb-*` cookie, even when Supabase is unreachable. Caveat: if Supabase was unreachable, the old access token remains valid until it expires (default one hour) wherever it was copied. Cookies are `HttpOnly`, so page scripts cannot copy them.
- **Known limits:** no app-level throttling of sign-in attempts (Supabase Auth's own limits apply); no sign-in audit rows (the logger is service-role only and the service-role key is not used here); no sign-up, password reset, magic link or OAuth exists in the app (a test forbids them). Password reset needs redirect-URL configuration and is a separate approval.
- **Sign-ups:** a database trigger creates an inactive, role-less profile for any new Auth user, so a stray sign-up cannot gain access, but whether public sign-ups are disabled in the Supabase dashboard is **unverified** (gap S11). Check it.

## Tests

Run with `npm test` (after `npm install`; same as `node tests/run.mjs`). The runner bundles each test with esbuild, which is now a declared devDependency. A global esbuild install is not found by the runner. Offline fallback: `ESBUILD_MODULE=/path/to/esbuild/lib/main.js node tests/run.mjs`. **A clean `npm install` followed by `npm test` has not been run**; in the sandbox the runner was checked against a project-style `node_modules` layout (symlinks to the sandbox copies), which is not the same thing. 83 tests in two files, all passing in the sandbox:

- environment guard, cookie hardening, `my_access` parsing, the verifier (signed out, Auth down, inactive, error, mismatch, ready), real wiring through `session.ts` and `user-client.ts`, sign-in (validation, wrong password, rate limit, outage, thrown error, success), sign-out (revoke, cookie cleanup, Auth down), the proxy (refresh, hardened cookies, never redirects, matcher), the layout and pages in every state, the dashboard end to end for admin, agent and viewer (including a tampered viewer response), the login page, and static guards (no service-role use, no `getSession`, no development branch, no sign-up/reset calls, every page re-checks the session, nothing outside `(app)` except `/` and `/login`).
- Mutation checks: 19 distinct deliberate code breaks, run 21 times (for example: layout renders children for inactive users, inactive check removed, cookies not HttpOnly, sign-in echoes the password, user client given the service key, proxy redirecting, a development bypass re-added). Two were missed at first: one was an equivalent mutant (it changed a branch that never carries a message) and one exposed a missing direct test of `getDashboard` for non-ready states. A test was added and a better mutation used, and all 19 are now caught. The environment guard was mutation-checked separately in the remediation pass (below).
- Chromium (system Chromium, Tailwind compiled from the real `globals.css`, real components): 313 checks on the login page, gate screens and the shell's Sign out (320 to 1280 px, light and dark; no overflow, labels, 16 px inputs, 44 px targets, focus rings, tab order, Sign out submits the action once), plus the 441 dashboard checks re-run against the new shell. One real defect found and fixed: a long variable name overflowed at 320 px in the "not configured" screen.
- Static import check and strict `tsc` (including the tests) pass **against stand-in typings**.

## Not verified

- **`next build` was not run** (the npm registry is unreachable from the sandbox). Real `next`, `react` and `@supabase/*` types have never been applied. A stand-in type check is not a build.
- **No real Supabase Auth or PostgREST call was made.** The shapes of Auth errors (`AuthSessionMissingError`, status codes, `code` values) and of `my_access` / `dashboard_summary` responses are taken from documentation and from the local database replica. The mapping of real error codes to states is an assumption.
- `@supabase/ssr` details assumed: `createServerClient` with `getAll`/`setAll`; `setAll` receiving a second `headers` argument (handled if present); `auth.getClaims()` existing in the installed version (if it does not, the proxy swallows the error and does nothing).
- Real cookie behaviour (chunked `sb-*-auth-token.N` names, session lifetime, refresh-token rotation) and HttpOnly handling with the real library.
- The proxy file name for the Next version that `npm install` resolves (`latest` is unpinned and there is no lockfile).
- `useActionState` / Server Action behaviour in a real Next runtime (redirect inside a Server Action, form reset).

## Unresolved blockers before anyone can sign in

1. No Auth user and no profile exist (auth.users 0, profiles 0). By instruction, none was created.
2. `npm install`, `npm run typecheck`, `npm run build` have never succeeded on a machine with the registry. Expect first-run fixes.
3. `.env.local` must be created with the project URL and the public anon key (never the service-role key).
4. Supabase Auth settings are unverified (gap S11): public sign-ups off, email confirmation required, password length, leaked-password protection, session limits.
5. Whether `app` is excluded from the Data API's exposed schemas is unverified (gap S10).

## Exact next steps for a separately approved first-admin setup

Do not start any of this without explicit approval.

1. **Prepare the machine.** Follow "Verification procedure on an internet-connected machine" below, exactly. Report any failure first. Review `package-lock.json` before committing it.
2. **Create `.env.local`** with `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` only. Run `npm run dev` and open `/dashboard`: it must redirect to `/login` and show the form. Wrong credentials must show the generic message.
3. **Check the Supabase dashboard** (Authentication): sign-ups disabled, email confirmation required, password minimum length, leaked-password protection, redirect URL settings; Project Settings, API: exposed schemas list only `public`.
4. **Create the one Auth user** for the owner's email in the Supabase dashboard (Authentication, Users, Add user) with a strong password, email confirmed. The `on_auth_user_created` trigger then creates an inactive, role-less profile. Do not put the password in chat or in any file.
5. **Arm and consume bootstrap** as the database owner in the SQL editor, per `docs/PHASE2_TESTING.md` and migration 0010b: `select app.arm_bootstrap('<secret of 20+ characters>', '<the same email>', 60);` then `select app.bootstrap_first_admin('<the user id>', '<the same secret>');`. The window is 5 to 1440 minutes, the email must match and be confirmed, and the secret is hashed and wiped on success. Keep the secret out of chat and files.
6. **First real sign-in test** (this is the first genuine authentication test): sign in at `/login`, confirm redirect to the dashboard, 13 cards loaded, the shell shows the name and role `admin`; every figure is 0 and "Nothing to count yet" appears because no business records exist. Then Sign out, confirm `/dashboard` redirects to `/login`, and confirm the old session no longer works after a browser refresh.
7. **Negative tests with a second, temporary user** (needs its own approval): a user with no role sees the inactive screen and a Sign out button; deactivating an admin is refused for the last admin.
8. Only then plan Phase 3.3B (user management screens, password reset) and the later fixes already on the list (manager archive functions, bootstrap throttling).

## Environment guard

`src/lib/supabase/env.ts` reads only `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`. It is an allow-list and fails closed (returns nothing, so the app shows "not configured"); it never logs or returns a value.

| Setting | Accepted | Refused (examples) |
|---|---|---|
| URL | `https://<20 lowercase letters or digits>.supabase.co`, no port, path, query, fragment or credentials. Plain http only for `localhost` and `127.0.0.1`. | any other https host, `http://localhost.evil.com`, `https://<ref>.supabase.co.evil.com`, `https://<ref>.supabase.co@evil.com`, other schemes, private-network hosts |
| Key | `sb_publishable_` followed by 16 to 128 characters of `A-Z a-z 0-9 _ -`, **or** a three-part JWT with a header `alg` and a payload `role` exactly `anon` (and, if the payload has a `ref`, it must equal the project reference in a hosted URL) | `sb_secret_` and `SB_SECRET_` in any case, `sbp_` tokens, service_role, supabase_admin and authenticated JWTs, `Anon` or `ANON`, wrong-case `SB_PUBLISHABLE_`, quoted values, values with whitespace or invisible characters inside them, random strings, over-long values |

**Whitespace policy.** Whitespace around a value (spaces, tabs, CR/LF and anything else `String.prototype.trim()` removes, such as a byte-order mark or a no-break space) is trimmed once, before validation, because env files and hosting dashboards routinely add a trailing newline. The trimmed value is what is validated, returned and used, so the client never sees padding. Padding never changes the verdict: a padded secret, other-role or wrong-case key is refused exactly like the unpadded one. Whitespace inside a value (inside a key, between JWT segments, inside a host) is never repaired and is refused. Quotes are refused. Characters that are not whitespace, such as a zero-width space, are not trimmed and fail the key allow-list. For the URL, the standard URL parser normalises a few ignorable characters (it also lower-cases the host), and the guard returns that canonical origin, so a URL value is either refused or comes out as exactly `https://<ref>.supabase.co`. The exported `matchesPublicKeyAllowList()` does not trim; trimming happens once, in `parseSupabasePublicEnv()`. (An earlier wording of this document and of a code comment said "padded values" are refused. That was inaccurate for whitespace; the code and its test already trimmed by design. "Padded" there could also be read as base64 `=` padding, which is refused.)

Consequence: a project on a custom domain is refused until `env.ts` is changed in a reviewed step. The accepted forms are a format check only; whether a key really belongs to the project is decided by Supabase on the first call.

## Remediation pass (review findings M1, M2, M3, L1, L2, L9)

Code and documentation only. No database, migration, Auth user, profile, bootstrap, Firebase or website change.

- **M1** `src/lib/supabase/env.ts` rewritten from a deny-list to the allow-list above. `tests/auth.test.ts` gained tests for the exact bypass cases from the review and for case variants. The guard has two layers, tested separately: `looksLikeSecretKey()` (explicit refusal of `sb_secret_`, `sbp_`, service_role and supabase_admin keys, any case) and `matchesPublicKeyAllowList()` (the allow-list, exported so it can be tested on its own). A test asserts that each layer refuses every secret sample by itself. Mutation check: 16 deliberate breaks, 15 detected. The one not detected is deleting the single call to `looksLikeSecretKey()` inside `isAllowedKey()`. That is a logically equivalent mutation: the allow-list accepts only `sb_publishable_` keys and JWTs with role exactly `anon`, so it already refuses every input the explicit check refuses, and no input can tell the two versions apart. It is documented here, not hidden by a weaker guard or a contrived test. What is covered: breaking the explicit check itself (always false, case-sensitive, missing `supabase_admin`) IS detected, and so is every weakening of the allow-list. The call stays on purpose, so a future loosening of the allow-list cannot by itself let a secret key through. A second equivalent mutation exists in the whitespace handling: the explicit `/\s/` test at the top of `matchesPublicKeyAllowList()` can be deleted without changing any result, because the anchored key patterns already refuse whitespace. It is kept as a readable statement of the policy. Every other whitespace, trimming and base64url mutation tried (11 in total, 9 not equivalent) is detected by the tests.
- **M2** `esbuild` added to `devDependencies` (range `latest`, like every other entry), plus `"test": "node tests/run.mjs"`. `tests/run.mjs` header and error message corrected (a global install does not work for an ES module import). No lockfile exists and none was written.
- **M3** `engines.node` changed from `>=20.9` to `>=22.0.0`. **Node 22 as the minimum was approved by the project owner on 2026-10-11.** Reason: the registry metadata read during the review shows `@supabase/supabase-js` (latest, 2.117.3) requires Node `>=22.0.0`; `next` (16.4.0) requires `>=20.9.0`; `@supabase/ssr` (0.12.7) declares no engine; `esbuild` (0.28.2) requires `>=18`. All sandbox tests ran on Node 22.22.0. No runtime or hosting setting was changed.
- **L1, L2, L9** documentation corrected (the README also now records the verified live migration history, 6 applied migrations, and states plainly that the system is not production-ready): mutation-test wording above; `README.md` (no in-app sign-up, first admin created in the Supabase dashboard and not yet done, current status, Node 22, `npm test`); `docs/PHASE2_HANDOVER.md` (obsolete "sign up in the app" step); `docs/PHASE3_1_APP_SHELL.md` and `docs/PHASE3_2_DASHBOARD_UI.md` (`shell_preview` and "not connected to a session" descriptions).

Still unverified after this pass: everything in "Not verified" above, plus that `npm install` resolves the unpinned `latest` ranges to versions compatible with this code, and that Node 22 is the intended runtime.

## Verification procedure on an internet-connected machine

Nothing below has been run. Everything done so far used stand-ins in a sandbox with no npm access, so none of it counts as a real install, a real type check or a real build. Run these steps in order from the project folder (the one containing `package.json`). Stop at the first failure and report it; do not work around it.

| # | Command | What to check |
|---|---|---|
| 1 | `node --version && npm --version` | Node is 22.0.0 or later. If not, stop and install Node 22 first. |
| 2 | `ls package-lock.json node_modules` | Both should be absent (a fresh start). |
| 3 | `npm install` | Completes without error. Do not add `--force` or `--legacy-peer-deps`; an `ERESOLVE` or engine error is a finding to report. This creates `package-lock.json`. |
| 4 | `npm ls --depth=0 > versions-installed.txt; npm ls next react react-dom @supabase/ssr @supabase/supabase-js esbuild typescript tailwindcss` | Record every version. Keep `versions-installed.txt`. The ranges in `package.json` are `latest`, so this file is the only record of what was resolved. |
| 5 | `grep -rl "getClaims" node_modules/@supabase/auth-js/dist --include=*.d.ts` | At least one file is listed (the installed `getClaims()` exists). If nothing is listed, report it: `src/lib/supabase/proxy.ts` would silently do nothing. |
| 6 | `grep -A2 '"engines"' node_modules/@supabase/supabase-js/package.json` | Shows the Node requirement actually installed; it must be satisfied by the Node from step 1. |
| 7 | `npm run typecheck` | Source type check against the real `next`, `react` and `@supabase/*` types. Expect first-run findings; paste them as they are. Next may rewrite `tsconfig.json` on first use; keep the rewritten file only after reviewing the diff. |
| 8 | `npx tsc -p tests/tsconfig.json --noEmit` | Type check of `src` and `tests` together. |
| 9 | `npm test` | Runs `node tests/run.mjs`. Expect 83 tests, 0 failures. These tests use stand-ins for `next/*` and `@supabase/ssr`; a pass proves the app logic, not the real libraries. |
| 10 | `npm run build` | `next build` with no `.env.local` is enough (every app page is dynamic). It must exit 0. In the output, confirm that Next lists the proxy (`src/proxy.ts`) and shows the app routes as dynamic. |

Report back: the full text of every failing step, `versions-installed.txt`, the Node and npm versions, and the build's route summary.

Afterwards, and only with separate approval: review `package-lock.json` and commit it (it is generated by npm, never edited by hand); decide whether to replace the `latest` ranges with ranges based on the recorded versions; then do the Supabase dashboard checks listed above and the first sign-in smoke test. Do not put any key or password in the report, in a file in the project, or in chat.
