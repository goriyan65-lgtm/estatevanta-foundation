# Phase 2 — Security tests (fully rolled back)

Script: `supabase/tests/phase2_security_tests.sql`. Run it in **Supabase Dashboard → SQL Editor** for the project *Estate vanta crm*: paste the whole file, press Run once.

## How to read the result
The script is one `DO` statement that **always ends with an intentional error** whose text is the report. That error is the proof that everything was rolled back — do not "fix" it. The report starts with:

    RESULT: PASS n | FAIL n | GAP n | SKIP n
    STATE AFTER ROLLBACK: IDENTICAL to pre-test snapshot ...
    SEQUENCES: restored to pre-test values

* **FAIL** = unexpected behaviour (a permission that should be denied was allowed, or vice versa). Send me the report.
* **GAP** = known, documented behaviour that the script deliberately flags (see "Known gaps").
* **SKIP** = the bootstrap tests are skipped if a real active admin already exists or the real bootstrap is armed, so real state is never touched. Run the script **before** the real bootstrap to get them.
* Matrix lines show `adm / mgr / agt / vwr` results, e.g. `deals visible -> adm=2 mgr=2 agt=1 vwr=0`.

The Dashboard may show a "destructive operation" confirmation (it sees UPDATE/DELETE text). That is expected.

## Can the SQL Editor safely run the auth.users setup?
Yes, with these properties (all checked on the live project before writing the script, except where marked):
* The editor connects as role `postgres`, which has INSERT/DELETE on `auth.users`, owns the `public`/`app` tables, is a member of `anon`, `authenticated` and `service_role` (needed for `SET LOCAL ROLE`), and can run the owner-only bootstrap functions. The script's preflight section re-checks each of these and reports FAIL if not.
* The only non-internal trigger on `auth.users` is `on_auth_user_created` (creates the inactive, role-less profile), so inserting test users does **not** send e-mail, call webhooks or create sessions.
* The whole script is **one statement**, therefore one transaction. A deliberate `RAISE EXCEPTION` at the end aborts it, so every user, profile, fixture, role, setting, audit row and temporary function disappears. If the connection is lost mid-run the transaction aborts as well.
* Sequences are the one thing a rollback cannot undo. The script records every sequence in `public`, `app` and `auth` first and restores it with `setval()` before reporting (verified by comparison).
* Before and after, it fingerprints `auth.users`, `profiles`, `audit_logs`, **every** table in `public` and `app` (row count + hash of all rows) and selected `auth` tables, and reports any difference.
* Test identities are `@example.invalid` with a random tag. The bootstrap secret is generated inside the script, never printed, never stored outside the aborted transaction, and unrelated to your real secret.
* Tests that try to change real roles/permissions are denial tests, each run in its own sub-transaction that is rolled back even if the statement unexpectedly succeeded. Allowed-path write tests use throwaway keys/roles only.
* Not verified on the live project by me: I could not run this script there (the tooling cancelled earlier `auth.users` writes) and chose not to retry. It was validated on a local PostgreSQL 16 replica built from the same migrations (0001–0009 + Phase 2 Steps 1–2), including: normal run, run with a committed "real" admin present (bootstrap tests skip), and a run with an injected fatal error (state still identical). Differences from your project (Supabase's own `auth`/`storage` internals, extension schema, `supautils`) are the residual risk; if the script fails to start on your project, nothing has changed and the error text will say why.

## What is covered
1. Bootstrap success path (right secret, confirmed matching email, armed, unexpired, no admin) incl. consumed row, wiped hash, audit event, secret not retained.
2. Wrong / null / empty secret.
3. Expired window (window forced into the past inside the aborted transaction).
4. Email mismatch.
5. Unconfirmed email.
6. Concurrency — **evidence only** (see below).
7. Self-promotion and escalation attempts by role-less, viewer, agent and manager users (own role, own activation, other users, role_permissions, roles, permissions, profile insert/delete, calling the bootstrap functions, old one-argument function).
8. Permission matrix for admin / manager / agent / viewer: 17 read checks and 25 write checks, each with real role + JWT claims (`request.jwt.claims`, `sub`, `role`) exactly as PostgREST sets them; viewers cannot see deals, commissions, payments or owner terms; agents see all active inventory but cannot edit others' properties; audit_logs is append-only for everyone.
9. Edge callers: deactivated, soft-deleted, profile-less, anon. `my_access()` caller-only checks. `security_log_event()` success and rejection paths.
10. Section 7, Step 3 protections: triggers installed; soft-delete guard on profiles; system roles cannot be deleted/renamed/un-flagged; admin permissions cannot be removed or reassigned; last-admin protection (demote, deactivate, soft-delete, delete, auth-user cascade, self-demotion) with controls proving normal admin work and non-admin roles are unaffected.

## Latest live result (project "Estate vanta crm", after Step 3, 2026-10-04)
`PASS 322 | FAIL 0 | GAP 2 | SKIP 0`, no fatal error, state identical after rollback, sequences restored. The only 2 GAP lines are the known manager soft-delete defect below.

## Concurrency: what is and is not proven
A real race needs two sessions at the same time and **committed** data (a second session cannot see uncommitted `auth.users` rows). You asked for no committed users, so the script proves serialisation indirectly: the bootstrap call holds the global advisory lock (checked in `pg_locks`), both functions use the same lock key and `FOR UPDATE` on the state row (static check of their source), and a second attempt after the first succeeds is refused with "already completed" — the exact outcome a racing loser sees after waiting on the lock. Real parallel testing, if you want it, needs an explicit approval for temporary committed users and a cleanup step. Step 3's last-admin race is not proven by the live script either. It was proven separately on a local replica with two real concurrent sessions (two committed admins, each session deactivating one): one succeeded, the other was refused with "Cannot remove, demote or deactivate the last active admin". It has not been run against the live project, which has no committed users.

## Known gaps reported as GAP (expected)
* ~~Soft-deleted user can restore their own profile~~ **FIXED by Step 3** (`guard_profile_privileges` now also checks `deleted_at`). Live result after Step 3: PASS.
* **Non-admin soft-delete is rejected by RLS** (leads, properties; likely other soft-delete tables): the SELECT policy hides rows with `deleted_at` set from non-admins, and PostgreSQL re-checks that policy on the updated row. Managers who hold `*.delete` therefore cannot archive records. Not a security hole (it only denies). Proposed fix for Phase 3: a SECURITY DEFINER archive/restore function per entity that checks the `.delete` permission, instead of loosening the SELECT policy.

## Other observations
* `viewer` holds `properties.read_all`, so viewers can read `property_documents` metadata (title, category, storage path; not the files themselves). This matches the policy text from 0009 but you may prefer to restrict it.
* There is no throttling on wrong bootstrap secrets; mitigated because only the database owner can call the function.
* `service_role` can still write directly to `audit_logs` (server-side only by design; never expose that key to the browser).
* `users.manage` is effectively admin-equivalent: a non-admin role that is ever granted `users.manage` could promote users to admin. With the default roles only admin holds it. Step 3 does not change this; keep it in mind when editing role permissions in the admin UI (later phase).
* Step 3 protections apply to the database owner / SQL Editor too (the last-admin check is a trigger, not a policy). Owner recovery: `alter table profiles disable trigger protect_last_admin;` and re-enable afterwards.
