# Supabase Setup — Fresh Project (no Cloud Shell, no billing)

Installer: `migrations/0000_estatevanta_all.sql` (one file, runs once). It contains no BEGIN/COMMIT: PostgreSQL runs a multi-statement script as one implicit transaction, so a failure rolls everything back.
Status of this file: **statically checked only** (no PostgreSQL was available to execute it). Your first run is its first real test.

## 1. Create the project (free plan)
1. Open https://supabase.com → **Sign in** (GitHub or email).
2. **New project** → choose/create an organization (Free plan is fine; no card needed).
3. Name: `estatevanta-crm`. Database password: create a strong one and **save it in a password manager**. Region: closest to you (e.g. Mumbai / South Asia).
4. Tap **Create new project**, wait 1–3 minutes until the dashboard loads.
5. Do not add any other setup. Do not run any template SQL or "sample data".

Android tip: the dashboard is easier in Chrome with **⋮ → Desktop site** turned on.

## 2. Run the installer
1. Dashboard left menu → **SQL Editor** → **New query** (blank).
2. The tab must be **completely empty** first: tap in the editor, select all, delete. Then open `0000_estatevanta_all.sql`, select all, copy, paste. Confirm the very first line of the editor is `-- ====…` followed by `-- EstateVanta CRM — 0000_estatevanta_all.sql (installer, revision 2)` and the last line is `-- ## END SECTION 0009_confirmed_decisions.sql`. Nothing may appear above or below the pasted text.
3. Tap **Run**. If a warning about "destructive operations" appears (the script contains a `drop column`, `drop policy` and one `delete` on empty configuration tables), choose **Run this query**.
4. Wait for the result. Expected: **Success. No rows returned.**

If it fails, nothing should be kept (implicit single transaction). Go to §5.

## 3. Verify — run each query in a new SQL Editor tab

**3.1 Tables (expect 43)**
```sql
select count(*) as tables from information_schema.tables
where table_schema='public' and table_type='BASE TABLE';
```

**3.2 RLS on every table (expect 0 rows)**
```sql
select c.relname as table_without_rls
from pg_class c join pg_namespace n on n.oid=c.relnamespace
where n.nspname='public' and c.relkind='r' and not c.relrowsecurity;
```

**3.3 Policies exist (expect a positive number, and 0 tables without any policy)**
```sql
select count(*) as policies from pg_policies where schemaname in ('public','storage');

select c.relname as table_without_policy
from pg_class c join pg_namespace n on n.oid=c.relnamespace
where n.nspname='public' and c.relkind='r'
  and not exists (select 1 from pg_policies p where p.schemaname='public' and p.tablename=c.relname);
```

**3.4 Roles (expect admin, manager, agent, viewer)**
```sql
select code from roles order by id;
```

**3.5 Permissions per role (expect admin 60, manager 57, agent 18, viewer 12)**
```sql
select r.code, count(*) as permissions
from roles r join role_permissions rp on rp.role_id=r.id
group by r.code order by r.code;
select count(*) as total_permissions from permissions;   -- expect 60
```

**3.6 Confirmed decisions**
```sql
-- Viewer has NO finance or deal access (expect 0 rows)
select p.code from roles r join role_permissions rp on rp.role_id=r.id
join permissions p on p.id=rp.permission_id
where r.code='viewer' and (p.code like 'finance.%' or p.code like 'deals.%');

-- Agent can view active inventory but not edit all (expect read_active present, write_all absent)
select p.code from roles r join role_permissions rp on rp.role_id=r.id
join permissions p on p.id=rp.permission_id
where r.code='agent' and p.code like 'properties.%' order by 1;

-- Settings (expect reverify 30, hot priorities ["high","urgent"])
select key, value from settings order by key;

-- Area units (expect marla 272.25, kanal 5445, bigha NULL)
select code, sq_ft_factor from area_units order by code;
```

**3.6b Default matching weights (expect 6 rows, total 100, config active)**
```sql
select c.name, c.is_active, w.criterion, w.weight
from matching_configs c join matching_weights w on w.config_id=c.id order by w.weight desc;
```

**3.7 Reference lists (expect 11 / 13 / 12 / 7)**
```sql
select (select count(*) from lead_statuses)  as lead_statuses,
       (select count(*) from lead_sources)   as lead_sources,
       (select count(*) from property_types) as property_types,
       (select count(*) from area_units)     as area_units;
```

**3.8 No demo/business data (every count must be 0)**
```sql
select 'contacts' t, count(*) from contacts union all
select 'leads', count(*) from leads union all
select 'buyers', count(*) from buyers union all
select 'sellers', count(*) from sellers union all
select 'properties', count(*) from properties union all
select 'buyer_requirements', count(*) from buyer_requirements union all
select 'property_matches', count(*) from property_matches union all
select 'appointments', count(*) from appointments union all
select 'site_visits', count(*) from site_visits union all
select 'tasks', count(*) from tasks union all
select 'activities', count(*) from activities union all
select 'deals', count(*) from deals union all
select 'commissions', count(*) from commissions union all
select 'payments', count(*) from payments union all
select 'market_data', count(*) from market_data union all
select 'import_batches', count(*) from import_batches union all
select 'notifications', count(*) from notifications union all
select 'profiles', count(*) from profiles;
```

**3.9 Audit triggers (expect 25) and buckets (expect 4)**
```sql
select count(*) as audit_triggers from pg_trigger where tgname like 'audit\_%' and not tgisinternal;
select id, public from storage.buckets order by id;    -- 4 rows, public = false
```

**3.10 Money column moved (expect 0 rows for properties, 1 row for owner terms)**
```sql
select column_name from information_schema.columns
where table_schema='public' and table_name='properties' and column_name='min_price';
select column_name from information_schema.columns
where table_schema='public' and table_name='property_owner_terms' and column_name='min_price';
```

Note: `audit_logs` will contain rows for the configuration inserts (roles, settings, etc.). That is expected and is not business data.

## 4. Do NOT do yet
- Do not create users or run the bootstrap until Phase 2 is reviewed (use `docs/PHASE2_TESTING.md` first; the old one-argument `bootstrap_first_admin` is disabled).
- Do not connect the existing website.
- Do not insert test rows into business tables.

## 5. If something goes wrong
1. Do not re-run the file yet.
2. Run 3.1. If it returns **0**, the rollback worked; the project is clean.
3. If it returns a number between 1 and 42, or 3.4 shows roles although the run failed, the project is partly installed: **delete the project** (Project Settings → General → Delete project) and create a fresh one. That costs nothing.
4. Send back:
   - The exact error text (copy it; a screenshot is fine if copy fails), including any `LINE`/`position` shown
   - The first 3 lines and last 2 lines of what is in the editor (so I can tell whether anything extra is above/below the script). The first executable statement in the file is on line 31 (`create extension if not exists pgcrypto;`); a reported line number that is far from where the same text sits in the file means extra text is in the editor
   - Which step you were on (2 or 3.x)
   - The result of 3.1
   - Do **not** send your database password or API keys
