# EstateVanta CRM — Architecture (Phase 1)

Status: design + database migrations written. **Nothing has been executed against a live database or deployed.** The existing website has not been touched.

---

## 1. OBSERVED FROM LIVE WEBSITE

Source: `https://estatevanta-8bb02.web.app/` (fetched once). Only the HTML `<head>` metadata was returned; the visible page body was not.

| Observed | Value |
|---|---|
| Title | EstateVanta — Find Your Place. Build Your Future. \| Hisar, Haryana |
| Business | Real estate / property consultancy, Hisar, Haryana; buy, sell, rent, invest |
| Named contact in metadata | Neeraj Goriya, Founder & Property Consultant |
| Canonical URL | `https://estatevanta.com/` (a custom domain exists) |
| Hosting host | `*.web.app` = Firebase Hosting domain |
| SEO | Indexable; keywords for homes, plots, commercial property in Hisar |
| Tagline | "Find Your Place. Build Your Future." |

`https://estatevanta.com/` blocks automated access (robots), so it was **not** inspected. No workaround was attempted.

## 2. CANNOT BE DETERMINED WITHOUT SOURCE CODE / A BROWSER SESSION

Not observed, therefore **not assumed**:

- Framework (React, Vue, plain HTML, other), routing, component structure
- Whether it is a single-page app or multi-page
- Pages, navigation, property listings, property detail layout, filters
- Enquiry/contact form fields, where they submit, and to what backend
- Whether Firestore, Firebase Auth, Functions or Storage are used
- Whether property data is hard-coded, in Firestore, or elsewhere
- Deployment config (`firebase.json`, rewrites, CI)

Ways to close this gap **without source code** (pick any; none require Cloud Shell or billing):
1. You paste/screenshot the pages and forms from your phone browser.
2. You open the site → browser menu → "View page source" / DevTools → Network tab while submitting the enquiry form, and share what the form request looks like.
3. Firebase Console (free tier, read-only look): Hosting → shows the deployed release; Firestore/Auth tabs show whether they're used.

## 3. NEW CRM ARCHITECTURE

```
 Public website (unchanged)          Admin Panel (new)
        │  enquiry POST                    │  authenticated
        ▼                                  ▼
 /api/public/enquiries            Next.js App Router (server components,
 (server route, validated,        route handlers, server actions)
  rate-limited, honeypot)                  │
        │                                  │ user JWT  → RLS enforced
        ▼                                  ▼
   services/leads  ─────────►   Supabase PostgreSQL  ◄── Supabase Auth
   (dedupe → lead → requirement            │
    → matching → notification)              └── Supabase Storage (private buckets)
```

Principles
- **One database, one person table.** `contacts` holds name/phone/WhatsApp/email once. Buyers, sellers and leads point to it.
- **Two DB access modes.** (a) *User-context* client (user JWT) for all admin reads/writes → RLS decides. (b) *Service-role* client only in server-only modules (`server/admin-client.ts`) for public enquiry intake, matching runs and scheduled jobs. Never imported by client code.
- **Business logic in TypeScript services**, data rules and security in SQL. Matching weights are rows, not code.
- **Provider-portable.** Plain Postgres + SQL migrations + S3-like storage paths. Moving off Supabase means moving Postgres and swapping the auth/storage adapters.
- **Cost-conscious.** One Next.js app, one Supabase project, no queue/cache/search services in v1.

Key design decisions (⚑ = confirmed by owner on Phase 1 review; applied in migration `0009_confirmed_decisions.sql`)

| # | Decision |
|---|---|
| 1 | Buyer-level "preferred locations / budget / BHK / area / property types" live in `buyer_requirements` (a buyer can have many). The buyer screen shows a **derived summary** of active requirements, so nothing is typed twice. |
| 2 | Owner phone/WhatsApp on a property is read via property → seller → contact. Agents who can view a property but are not assigned to its owner will not see the owner's contact record (seller RLS is assignment-based). |
| 3 | Site Visit = `appointments` row (type `site_visit`) + `site_visits` detail row. Owner is derived from the property. |
| 4 | ⚑ **Hot Lead = priority High or Urgent.** Stored in setting `leads.hot_priorities`; editable in Settings. |
| 5 | ⚑ **Agents can VIEW all active inventory** (status available / reserved / under negotiation) via permission `properties.read_active`. **Editing/deleting** requires being the assigned/creating user, or holding `properties.write_all` (Admin, Manager). Agents do not see other agents' inactive/sold listings, nor their documents or owner terms. |
| 6 | ⚑ **Viewers see no financial fields.** Viewer has no `finance.*` and no `deals.*` permission. "Minimum price" was moved from `properties` to `property_owner_terms` (visible only to the property's editors and `finance.read_all` holders), as are brokerage terms. Analytics endpoints must omit commission / deal-value / payment metrics unless the caller holds `finance.read_all` (enforced in the API layer in Phase 10). Viewers still have `analytics.read` for non-financial metrics. |
| 7 | ⚑ **Re-verification default = 30 days** (`property.reverify_days`, editable). |
| 8 | Phone matching uses the **last 10 digits** (assumes Indian numbers). |
| 9 | ⚑ **Area units:** Marla = 272.25 sq ft, Kanal = 5,445 sq ft (= 20 marla). **Bigha is intentionally unset** (`sq_ft_factor` NULL) because the local definition varies; area matching skips bigha-denominated values until you set it in Settings. Sq ft, sq yd (gaj = 9 sq ft), sq m and acre are preset. |
| 10 | Commission: deal-level `commission_amount = final_price × pct / 100` (generated column). Buyer-side/seller-side expected commission and receipts are separate rows in `commissions` / `payments`. |
| 11 | Deleting = soft delete (`deleted_at`) for business entities; hard delete is admin-only. |
| 12 | The matching engine runs server-side with the service-role client so it can consider all matchable inventory; what an agent sees of the results is still filtered by RLS. |

## 4. FOLDER STRUCTURE (target)

```
estatevanta-crm/
├─ README.md
├─ package.json  tsconfig.json  next.config.ts  tailwind.config.ts  .env.example
├─ middleware.ts                         # session refresh + admin route protection
├─ supabase/
│  ├─ config.toml
│  ├─ migrations/0001…0009_*.sql         # ← WRITTEN
│  └─ tests/                             # pgTAP/SQL RLS + constraint tests
├─ src/
│  ├─ app/
│  │  ├─ (public)/                       # ⟂ REQUIRES EXISTING WEBSITE — placeholder only
│  │  ├─ (auth)/login, reset-password
│  │  ├─ (admin)/
│  │  │  ├─ layout.tsx                   # responsive shell (sidebar ≥lg, bottom-nav + drawer on phone)
│  │  │  ├─ dashboard/
│  │  │  ├─ crm/{leads,buyers,sellers,contacts}/
│  │  │  ├─ properties/{[id],new,owner-inventory}/
│  │  │  ├─ matching/{requirements,matches,history}/
│  │  │  ├─ appointments/{site-visits,calls,meetings,follow-ups}/
│  │  │  ├─ deals/{negotiations,closed,commission,payments}/
│  │  │  ├─ analytics/
│  │  │  ├─ market/
│  │  │  └─ settings/{users,roles,lists,matching,import,general}/
│  │  └─ api/
│  │     ├─ public/enquiries/route.ts    # website → CRM (no auth, hardened)
│  │     ├─ leads|buyers|sellers|contacts|properties|requirements|matches|
│  │     │  site-visits|appointments|tasks|deals|payments|commissions/…
│  │     ├─ imports/…                    # upload, map, validate, confirm
│  │     └─ health/route.ts
│  ├─ server/                            # server-only (never bundled to client)
│  │  ├─ supabase/{user-client,admin-client}.ts
│  │  ├─ auth/{session,permissions}.ts
│  │  ├─ services/
│  │  │  ├─ crm/{leads,buyers,sellers,contacts,duplicates}.ts
│  │  │  ├─ properties/{properties,media,verification}.ts
│  │  │  ├─ matching/{engine,scoring,config}.ts
│  │  │  ├─ appointments/{visits,tasks}.ts
│  │  │  ├─ deals/{deals,commission,payments}.ts
│  │  │  ├─ analytics/{dashboard,reports}.ts
│  │  │  ├─ imports/{parse-csv,parse-xlsx,parse-json,validate,commit}.ts
│  │  │  └─ notifications/{notify,outbox}.ts
│  │  └─ integrations/
│  │     └─ messaging/{provider.ts, whatsapp-cloud.ts?, email.ts?}   # adapters, off by default
│  ├─ lib/{validation/*.zod.ts, format.ts, phone.ts, errors.ts}
│  ├─ components/{ui,layout,forms,tables,cards,empty-states}/
│  └─ types/database.ts                  # generated from the schema
└─ tests/{unit,integration,e2e}/
```

## 5. DATABASE

Files: `supabase/migrations/0001…0009` (`migrations/0000_estatevanta_all.sql` is a straight concatenation for one-shot installation). 43 tables, 4 views and 43 enums across:

- **Auth/RBAC:** `profiles`, `roles`, `permissions`, `role_permissions`
- **People:** `contacts`, `duplicate_candidates`, `buyers`, `sellers`, `leads`
- **Inventory:** `properties`, `property_owner_terms`, `property_amenities`, `property_media`, `property_documents`
- **Matching:** `buyer_requirements`, `requirement_property_types`, `requirement_localities`, `requirement_preferences`, `matching_configs`, `matching_weights`, `property_matches`
- **Scheduling/work:** `appointments`, `site_visits`, `tasks`, `activities`
- **Money:** `deals`, `deal_documents`, `commissions`, `payments`
- **Platform:** `settings`, `notifications`, `message_outbox`, `import_batches`, `import_rows`, `market_data`, `saved_filters`, `audit_logs`
- **Reference:** `lead_statuses`, `lead_sources`, `property_types`, `area_units`, `amenities`, `localities`

Relationship chain requested:

```
sellers 1─N properties
buyers 1─N buyer_requirements 1─N property_matches N─1 properties
properties 1─N site_visits N─1 buyers          (site_visits ↔ appointments 1:1)
leads N─1 contacts ;  leads N─0..1 buyers / sellers
leads 1─N activities, tasks
deals: buyer_id + seller_id + property_id (+ lead_id, requirement_id)
deals 1─N payments ; deals 1─N commissions (buyer/seller side) ; payments → commissions
```

Enum vs reference: lifecycle states used by code = Postgres enums; owner-configurable lists = reference tables with text-code PKs.
Soft delete: `deleted_at/deleted_by` on people, properties, requirements, appointments, tasks, deals, market data. Partial indexes ignore deleted rows.

## 6. AUDIT

`audit_logs` (append-only). One generic trigger `app.audit_row()` on 25 tables records actor (`auth.uid()`), action (`insert/update/delete/soft_delete/restore`), table, id, **only the changed columns** old/new, timestamp, optional `request_id`. Property price/status, lead status, deal, owner, and document changes are covered because those tables are audited. Readable only with `audit.read`. `updated_at` alone is ignored as noise.

## 7. SECURITY / RLS

1. RLS enabled on **every** public table; migration 0007 ends by failing if any table lacks RLS. `anon` has no table privileges.
2. Policies check **permission codes**, not role names → permissions are configurable in Settings without changing SQL.
3. Scoped modules (`leads, buyers, sellers, properties, appointments, tasks, deals`): `read_all` sees everything; `read` sees rows where `assigned_to` or `created_by` = caller. Write requires `<module>.write`.
4. Child tables inherit from the parent row's visibility (requirements, matches, media, documents, visits, payments…).
5. New signups get a profile that is **inactive with no role**; an admin activates them. The first admin is created once from the SQL editor by the database owner: `app.arm_bootstrap(secret, expected_email, minutes)` then `app.bootstrap_first_admin(user_uuid, secret)` (only a hash of the secret is stored; confirmed e-mail must equal the armed e-mail; single-use, serialised by an advisory lock; not callable by any API role). The old one-argument function is disabled.
6. Users cannot change their own role/activation (trigger guard). Phase 2 Step 3 (applied) adds soft-delete protection, last-active-admin protection and immutable system roles/admin permissions.
   Server-side security events go through `public.security_log_event` (service_role only); the browser reads its own access with `public.my_access()` (SECURITY INVOKER).
7. Soft delete needs `<module>.delete` (trigger guard).
8. Storage: four private buckets; object reads allowed only if a matching row is visible; browser gets signed URLs.
9. Service-role key: server-only env var, imported only under `src/server/`.
10. API: every route validates input with zod, checks session + permission, returns typed errors; public enquiry route adds honeypot, size limits, IP rate limiting, no data echoed back.

Default role grants (60 permissions; Admin 60 · Manager 57 · Agent 18 · Viewer 12): **Admin** all · **Manager** everything operational + finance + analytics + imports, incl. `properties.read_active/write_all` (no users/settings/audit) · **Agent** assigned leads/buyers/sellers/appointments/tasks/deals, assigned-only property editing, read-only view of all active inventory, no finance · **Viewer** read-only on operational modules, no finance, no deals, no imports/messaging/audit.

Grants: migration 0009 gives `authenticated` and `service_role` schema/table/sequence privileges (RLS still governs rows); `anon` has none.

## 8. API PLAN

REST route handlers, JSON, all under `/api`, all authenticated except `/api/public/enquiries` and `/api/health`.

```
GET/POST   /api/leads              GET/PATCH/DELETE(soft) /api/leads/:id      POST /api/leads/:id/convert
GET/POST   /api/contacts           GET/PATCH /api/contacts/:id   POST /api/contacts/duplicates/:id/resolve
GET/POST   /api/buyers             GET/PATCH /api/buyers/:id
GET/POST   /api/sellers            GET/PATCH /api/sellers/:id
GET/POST   /api/properties         GET/PATCH/DELETE /api/properties/:id
POST       /api/properties/:id/media (upload-url, reorder, set-primary, delete)
POST       /api/properties/:id/documents
POST       /api/properties/:id/verify
GET/POST   /api/requirements       GET/PATCH /api/requirements/:id
POST       /api/matches/run        GET /api/matches?requirement_id=   PATCH /api/matches/:id
GET/POST   /api/site-visits        PATCH /api/site-visits/:id
GET/POST   /api/appointments       GET/POST /api/tasks   PATCH /api/tasks/:id
GET/POST   /api/deals              GET/PATCH /api/deals/:id
POST       /api/deals/:id/payments GET /api/commissions
GET        /api/dashboard          GET /api/analytics/*
POST       /api/imports (upload)   POST /api/imports/:id/{map,validate,confirm}
GET        /api/audit-logs         GET/PATCH /api/settings
POST       /api/public/enquiries   ← website → CRM
```

Public enquiry pipeline: validate → normalise phone → `find_contact_matches` → (exact match: attach new lead to existing contact and flag; possible match: create `duplicate_candidates` row for a human decision) → create lead → create buyer requirement if budget/location/type given → run matching (service-role, background-safe) → notification rows to assigned/on-duty users.

## 9. IMPORT SYSTEM (authorized data only)

`upload → parse (CSV/XLSX/JSON) → map fields → validate → duplicate detection → preview → confirm → import`.
- Each batch requires a written **authorization note** (DB-enforced) and `source_name`; `source_url`, `source_date` and `verification_status` are preserved on every imported record.
- Raw rows are stored untouched in `import_rows`; nothing is written to real tables until an authorized user confirms.
- No scraper, crawler or headless-browser code exists in this project. Housing.com, 99acres and MagicBricks data is accepted only as files you are entitled to use.

## 10. REQUIRES EXISTING SOURCE CODE / ACCESS

| Item | Why |
|---|---|
| Public site enquiry-form wiring | Need the form's fields and submit mechanism |
| Property listing source | Unknown whether static, Firestore or other |
| Migrating any existing Firestore data | Unknown whether it exists |
| CORS/allow-list for the public endpoint | Need final site origin(s): `estatevanta.com`, `estatevanta-8bb02.web.app` (both observed) |
| Any redirect/deployment change | Nothing to do until we can see the hosting config |

None of these block Phases 2–8 and 10–11.
