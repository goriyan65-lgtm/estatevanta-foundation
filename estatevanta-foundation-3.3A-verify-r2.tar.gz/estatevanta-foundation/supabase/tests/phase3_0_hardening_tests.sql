-- =====================================================================
-- EstateVanta CRM — Phase 3.0 hardening tests (FULLY ROLLED BACK)
-- Run in: Supabase Dashboard -> SQL Editor, project "Estate vanta crm", AFTER 0011a is applied
-- (also runnable BEFORE it: hardening-specific lines then show as GAP, everything else must pass).
-- Same safety model as phase2_security_tests.sql: ONE DO statement, throwaway @example.invalid users,
-- every change thrown away by a final deliberate error (P0001 "P3.0 TEST REPORT" = normal outcome),
-- sequences restored with setval, before/after fingerprint of every public/app table.
-- It never reads or changes real data and never uses a real secret.
-- =====================================================================
do $p3$
declare
  sep text := chr(31);
  tag text := substr(md5(random()::text || clock_timestamp()::text), 1, 8);
  sec_ok text := 'P3TEST-' || md5(random()::text) || md5(clock_timestamp()::text);
  deny text := '0//ERR 42501%';
  u_boot uuid := gen_random_uuid(); u_admin uuid := gen_random_uuid(); u_mgr uuid := gen_random_uuid();
  u_agent uuid := gen_random_uuid(); u_viewer uuid := gen_random_uuid(); u_new uuid := gen_random_uuid();
  c_a uuid := gen_random_uuid(); lead_a uuid := gen_random_uuid();
  r_admin smallint; r_mgr smallint;
  out text[] := '{}'; fatal text; do_boot boolean; admin_before boolean; armed_before boolean;
  hardened boolean; kh text; n_pinned int; orig_sp text;
  snap0 jsonb; snap1 jsonb; seq0 jsonb; seq1 jsonb; seq_ok boolean; diff_tables text;
  rec record; rpt text := ''; top text := ''; cur_sec text := ''; msg text;
  n_p int; n_f int; n_g int; n_s int;
begin

  -- ---------------------------------------------------------------
  execute $h$
    create function pg_temp.pk(p_ok boolean, p_kind text, p_label text, p_who text, p_got text, p_want text)
    returns text language sql as $f$
      select (case when p_ok then 'P' when p_kind = 'G' then 'G' when p_kind = 'S' then 'S' else 'F' end)
             || chr(31) || coalesce(current_setting('p2.section', true), '')
             || chr(31) || p_label || chr(31) || p_who
             || chr(31) || left(replace(coalesce(p_got, ''), chr(10), ' '), 70)
             || chr(31) || left(coalesce(p_want, ''), 70)
    $f$ $h$;

  execute $h$
    create function pg_temp.chk(p_label text, p_who text, p_role text, p_uid uuid, p_sql text,
                                p_expect text, p_kind text default 'T', p_rb boolean default false)
    returns text language plpgsql as $f$
    declare v text; n bigint; claims text; ok boolean := false; alt text;
    begin
      if p_role in ('anon', 'authenticated', 'service_role') then
        claims := case when p_uid is null then json_build_object('role', p_role)::text
                       else json_build_object('sub', p_uid, 'role', p_role, 'aud', 'authenticated')::text end;
        perform set_config('request.jwt.claims', claims, true);
        perform set_config('request.jwt.claim.sub', coalesce(p_uid::text, ''), true);
        perform set_config('request.jwt.claim.role', p_role, true);
        execute format('set local role %I', p_role);
      end if;
      begin
        if p_sql ~* '^\s*(insert|update|delete)\s' then
          execute p_sql; get diagnostics n = row_count; v := n::text;
        else
          execute p_sql into v; v := coalesce(v, '(null)');
        end if;
        if p_rb then raise exception 'rollback this test' using errcode = 'P2RBK'; end if;
      exception
        when sqlstate 'P2RBK' then null;
        when others then v := 'ERR ' || sqlstate || ' ' || left(sqlerrm, 80);
      end;
      execute 'reset role';
      perform set_config('request.jwt.claims', '', true);
      perform set_config('request.jwt.claim.sub', '', true);
      perform set_config('request.jwt.claim.role', '', true);
      foreach alt in array string_to_array(p_expect, '//') loop
        if v like alt then ok := true; end if;
      end loop;
      return pg_temp.pk(ok, p_kind, p_label, p_who, v, p_expect);
    end $f$ $h$;

  execute $h$
    create function pg_temp.mx(p_label text, p_sql text, ea text, em text, eg text, ev text, p_kind text default 'T')
    returns text[] language plpgsql as $f$
    begin
      return array[
        pg_temp.chk(p_label, 'adm', 'authenticated', current_setting('p2.u_admin')::uuid,  p_sql, ea, p_kind, true),
        pg_temp.chk(p_label, 'mgr', 'authenticated', current_setting('p2.u_mgr')::uuid,    p_sql, em, p_kind, true),
        pg_temp.chk(p_label, 'agt', 'authenticated', current_setting('p2.u_agent')::uuid,  p_sql, eg, p_kind, true),
        pg_temp.chk(p_label, 'vwr', 'authenticated', current_setting('p2.u_viewer')::uuid, p_sql, ev, p_kind, true)];
    end $f$ $h$;

  execute $h$
    create function pg_temp.p2_snapshot() returns jsonb language plpgsql as $f$
    declare r record; j jsonb := '{}'; v text;
    begin
      for r in select n.nspname, c.relname from pg_class c join pg_namespace n on n.oid = c.relnamespace
               where c.relkind in ('r', 'p')
                 and (n.nspname in ('public', 'app')
                      or (n.nspname = 'auth' and c.relname in ('users', 'identities', 'sessions', 'refresh_tokens')))
               order by 1, 2
      loop
        begin
          execute format('select count(*)::text || '':'' || coalesce(md5(string_agg(t::text, ''|'' order by t::text)), ''-'') from %I.%I t',
                         r.nspname, r.relname) into v;
        exception when others then v := 'unreadable';
        end;
        j := j || jsonb_build_object(r.nspname || '.' || r.relname, v);
      end loop;
      return j;
    end $f$ $h$;

  execute $h$
    create function pg_temp.p2_seqs() returns jsonb language plpgsql as $f$
    declare r record; j jsonb := '{}'; lv bigint; ic boolean;
    begin
      for r in select n.nspname, c.relname from pg_class c join pg_namespace n on n.oid = c.relnamespace
               where c.relkind = 'S' and n.nspname in ('public', 'app', 'auth') order by 1, 2
      loop
        begin
          execute format('select last_value, is_called from %I.%I', r.nspname, r.relname) into lv, ic;
          j := j || jsonb_build_object(r.nspname || '.' || r.relname, jsonb_build_array(lv, ic));
        exception when others then null;
        end;
      end loop;
      return j;
    end $f$ $h$;

  execute $h$
    create function pg_temp.p2_restore_seqs(p_seqs jsonb) returns void language plpgsql as $f$
    declare r record;
    begin
      for r in select key, value from jsonb_each(p_seqs) loop
        begin
          perform setval(r.key::regclass, (r.value ->> 0)::bigint, (r.value ->> 1)::boolean);
        exception when others then null;
        end;
      end loop;
    end $f$ $h$;

  execute $h$
    create function pg_temp.p30_owner_apply() returns text language plpgsql as $f$
    declare n int;
    begin
      create table public.zz_p30_tbl (id int);
      perform app.apply_global_policies('zz_p30_tbl', 'settings');
      select count(*) into n from pg_policies where schemaname = 'public' and tablename = 'zz_p30_tbl';
      return n::text;
    end $f$ $h$;

  snap0 := pg_temp.p2_snapshot();
  seq0  := pg_temp.p2_seqs();
  admin_before := exists (select 1 from profiles p join roles r on r.id = p.role_id
                          where r.code = 'admin' and p.is_active and p.deleted_at is null);
  armed_before := exists (select 1 from app.bootstrap_setup);
  do_boot := not admin_before and not armed_before;
  select count(*) into n_pinned from pg_proc
   where oid in ('app.guard_profile_privileges()'::regprocedure, 'app.guard_soft_delete()'::regprocedure,
                 'app.set_updated_at()'::regprocedure, 'app.enforce_active_weights()'::regprocedure,
                 'app.next_code(text,regclass)'::regprocedure, 'app.bootstrap_first_admin(uuid)'::regprocedure,
                 'public.find_contact_matches(text,text,text)'::regprocedure,
                 'app.apply_child_policies(text,text,text,text,text)'::regprocedure, 'app.apply_global_policies(text,text)'::regprocedure,
                 'app.apply_scoped_policies(text,text,text)'::regprocedure)
     and proconfig = array['search_path=public, extensions, pg_temp'];
  hardened := (n_pinned = 10) and not has_function_privilege('authenticated', 'app.apply_scoped_policies(text,text,text)'::regprocedure, 'execute');
  kh := case when hardened then 'T' else 'G' end;

  begin
    perform set_config('request.jwt.claims', '', true);
    perform set_config('request.jwt.claim.sub', '', true);
    perform set_config('request.jwt.claim.role', '', true);

    select id into r_admin from roles where code = 'admin';
    select id into r_mgr from roles where code = 'manager';
    perform set_config('p2.section', '0 Catalogue state', true);
    out := out || pg_temp.pk(hardened, kh, 'Phase 3.0 hardening is installed (10 functions pinned, apply_* revoked)', 'state',
                             n_pinned::text || ' pinned', '10 pinned');
    out := out || pg_temp.chk('hardening did not change policy count (139)', 'catalog', 'postgres', null,
      $q$select count(*)::text from pg_policies where schemaname = 'public'$q$, '139');
    out := out || pg_temp.chk('Step 3 triggers + profile guard + audit/soft-delete/updated_at triggers still enabled', 'catalog', 'postgres', null,
      $q$select (count(*) filter (where tgname = 'protect_last_admin' and tgenabled = 'O') = 1
             and count(*) filter (where tgname = 'protect_system_roles' and tgenabled = 'O') = 1
             and count(*) filter (where tgname = 'protect_admin_permissions' and tgenabled = 'O') = 1
             and count(*) filter (where tgname = 'guard_profile_privileges' and tgenabled = 'O') = 1
             and count(*) filter (where tgfoid = 'app.audit_row()'::regprocedure and tgenabled = 'O') = 25
             and count(*) filter (where tgfoid = 'app.guard_soft_delete()'::regprocedure and tgenabled = 'O') = 10
             and count(*) filter (where tgfoid = 'app.set_updated_at()'::regprocedure and tgenabled = 'O') = 17)::text
           from pg_trigger where not tgisinternal$q$, 'true');
    out := out || pg_temp.chk('RLS helper functions still executable by authenticated (policies depend on them)', 'catalog', 'postgres', null,
      $q$select (has_function_privilege('authenticated', 'app.can(text)'::regprocedure, 'execute')
             and has_function_privilege('authenticated', 'app.is_admin()'::regprocedure, 'execute')
             and has_function_privilege('authenticated', 'app.current_role_code()'::regprocedure, 'execute')
             and has_function_privilege('authenticated', 'app.can_edit_property(uuid)'::regprocedure, 'execute')
             and has_function_privilege('authenticated', 'app.next_code(text,regclass)'::regprocedure, 'execute'))::text$q$, 'true');

    perform set_config('p2.section', '1 Execute rights on the migration-only helpers (apply_*)', true);
    out := out || pg_temp.chk('apply_* are executable by NO API role (catalogue check; the calls below are also blocked earlier by DDL ownership)', 'catalog', 'postgres', null,
      $q$select (not exists (select 1 from pg_proc p, unnest(array['anon','authenticated','service_role']) r
                              where p.oid in ('app.apply_child_policies(text,text,text,text,text)'::regprocedure,
                                              'app.apply_global_policies(text,text)'::regprocedure,
                                              'app.apply_scoped_policies(text,text,text)'::regprocedure)
                                and has_function_privilege(r, p.oid, 'execute'))
             and has_function_privilege('postgres', 'app.apply_scoped_policies(text,text,text)'::regprocedure, 'execute'))::text$q$,
      'true', kh);
    out := out || pg_temp.chk('authenticated cannot call apply_scoped_policies', 'auth', 'authenticated', gen_random_uuid(),
      $q$select app.apply_scoped_policies('leads', 'leads', 'assigned_to')::text$q$, 'ERR 42501%', kh, true);
    out := out || pg_temp.chk('authenticated cannot call apply_global_policies', 'auth', 'authenticated', gen_random_uuid(),
      $q$select app.apply_global_policies('settings', 'settings')::text$q$, 'ERR 42501%', kh, true);
    out := out || pg_temp.chk('authenticated cannot call apply_child_policies', 'auth', 'authenticated', gen_random_uuid(),
      $q$select app.apply_child_policies('property_media', 'properties', 'properties', 'property_id')::text$q$, 'ERR 42501%', kh, true);
    out := out || pg_temp.chk('service_role cannot call apply_global_policies', 'svc', 'service_role', null,
      $q$select app.apply_global_policies('settings', 'settings')::text$q$, 'ERR 42501%', kh, true);
    out := out || pg_temp.chk('anon cannot call apply_global_policies', 'anon', 'anon', null,
      $q$select app.apply_global_policies('settings', 'settings')::text$q$, 'ERR 42501%', 'T', true);
    out := out || pg_temp.chk('owner (postgres) can still run the helpers (migrations keep working)', 'owner', 'postgres', null,
      $q$select pg_temp.p30_owner_apply()$q$, '4', 'T', true);

    perform set_config('p2.section', '1b Bootstrap still works end to end (throwaway user, rolled back)', true);
    if do_boot then
      insert into auth.users(id, aud, role, email, email_confirmed_at, last_sign_in_at)
        values (u_boot, 'authenticated', 'authenticated', 'p3t-' || tag || '-boot@example.invalid', now(), now());
      out := out || pg_temp.chk('handle_new_auth_user: new sign-up has an INACTIVE profile with NO role', 'boot', 'postgres', null,
        format($q$select count(*)::text from profiles where id = %L and role_id is null and not is_active$q$, u_boot), '1');
      out := out || pg_temp.chk('arm_bootstrap works', 'owner', 'postgres', null,
        format($q$select 'OK' from (select app.arm_bootstrap(%L, %L, 15)) s$q$, sec_ok, 'p3t-' || tag || '-boot@example.invalid'), 'OK');
      out := out || pg_temp.chk('wrong secret refused', 'owner', 'postgres', null,
        format($q$select app.bootstrap_first_admin(%L::uuid, 'wrong')::text$q$, u_boot), 'ERR 28000 Invalid setup secret%');
      out := out || pg_temp.chk('authenticated cannot call bootstrap', 'boot', 'authenticated', u_boot,
        format($q$select app.bootstrap_first_admin(%L::uuid, %L)::text$q$, u_boot, sec_ok), 'ERR 42501%');
      out := out || pg_temp.chk('bootstrap success with the right secret', 'owner', 'postgres', null,
        format($q$select 'OK' from (select app.bootstrap_first_admin(%L::uuid, %L)) s$q$, u_boot, sec_ok), 'OK');
      out := out || pg_temp.chk('replay refused', 'owner', 'postgres', null,
        format($q$select app.bootstrap_first_admin(%L::uuid, %L)::text$q$, u_boot, sec_ok), 'ERR 55000 Bootstrap has already been completed%');
      out := out || pg_temp.chk('old one-argument bootstrap_first_admin(uuid) still disabled (55000)', 'owner', 'postgres', null,
        format('select app.bootstrap_first_admin(%L::uuid)::text', u_boot), 'ERR 55000%');
      out := out || pg_temp.chk('last-admin protection still blocks demoting the only admin', 'owner', 'postgres', null,
        format('update profiles set role_id = %s where id = %L', r_mgr, u_boot), 'ERR 55000 Cannot remove, demote or deactivate the last active admin');
    else
      out := out || pg_temp.pk(false, 'S', 'bootstrap section SKIPPED (an admin exists or bootstrap is armed)', 'state',
                               'admin=' || admin_before::text || ' armed=' || armed_before::text, '-');
    end if;

    perform set_config('p2.section', '2 Fixtures', true);
    insert into auth.users(id, aud, role, email, email_confirmed_at, last_sign_in_at) values
      (u_admin,  'authenticated', 'authenticated', 'p3t-' || tag || '-admin@example.invalid',  now(), now()),
      (u_mgr,    'authenticated', 'authenticated', 'p3t-' || tag || '-mgr@example.invalid',    now(), now()),
      (u_agent,  'authenticated', 'authenticated', 'p3t-' || tag || '-agent@example.invalid',  now(), now()),
      (u_viewer, 'authenticated', 'authenticated', 'p3t-' || tag || '-viewer@example.invalid', now(), now());
    update profiles set role_id = (select id from roles where code = 'admin'),   is_active = true where id = u_admin;
    update profiles set role_id = (select id from roles where code = 'manager'), is_active = true where id = u_mgr;
    update profiles set role_id = (select id from roles where code = 'agent'),   is_active = true where id = u_agent;
    update profiles set role_id = (select id from roles where code = 'viewer'),  is_active = true where id = u_viewer;
    insert into contacts(id, full_name, phone, email) values (c_a, 'P3TEST contact', '+91 99999 11111', 'p3t-' || tag || '@example.invalid');
    insert into leads(id, contact_id, lead_type, source_code, status_code, assigned_to, created_at, updated_at)
      values (lead_a, c_a, 'buy', 'website', 'new', u_agent, now() - interval '2 days', now() - interval '2 days');
    out := out || pg_temp.chk('fixtures created', 'owner', 'postgres', null,
      format($q$select ((select count(*) from profiles where id in (%L,%L,%L,%L)) = 4 and (select count(*) from leads where id = %L) = 1)::text$q$,
             u_admin, u_mgr, u_agent, u_viewer, lead_a), 'true');

    perform set_config('p2.section', '3 Functions pinned by 3.0 still do their job', true);
    out := out || pg_temp.chk('next_code via column default: agent inserts a lead and gets an LD-nnnnnn code', 'agent', 'authenticated', u_agent,
      format($q$with i as (insert into leads(contact_id, lead_type, source_code, status_code, assigned_to) values (%L, 'buy', 'website', 'new', %L) returning code) select code from i$q$, c_a, u_agent),
      'LD-______');
    out := out || pg_temp.chk('set_updated_at trigger: update moves updated_at forward', 'agent', 'authenticated', u_agent,
      format($q$with u as (update leads set notes = 'p3' where id = %L returning (updated_at > created_at) as ok) select ok::text from u$q$, lead_a), 'true');
    out := out || pg_temp.chk('guard_profile_privileges: agent cannot raise own role', 'agent', 'authenticated', u_agent,
      format('update profiles set role_id = %s where id = %L', r_admin, u_agent), deny);
    out := out || pg_temp.chk('guard_profile_privileges: agent cannot soft-delete own profile (Step 3 check kept)', 'agent', 'authenticated', u_agent,
      format('update profiles set deleted_at = now() where id = %L', u_agent), deny);
    out := out || pg_temp.chk('guard_profile_privileges: harmless self-edit still works  [control]', 'agent', 'authenticated', u_agent,
      format($q$update profiles set full_name = 'P3TEST' where id = %L$q$, u_agent), '1');
    out := out || pg_temp.chk('guard_soft_delete: agent cannot soft-delete a lead (needs leads.delete)', 'agent', 'authenticated', u_agent,
      format('update leads set deleted_at = now() where id = %L', lead_a), 'ERR 42501 permission denied: leads.delete%');
    out := out || pg_temp.chk('enforce_active_weights: activating a config without weights totalling 100 is refused', 'owner', 'postgres', null,
      $q$insert into matching_configs(name, version, is_active) values ('p3test-zz', 1, true)$q$, 'ERR P0001 Matching weights must total 100%');
    out := out || pg_temp.chk('find_contact_matches: manager finds the contact by phone (different format) and e-mail', 'mgr', 'authenticated', u_mgr,
      format($q$select array_to_string(matched_on, ',') from public.find_contact_matches('099999-11111', null, %L) where contact_id = %L$q$,
             'p3t-' || tag || '@example.invalid', c_a), 'phone,email//email,phone');
    out := out || pg_temp.chk('find_contact_matches: anon still refused', 'anon', 'anon', null,
      $q$select count(*)::text from public.find_contact_matches('9999911111', null, null)$q$, 'ERR 42501%');

    perform set_config('p2.section', '4 search_path hijack attempts (the reason for 3.0)', true);
    execute 'create schema zz_evil';
    execute 'create table zz_evil.contacts (like public.contacts including defaults)';
    execute 'grant usage on schema zz_evil to authenticated';
    execute 'grant select on zz_evil.contacts to authenticated';
    orig_sp := current_setting('search_path');
    perform set_config('search_path', 'zz_evil, public, extensions', true);   -- hostile path in force BEFORE the call is planned
    out := out || pg_temp.chk('find_contact_matches ignores a hostile caller search_path (zz_evil first)', 'mgr', 'authenticated', u_mgr,
      format($q$select count(*)::text from public.find_contact_matches('9999911111', null, null) where contact_id = %L$q$, c_a),
      '1', kh, true);
    perform set_config('search_path', orig_sp, true);
    out := out || pg_temp.chk('...same call without the hostile path (control)', 'mgr', 'authenticated', u_mgr,
      format($q$select count(*)::text from public.find_contact_matches('9999911111', null, null) where contact_id = %L$q$, c_a), '1');

    raise exception 'P3 rollback sentinel' using errcode = 'P2RBK';
  exception
    when sqlstate 'P2RBK' then null;
    when others then fatal := sqlstate || ' ' || sqlerrm;
  end;

  -- ---------------------------------------------------------------
  -- After the rollback: restore sequences, verify state, build report
  -- ---------------------------------------------------------------
  perform pg_temp.p2_restore_seqs(seq0);
  snap1 := pg_temp.p2_snapshot();
  seq1  := pg_temp.p2_seqs();
  seq_ok := (seq0 = seq1);
  select string_agg(coalesce(x.key, y.key), ', ' order by coalesce(x.key, y.key)) into diff_tables
    from jsonb_each_text(snap0) x full join jsonb_each_text(snap1) y on x.key = y.key
   where x.value is distinct from y.value;

  select count(*) filter (where split_part(x, sep, 1) = 'P'), count(*) filter (where split_part(x, sep, 1) = 'F'),
         count(*) filter (where split_part(x, sep, 1) = 'G'), count(*) filter (where split_part(x, sep, 1) = 'S')
    into n_p, n_f, n_g, n_s from unnest(out) x;

  for rec in
    select s.section, s.label, min(s.ord) o,
           string_agg(s.who || '=' || s.got || case when s.st in ('F', 'G') then '  [want ' || s.want || ']' else '' end, '   ' order by s.ord) cells,
           bool_or(s.st = 'F') f, bool_or(s.st = 'G') g, bool_or(s.st = 'S') sk
      from (select split_part(x, sep, 1) st, split_part(x, sep, 2) section, split_part(x, sep, 3) label,
                   split_part(x, sep, 4) who, split_part(x, sep, 5) got, split_part(x, sep, 6) want, ord
              from unnest(out) with ordinality t(x, ord)) s
     group by s.section, s.label order by min(s.ord)
  loop
    if rec.section <> cur_sec then rpt := rpt || E'\n== ' || rec.section || E'\n'; cur_sec := rec.section; end if;
    rpt := rpt || case when rec.f then 'FAIL ' when rec.g then 'GAP  ' when rec.sk then 'SKIP ' else 'ok   ' end
                || rec.label || '  ->  ' || rec.cells || E'\n';
    if rec.f or rec.g or rec.sk then
      top := top || case when rec.f then 'FAIL ' when rec.g then 'GAP  ' else 'SKIP ' end || rec.label || '  ->  ' || rec.cells || E'\n';
    end if;
  end loop;

  msg := E'P3.0 TEST REPORT  (this error is intentional: it is what rolled everything back)\n'
      || 'RESULT: PASS ' || n_p || ' | FAIL ' || n_f || ' | GAP ' || n_g || ' (known + documented, see below) | SKIP ' || n_s || E'\n'
      || 'FATAL ERROR INSIDE TESTS: ' || coalesce(fatal, 'none') || E'\n'
      || 'STATE AFTER ROLLBACK: ' || case when diff_tables is null
             then 'IDENTICAL to pre-test snapshot (auth.users, profiles, audit_logs, every public/app table)'
             else 'DIFFERENCES in: ' || diff_tables end || E'\n'
      || 'SEQUENCES: ' || case when seq_ok then 'restored to pre-test values' else 'NOT identical (see docs/PHASE2_TESTING.md)' end || E'\n\n'
      || case when top = '' then 'No FAIL / GAP / SKIP lines.' else E'--- needs attention ---\n' || top end
      || E'\n--- details ---' || rpt;
  raise exception '%', msg using errcode = 'P0001';
end
$p3$;
