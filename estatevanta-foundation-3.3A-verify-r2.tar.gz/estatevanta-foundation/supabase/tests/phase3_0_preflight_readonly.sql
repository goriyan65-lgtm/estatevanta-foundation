-- READ-ONLY pre/post-flight for Phase 3.0. Pure SELECT; changes nothing. Run in the SQL Editor of
-- "Estate vanta crm" (bmvozgfjrvdrfdhvfray) BEFORE and AFTER the migration.
-- It checks, per function: body hash, function-level configuration (search_path) AND the complete EXECUTE
-- ACL (every grantee incl. PUBLIC), not just search_path.
-- Before: every row = 'PRE-3.0 (as expected)'.  After: every row = 'POST-3.0 (hardened)'.
-- Anything else (BODY DIFFERS / UNEXPECTED) = the database is not what the migration was designed against: stop.
with expected(fn, body_md5, pre_acl, post_acl) as (values
  ('app.guard_profile_privileges()',                     '1d1722337140c38e7ba77a02f755fe3e', 'PUBLIC:EXECUTE,authenticated:EXECUTE,postgres:EXECUTE,service_role:EXECUTE', 'PUBLIC:EXECUTE,authenticated:EXECUTE,postgres:EXECUTE,service_role:EXECUTE'),
  ('app.guard_soft_delete()',                            '36e5a160fcf2eed72254297490bfae50', 'PUBLIC:EXECUTE,authenticated:EXECUTE,postgres:EXECUTE,service_role:EXECUTE', 'PUBLIC:EXECUTE,authenticated:EXECUTE,postgres:EXECUTE,service_role:EXECUTE'),
  ('app.set_updated_at()',                               '2087ee763cae5a840d5f9851ac4e1eb8', 'PUBLIC:EXECUTE,authenticated:EXECUTE,postgres:EXECUTE,service_role:EXECUTE', 'PUBLIC:EXECUTE,authenticated:EXECUTE,postgres:EXECUTE,service_role:EXECUTE'),
  ('app.enforce_active_weights()',                       '70ef85b21720c89c9ad9080f24c98cd3', 'PUBLIC:EXECUTE,authenticated:EXECUTE,postgres:EXECUTE,service_role:EXECUTE', 'PUBLIC:EXECUTE,authenticated:EXECUTE,postgres:EXECUTE,service_role:EXECUTE'),
  ('app.next_code(text,regclass)',                       'f7a1c9e917fa28a6483f9f5f2d823c5f', 'PUBLIC:EXECUTE,authenticated:EXECUTE,postgres:EXECUTE,service_role:EXECUTE', 'PUBLIC:EXECUTE,authenticated:EXECUTE,postgres:EXECUTE,service_role:EXECUTE'),
  ('app.bootstrap_first_admin(uuid)',                    '2ec02e307d3c37277870b1af096765f2', 'postgres:EXECUTE', 'postgres:EXECUTE'),
  ('public.find_contact_matches(text,text,text)',        'a4f8e9b45e98e08f0ad6ddf3cd2c1496', 'authenticated:EXECUTE,postgres:EXECUTE,service_role:EXECUTE', 'authenticated:EXECUTE,postgres:EXECUTE,service_role:EXECUTE'),
  ('app.apply_child_policies(text,text,text,text,text)', '8e1fd5c87ff5ec295868d5dd4866c881', 'PUBLIC:EXECUTE,authenticated:EXECUTE,postgres:EXECUTE,service_role:EXECUTE', 'postgres:EXECUTE'),
  ('app.apply_global_policies(text,text)',               'd391c0d1c068d31b52c60c8aa9039438', 'PUBLIC:EXECUTE,authenticated:EXECUTE,postgres:EXECUTE,service_role:EXECUTE', 'postgres:EXECUTE'),
  ('app.apply_scoped_policies(text,text,text)',          'e39efbb74f1cf88b7ce632e47bc7a870', 'PUBLIC:EXECUTE,authenticated:EXECUTE,postgres:EXECUTE,service_role:EXECUTE', 'postgres:EXECUTE')
), cur as (
  select e.*, p.oid, p.proconfig, md5(p.prosrc) as cur_md5,
         (select coalesce(string_agg(coalesce(g.rolname, 'PUBLIC') || ':' || a.privilege_type, ','
                                     order by coalesce(g.rolname, 'PUBLIC') collate "C", a.privilege_type collate "C"), '<null>')
            from aclexplode(p.proacl) a left join pg_roles g on g.oid = a.grantee) as cur_acl
  from expected e join pg_proc p on p.oid = to_regprocedure(e.fn)
)
select fn,
       coalesce(array_to_string(proconfig, ','), '-')            as search_path_setting,
       cur_acl                                                   as execute_acl,
       has_function_privilege('anon', oid, 'execute')            as anon_exec,
       has_function_privilege('authenticated', oid, 'execute')   as authenticated_exec,
       has_function_privilege('service_role', oid, 'execute')    as service_role_exec,
       has_function_privilege('postgres', oid, 'execute')        as postgres_exec,
       (cur_md5 = body_md5)                                      as body_unchanged,
       case
         when cur_md5 <> body_md5 then 'BODY DIFFERS - STOP'
         when proconfig is null and cur_acl = pre_acl then 'PRE-3.0 (as expected)'
         when proconfig = array['search_path=public, extensions, pg_temp'] and cur_acl = post_acl then 'POST-3.0 (hardened)'
         else 'UNEXPECTED - STOP'
       end as state
from cur
union all
select 'MISSING: ' || e.fn, null, null, null, null, null, null, null, 'MISSING - STOP'
from expected e where to_regprocedure(e.fn) is null
order by 9, 1;
