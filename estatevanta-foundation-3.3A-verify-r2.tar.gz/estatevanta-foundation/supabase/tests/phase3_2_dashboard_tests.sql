-- =====================================================================
-- EstateVanta CRM — Phase 3.2 dashboard_summary() tests (FULLY ROLLED BACK)
-- Run AFTER 0012a is installed (local replica, or later the live project once you approve it).
-- Same safety model as phase2_security_tests.sql / phase3_0_hardening_tests.sql:
--   * ONE DO statement. Throwaway @example.invalid users and fixture rows exist only inside it.
--   * Every change is thrown away by a final deliberate error. SQLSTATE P0001 "P3.2 TEST REPORT" is the NORMAL
--     outcome; the report is the error message. Any other error = the harness itself broke.
--   * Sequences are restored with setval (sequences are not transactional).
--   * It refuses to run if any business table already has rows (so it can never mix with real data).
--   * Never reads real data, never uses a real secret, never touches anything outside this transaction.
-- Fixture rows are never persisted; the database stays empty of business data.
-- =====================================================================
do $p32$
declare
  u_admin uuid := gen_random_uuid(); u_mgr uuid := gen_random_uuid(); u_agent uuid := gen_random_uuid();
  u_agent2 uuid := gen_random_uuid(); u_viewer uuid := gen_random_uuid(); u_inactive uuid := gen_random_uuid();
  u_norole uuid := gen_random_uuid(); u_deleted uuid := gen_random_uuid(); u_ghost uuid := gen_random_uuid();
  cfg uuid; rpt text := ''; n_pass int; n_fail int; rec record; seq0 jsonb;
  snapA jsonb; snapB jsonb; v text; j jsonb; tzname text;
  keys13 text := 'active_inventory,listings_due_verification,open_leads,new_leads_uncontacted,hot_leads,overdue_followups,buyers_active_requirements,sellers_awaiting_contact,matches_ready_to_share,appointments_today,appointments_awaiting_outcome,overdue_tasks,open_deals';
  ds0 timestamptz; de0 timestamptz;
  exp_ref int;
begin
  -- ------------------------------------------------------------------ helpers
  create temp table tr(n serial, ok boolean, label text, got text, want text) on commit drop;
  create temp table fx(k text primary key, id uuid not null default gen_random_uuid()) on commit drop;

  create function pg_temp.rec(p_label text, p_got text, p_want text) returns void language sql as
  $f$ insert into tr(ok, label, got, want) values (p_got is not distinct from p_want, p_label, p_got, p_want) $f$;

  create function pg_temp.f(p_k text) returns uuid language plpgsql as
  $f$ declare r uuid; begin
        select id into r from fx where k = p_k;
        if r is null then insert into fx(k) values (p_k) returning id into r; end if;
        return r; end $f$;

  -- run dashboard_summary() as <role> with JWT subject <uid text>; errors come back as {"error":sqlstate}
  create function pg_temp.ds(p_role text, p_uid text) returns jsonb language plpgsql as $f$
  declare r jsonb;
  begin
    perform set_config('request.jwt.claims',
      case when p_uid is null then json_build_object('role', p_role)::text
           else json_build_object('sub', p_uid, 'role', p_role, 'aud', 'authenticated')::text end, true);
    perform set_config('request.jwt.claim.sub', coalesce(p_uid, ''), true);
    perform set_config('request.jwt.claim.role', p_role, true);
    execute format('set local role %I', p_role);
    begin
      r := public.dashboard_summary();
    exception when others then
      r := jsonb_build_object('error', sqlstate, 'msg', left(sqlerrm, 90));
    end;
    execute 'reset role';
    perform set_config('request.jwt.claims', '', true);
    perform set_config('request.jwt.claim.sub', '', true);
    perform set_config('request.jwt.claim.role', '', true);
    return r;
  end $f$;

  -- run arbitrary SQL (single value) as role/uid; errors come back as 'ERR <state>'
  create function pg_temp.q(p_role text, p_uid text, p_sql text) returns text language plpgsql as $f$
  declare r text;
  begin
    perform set_config('request.jwt.claims',
      case when p_uid is null then json_build_object('role', p_role)::text
           else json_build_object('sub', p_uid, 'role', p_role, 'aud', 'authenticated')::text end, true);
    perform set_config('request.jwt.claim.sub', coalesce(p_uid, ''), true);
    perform set_config('request.jwt.claim.role', p_role, true);
    execute format('set local role %I', p_role);
    begin
      execute p_sql into r; r := coalesce(r, '(null)');
    exception when others then r := 'ERR ' || sqlstate;
    end;
    execute 'reset role';
    perform set_config('request.jwt.claims', '', true);
    perform set_config('request.jwt.claim.sub', '', true);
    perform set_config('request.jwt.claim.role', '', true);
    return r;
  end $f$;

  -- compact "value,value,..." in fixed card order; unavailable card = NA
  create function pg_temp.vals(j jsonb, p_keys text) returns text language sql as $f$
    select case when j ? 'error' then 'ERR ' || (j ->> 'error')
      else (select string_agg(case when (j -> 'cards' -> k ->> 'available') = 'true'
                                   then coalesce(j -> 'cards' -> k ->> 'value', 'NULL?') else 'NA' end, ',' order by ord)
              from unnest(string_to_array(p_keys, ',')) with ordinality t(k, ord)) end $f$;

  create function pg_temp.scopes(j jsonb, p_keys text) returns text language sql as $f$
    select case when j ? 'error' then 'ERR ' || (j ->> 'error')
      else (select string_agg(coalesce(j -> 'cards' -> k ->> 'scope', '-'), ',' order by ord)
              from unnest(string_to_array(p_keys, ',')) with ordinality t(k, ord)) end $f$;

  create function pg_temp.snap() returns jsonb language plpgsql as $f$
  declare r record; j jsonb := '{}'; v text;
  begin
    for r in select n.nspname, c.relname from pg_class c join pg_namespace n on n.oid = c.relnamespace
             where c.relkind in ('r', 'p') and n.nspname in ('public', 'app') order by 1, 2
    loop
      execute format('select count(*)::text || '':'' || coalesce(md5(string_agg(t::text, ''|'' order by t::text)), ''-'') from %I.%I t',
                     r.nspname, r.relname) into v;
      j := j || jsonb_build_object(r.nspname || '.' || r.relname, v);
    end loop;
    return j;
  end $f$;

  create function pg_temp.seqs() returns jsonb language plpgsql as $f$
  declare r record; j jsonb := '{}'; lv bigint; ic boolean;
  begin
    for r in select n.nspname, c.relname from pg_class c join pg_namespace n on n.oid = c.relnamespace
             where c.relkind = 'S' and n.nspname in ('public', 'app', 'auth') order by 1, 2
    loop
      begin
        execute format('select last_value, is_called from %I.%I', r.nspname, r.relname) into lv, ic;
        j := j || jsonb_build_object(r.nspname || '.' || r.relname, jsonb_build_array(lv, ic));
      exception when others then null; end;
    end loop;
    return j;
  end $f$;

  create function pg_temp.restore_seqs(p_seqs jsonb) returns void language plpgsql as $f$
  declare r record;
  begin
    for r in select key, value from jsonb_each(p_seqs) loop
      begin perform setval(r.key::regclass, (r.value ->> 0)::bigint, (r.value ->> 1)::boolean);
      exception when others then null; end;
    end loop;
  end $f$;

  create function pg_temp.mk_contact(p_name text) returns uuid language plpgsql as $f$
  declare r uuid; begin insert into contacts(full_name, email) values (p_name, lower(replace(p_name, ' ', '-')) || '@example.invalid') returning id into r; return r; end $f$;

  seq0 := pg_temp.seqs();

  -- ------------------------------------------------------------------ 0. refuse to run on a database with business rows
  if exists (select 1 from properties) or exists (select 1 from leads) or exists (select 1 from buyers)
     or exists (select 1 from sellers) or exists (select 1 from deals) or exists (select 1 from appointments)
     or exists (select 1 from tasks) or exists (select 1 from property_matches) or exists (select 1 from contacts) then
    raise exception 'ABORT: business tables are not empty — this test only runs on an empty CRM database';
  end if;
  if to_regprocedure('public.dashboard_summary()') is null then
    perform pg_temp.rec('00 function exists', 'missing', 'present');
  end if;

  -- ------------------------------------------------------------------ 1. static catalog checks
  perform pg_temp.rec('S1 SECURITY INVOKER (not definer)',
    (select (not prosecdef)::text from pg_proc where oid = to_regprocedure('public.dashboard_summary()')), 'true');
  perform pg_temp.rec('S2 STABLE',
    (select provolatile::text from pg_proc where oid = to_regprocedure('public.dashboard_summary()')), 's');
  perform pg_temp.rec('S3 search_path pinned exactly',
    (select proconfig::text from pg_proc where oid = to_regprocedure('public.dashboard_summary()')),
    '{"search_path=public, extensions, pg_temp"}');
  perform pg_temp.rec('S4 takes no arguments',
    (select pronargs::text from pg_proc where oid = to_regprocedure('public.dashboard_summary()')), '0');
  perform pg_temp.rec('S5 no dynamic SQL in body',
    (select (prosrc !~* '\mexecute\M')::text from pg_proc where oid = to_regprocedure('public.dashboard_summary()')), 'true');
  perform pg_temp.rec('S6 EXECUTE ACL = authenticated + owner only',
    (select coalesce(string_agg(coalesce(g.rolname, 'PUBLIC') || ':' || x.privilege_type, ',' order by coalesce(g.rolname, 'PUBLIC') collate "C"), '<null>')
       from pg_proc p, aclexplode(p.proacl) x left join pg_roles g on g.oid = x.grantee
      where p.oid = to_regprocedure('public.dashboard_summary()')),
    'authenticated:EXECUTE,postgres:EXECUTE');
  perform pg_temp.rec('S7 anon / service_role / PUBLIC cannot execute',
    (has_function_privilege('anon', 'public.dashboard_summary()', 'execute')
     or has_function_privilege('service_role', 'public.dashboard_summary()', 'execute'))::text, 'false');
  perform pg_temp.rec('S8 body has no write statements',
    (select (prosrc !~* '\m(insert\s+into|update\s+\w+\s+set|delete\s+from|truncate)\M')::text
       from pg_proc where oid = to_regprocedure('public.dashboard_summary()')), 'true');

  -- ------------------------------------------------------------------ 2. users (throwaway)
  cfg := (select id from matching_configs limit 1);
  insert into auth.users(id, aud, role, email, email_confirmed_at, last_sign_in_at) values
    (u_admin, 'authenticated', 'authenticated', 'p32-admin@example.invalid', now(), now()),
    (u_mgr, 'authenticated', 'authenticated', 'p32-mgr@example.invalid', now(), now()),
    (u_agent, 'authenticated', 'authenticated', 'p32-agent@example.invalid', now(), now()),
    (u_agent2, 'authenticated', 'authenticated', 'p32-agent2@example.invalid', now(), now()),
    (u_viewer, 'authenticated', 'authenticated', 'p32-viewer@example.invalid', now(), now()),
    (u_inactive, 'authenticated', 'authenticated', 'p32-inactive@example.invalid', now(), now()),
    (u_norole, 'authenticated', 'authenticated', 'p32-norole@example.invalid', now(), now()),
    (u_deleted, 'authenticated', 'authenticated', 'p32-deleted@example.invalid', now(), now());
  update profiles set role_id = (select id from roles where code = 'admin'),   is_active = true where id = u_admin;
  update profiles set role_id = (select id from roles where code = 'manager'), is_active = true where id = u_mgr;
  update profiles set role_id = (select id from roles where code = 'agent'),   is_active = true where id in (u_agent, u_agent2, u_deleted);
  update profiles set role_id = (select id from roles where code = 'viewer'),  is_active = true where id = u_viewer;
  update profiles set role_id = (select id from roles where code = 'agent'),   is_active = false where id = u_inactive;
  update profiles set deleted_at = now() where id = u_deleted;

  -- ------------------------------------------------------------------ 3. EMPTY DATABASE (all four roles)
  j := pg_temp.ds('authenticated', u_admin::text);
  perform pg_temp.rec('E1 empty DB admin = all zeros',   pg_temp.vals(j, keys13), '0,0,0,0,0,0,0,0,0,0,0,0,0');
  perform pg_temp.rec('E1b empty DB admin warnings = []', j ->> 'warnings', '[]');
  perform pg_temp.rec('E1c empty DB admin timezone',      j ->> 'timezone', 'Asia/Kolkata');
  perform pg_temp.rec('E1d schema_version',               j ->> 'schema_version', '1');
  perform pg_temp.rec('E2 empty DB manager = all zeros', pg_temp.vals(pg_temp.ds('authenticated', u_mgr::text), keys13), '0,0,0,0,0,0,0,0,0,0,0,0,0');
  perform pg_temp.rec('E3 empty DB agent = all zeros',   pg_temp.vals(pg_temp.ds('authenticated', u_agent::text), keys13), '0,0,0,0,0,0,0,0,0,0,0,0,0');
  perform pg_temp.rec('E4 empty DB viewer = zeros, open_deals NA (not 0)',
                      pg_temp.vals(pg_temp.ds('authenticated', u_viewer::text), keys13), '0,0,0,0,0,0,0,0,0,0,0,0,NA');

  -- ------------------------------------------------------------------ 4. FIXTURES (rolled back; never persisted)
  -- properties
  insert into properties(id, title, property_type_code, transaction_type, city, source, status, last_verified_at, assigned_to, created_by) values
    (pg_temp.f('p1'),  'P32 p1',  'flat_apartment', 'sale', 'P32CITY', 'other', 'available',         null,                                         u_agent,  u_agent),
    (pg_temp.f('p2'),  'P32 p2',  'flat_apartment', 'sale', 'P32CITY', 'other', 'available',         now() - interval '31 days',                  u_agent2, u_agent2),
    (pg_temp.f('p3'),  'P32 p3',  'flat_apartment', 'sale', 'P32CITY', 'other', 'reserved',          now() - interval '30 days' + interval '1 hour', null,   u_agent),
    (pg_temp.f('p3b'), 'P32 p3b', 'flat_apartment', 'sale', 'P32CITY', 'other', 'under_negotiation', now() - interval '30 days' - interval '1 hour', u_mgr, u_mgr),
    (pg_temp.f('p4'),  'P32 p4',  'flat_apartment', 'sale', 'P32CITY', 'other', 'sold',              now(),                                       u_agent,  u_agent),
    (pg_temp.f('p5'),  'P32 p5',  'flat_apartment', 'sale', 'P32CITY', 'other', 'inactive',          null,                                        u_agent,  u_agent),
    (pg_temp.f('p6'),  'P32 p6',  'flat_apartment', 'sale', 'P32CITY', 'other', 'available',         null,                                        u_agent,  u_agent),
    (pg_temp.f('p7'),  'P32 p7',  'flat_apartment', 'sale', 'P32CITY', 'other', 'available',         now() - interval '5 days',                   u_agent,  u_agent);
  update properties set deleted_at = now() where id = pg_temp.f('p6');

  -- leads
  insert into leads(id, contact_id, lead_type, source_code, status_code, priority, assigned_to, created_by, last_contact_at, next_follow_up_at) values
    (pg_temp.f('l1'), pg_temp.mk_contact('P32 c-l1'), 'buy', 'website', 'new',         'high',   u_agent,  u_agent,  null,                    null),
    (pg_temp.f('l2'), pg_temp.mk_contact('P32 c-l2'), 'buy', 'website', 'new',         'low',    u_agent2, u_agent2, now() - interval '1 hour', null),
    (pg_temp.f('l3'), pg_temp.mk_contact('P32 c-l3'), 'buy', 'website', 'contacted',   'urgent', u_agent,  u_agent,  now() - interval '3 days', now() - interval '2 days'),
    (pg_temp.f('l4'), pg_temp.mk_contact('P32 c-l4'), 'buy', 'website', 'qualified',   'medium', u_agent2, u_agent2, now() - interval '1 day',  now() + interval '2 days'),
    (pg_temp.f('l5'), pg_temp.mk_contact('P32 c-l5'), 'buy', 'website', 'negotiation', 'high',   u_mgr,    u_mgr,    now() - interval '1 day',  now()),
    (pg_temp.f('l6'), pg_temp.mk_contact('P32 c-l6'), 'buy', 'website', 'deal_won',    'urgent', u_agent,  u_agent,  now() - interval '9 days', now() - interval '10 days'),
    (pg_temp.f('l7'), pg_temp.mk_contact('P32 c-l7'), 'buy', 'website', 'deal_lost',   'high',   u_agent2, u_agent2, now() - interval '9 days', now() - interval '10 days'),
    (pg_temp.f('l8'), pg_temp.mk_contact('P32 c-l8'), 'buy', 'website', 'new',         'urgent', u_agent,  u_agent,  null,                    null),
    (pg_temp.f('l9'), pg_temp.mk_contact('P32 c-l9'), 'buy', 'website', 'follow_up',   'low',    u_agent2, u_agent2, now() - interval '2 days', now() - interval '1 minute');
  update leads set deleted_at = now() where id = pg_temp.f('l8');

  -- buyers + requirements
  insert into buyers(id, contact_id, is_active, assigned_to, created_by) values
    (pg_temp.f('b1'), pg_temp.mk_contact('P32 c-b1'), true,  u_agent,  u_agent),
    (pg_temp.f('b2'), pg_temp.mk_contact('P32 c-b2'), true,  u_agent2, u_agent2),
    (pg_temp.f('b3'), pg_temp.mk_contact('P32 c-b3'), true,  u_agent,  u_agent),
    (pg_temp.f('b4'), pg_temp.mk_contact('P32 c-b4'), false, u_agent2, u_agent2),
    (pg_temp.f('b5'), pg_temp.mk_contact('P32 c-b5'), true,  u_agent2, u_agent2),
    (pg_temp.f('b6'), pg_temp.mk_contact('P32 c-b6'), true,  u_mgr,    u_mgr),
    (pg_temp.f('b7'), pg_temp.mk_contact('P32 c-b7'), true,  u_agent2, u_agent2);
  update buyers set deleted_at = now() where id = pg_temp.f('b5');
  insert into buyer_requirements(id, buyer_id, transaction_type, status) values
    (pg_temp.f('r1'), pg_temp.f('b1'), 'sale', 'active'),
    (pg_temp.f('r2'), pg_temp.f('b2'), 'sale', 'on_hold'),
    (pg_temp.f('r3'), pg_temp.f('b3'), 'sale', 'active'),
    (pg_temp.f('r4'), pg_temp.f('b3'), 'sale', 'active'),
    (pg_temp.f('r5'), pg_temp.f('b4'), 'sale', 'active'),
    (pg_temp.f('r6'), pg_temp.f('b5'), 'sale', 'active'),
    (pg_temp.f('r7'), pg_temp.f('b6'), 'sale', 'active'),
    (pg_temp.f('r8'), pg_temp.f('b7'), 'sale', 'active');
  update buyer_requirements set deleted_at = now() where id = pg_temp.f('r7');

  -- sellers
  insert into sellers(id, contact_id, relationship_status, assigned_to, created_by) values
    (pg_temp.f('s1'), pg_temp.mk_contact('P32 c-s1'), 'new',       u_agent,  u_agent),
    (pg_temp.f('s2'), pg_temp.mk_contact('P32 c-s2'), 'new',       u_agent2, u_agent2),
    (pg_temp.f('s3'), pg_temp.mk_contact('P32 c-s3'), 'contacted', u_agent,  u_agent),
    (pg_temp.f('s4'), pg_temp.mk_contact('P32 c-s4'), 'new',       u_agent,  u_agent),
    (pg_temp.f('s5'), pg_temp.mk_contact('P32 c-s5'), 'inactive',  u_agent2, u_agent2);
  update sellers set deleted_at = now() where id = pg_temp.f('s4');

  -- matches (property_matches has NO deleted_at column; filters apply to parents)
  insert into property_matches(requirement_id, property_id, config_id, score, criteria_results, status) values
    (pg_temp.f('r1'), pg_temp.f('p1'),  cfg, 80, '{}', 'suggested'),
    (pg_temp.f('r1'), pg_temp.f('p3'),  cfg, 70, '{}', 'shared'),
    (pg_temp.f('r3'), pg_temp.f('p7'),  cfg, 75, '{}', 'suggested'),
    (pg_temp.f('r2'), pg_temp.f('p1'),  cfg, 60, '{}', 'suggested'),
    (pg_temp.f('r5'), pg_temp.f('p1'),  cfg, 60, '{}', 'suggested'),
    (pg_temp.f('r6'), pg_temp.f('p1'),  cfg, 60, '{}', 'suggested'),
    (pg_temp.f('r7'), pg_temp.f('p1'),  cfg, 60, '{}', 'suggested'),
    (pg_temp.f('r8'), pg_temp.f('p4'),  cfg, 60, '{}', 'suggested'),
    (pg_temp.f('r8'), pg_temp.f('p6'),  cfg, 60, '{}', 'suggested'),
    (pg_temp.f('r8'), pg_temp.f('p2'),  cfg, 90, '{}', 'suggested'),
    (pg_temp.f('r1'), pg_temp.f('p3b'), cfg, 85, '{}', 'suggested');

  -- appointments (boundaries computed in Asia/Kolkata, the live app.timezone)
  ds0 := date_trunc('day', now() at time zone 'Asia/Kolkata') at time zone 'Asia/Kolkata';
  de0 := (date_trunc('day', now() at time zone 'Asia/Kolkata') + interval '1 day') at time zone 'Asia/Kolkata';
  insert into appointments(id, type, starts_at, status, assigned_to, created_by) values
    (pg_temp.f('a1'),  'site_visit', ds0,                       'scheduled',   u_agent,  u_agent),
    (pg_temp.f('a2'),  'site_visit', de0 - interval '1 second', 'confirmed',   u_agent2, u_agent2),
    (pg_temp.f('a3'),  'site_visit', de0,                       'scheduled',   u_agent,  u_agent),
    (pg_temp.f('a4'),  'site_visit', ds0 - interval '1 second', 'scheduled',   u_agent2, u_agent2),
    (pg_temp.f('a5'),  'site_visit', ds0 - interval '2 days',   'completed',   u_agent,  u_agent),
    (pg_temp.f('a6'),  'site_visit', ds0,                       'rescheduled', u_agent,  u_agent),
    (pg_temp.f('a7'),  'site_visit', ds0,                       'cancelled',   u_agent2, u_agent2),
    (pg_temp.f('a8'),  'site_visit', ds0 - interval '1 day',    'no_show',     u_agent2, u_agent2),
    (pg_temp.f('a9'),  'site_visit', ds0 - interval '1 day',    'scheduled',   u_agent,  u_agent),
    (pg_temp.f('a10'), 'site_visit', ds0 - interval '3 days',   'confirmed',   u_agent,  u_agent);
  update appointments set deleted_at = now() where id = pg_temp.f('a9');

  -- tasks
  insert into tasks(id, title, status, due_at, completed_at, assigned_to, created_by) values
    (pg_temp.f('t1'), 'P32 t1', 'pending',     now() - interval '1 day',  null,  u_agent,  u_agent),
    (pg_temp.f('t2'), 'P32 t2', 'in_progress', now() - interval '1 hour', null,  u_agent2, u_agent2),
    (pg_temp.f('t3'), 'P32 t3', 'pending',     now() + interval '1 day',  null,  u_agent,  u_agent),
    (pg_temp.f('t4'), 'P32 t4', 'completed',   now() - interval '1 day',  now(), u_agent,  u_agent),
    (pg_temp.f('t5'), 'P32 t5', 'cancelled',   now() - interval '1 day',  null,  u_agent2, u_agent2),
    (pg_temp.f('t6'), 'P32 t6', 'pending',     null,                      null,  u_agent,  u_agent),
    (pg_temp.f('t7'), 'P32 t7', 'pending',     now() - interval '1 day',  null,  u_agent2, u_agent2),
    (pg_temp.f('t8'), 'P32 t8', 'pending',     now(),                     null,  u_mgr,    u_mgr);
  update tasks set deleted_at = now() where id = pg_temp.f('t7');

  -- deals (final_price / closed_at / cancelled_reason are fixture-only values to satisfy table checks)
  insert into deals(id, buyer_id, seller_id, property_id, status, assigned_to, created_by, final_price, closed_at, cancelled_reason) values
    (pg_temp.f('d1'), pg_temp.f('b1'), pg_temp.f('s1'), pg_temp.f('p1'),  'negotiation',  u_agent,  u_agent,  null,    null,  null),
    (pg_temp.f('d2'), pg_temp.f('b3'), pg_temp.f('s1'), pg_temp.f('p7'),  'token',        u_agent2, u_agent2, null,    null,  null),
    (pg_temp.f('d3'), pg_temp.f('b7'), pg_temp.f('s2'), pg_temp.f('p2'),  'documentation', u_agent,  u_agent,  null,    null,  null),
    (pg_temp.f('d4'), pg_temp.f('b1'), pg_temp.f('s1'), pg_temp.f('p3'),  'closed',        u_agent,  u_agent,  1000000, now(), null),
    (pg_temp.f('d5'), pg_temp.f('b3'), pg_temp.f('s2'), pg_temp.f('p3'),  'cancelled',     u_agent2, u_agent2, null,    null,  'P32 test'),
    (pg_temp.f('d6'), pg_temp.f('b7'), pg_temp.f('s1'), pg_temp.f('p3b'), 'registration',  u_agent2, u_agent2, null,    null,  null),
    (pg_temp.f('d7'), pg_temp.f('b1'), pg_temp.f('s2'), pg_temp.f('p3b'), 'agreement',     u_mgr,    u_mgr,    null,    null,  null);
  update deals set deleted_at = now() where id = pg_temp.f('d6');

  -- ------------------------------------------------------------------ 5. CORRECTNESS PER ROLE (hand-derived expectations)
  --                       inv,due,open,new,hot,ovfu,buy,sell,match,today,await,task,deals
  perform pg_temp.rec('R1 admin counts',    pg_temp.vals(pg_temp.ds('authenticated', u_admin::text),  keys13), '5,3,6,1,3,2,3,2,4,2,3,2,4');
  perform pg_temp.rec('R2 manager counts',  pg_temp.vals(pg_temp.ds('authenticated', u_mgr::text),    keys13), '5,3,6,1,3,2,3,2,4,2,3,2,4');
  perform pg_temp.rec('R3 agent1 counts',   pg_temp.vals(pg_temp.ds('authenticated', u_agent::text),  keys13), '5,1,2,1,2,1,2,1,3,1,2,1,2');
  perform pg_temp.rec('R4 agent2 counts',   pg_temp.vals(pg_temp.ds('authenticated', u_agent2::text), keys13), '5,1,3,0,0,1,1,1,1,1,1,1,1');
  perform pg_temp.rec('R5 viewer counts (deals NA)', pg_temp.vals(pg_temp.ds('authenticated', u_viewer::text), keys13), '5,3,6,1,3,2,3,2,4,2,3,2,NA');

  -- scope labels
  perform pg_temp.rec('SC1 admin scopes all=all',  pg_temp.scopes(pg_temp.ds('authenticated', u_admin::text), keys13), 'all,all,all,all,all,all,all,all,all,all,all,all,all');
  perform pg_temp.rec('SC2 manager scopes',        pg_temp.scopes(pg_temp.ds('authenticated', u_mgr::text), keys13),   'all,all,all,all,all,all,all,all,all,all,all,all,all');
  perform pg_temp.rec('SC3 agent scopes (inventory all, rest assigned)',
                      pg_temp.scopes(pg_temp.ds('authenticated', u_agent::text), keys13), 'all,assigned,assigned,assigned,assigned,assigned,assigned,assigned,assigned,assigned,assigned,assigned,assigned');
  perform pg_temp.rec('SC4 viewer scopes (deals none)',
                      pg_temp.scopes(pg_temp.ds('authenticated', u_viewer::text), keys13), 'all,all,all,all,all,all,all,all,all,all,all,all,-');

  -- ------------------------------------------------------------------ 6. SECURITY: shape + viewer deal/finance exclusion
  for rec in select * from (values ('admin', u_admin), ('manager', u_mgr), ('agent', u_agent), ('viewer', u_viewer)) t(who, uid) loop
    j := pg_temp.ds('authenticated', rec.uid::text);
    perform pg_temp.rec('X1 ' || rec.who || ' top-level keys exact',
      (select string_agg(k, ',' order by k) from jsonb_object_keys(j) k), 'cards,generated_at,schema_version,timezone,warnings');
    perform pg_temp.rec('X2 ' || rec.who || ' 13 card keys exact',
      (select string_agg(k, ',' order by k) from jsonb_object_keys(j -> 'cards') k),
      (select string_agg(k, ',' order by k) from unnest(string_to_array(keys13, ',')) k));
    perform pg_temp.rec('X3 ' || rec.who || ' every card has only available/value/scope',
      (select string_agg(distinct (select string_agg(kk, ',' order by kk) from jsonb_object_keys(c.value) kk), '|') from jsonb_each(j -> 'cards') c),
      'available,scope,value');
    perform pg_temp.rec('X4 ' || rec.who || ' no money/finance/deal-field words anywhere in the payload',
      (j::text !~* '(price|amount|commission|payment|token_amount|final_price|revenue|brokerage)')::text, 'true');
  end loop;
  perform pg_temp.rec('X5 viewer open_deals is exactly {available:false,value:null,scope:null}',
    (pg_temp.ds('authenticated', u_viewer::text) -> 'cards' -> 'open_deals')::text,
    '{"scope": null, "value": null, "available": false}');
  perform pg_temp.rec('X6 viewer deals really are blocked by RLS (so a bare 0 would have been misleading)',
    pg_temp.q('authenticated', u_viewer::text, 'select count(*)::text from public.deals'), '0');
  perform pg_temp.rec('X7 viewer has no deals/finance permission',
    pg_temp.q('authenticated', u_viewer::text, $q$select count(*)::text from (select 1 where app.can('deals.read') or app.can('deals.read_all') or app.can('finance.read') or app.can('finance.read_all')) z$q$), '0');

  -- RLS-respect: function never exceeds what the caller can read; admin raw RLS DOES include soft-deleted rows
  perform pg_temp.rec('RL1 admin raw RLS leads includes deleted+terminal (9) while function open_leads = 6',
    pg_temp.q('authenticated', u_admin::text, 'select count(*)::text from public.leads'), '9');
  perform pg_temp.rec('RL2 agent1 raw RLS leads = own non-deleted only (l1,l3,l6 = 3)',
    pg_temp.q('authenticated', u_agent::text, 'select count(*)::text from public.leads'), '3');
  perform pg_temp.rec('RL3 agent1 raw RLS deals = own only (d1,d3,d4 = 3)',
    pg_temp.q('authenticated', u_agent::text, 'select count(*)::text from public.deals'), '3');
  perform pg_temp.rec('RL4 agent1 raw RLS properties = all active + own (p1,p2,p3,p3b,p7 + p4 own sold + p5 own inactive = 7)',
    pg_temp.q('authenticated', u_agent::text, 'select count(*)::text from public.properties'), '7');
  perform pg_temp.rec('RL5 agent1 raw RLS matches = visible requirements only',
    pg_temp.q('authenticated', u_agent::text, 'select count(*)::text from public.property_matches'),
    pg_temp.q('authenticated', u_agent::text, 'select count(*)::text from public.property_matches pm where exists (select 1 from public.buyer_requirements r where r.id = pm.requirement_id)'));

  -- ------------------------------------------------------------------ 7. UNAUTHORIZED / MALFORMED CALLS
  perform pg_temp.rec('U1 anon denied',                      pg_temp.ds('anon', null) ->> 'error', '42501');
  perform pg_temp.rec('U2 anon with a real user id denied',  pg_temp.ds('anon', u_admin::text) ->> 'error', '42501');
  perform pg_temp.rec('U3 service_role denied (no EXECUTE)', pg_temp.ds('service_role', u_admin::text) ->> 'error', '42501');
  perform pg_temp.rec('U4 authenticated, no sub claim',      pg_temp.ds('authenticated', null) ->> 'error', '42501');
  perform pg_temp.rec('U5 authenticated, unknown user id',   pg_temp.ds('authenticated', u_ghost::text) ->> 'error', '42501');
  perform pg_temp.rec('U6 authenticated, inactive profile',  pg_temp.ds('authenticated', u_inactive::text) ->> 'error', '42501');
  perform pg_temp.rec('U7 authenticated, profile without role', pg_temp.ds('authenticated', u_norole::text) ->> 'error', '42501');
  perform pg_temp.rec('U8 authenticated, soft-deleted profile', pg_temp.ds('authenticated', u_deleted::text) ->> 'error', '42501');
  perform pg_temp.rec('U9 malformed (non-uuid) subject returns an error, no data', pg_temp.ds('authenticated', 'not-a-uuid') ->> 'error', '22P02');
  perform pg_temp.rec('U11 positional argument rejected (no client input)',
    pg_temp.q('authenticated', u_admin::text, $q$select public.dashboard_summary(1)::text$q$), 'ERR 42883');
  perform pg_temp.rec('U12 named table/column/filter arguments rejected',
    pg_temp.q('authenticated', u_admin::text, $q$select public.dashboard_summary(p_table => 'deals', p_filter => 'true')::text$q$), 'ERR 42883');
  perform pg_temp.rec('U13 unauthorized callers get no card data at all',
    (pg_temp.ds('anon', null) ? 'cards')::text, 'false');

  -- ------------------------------------------------------------------ 8. NO WRITES (snapshot of every public/app table before vs after)
  snapA := pg_temp.snap();
  perform pg_temp.ds('authenticated', u_admin::text); perform pg_temp.ds('authenticated', u_mgr::text);
  perform pg_temp.ds('authenticated', u_agent::text); perform pg_temp.ds('authenticated', u_viewer::text);
  perform pg_temp.ds('anon', null); perform pg_temp.ds('authenticated', u_ghost::text);
  snapB := pg_temp.snap();
  perform pg_temp.rec('W1 no table (incl. audit_logs) changed by any call', (snapA = snapB)::text, 'true');

  -- ------------------------------------------------------------------ 9. TIMEZONE DAY BOUNDARY vs an independent reference
  for tzname in select unnest(array['Asia/Kolkata', 'America/New_York', 'Pacific/Kiritimati', 'UTC', 'Pacific/Auckland']) loop
    update settings set value = to_jsonb(tzname) where key = 'app.timezone';
    j := pg_temp.ds('authenticated', u_admin::text);
    select count(*) into exp_ref from appointments
     where deleted_at is null and status in ('scheduled', 'confirmed')
       and (starts_at at time zone tzname)::date = (now() at time zone tzname)::date;
    perform pg_temp.rec('TZ ' || tzname || ' appointments_today = independent local-date reference',
      j -> 'cards' -> 'appointments_today' ->> 'value', exp_ref::text);
    perform pg_temp.rec('TZ ' || tzname || ' reported timezone', j ->> 'timezone', tzname);
  end loop;
  update settings set value = '"Asia/Kolkata"'::jsonb where key = 'app.timezone';

  -- ------------------------------------------------------------------ 10. SETTINGS: configurable + malformed values
  -- hot priorities
  update settings set value = '["urgent"]' where key = 'leads.hot_priorities';
  perform pg_temp.rec('ST1 hot=["urgent"] -> 1 (l3)', pg_temp.ds('authenticated', u_admin::text) -> 'cards' -> 'hot_leads' ->> 'value', '1');
  update settings set value = '[]' where key = 'leads.hot_priorities';
  j := pg_temp.ds('authenticated', u_admin::text);
  perform pg_temp.rec('ST2 hot=[] is valid -> 0, no warning', (j -> 'cards' -> 'hot_leads' ->> 'value') || ' ' || (j ->> 'warnings'), '0 []');
  update settings set value = '["high","medium"]' where key = 'leads.hot_priorities';
  perform pg_temp.rec('ST3 hot=["high","medium"] -> l1,l4,l5 = 3', pg_temp.ds('authenticated', u_admin::text) -> 'cards' -> 'hot_leads' ->> 'value', '3');
  foreach v in array array['"high"', '["high","bogus"]', '[1]', '{"a":1}', 'null', '123', '[["high"]]'] loop
    update settings set value = v::jsonb where key = 'leads.hot_priorities';
    j := pg_temp.ds('authenticated', u_admin::text);
    perform pg_temp.rec('ST4 hot=' || v || ' -> falls back to default (3) + warning, no error',
      coalesce(j ->> 'error', (j -> 'cards' -> 'hot_leads' ->> 'value') || ' ' || (j ->> 'warnings')), '3 ["leads_hot_priorities_fallback"]');
  end loop;
  update settings set value = '["high","urgent"]' where key = 'leads.hot_priorities';

  -- re-verification days
  update settings set value = '5' where key = 'property.reverify_days';
  perform pg_temp.rec('ST5 reverify=5 -> p1,p2,p3,p3b = 4', pg_temp.ds('authenticated', u_admin::text) -> 'cards' -> 'listings_due_verification' ->> 'value', '4');
  update settings set value = '60' where key = 'property.reverify_days';
  perform pg_temp.rec('ST6 reverify=60 -> only p1 (never verified) = 1', pg_temp.ds('authenticated', u_admin::text) -> 'cards' -> 'listings_due_verification' ->> 'value', '1');
  foreach v in array array['0', '-5', '30.5', '"30"', 'null', '99999', '[30]', 'true'] loop
    update settings set value = v::jsonb where key = 'property.reverify_days';
    j := pg_temp.ds('authenticated', u_admin::text);
    perform pg_temp.rec('ST7 reverify=' || v || ' -> falls back to 30 (3) + warning, no error',
      coalesce(j ->> 'error', (j -> 'cards' -> 'listings_due_verification' ->> 'value') || ' ' || (j ->> 'warnings')), '3 ["property_reverify_days_fallback"]');
  end loop;
  update settings set value = '30' where key = 'property.reverify_days';

  -- timezone malformed
  foreach v in array array['"Mars/Phobos"', '123', 'null', '["UTC"]', '""'] loop
    update settings set value = v::jsonb where key = 'app.timezone';
    j := pg_temp.ds('authenticated', u_admin::text);
    perform pg_temp.rec('ST8 timezone=' || v || ' -> falls back to Asia/Kolkata + warning, no error',
      coalesce(j ->> 'error', (j ->> 'timezone') || ' ' || (j ->> 'warnings')), 'Asia/Kolkata ["app_timezone_fallback"]');
  end loop;
  update settings set value = '"Asia/Kolkata"' where key = 'app.timezone';

  -- settings rows missing entirely
  delete from settings where key in ('app.timezone', 'leads.hot_priorities', 'property.reverify_days');
  j := pg_temp.ds('authenticated', u_admin::text);
  perform pg_temp.rec('ST9 all three settings missing -> defaults + 3 warnings, still correct counts',
    coalesce(j ->> 'error', pg_temp.vals(j, keys13) || ' ' || (j ->> 'timezone') || ' ' || jsonb_array_length(j -> 'warnings')),
    '5,3,6,1,3,2,3,2,4,2,3,2,4 Asia/Kolkata 3');

  -- ------------------------------------------------------------------ 11. VIEWER cannot reach deal data even when the deals permission is probed other ways
  perform pg_temp.rec('V1 viewer cannot select deals directly', pg_temp.q('authenticated', u_viewer::text, 'select count(*)::text from public.deals'), '0');
  perform pg_temp.rec('V2 viewer cannot select commissions directly', pg_temp.q('authenticated', u_viewer::text, 'select count(*)::text from public.commissions'), '0');
  perform pg_temp.rec('V3 viewer cannot select payments directly', pg_temp.q('authenticated', u_viewer::text, 'select count(*)::text from public.payments'), '0');

  -- ------------------------------------------------------------------ 12. REPORT (the error below is the intentional rollback)
  perform pg_temp.restore_seqs(seq0);
  select count(*) filter (where ok), count(*) filter (where not ok) into n_pass, n_fail from tr;
  for rec in select * from tr order by n loop
    rpt := rpt || E'\n' || case when rec.ok then 'PASS ' else 'FAIL ' end || rec.label
           || case when rec.ok then '' else '   got=[' || coalesce(rec.got, 'NULL') || '] want=[' || coalesce(rec.want, 'NULL') || ']' end;
  end loop;
  raise exception 'P3.2 TEST REPORT: % PASS, % FAIL%', n_pass, n_fail, rpt using errcode = 'P0001';
end
$p32$;
