-- =====================================================================
-- EstateVanta CRM — Phase 2 security tests (FULLY ROLLED BACK)
-- Run in: Supabase Dashboard -> SQL Editor, project "Estate vanta crm".
-- Read docs/PHASE2_TESTING.md first. Paste the WHOLE file and press Run once.
--
-- WHAT YOU WILL SEE
--   The script is ONE statement (a DO block). It always ends with a deliberate
--   error whose text is the test report. That error is the ONLY way to be sure
--   everything rolls back, so "ERROR: P0001 ... P2 TEST REPORT" is the SUCCESS
--   output. The editor may also ask you to confirm "destructive" statements
--   (it sees UPDATE/DELETE keywords) — that is expected; every row written by
--   this script is thrown away.
--
-- SAFETY
--   * Single statement  => single transaction. The final RAISE aborts it, so
--     every auth.users row, profile, fixture row, audit row, pg_temp function,
--     role and setting created here disappears.
--   * Sequences are not transactional, so their values are captured at the
--     start and restored with setval() at the end (before the report).
--   * Throwaway users only (@example.invalid, random tags). No real user,
--     profile, business row, role, permission or setting is read for its
--     content or changed. Tests that try to modify real roles / permissions
--     are DENIAL tests, each run in its own sub-transaction that is rolled back
--     even if the statement unexpectedly succeeded.
--   * The bootstrap secret used here is generated randomly inside the script,
--     is never printed, never stored outside the aborted transaction, and has
--     nothing to do with your real secret. If a real bootstrap is already armed
--     or an active admin exists, the bootstrap tests are SKIPPED so that the
--     real state is never touched.
--   * At the end the script re-reads auth.users, profiles, audit_logs and every
--     other table in public/app plus selected auth tables and sequences, and
--     reports whether they are byte-identical to the pre-test snapshot.
--
-- NOT COVERED HERE: real parallel races (bootstrap, last-admin) need two simultaneous
--   sessions and committed data. Sections 6 and 7 give single-session evidence only.
--   Section 7 shows GAP lines until Step 3 is installed and hard PASS/FAIL afterwards
--   (Step 3 is installed on the live project since 2026-10-04: expected result PASS 322 / FAIL 0 / GAP 2).
-- =====================================================================
do $p2$
declare
  sep         text := chr(31);
  tag         text := substr(md5(random()::text || clock_timestamp()::text), 1, 8);
  sec_ok      text := 'P2TEST-' || md5(random()::text) || md5(clock_timestamp()::text);
  sec_bad     text := 'P2WRONG-' || md5(random()::text) || md5(clock_timestamp()::text);
  deny        text := '0//ERR 42501%';
  -- throwaway identities
  u_boot uuid := gen_random_uuid(); u_other uuid := gen_random_uuid(); u_unconf uuid := gen_random_uuid();
  u_admin uuid := gen_random_uuid(); u_mgr uuid := gen_random_uuid();
  u_agent uuid := gen_random_uuid(); u_agent2 uuid := gen_random_uuid();
  u_viewer uuid := gen_random_uuid(); u_plain uuid := gen_random_uuid();
  u_inact uuid := gen_random_uuid(); u_del uuid := gen_random_uuid(); u_ghost uuid := gen_random_uuid();
  e_boot text; e_other text; e_unconf text;
  -- fixtures
  c_a uuid := gen_random_uuid(); c_b uuid := gen_random_uuid();
  lead_a uuid := gen_random_uuid(); lead_b uuid := gen_random_uuid();
  buyer1 uuid := gen_random_uuid(); seller1 uuid := gen_random_uuid();
  p_avail uuid := gen_random_uuid(); p_sold uuid := gen_random_uuid(); p_mine uuid := gen_random_uuid();
  deal1 uuid := gen_random_uuid(); deal2 uuid := gen_random_uuid();
  com1 uuid := gen_random_uuid(); pay1 uuid := gen_random_uuid();
  batch1 uuid := gen_random_uuid(); md1 uuid := gen_random_uuid();
  role_t smallint; r_admin smallint; r_mgr smallint; r_viewer smallint; perm_um smallint;
  -- state
  out         text[] := '{}';
  fatal       text;
  do_boot     boolean;
  admin_before boolean; armed_before boolean; step3 boolean; k7 text;
  snap0 jsonb; snap1 jsonb; seq0 jsonb; seq1 jsonb;
  state_before text; state_after text;
  a record; rec record;
  rpt text := ''; top text := ''; cur_sec text := ''; msg text;
  n_p int; n_f int; n_g int; n_s int; diff_tables text; seq_ok boolean;
begin
  e_boot := 'p2t-' || tag || '-boot@example.invalid';
  e_other := 'p2t-' || tag || '-other@example.invalid';
  e_unconf := 'p2t-' || tag || '-unconf@example.invalid';

  -- ---------------------------------------------------------------
  -- 0. helpers (pg_temp; vanish with the transaction) and snapshots
  -- ---------------------------------------------------------------
  execute $h$
    create function pg_temp.pk(p_ok boolean, p_kind text, p_label text, p_who text, p_got text, p_want text)
    returns text language sql as $f$
      select (case when p_ok then 'P' when p_kind = 'G' then 'G' when p_kind = 'S' then 'S' else 'F' end)
             || chr(31) || coalesce(current_setting('p2.section', true), '')
             || chr(31) || p_label || chr(31) || p_who
             || chr(31) || left(replace(coalesce(p_got, ''), chr(10), ' '), 70)
             || chr(31) || left(coalesce(p_want, ''), 70)
    $f$ $h$;

  execute $h$
    create function pg_temp.chk(p_label text, p_who text, p_role text, p_uid uuid, p_sql text,
                                p_expect text, p_kind text default 'T', p_rb boolean default false)
    returns text language plpgsql as $f$
    declare v text; n bigint; claims text; ok boolean := false; alt text;
    begin
      if p_role in ('anon', 'authenticated', 'service_role') then
        claims := case when p_uid is null then json_build_object('role', p_role)::text
                       else json_build_object('sub', p_uid, 'role', p_role, 'aud', 'authenticated')::text end;
        perform set_config('request.jwt.claims', claims, true);
        perform set_config('request.jwt.claim.sub', coalesce(p_uid::text, ''), true);
        perform set_config('request.jwt.claim.role', p_role, true);
        execute format('set local role %I', p_role);
      end if;
      begin
        if p_sql ~* '^\s*(insert|update|delete)\s' then
          execute p_sql; get diagnostics n = row_count; v := n::text;
        else
          execute p_sql into v; v := coalesce(v, '(null)');
        end if;
        if p_rb then raise exception 'rollback this test' using errcode = 'P2RBK'; end if;
      exception
        when sqlstate 'P2RBK' then null;
        when others then v := 'ERR ' || sqlstate || ' ' || left(sqlerrm, 80);
      end;
      execute 'reset role';
      perform set_config('request.jwt.claims', '', true);
      perform set_config('request.jwt.claim.sub', '', true);
      perform set_config('request.jwt.claim.role', '', true);
      foreach alt in array string_to_array(p_expect, '//') loop
        if v like alt then ok := true; end if;
      end loop;
      return pg_temp.pk(ok, p_kind, p_label, p_who, v, p_expect);
    end $f$ $h$;

  execute $h$
    create function pg_temp.mx(p_label text, p_sql text, ea text, em text, eg text, ev text, p_kind text default 'T')
    returns text[] language plpgsql as $f$
    begin
      return array[
        pg_temp.chk(p_label, 'adm', 'authenticated', current_setting('p2.u_admin')::uuid,  p_sql, ea, p_kind, true),
        pg_temp.chk(p_label, 'mgr', 'authenticated', current_setting('p2.u_mgr')::uuid,    p_sql, em, p_kind, true),
        pg_temp.chk(p_label, 'agt', 'authenticated', current_setting('p2.u_agent')::uuid,  p_sql, eg, p_kind, true),
        pg_temp.chk(p_label, 'vwr', 'authenticated', current_setting('p2.u_viewer')::uuid, p_sql, ev, p_kind, true)];
    end $f$ $h$;

  execute $h$
    create function pg_temp.p2_snapshot() returns jsonb language plpgsql as $f$
    declare r record; j jsonb := '{}'; v text;
    begin
      for r in select n.nspname, c.relname from pg_class c join pg_namespace n on n.oid = c.relnamespace
               where c.relkind in ('r', 'p')
                 and (n.nspname in ('public', 'app')
                      or (n.nspname = 'auth' and c.relname in ('users', 'identities', 'sessions', 'refresh_tokens')))
               order by 1, 2
      loop
        begin
          execute format('select count(*)::text || '':'' || coalesce(md5(string_agg(t::text, ''|'' order by t::text)), ''-'') from %I.%I t',
                         r.nspname, r.relname) into v;
        exception when others then v := 'unreadable';
        end;
        j := j || jsonb_build_object(r.nspname || '.' || r.relname, v);
      end loop;
      return j;
    end $f$ $h$;

  execute $h$
    create function pg_temp.p2_seqs() returns jsonb language plpgsql as $f$
    declare r record; j jsonb := '{}'; lv bigint; ic boolean;
    begin
      for r in select n.nspname, c.relname from pg_class c join pg_namespace n on n.oid = c.relnamespace
               where c.relkind = 'S' and n.nspname in ('public', 'app', 'auth') order by 1, 2
      loop
        begin
          execute format('select last_value, is_called from %I.%I', r.nspname, r.relname) into lv, ic;
          j := j || jsonb_build_object(r.nspname || '.' || r.relname, jsonb_build_array(lv, ic));
        exception when others then null;
        end;
      end loop;
      return j;
    end $f$ $h$;

  execute $h$
    create function pg_temp.p2_restore_seqs(p_seqs jsonb) returns void language plpgsql as $f$
    declare r record;
    begin
      for r in select key, value from jsonb_each(p_seqs) loop
        begin
          perform setval(r.key::regclass, (r.value ->> 0)::bigint, (r.value ->> 1)::boolean);
        exception when others then null;
        end;
      end loop;
    end $f$ $h$;

  snap0 := pg_temp.p2_snapshot();
  seq0  := pg_temp.p2_seqs();
  admin_before := exists (select 1 from profiles p join roles r on r.id = p.role_id
                          where r.code = 'admin' and p.is_active and p.deleted_at is null);
  armed_before := exists (select 1 from app.bootstrap_setup);
  do_boot := not admin_before and not armed_before;
  step3 := exists (select 1 from pg_trigger where tgname = 'protect_last_admin' and tgrelid = 'public.profiles'::regclass and not tgisinternal);
  -- Step 3 expectations are hard FAILs once Step 3 is installed; before that they are reported as GAP.
  k7 := case when step3 then 'T' else 'G' end;

  -- ---------------------------------------------------------------
  -- Everything below runs in a sub-transaction that is ALWAYS aborted.
  -- ---------------------------------------------------------------
  begin
    perform set_config('request.jwt.claims', '', true);
    perform set_config('request.jwt.claim.sub', '', true);
    perform set_config('request.jwt.claim.role', '', true);

    -- ===== 0 PREFLIGHT ==============================================
    perform set_config('p2.section', '0 Preflight', true);
    out := out || pg_temp.chk('caller may execute the owner-only bootstrap functions', 'sql-editor', 'postgres', null,
      $q$select (has_function_privilege(current_user, 'app.arm_bootstrap(text,text,int)', 'EXECUTE')
             and has_function_privilege(current_user, 'app.bootstrap_first_admin(uuid,text)', 'EXECUTE'))::text$q$, 'true');
    out := out || pg_temp.chk('caller is a member of anon/authenticated/service_role (needed for role tests)', 'sql-editor', 'postgres', null,
      $q$select (pg_has_role(current_user, 'anon', 'MEMBER') and pg_has_role(current_user, 'authenticated', 'MEMBER')
             and pg_has_role(current_user, 'service_role', 'MEMBER'))::text$q$, 'true');
    out := out || pg_temp.chk('caller can insert into auth.users (throwaway fixtures)', 'sql-editor', 'postgres', null,
      $q$select has_table_privilege(current_user, 'auth.users', 'INSERT')::text$q$, 'true');
    if do_boot then
      out := out || pg_temp.pk(true, 'T', 'no active admin and bootstrap not armed -> bootstrap tests will run', 'state', 'true', 'true');
    else
      out := out || pg_temp.pk(false, 'S', 'bootstrap tests SKIPPED (a real admin exists or bootstrap is armed; real state is never touched)',
                               'state', 'admin=' || admin_before::text || ' armed=' || armed_before::text, '-');
    end if;

    -- ===== 1 BOOTSTRAP ==============================================
    if do_boot then
      perform set_config('p2.section', '1 Bootstrap (owner session, throwaway users)', true);
      insert into auth.users(id, aud, role, email, email_confirmed_at, last_sign_in_at) values
        (u_boot,   'authenticated', 'authenticated', e_boot,   now(), now()),
        (u_other,  'authenticated', 'authenticated', e_other,  now(), now()),
        (u_unconf, 'authenticated', 'authenticated', e_unconf, null,  null);

      out := out || pg_temp.chk('new sign-ups get an INACTIVE profile with NO role', 'all3', 'postgres', null,
        format($q$select count(*)::text from profiles where id in (%L,%L,%L) and role_id is null and not is_active$q$, u_boot, u_other, u_unconf), '3');
      out := out || pg_temp.chk('confirmed email alone grants nothing (my_access: role null, 0 permissions)', 'boot', 'authenticated', u_boot,
        $q$select (public.my_access()->>'role') is null and jsonb_array_length(public.my_access()->'permissions') = 0$q$, 'true');
      out := out || pg_temp.chk('not armed -> refused', 'owner', 'postgres', null,
        format($q$select app.bootstrap_first_admin(%L::uuid, %L)::text$q$, u_boot, sec_ok), 'ERR 55000 Bootstrap is not armed%');
      out := out || pg_temp.chk('arm with valid secret/email/window', 'owner', 'postgres', null,
        format($q$select 'OK' from (select app.arm_bootstrap(%L, %L, 30)) s$q$, sec_ok, e_boot), 'OK');

      -- 2 wrong secret
      out := out || pg_temp.chk('WRONG secret (right user, confirmed email) -> refused', 'owner', 'postgres', null,
        format($q$select app.bootstrap_first_admin(%L::uuid, %L)::text$q$, u_boot, sec_bad), 'ERR 28000 Invalid setup secret%');
      out := out || pg_temp.chk('NULL secret -> refused', 'owner', 'postgres', null,
        format($q$select app.bootstrap_first_admin(%L::uuid, null)::text$q$, u_boot), 'ERR 28000 Invalid setup secret%');
      out := out || pg_temp.chk('empty secret -> refused', 'owner', 'postgres', null,
        format($q$select app.bootstrap_first_admin(%L::uuid, '')::text$q$, u_boot), 'ERR 28000 Invalid setup secret%');
      out := out || pg_temp.chk('failed attempts did not consume the window or promote anyone', 'state', 'postgres', null,
        format($q$select (select consumed_at is null from app.bootstrap_setup)::text || '/' ||
                         (select count(*)::text from profiles p join roles r on r.id = p.role_id
                           where r.code = 'admin' and p.id in (%L,%L,%L))$q$, u_boot, u_other, u_unconf), 'true/0');

      -- 4 email mismatch
      out := out || pg_temp.chk('EMAIL MISMATCH (right secret, other confirmed user) -> refused', 'owner', 'postgres', null,
        format($q$select app.bootstrap_first_admin(%L::uuid, %L)::text$q$, u_other, sec_ok), 'ERR 55000 User email does not match%');

      -- 5 unconfirmed email (re-arm for the unconfirmed user's address)
      out := out || pg_temp.chk('re-arm for the unconfirmed user''s email (allowed while unconsumed)', 'owner', 'postgres', null,
        format($q$select 'OK' from (select app.arm_bootstrap(%L, %L, 30)) s$q$, sec_ok, e_unconf), 'OK');
      out := out || pg_temp.chk('UNCONFIRMED email (right secret + matching email) -> refused', 'owner', 'postgres', null,
        format($q$select app.bootstrap_first_admin(%L::uuid, %L)::text$q$, u_unconf, sec_ok), 'ERR 55000 The user%email must be confirmed%');

      -- 3 expired window
      out := out || pg_temp.chk('arm 5-minute window for the real candidate', 'owner', 'postgres', null,
        format($q$select 'OK' from (select app.arm_bootstrap(%L, %L, 5)) s$q$, sec_ok, e_boot), 'OK');
      out := out || pg_temp.chk('force the window into the past (test-only edit of the aborted row)', 'owner', 'postgres', null,
        $q$update app.bootstrap_setup set expires_at = now() - interval '1 minute'$q$, '1');
      out := out || pg_temp.chk('EXPIRED window (everything else correct) -> refused', 'owner', 'postgres', null,
        format($q$select app.bootstrap_first_admin(%L::uuid, %L)::text$q$, u_boot, sec_ok), 'ERR 55000 Bootstrap window has expired%');
      out := out || pg_temp.chk('re-arm after expiry (unconsumed rows may be re-armed)', 'owner', 'postgres', null,
        format($q$select 'OK' from (select app.arm_bootstrap(%L, %L, 30)) s$q$, sec_ok, e_boot), 'OK');

      -- API roles still cannot touch any of it
      out := out || pg_temp.chk('authenticated cannot call bootstrap even with the right secret', 'boot', 'authenticated', u_boot,
        format($q$select app.bootstrap_first_admin(%L::uuid, %L)::text$q$, u_boot, sec_ok), 'ERR 42501%');
      out := out || pg_temp.chk('service_role cannot call bootstrap even with the right secret', 'svc', 'service_role', null,
        format($q$select app.bootstrap_first_admin(%L::uuid, %L)::text$q$, u_boot, sec_ok), 'ERR 42501%');

      -- 1 success path
      out := out || pg_temp.chk('SUCCESS: right secret + confirmed matching email + armed + no admin', 'owner', 'postgres', null,
        format($q$select 'OK' from (select app.bootstrap_first_admin(%L::uuid, %L)) s$q$, u_boot, sec_ok), 'OK');
      out := out || pg_temp.chk('candidate is now active admin', 'state', 'postgres', null,
        format($q$select r.code || '/' || p.is_active::text from profiles p join roles r on r.id = p.role_id where p.id = %L$q$, u_boot), 'admin/true');
      out := out || pg_temp.chk('setup row consumed, hash wiped, consumed_by recorded', 'state', 'postgres', null,
        format($q$select (consumed_at is not null)::text || '/' || (secret_hash = repeat('0', 64))::text || '/' || (consumed_by = %L)::text
                    from app.bootstrap_setup$q$, u_boot), 'true/true/true');
      out := out || pg_temp.chk('audit trail: one bootstrap_admin event for the promoted user', 'state', 'postgres', null,
        format($q$select count(*)::text from audit_logs where action = 'bootstrap_admin' and entity_id = %L$q$, u_boot::text), '1');
      out := out || pg_temp.chk('secret (or its hash) is not left in the setup table', 'state', 'postgres', null,
        format($q$select count(*)::text from app.bootstrap_setup where secret_hash = encode(sha256(convert_to(%L, 'UTF8')), 'hex')$q$, sec_ok), '0');
      out := out || pg_temp.chk('secret is not written to audit_logs', 'state', 'postgres', null,
        format($q$select count(*)::text from audit_logs where new_values::text like '%%' || %L || '%%'$q$, sec_ok), '0');

      -- replay / second candidate (also the "losing racer" outcome, section 6)
      out := out || pg_temp.chk('REPLAY with the same secret -> refused', 'owner', 'postgres', null,
        format($q$select app.bootstrap_first_admin(%L::uuid, %L)::text$q$, u_boot, sec_ok), 'ERR 55000 Bootstrap has already been completed%');
      out := out || pg_temp.chk('SECOND confirmed user, same secret -> refused, cannot be promoted', 'owner', 'postgres', null,
        format($q$select app.bootstrap_first_admin(%L::uuid, %L)::text$q$, u_other, sec_ok), 'ERR 55000 Bootstrap has already been completed%');
      out := out || pg_temp.chk('re-arming after completion -> refused', 'owner', 'postgres', null,
        format($q$select app.arm_bootstrap(%L, %L, 30)::text$q$, sec_ok, e_other), 'ERR 55000%');
      out := out || pg_temp.chk('only the one candidate is admin', 'state', 'postgres', null,
        format($q$select count(*)::text from profiles p join roles r on r.id = p.role_id
                   where r.code = 'admin' and p.id in (%L,%L,%L)$q$, u_boot, u_other, u_unconf), '1');

      -- 6 concurrency evidence (single session; see docs/PHASE2_TESTING.md)
      perform set_config('p2.section', '6 Concurrency evidence (single-session proxy, NOT a real race)', true);
      out := out || pg_temp.chk('bootstrap call holds the global bootstrap advisory lock until commit', 'lock', 'postgres', null,
        $q$select count(*)::text from pg_locks where locktype = 'advisory' and pid = pg_backend_pid() and granted
              and objid::text::bigint = (hashtext('estatevanta.bootstrap')::bigint & 4294967295)$q$, '1');
      out := out || pg_temp.chk('arm_bootstrap and bootstrap_first_admin share that lock and lock the state row FOR UPDATE', 'code', 'postgres', null,
        $q$select (bool_and(prosrc like '%pg_advisory_xact_lock(hashtext(''estatevanta.bootstrap''))%')
                   and bool_and(prosrc like '%for update%'))::text
             from pg_proc where oid in ('app.arm_bootstrap(text,text,int)'::regprocedure, 'app.bootstrap_first_admin(uuid,text)'::regprocedure)$q$, 'true');
    end if;

    -- ===== 2 CREATE ROLE USERS + FIXTURES ===========================
    perform set_config('p2.section', '2 Fixtures', true);
    insert into auth.users(id, aud, role, email, email_confirmed_at, last_sign_in_at) values
      (u_admin,  'authenticated', 'authenticated', 'p2t-' || tag || '-admin@example.invalid',  now(), now()),
      (u_mgr,    'authenticated', 'authenticated', 'p2t-' || tag || '-mgr@example.invalid',    now(), now()),
      (u_agent,  'authenticated', 'authenticated', 'p2t-' || tag || '-agent@example.invalid',  now(), now()),
      (u_agent2, 'authenticated', 'authenticated', 'p2t-' || tag || '-agent2@example.invalid', now(), now()),
      (u_viewer, 'authenticated', 'authenticated', 'p2t-' || tag || '-viewer@example.invalid', now(), now()),
      (u_plain,  'authenticated', 'authenticated', 'p2t-' || tag || '-plain@example.invalid',  now(), now()),
      (u_inact,  'authenticated', 'authenticated', 'p2t-' || tag || '-inact@example.invalid',  now(), now()),
      (u_del,    'authenticated', 'authenticated', 'p2t-' || tag || '-del@example.invalid',    now(), now());
    update profiles set role_id = (select id from roles where code = 'admin'),   is_active = true where id = u_admin;
    update profiles set role_id = (select id from roles where code = 'manager'), is_active = true where id = u_mgr;
    update profiles set role_id = (select id from roles where code = 'agent'),   is_active = true where id in (u_agent, u_agent2);
    update profiles set role_id = (select id from roles where code = 'viewer'),  is_active = true where id = u_viewer;
    update profiles set role_id = (select id from roles where code = 'agent'),   is_active = false where id = u_inact;
    update profiles set role_id = (select id from roles where code = 'agent'),   is_active = true, deleted_at = now() where id = u_del;

    insert into contacts(id, full_name, email) values
      (c_a, 'P2TEST contact A', 'p2t-' || tag || '-ca@example.invalid'), (c_b, 'P2TEST contact B', 'p2t-' || tag || '-cb@example.invalid');
    insert into leads(id, contact_id, lead_type, source_code, status_code, assigned_to) values
      (lead_a, c_a, 'buy', 'website', 'new', u_agent), (lead_b, c_b, 'buy', 'website', 'new', u_agent2);
    insert into buyers(id, contact_id, assigned_to) values (buyer1, c_a, u_agent);
    insert into sellers(id, contact_id, assigned_to) values (seller1, c_b, u_agent2);
    insert into properties(id, title, property_type_code, transaction_type, city, source, status, assigned_to) values
      (p_avail, 'P2TEST available (agent2)', 'plot', 'sale', 'P2TEST', 'other', 'available', u_agent2),
      (p_sold,  'P2TEST sold (agent2)',      'plot', 'sale', 'P2TEST', 'other', 'sold',      u_agent2),
      (p_mine,  'P2TEST available (agent)',  'plot', 'sale', 'P2TEST', 'other', 'available', u_agent);
    insert into property_owner_terms(property_id, min_price) values (p_avail, 1000), (p_mine, 2000);
    insert into property_documents(property_id, category, title, storage_path)
      values (p_avail, 'other', 'P2TEST doc', 'p2test/doc.pdf');
    insert into deals(id, buyer_id, seller_id, property_id, assigned_to) values
      (deal1, buyer1, seller1, p_mine, u_agent), (deal2, buyer1, seller1, p_avail, u_agent2);
    insert into commissions(id, deal_id, party, expected_amount) values (com1, deal1, 'buyer', 1000);
    insert into payments(id, deal_id, purpose, amount) values (pay1, deal1, 'token', 500);
    insert into import_batches(id, entity, format, file_name, storage_path, source_name, authorization_note)
      values (batch1, 'leads', 'csv', 'p2test.csv', 'p2test/p2test.csv', 'P2TEST', 'P2TEST fixture authorization note');
    insert into market_data(id, city, data_kind, source_name, collected_on, price)
      values (md1, 'P2TEST', 'asking_price', 'P2TEST', current_date, 1);
    insert into roles(code, label) values ('zz_p2_' || tag, 'P2TEST role') returning id into role_t;
    select id into r_admin from roles where code = 'admin';
    select id into r_mgr from roles where code = 'manager';
    select id into r_viewer from roles where code = 'viewer';
    select id into perm_um from permissions where code = 'users.manage';

    perform set_config('p2.u_admin', u_admin::text, true);   perform set_config('p2.u_mgr', u_mgr::text, true);
    perform set_config('p2.u_agent', u_agent::text, true);   perform set_config('p2.u_viewer', u_viewer::text, true);

    out := out || pg_temp.chk('fixtures created: 8 users with profiles, business rows present', 'owner', 'postgres', null,
      format($q$select ((select count(*) from profiles where id in (%L,%L,%L,%L,%L,%L,%L,%L)) = 8
                   and (select count(*) from leads where id in (%L,%L)) = 2
                   and (select count(*) from deals where id in (%L,%L)) = 2)::text$q$,
             u_admin, u_mgr, u_agent, u_agent2, u_viewer, u_plain, u_inact, u_del, lead_a, lead_b, deal1, deal2), 'true');

    -- ===== 3 PERMISSION MATRIX (real role + JWT claims, each test rolled back)
    perform set_config('p2.section', '3a Matrix: what each role can READ (adm / mgr / agt / vwr)', true);
    out := out || pg_temp.mx('leads visible (2 fixtures; agent owns 1)',
      format('select count(*)::text from leads where id in (%L,%L)', lead_a, lead_b), '2', '2', '1', '2');
    out := out || pg_temp.mx('contacts visible (2 fixtures; agent via own lead)',
      format('select count(*)::text from contacts where id in (%L,%L)', c_a, c_b), '2', '2', '1', '2');
    out := out || pg_temp.mx('properties visible (available/sold/own-available)',
      format('select count(*)::text from properties where id in (%L,%L,%L)', p_avail, p_sold, p_mine), '3', '3', '2', '3');
    out := out || pg_temp.mx('AGENT sees ACTIVE inventory that is not theirs (available, agent2''s)',
      format('select count(*)::text from properties where id = %L', p_avail), '1', '1', '1', '1');
    out := out || pg_temp.mx('AGENT does NOT see non-active inventory that is not theirs (sold)',
      format('select count(*)::text from properties where id = %L', p_sold), '1', '1', '0', '1');
    out := out || pg_temp.mx('deals visible (agent: own only; VIEWER: none = no deal data)',
      format('select count(*)::text from deals where id in (%L,%L)', deal1, deal2), '2', '2', '1', '0');
    out := out || pg_temp.mx('commissions visible (finance)',
      format('select count(*)::text from commissions where id = %L', com1), '1', '1', '0', '0');
    out := out || pg_temp.mx('payments visible (finance)',
      format('select count(*)::text from payments where id = %L', pay1), '1', '1', '0', '0');
    out := out || pg_temp.mx('owner terms / min price of a property that is not theirs',
      format('select count(*)::text from property_owner_terms where property_id = %L', p_avail), '1', '1', '0', '0');
    out := out || pg_temp.mx('owner terms / min price of the agent''s own property',
      format('select count(*)::text from property_owner_terms where property_id = %L', p_mine), '1', '1', '1', '0');
    out := out || pg_temp.mx('property documents (viewer has properties.read_all: see docs note)',
      format('select count(*)::text from property_documents where property_id = %L', p_avail), '1', '1', '0', '1');
    out := out || pg_temp.mx('audit log readable (audit.read = admin only)',
      format($q$select (count(*) > 0)::text from audit_logs where entity_table = 'profiles' and entity_id = %L$q$, u_agent::text),
      'true', 'false', 'false', 'false');
    out := out || pg_temp.mx('import batches visible',
      format('select count(*)::text from import_batches where id = %L', batch1), '1', '1', '0', '0');
    out := out || pg_temp.mx('market data visible',
      format('select count(*)::text from market_data where id = %L', md1), '1', '1', '0', '1');
    out := out || pg_temp.mx('settings readable (any active role)',
      $q$select count(*)::text from settings where key = 'company.name'$q$, '1', '1', '1', '1');
    out := out || pg_temp.mx('profiles directory visible to any active role (4 role users)',
      format('select count(*)::text from profiles where id in (%L,%L,%L,%L)', u_admin, u_mgr, u_agent, u_viewer), '4', '4', '4', '4');
    out := out || pg_temp.mx('roles + role_permissions readable (>= 4 roles)',
      $q$select ((select count(*) from roles) >= 4 and (select count(*) from role_permissions) > 0)::text$q$, 'true', 'true', 'true', 'true');

    perform set_config('p2.section', '3b Matrix: what each role can WRITE (adm / mgr / agt / vwr; 0 or 42501 = denied)', true);
    out := out || pg_temp.mx('leads: insert',
      format($q$insert into leads(contact_id, lead_type, source_code, status_code) values (%L, 'buy', 'website', 'new')$q$, c_a),
      '1', '1', '1', deny);
    out := out || pg_temp.mx('leads: update own/assigned (lead_a)',
      format($q$update leads set notes = 'p2' where id = %L$q$, lead_a), '1', '1', '1', deny);
    out := out || pg_temp.mx('leads: update someone else''s (lead_b)  [manager-only operation for agents]',
      format($q$update leads set notes = 'p2' where id = %L$q$, lead_b), '1', '1', deny, deny);
    out := out || pg_temp.mx('KNOWN FUNCTIONAL DEFECT (Phase 1 RLS, not a security hole): leads soft-delete by a non-admin holding leads.delete',
      format('update leads set deleted_at = now() where id = %L', lead_a), '1', '1', deny, deny, 'G');
    out := out || pg_temp.mx('leads: hard-delete (admin only)',
      format('delete from leads where id = %L', lead_a), '1', deny, deny, deny);
    out := out || pg_temp.mx('properties: insert',
      $q$insert into properties(title, property_type_code, transaction_type, city, source) values ('P2 new', 'plot', 'sale', 'P2TEST', 'other')$q$,
      '1', '1', '1', deny);
    out := out || pg_temp.mx('properties: update own (p_mine)',
      format($q$update properties set description = 'p2' where id = %L$q$, p_mine), '1', '1', '1', deny);
    out := out || pg_temp.mx('properties: update NOT theirs (p_avail)  [agent: view only]',
      format($q$update properties set description = 'p2' where id = %L$q$, p_avail), '1', '1', deny, deny);
    out := out || pg_temp.mx('KNOWN FUNCTIONAL DEFECT (Phase 1 RLS, not a security hole): properties soft-delete by a non-admin holding properties.delete',
      format('update properties set deleted_at = now() where id = %L', p_mine), '1', '1', deny, deny, 'G');
    out := out || pg_temp.mx('properties: hard-delete (admin only; p_sold)',
      format('delete from properties where id = %L', p_sold), '1', deny, deny, deny);
    out := out || pg_temp.mx('owner terms: update on a property that is not theirs',
      format('update property_owner_terms set min_price = 1 where property_id = %L', p_avail), '1', '1', deny, deny);
    out := out || pg_temp.mx('owner terms: update on own property',
      format('update property_owner_terms set min_price = 1 where property_id = %L', p_mine), '1', '1', '1', deny);
    out := out || pg_temp.mx('deals: insert (deals.write)',
      format('insert into deals(buyer_id, seller_id, property_id) values (%L, %L, %L)', buyer1, seller1, p_sold),
      '1', '1', deny, deny);
    out := out || pg_temp.mx('deals: update (deals.write)',
      format($q$update deals set notes = 'p2' where id = %L$q$, deal1), '1', '1', deny, deny);
    out := out || pg_temp.mx('payments: insert (finance.write)',
      format($q$insert into payments(deal_id, purpose, amount) values (%L, 'token', 1)$q$, deal1), '1', '1', deny, deny);
    out := out || pg_temp.mx('commissions: insert (finance.write)',
      format($q$insert into commissions(deal_id, party, expected_amount) values (%L, 'buyer', 1)$q$, deal2), '1', '1', deny, deny);
    out := out || pg_temp.mx('settings: insert a throwaway key (settings.manage = admin only)',
      format($q$insert into settings(key, value) values (%L, '1'::jsonb)$q$, 'zz.p2test.' || tag), '1', deny, deny, deny);
    out := out || pg_temp.mx('import batches: insert (imports.write)',
      $q$insert into import_batches(entity, format, file_name, storage_path, source_name, authorization_note)
         values ('leads', 'csv', 'x.csv', 'p2test/x.csv', 'P2TEST', 'P2TEST authorization note')$q$, '1', '1', deny, deny);
    out := out || pg_temp.mx('market data: insert (market.write)',
      $q$insert into market_data(city, data_kind, source_name, collected_on, price) values ('P2TEST', 'asking_price', 'P2TEST', current_date, 1)$q$,
      '1', '1', deny, deny);
    out := out || pg_temp.mx('roles: insert a throwaway role (users.manage = admin only)',
      format($q$insert into roles(code, label) values (%L, 'x')$q$, 'zz_p2b_' || tag), '1', deny, deny, deny);
    out := out || pg_temp.mx('role_permissions: insert on the throwaway role (admin only)',
      format('insert into role_permissions(role_id, permission_id) select %s, id from permissions limit 1', role_t),
      '1', deny, deny, deny);
    out := out || pg_temp.mx('profiles: change ANOTHER user''s role (admin only; target = agent2)',
      format('update profiles set role_id = %s where id = %L', r_viewer, u_agent2),
      '1', deny, deny, deny);
    out := out || pg_temp.mx('audit_logs: UPDATE (append-only, nobody)',
      format($q$update audit_logs set action = 'update' where entity_table = 'profiles' and entity_id = %L$q$, u_agent::text),
      'ERR 42501%', 'ERR 42501%', 'ERR 42501%', 'ERR 42501%');
    out := out || pg_temp.mx('audit_logs: DELETE (append-only, nobody)',
      format($q$delete from audit_logs where entity_table = 'profiles' and entity_id = %L$q$, u_agent::text),
      'ERR 42501%', 'ERR 42501%', 'ERR 42501%', 'ERR 42501%');
    out := out || pg_temp.mx('audit_logs: INSERT a forged event (browser roles cannot)',
      $q$insert into audit_logs(action, entity_table) values ('update', 'security')$q$,
      'ERR 42501%', 'ERR 42501%', 'ERR 42501%', 'ERR 42501%');

    -- ===== 4 SELF-PROMOTION / PRIVILEGE ESCALATION ====================
    perform set_config('p2.section', '4 Self-promotion and escalation attempts (real authenticated sessions)', true);
    select string_agg(p.id::text || '=' || coalesce(r.code, '-') || ':' || p.is_active::text || ':' || (p.deleted_at is not null)::text,
                      ',' order by p.id)
      into state_before
      from profiles p left join roles r on r.id = p.role_id
     where p.id in (u_admin, u_mgr, u_agent, u_agent2, u_viewer, u_plain, u_inact, u_del);

    for a in select * from (values ('plain', u_plain), ('viewer', u_viewer), ('agent', u_agent), ('manager', u_mgr)) v(nm, uid) loop
      out := out || pg_temp.chk('set OWN role to admin', a.nm, 'authenticated', a.uid,
        format('update profiles set role_id = %s where id = %L', r_admin, a.uid), deny);
      out := out || pg_temp.chk('set OWN role to admin AND activate', a.nm, 'authenticated', a.uid,
        format('update profiles set role_id = %s, is_active = true where id = %L', r_admin, a.uid), deny);
      out := out || pg_temp.chk('flip OWN is_active', a.nm, 'authenticated', a.uid,
        format('update profiles set is_active = not is_active where id = %L', a.uid), deny);
      out := out || pg_temp.chk('move OWN role sideways/up (to manager, or viewer for managers)', a.nm, 'authenticated', a.uid,
        format('update profiles set role_id = %s where id = %L', case when a.nm = 'manager' then r_viewer else r_mgr end, a.uid), deny);
      out := out || pg_temp.chk('promote ANOTHER user (agent2) to admin', a.nm, 'authenticated', a.uid,
        format('update profiles set role_id = %s, is_active = true where id = %L', r_admin, u_agent2), deny);
      out := out || pg_temp.chk('grant users.manage to own role via role_permissions', a.nm, 'authenticated', a.uid,
        format('insert into role_permissions(role_id, permission_id) values (%s, %s)', r_viewer, perm_um), deny);
      out := out || pg_temp.chk('rename the admin role', a.nm, 'authenticated', a.uid,
        format($q$update roles set label = 'hacked' where id = %s$q$, r_admin), deny);
      out := out || pg_temp.chk('edit the permissions catalogue', a.nm, 'authenticated', a.uid,
        format($q$update permissions set description = 'hacked' where id = %s$q$, perm_um), deny);
      out := out || pg_temp.chk('create a profile row directly', a.nm, 'authenticated', a.uid,
        $q$insert into profiles(id) values (gen_random_uuid())$q$, deny);
      out := out || pg_temp.chk('delete OWN profile row', a.nm, 'authenticated', a.uid,
        format('delete from profiles where id = %L', a.uid), deny);
      out := out || pg_temp.chk('call arm_bootstrap', a.nm, 'authenticated', a.uid,
        format($q$select app.arm_bootstrap(%L, 'x@example.invalid', 30)::text$q$, sec_ok), 'ERR 42501%');
      out := out || pg_temp.chk('call two-argument bootstrap_first_admin', a.nm, 'authenticated', a.uid,
        format($q$select app.bootstrap_first_admin(%L::uuid, %L)::text$q$, a.uid, sec_ok), 'ERR 42501%');
      out := out || pg_temp.chk('call the OLD one-argument bootstrap_first_admin', a.nm, 'authenticated', a.uid,
        format('select app.bootstrap_first_admin(%L::uuid)::text', a.uid), 'ERR 42501%');
      out := out || pg_temp.chk('harmless self-edit still works (full_name)  [control]', a.nm, 'authenticated', a.uid,
        format($q$update profiles set full_name = 'P2TEST renamed' where id = %L$q$, a.uid), '1', 'T', true);
    end loop;
    out := out || pg_temp.chk('deactivated user cannot re-activate themselves', 'inactive', 'authenticated', u_inact,
      format('update profiles set is_active = true where id = %L', u_inact), deny);

    select string_agg(p.id::text || '=' || coalesce(r.code, '-') || ':' || p.is_active::text || ':' || (p.deleted_at is not null)::text,
                      ',' order by p.id)
      into state_after
      from profiles p left join roles r on r.id = p.role_id
     where p.id in (u_admin, u_mgr, u_agent, u_agent2, u_viewer, u_plain, u_inact, u_del);
    out := out || pg_temp.pk(state_before = state_after, 'T', 'after all attempts every user''s role / active / deleted state is UNCHANGED',
                             'state', case when state_before = state_after then 'unchanged' else 'CHANGED' end, 'unchanged');
    out := out || pg_temp.chk('real admin/manager/agent/viewer roles intact (role of each test user)', 'state', 'postgres', null,
      format($q$select string_agg(r.code, ',' order by r.code) from profiles p join roles r on r.id = p.role_id
                 where p.id in (%L,%L,%L,%L)$q$, u_admin, u_mgr, u_agent, u_viewer), 'admin,agent,manager,viewer');

    -- ===== 5 UNUSUAL CALLERS + my_access + security_log_event =========
    perform set_config('p2.section', '5a Deactivated / soft-deleted / profile-less / anonymous callers', true);
    out := out || pg_temp.chk('deactivated agent sees leads', 'inactive', 'authenticated', u_inact,
      format('select count(*)::text from leads where id in (%L,%L)', lead_a, lead_b), '0');
    out := out || pg_temp.chk('deactivated agent reads settings', 'inactive', 'authenticated', u_inact,
      $q$select count(*)::text from settings where key = 'company.name'$q$, '0');
    out := out || pg_temp.chk('deactivated agent inserts a lead', 'inactive', 'authenticated', u_inact,
      format($q$insert into leads(contact_id, lead_type, source_code, status_code) values (%L, 'buy', 'website', 'new')$q$, c_a), deny);
    out := out || pg_temp.chk('deactivated agent: my_access shows 0 permissions', 'inactive', 'authenticated', u_inact,
      $q$select jsonb_array_length(public.my_access()->'permissions')::text$q$, '0');
    out := out || pg_temp.chk('soft-deleted agent sees leads', 'deleted', 'authenticated', u_del,
      format('select count(*)::text from leads where id in (%L,%L)', lead_a, lead_b), '0');
    out := out || pg_temp.chk('soft-deleted agent: my_access returns nothing', 'deleted', 'authenticated', u_del,
      $q$select coalesce(public.my_access()::text, '(none)')$q$, '(none)');
    out := out || pg_temp.chk('valid JWT but NO profile row: sees leads', 'ghost', 'authenticated', u_ghost,
      format('select count(*)::text from leads where id in (%L,%L)', lead_a, lead_b), '0');
    out := out || pg_temp.chk('valid JWT but NO profile row: my_access', 'ghost', 'authenticated', u_ghost,
      $q$select coalesce(public.my_access()::text, '(none)')$q$, '(none)');
    out := out || pg_temp.chk('role-less sign-up (plain) sees leads', 'plain', 'authenticated', u_plain,
      format('select count(*)::text from leads where id in (%L,%L)', lead_a, lead_b), '0');
    out := out || pg_temp.chk('anon reads leads', 'anon', 'anon', null, 'select count(*)::text from leads', 'ERR 42501%');
    out := out || pg_temp.chk('anon reads profiles', 'anon', 'anon', null, 'select count(*)::text from profiles', 'ERR 42501%');
    out := out || pg_temp.chk('anon reads audit_logs', 'anon', 'anon', null, 'select count(*)::text from audit_logs', 'ERR 42501%');
    out := out || pg_temp.chk('anon reads settings', 'anon', 'anon', null, 'select count(*)::text from settings', 'ERR 42501%');
    out := out || pg_temp.chk('anon calls my_access', 'anon', 'anon', null, 'select public.my_access()::text', 'ERR 42501%');
    out := out || pg_temp.chk('anon calls find_contact_matches', 'anon', 'anon', null,
      $q$select count(*)::text from public.find_contact_matches('9999999999', null, null)$q$, 'ERR 42501%');
    out := out || pg_temp.chk('anon calls security_log_event', 'anon', 'anon', null,
      $q$select public.security_log_event('logout', null)::text$q$, 'ERR 42501%');
    out := out || pg_temp.chk('STEP 3: soft-deleted user cannot restore their OWN profile', 'deleted', 'authenticated', u_del,
      format('update profiles set deleted_at = null where id = %L', u_del), deny, k7, true);

    perform set_config('p2.section', '5b my_access(): own data only, no RLS bypass, no parameters', true);
    out := out || pg_temp.chk('my_access takes no parameters and is SECURITY INVOKER', 'def', 'postgres', null,
      $q$select (pronargs = 0 and not prosecdef)::text from pg_proc where oid = 'public.my_access()'::regprocedure$q$, 'true');
    for a in select * from (values ('admin', u_admin), ('manager', u_mgr), ('agent', u_agent), ('viewer', u_viewer)) v(nm, uid) loop
      out := out || pg_temp.chk('returns the CALLER''s own user_id (even for admin)', a.nm, 'authenticated', a.uid,
        $q$select ((public.my_access()->>'user_id') = auth.uid()::text)::text$q$, 'true');
    end loop;
    out := out || pg_temp.chk('viewer permission list has NO finance.read_all / deals.read_all / deals.write', 'viewer', 'authenticated', u_viewer,
      $q$select (not (public.my_access()->'permissions' ? 'finance.read_all')
             and not (public.my_access()->'permissions' ? 'deals.read_all')
             and not (public.my_access()->'permissions' ? 'deals.write'))::text$q$, 'true');
    out := out || pg_temp.chk('agent has properties.read_active but NOT properties.write_all / users.manage', 'agent', 'authenticated', u_agent,
      $q$select ((public.my_access()->'permissions' ? 'properties.read_active')
             and not (public.my_access()->'permissions' ? 'properties.write_all')
             and not (public.my_access()->'permissions' ? 'users.manage'))::text$q$, 'true');
    out := out || pg_temp.chk('manager has finance.read_all but NOT users.manage / settings.manage / audit.read', 'manager', 'authenticated', u_mgr,
      $q$select ((public.my_access()->'permissions' ? 'finance.read_all')
             and not (public.my_access()->'permissions' ? 'users.manage')
             and not (public.my_access()->'permissions' ? 'settings.manage')
             and not (public.my_access()->'permissions' ? 'audit.read'))::text$q$, 'true');
    out := out || pg_temp.chk('admin has users.manage and audit.read', 'admin', 'authenticated', u_admin,
      $q$select ((public.my_access()->'permissions' ? 'users.manage') and (public.my_access()->'permissions' ? 'audit.read'))::text$q$, 'true');

    perform set_config('p2.section', '5c security_log_event(): server-only, validated', true);
    out := out || pg_temp.chk('authenticated user (admin!) cannot call it', 'admin', 'authenticated', u_admin,
      format($q$select public.security_log_event('logout', %L::uuid)::text$q$, u_admin), 'ERR 42501%');
    out := out || pg_temp.chk('service_role: valid logout for an active actor', 'svc', 'service_role', null,
      format($q$select 'OK' from (select public.security_log_event('logout', %L::uuid, '{"ip":"203.0.113.9"}'::jsonb)) s$q$, u_agent), 'OK');
    out := out || pg_temp.chk('...and exactly one audit row was written for that actor', 'state', 'postgres', null,
      format($q$select count(*)::text from audit_logs where action = 'logout' and entity_table = 'security' and actor_id = %L$q$, u_agent), '1');
    out := out || pg_temp.chk('service_role: valid login (recent sign-in recorded)', 'svc', 'service_role', null,
      format($q$select 'OK' from (select public.security_log_event('login', %L::uuid)) s$q$, u_agent), 'OK');
    out := out || pg_temp.chk('service_role: login for a role-less INACTIVE user', 'svc', 'service_role', null,
      format($q$select public.security_log_event('login', %L::uuid)::text$q$, u_plain), 'ERR 22023%');
    out := out || pg_temp.chk('service_role: login for a user with no recent sign-in is refused', 'svc', 'service_role', null,
      format($q$select public.security_log_event('login', %L::uuid)::text$q$, u_ghost), 'ERR 22023%');
    out := out || pg_temp.chk('service_role: login_failed with an actor is refused', 'svc', 'service_role', null,
      format($q$select public.security_log_event('login_failed', %L::uuid)::text$q$, u_agent), 'ERR 22023%');
    out := out || pg_temp.chk('service_role: login_failed without actor is accepted', 'svc', 'service_role', null,
      $q$select 'OK' from (select public.security_log_event('login_failed', null, '{"email":"nobody@example.invalid"}'::jsonb)) s$q$, 'OK');
    out := out || pg_temp.chk('service_role: forged event type bootstrap_admin', 'svc', 'service_role', null,
      format($q$select public.security_log_event('bootstrap_admin', %L::uuid)::text$q$, u_agent), 'ERR 22023%');
    out := out || pg_temp.chk('service_role: unsupported detail key', 'svc', 'service_role', null,
      format($q$select public.security_log_event('logout', %L::uuid, '{"role":"admin"}'::jsonb)::text$q$, u_agent), 'ERR 22023%');
    out := out || pg_temp.chk('service_role: non-admin cannot be recorded as inviter', 'svc', 'service_role', null,
      format($q$select public.security_log_event('invite', %L::uuid)::text$q$, u_agent), 'ERR 22023%');
    out := out || pg_temp.chk('service_role: admin may be recorded as inviter', 'svc', 'service_role', null,
      format($q$select 'OK' from (select public.security_log_event('invite', %L::uuid)) s$q$, u_admin), 'OK');

    -- ===== 7 STEP 3 PROTECTIONS ==========================================
    -- Before Step 3 is installed these lines show as GAP; once installed they are hard PASS/FAIL.
    perform set_config('p2.section', '7 Step 3: soft-delete guard, system roles, admin permissions, last-admin protection', true);
    out := out || pg_temp.pk(step3, 'T', 'Step 3 triggers installed (protect_last_admin / protect_system_roles / protect_admin_permissions)',
                             'state', step3::text, 'true');

    -- soft-delete guard on profiles
    out := out || pg_temp.chk('plain agent cannot soft-delete their OWN profile', 'agent', 'authenticated', u_agent,
      format('update profiles set deleted_at = now() where id = %L', u_agent), deny, k7, true);
    out := out || pg_temp.chk('manager (no users.manage) cannot soft-delete another user', 'mgr', 'authenticated', u_mgr,
      format('update profiles set deleted_at = now() where id = %L', u_agent2), deny, k7, true);
    out := out || pg_temp.chk('admin (users.manage) can still soft-delete a non-admin user  [control]', 'adm', 'authenticated', u_admin,
      format('update profiles set deleted_at = now() where id = %L', u_agent2), '1', 'T', true);
    out := out || pg_temp.chk('admin can still restore a soft-deleted user  [control]', 'adm', 'authenticated', u_admin,
      format('update profiles set deleted_at = null where id = %L', u_del), '1', 'T', true);

    -- system roles are immutable (denial tests on real role rows, each rolled back)
    out := out || pg_temp.chk('system role cannot be DELETED (viewer)', 'owner', 'postgres', null,
      format('delete from roles where id = %s', r_viewer), 'ERR 55000%', k7, true);
    out := out || pg_temp.chk('system role code cannot be CHANGED (viewer)', 'owner', 'postgres', null,
      format($q$update roles set code = 'zz_renamed' where id = %s$q$, r_viewer), 'ERR 55000%', k7, true);
    out := out || pg_temp.chk('admin role cannot be un-flagged as system', 'adm', 'authenticated', u_admin,
      format('update roles set is_system = false where id = %s', r_admin), 'ERR 55000%', k7, true);
    out := out || pg_temp.chk('non-system (throwaway) role can still be edited  [control]', 'adm', 'authenticated', u_admin,
      format($q$update roles set label = 'p2 edited' where id = %s$q$, role_t), '1', 'T', true);
    out := out || pg_temp.chk('non-system (throwaway) role can still be deleted  [control]', 'adm', 'authenticated', u_admin,
      format('delete from roles where id = %s', role_t), '1', 'T', true);

    -- admin role permissions are immutable
    out := out || pg_temp.chk('admin cannot REMOVE users.manage from the admin role', 'adm', 'authenticated', u_admin,
      format('delete from role_permissions where role_id = %s and permission_id = %s', r_admin, perm_um), 'ERR 55000%', k7, true);
    out := out || pg_temp.chk('owner cannot REMOVE users.manage from the admin role', 'owner', 'postgres', null,
      format('delete from role_permissions where role_id = %s and permission_id = %s', r_admin, perm_um), 'ERR 55000%', k7, true);
    out := out || pg_temp.chk('admin cannot REASSIGN an admin permission to another permission', 'adm', 'authenticated', u_admin,
      format($q$update role_permissions set permission_id = (select id from permissions where code = 'leads.read')
                where role_id = %s and permission_id = %s$q$, r_admin, perm_um), 'ERR 55000%', k7, true);
    out := out || pg_temp.chk('permissions of a NON-admin role can still be removed by an admin  [control, throwaway role]', 'adm', 'authenticated', u_admin,
      format($q$with i as (insert into role_permissions(role_id, permission_id) values (%s, %s) returning 1) select count(*)::text from i$q$, role_t, perm_um),
      '1', 'T', true);

    -- last-admin protection (needs a state with exactly one active admin => only when no real admin exists)
    if do_boot then
      out := out || pg_temp.chk('two admins exist: demoting one is allowed  [control]', 'owner', 'postgres', null,
        format('update profiles set role_id = %s where id = %L', r_viewer, u_admin), '1', 'T', false);
      out := out || pg_temp.chk('exactly one active admin now (the bootstrap candidate)', 'state', 'postgres', null,
        format($q$select count(*)::text from profiles p join roles r on r.id = p.role_id
                   where r.code = 'admin' and p.is_active and p.deleted_at is null and p.id in (%L,%L)$q$, u_boot, u_admin), '1');
      out := out || pg_temp.chk('last admin: cannot be DEMOTED (owner session)', 'owner', 'postgres', null,
        format('update profiles set role_id = %s where id = %L', r_viewer, u_boot), 'ERR 55000%', k7, true);
      out := out || pg_temp.chk('last admin: cannot be DEACTIVATED', 'owner', 'postgres', null,
        format('update profiles set is_active = false where id = %L', u_boot), 'ERR 55000%', k7, true);
      out := out || pg_temp.chk('last admin: cannot be SOFT-DELETED', 'owner', 'postgres', null,
        format('update profiles set deleted_at = now() where id = %L', u_boot), 'ERR 55000%', k7, true);
      out := out || pg_temp.chk('last admin: profile row cannot be DELETED', 'owner', 'postgres', null,
        format('delete from profiles where id = %L', u_boot), 'ERR 55000%', k7, true);
      out := out || pg_temp.chk('last admin: auth user cannot be DELETED (cascade is blocked)', 'owner', 'postgres', null,
        format('delete from auth.users where id = %L', u_boot), 'ERR 55000%', k7, true);
      out := out || pg_temp.chk('last admin cannot demote THEMSELVES through a real admin session', 'last-admin', 'authenticated', u_boot,
        format('update profiles set role_id = %s where id = %L', r_viewer, u_boot), 'ERR 55000%', k7, true);
      out := out || pg_temp.chk('last admin can still edit harmless fields  [control]', 'last-admin', 'authenticated', u_boot,
        format($q$update profiles set full_name = 'P2TEST admin' where id = %L$q$, u_boot), '1', 'T', true);
      out := out || pg_temp.chk('re-promote the second admin, then demoting the first is allowed again  [control]', 'owner', 'postgres', null,
        format($q$update profiles set role_id = %s where id = %L$q$, r_admin, u_admin), '1', 'T', false);
      out := out || pg_temp.chk('...demote the bootstrap admin while u_admin remains', 'owner', 'postgres', null,
        format('update profiles set role_id = %s where id = %L', r_viewer, u_boot), '1', 'T', true);
    else
      out := out || pg_temp.pk(false, 'S', 'last-admin refusal tests SKIPPED (a real admin exists; the sole-admin case cannot be built without touching it)',
                               'state', 'admin=' || admin_before::text || ' armed=' || armed_before::text, '-');
    end if;

    -- always abort: this is what rolls everything back
    raise exception 'P2 rollback sentinel' using errcode = 'P2RBK';
  exception
    when sqlstate 'P2RBK' then null;
    when others then fatal := sqlstate || ' ' || sqlerrm;
  end;

  -- ---------------------------------------------------------------
  -- After the rollback: restore sequences, verify state, build report
  -- ---------------------------------------------------------------
  perform pg_temp.p2_restore_seqs(seq0);
  snap1 := pg_temp.p2_snapshot();
  seq1  := pg_temp.p2_seqs();
  seq_ok := (seq0 = seq1);
  select string_agg(coalesce(x.key, y.key), ', ' order by coalesce(x.key, y.key)) into diff_tables
    from jsonb_each_text(snap0) x full join jsonb_each_text(snap1) y on x.key = y.key
   where x.value is distinct from y.value;

  select count(*) filter (where split_part(x, sep, 1) = 'P'), count(*) filter (where split_part(x, sep, 1) = 'F'),
         count(*) filter (where split_part(x, sep, 1) = 'G'), count(*) filter (where split_part(x, sep, 1) = 'S')
    into n_p, n_f, n_g, n_s from unnest(out) x;

  for rec in
    select s.section, s.label, min(s.ord) o,
           string_agg(s.who || '=' || s.got || case when s.st in ('F', 'G') then '  [want ' || s.want || ']' else '' end, '   ' order by s.ord) cells,
           bool_or(s.st = 'F') f, bool_or(s.st = 'G') g, bool_or(s.st = 'S') sk
      from (select split_part(x, sep, 1) st, split_part(x, sep, 2) section, split_part(x, sep, 3) label,
                   split_part(x, sep, 4) who, split_part(x, sep, 5) got, split_part(x, sep, 6) want, ord
              from unnest(out) with ordinality t(x, ord)) s
     group by s.section, s.label order by min(s.ord)
  loop
    if rec.section <> cur_sec then rpt := rpt || E'\n== ' || rec.section || E'\n'; cur_sec := rec.section; end if;
    rpt := rpt || case when rec.f then 'FAIL ' when rec.g then 'GAP  ' when rec.sk then 'SKIP ' else 'ok   ' end
                || rec.label || '  ->  ' || rec.cells || E'\n';
    if rec.f or rec.g or rec.sk then
      top := top || case when rec.f then 'FAIL ' when rec.g then 'GAP  ' else 'SKIP ' end || rec.label || '  ->  ' || rec.cells || E'\n';
    end if;
  end loop;

  msg := E'P2 TEST REPORT  (this error is intentional: it is what rolled everything back)\n'
      || 'RESULT: PASS ' || n_p || ' | FAIL ' || n_f || ' | GAP ' || n_g || ' (known + documented, see below) | SKIP ' || n_s || E'\n'
      || 'FATAL ERROR INSIDE TESTS: ' || coalesce(fatal, 'none') || E'\n'
      || 'STATE AFTER ROLLBACK: ' || case when diff_tables is null
             then 'IDENTICAL to pre-test snapshot (auth.users, profiles, audit_logs, every public/app table)'
             else 'DIFFERENCES in: ' || diff_tables end || E'\n'
      || 'SEQUENCES: ' || case when seq_ok then 'restored to pre-test values' else 'NOT identical (see docs/PHASE2_TESTING.md)' end || E'\n\n'
      || case when top = '' then 'No FAIL / GAP / SKIP lines.' else E'--- needs attention ---\n' || top end
      || E'\n--- details ---' || rpt;
  raise exception '%', msg using errcode = 'P0001';
end
$p2$;
