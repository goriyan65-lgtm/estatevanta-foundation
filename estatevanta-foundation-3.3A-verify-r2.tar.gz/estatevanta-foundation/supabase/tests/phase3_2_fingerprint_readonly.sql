-- READ-ONLY structural + state fingerprint for the Phase 3.2 gate. Pure SELECT; changes nothing.
-- Run BEFORE and AFTER anything (migration, test run, rollback). Identical output = identical database.
-- Works on the live project and on the local replica. table_grants differs between Postgres majors only by the
-- MAINTAIN privilege that PG17 (live) adds and PG16 (local) lacks: compare like with like.
select 'policies' k, count(*)::text n, md5(coalesce(string_agg(schemaname||'.'||tablename||'|'||policyname||'|'||cmd||'|'||permissive||'|'||roles::text||'|'||coalesce(qual,'')||'|'||coalesce(with_check,''), E'\n' order by schemaname, tablename, policyname),'')) h from pg_policies where schemaname in ('public','app')
union all
select 'triggers', count(*)::text, md5(coalesce(string_agg(tgrelid::regclass::text||'|'||tgname||'|'||pg_get_triggerdef(t.oid), E'\n' order by tgrelid::regclass::text, tgname),'')) from pg_trigger t join pg_class c on c.oid=t.tgrelid join pg_namespace n on n.oid=c.relnamespace where not tgisinternal and n.nspname in ('public','app')
union all
select 'table_grants', count(*)::text, md5(coalesce(string_agg(n.nspname||'.'||c.relname||'|'||coalesce(g.rolname,'PUBLIC')||'|'||a.privilege_type, E'\n' order by n.nspname, c.relname, coalesce(g.rolname,'PUBLIC') collate "C", a.privilege_type collate "C"),'')) from pg_class c join pg_namespace n on n.oid=c.relnamespace, lateral aclexplode(c.relacl) a left join pg_roles g on g.oid=a.grantee where n.nspname in ('public','app') and c.relkind in ('r','v','p','S')
union all
select 'functions', count(*)::text, md5(coalesce(string_agg(n.nspname||'.'||p.proname||'('||pg_get_function_identity_arguments(p.oid)||')|'||p.prosecdef::text||'|'||p.provolatile::text||'|'||coalesce(p.proconfig::text,'-')||'|'||md5(p.prosrc)||'|'||coalesce((select string_agg(coalesce(g.rolname,'PUBLIC')||':'||a.privilege_type, ',' order by coalesce(g.rolname,'PUBLIC') collate "C", a.privilege_type collate "C") from aclexplode(p.proacl) a left join pg_roles g on g.oid=a.grantee),'<null>'), E'\n' order by n.nspname, p.proname, pg_get_function_identity_arguments(p.oid)),'')) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname in ('public','app') and not exists (select 1 from pg_depend d where d.objid=p.oid and d.deptype='e')
union all
select 'rls_flags', count(*)::text, md5(string_agg(c.relname||c.relrowsecurity::text||c.relforcerowsecurity::text, ',' order by c.relname)) from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relkind='r'
union all
select 'role_permissions', count(*)::text, md5(string_agg(r.code||'|'||pm.code, ',' order by r.code, pm.code)) from role_permissions rp join roles r on r.id=rp.role_id join permissions pm on pm.id=rp.permission_id
union all
select 'settings', count(*)::text, md5(string_agg(key||'='||value::text, ',' order by key)) from settings
union all
select 'lead_statuses', count(*)::text, md5(string_agg(code||is_terminal::text, ',' order by code)) from lead_statuses
union all
select 'row_counts', count(*)::text, md5(string_agg(n.nspname||'.'||c.relname||'='||(xpath('/row/c/text()', query_to_xml(format('select count(*) as c from %I.%I', n.nspname, c.relname), false, true, '')))[1]::text, ',' order by n.nspname, c.relname)) from pg_class c join pg_namespace n on n.oid=c.relnamespace where c.relkind='r' and (n.nspname in ('public','app') or (n.nspname='auth' and c.relname='users'))
union all
select 'sequences', count(*)::text, md5(string_agg(schemaname||'.'||sequencename||'='||coalesce(last_value::text,'null'), ',' order by schemaname, sequencename)) from pg_sequences where schemaname in ('public','app')
order by 1;
