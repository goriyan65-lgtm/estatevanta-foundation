#!/usr/bin/env bash
# Phase 3.2 LOCAL gate. Runs ONLY against a throwaway local Postgres replica — never against Supabase.
# Usage: PSQL="psql -h <sock> -p <port> -U postgres -d ev -X" bash phase3_2_local_run.sh
# Lifecycle: baseline fingerprint -> apply 0012a -> fingerprint (only functions may change) -> run tests ->
#            fingerprint (must equal previous) -> rollback -> fingerprint (must equal baseline).
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"; MIG="$HERE/../migrations"
: "${PSQL:?set PSQL}"
fp() { $PSQL -AtF' | ' -f "$HERE/phase3_2_fingerprint_readonly.sql"; }
ok=1; chk() { if [ "$2" = "$3" ]; then echo "PASS $1"; else echo "FAIL $1"; ok=0; fi; }

$PSQL -q -c "drop function if exists public.dashboard_summary()" >/dev/null 2>&1
F0="$(fp)"
$PSQL -q -v ON_ERROR_STOP=1 -1 -f "$MIG/0012a_phase3_step2_dashboard_summary.sql" >/dev/null 2>&1 && echo "PASS migration applied" || { echo "FAIL migration apply"; ok=0; }
F1="$(fp)"
echo "--- fingerprint rows that changed after migration (expect ONLY 'functions'):"
diff <(echo "$F0") <(echo "$F1") | grep '^[<>]' | cut -c1-60
RES="$($PSQL -f "$HERE/phase3_2_dashboard_tests.sql" 2>&1 | grep -E 'TEST REPORT|^FAIL')"
echo "$RES"
echo "$RES" | grep -q 'TEST REPORT: [0-9]* PASS, 0 FAIL' && echo "PASS test suite: 0 FAIL" || { echo "FAIL test suite"; ok=0; }
F2="$(fp)"; chk "state identical after tests (rollback + sequences restored)" "$F1" "$F2"
$PSQL -q -v ON_ERROR_STOP=1 -1 -f "$MIG/rollback/0012a_rollback.sql" >/dev/null 2>&1 && echo "PASS rollback ran" || { echo "FAIL rollback"; ok=0; }
F3="$(fp)"; chk "rollback restores baseline fingerprint exactly" "$F0" "$F3"
# leave the replica in the post-migration state for further manual checks
$PSQL -q -v ON_ERROR_STOP=1 -1 -f "$MIG/0012a_phase3_step2_dashboard_summary.sql" >/dev/null 2>&1
[ $ok = 1 ] && echo "LOCAL GATE: ALL PASS" || echo "LOCAL GATE: FAILURES"
