-- =====================================================================
-- EstateVanta CRM — 0010_phase2_auth_security.sql
-- Phase 2: authentication hardening, bootstrap, security audit trail.
-- Additive on top of 0001–0009. NO business data inserted.
-- =====================================================================

-- 1. Audit vocabulary for security events -------------------------------
alter table audit_logs drop constraint audit_logs_action_check;
alter table audit_logs add constraint audit_logs_action_check check (action in (
  'insert','update','delete','soft_delete','restore',
  'login','logout','login_failed','access_denied','invite','bootstrap_admin'));

-- Server-only logger. Exposed via the API schema (public) but executable by
-- service_role ONLY, so browsers/anon/authenticated users cannot forge events.
create or replace function public.security_log_event(
  p_action text, p_actor uuid default null, p_detail jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if p_action not in ('login','logout','login_failed','access_denied','invite') then
    raise exception 'unsupported security event %', p_action using errcode = '22023';
  end if;
  if length(p_detail::text) > 2000 then
    raise exception 'event detail too large' using errcode = '22023';
  end if;
  insert into audit_logs(actor_id, actor_context, action, entity_table, entity_id, new_values)
  values (p_actor, 'api', p_action, 'security', p_actor::text, p_detail);
end $$;
revoke all on function public.security_log_event(text, uuid, jsonb) from public, anon, authenticated;
grant execute on function public.security_log_event(text, uuid, jsonb) to service_role;

-- 2. Current user's role + permissions (for UI gating only; RLS enforces) --
create or replace function public.my_access() returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'user_id', p.id, 'full_name', p.full_name, 'role', r.code, 'is_active', p.is_active,
    'permissions', coalesce((select jsonb_agg(pm.code order by pm.code)
                             from role_permissions rp join permissions pm on pm.id = rp.permission_id
                             where rp.role_id = p.role_id and p.is_active), '[]'::jsonb))
  from profiles p left join roles r on r.id = p.role_id
  where p.id = auth.uid() and p.deleted_at is null
$$;
revoke all on function public.my_access() from public, anon;
grant execute on function public.my_access() to authenticated, service_role;

-- 3. Hardening of a Phase 1 function exposed in the API schema ------------
revoke all on function public.find_contact_matches(text, text, text) from public, anon;
grant execute on function public.find_contact_matches(text, text, text) to authenticated, service_role;

-- 4. Secure first-admin bootstrap (SQL editor only; no HTTP path) ---------
create or replace function app.bootstrap_first_admin(target_user uuid) returns void
language plpgsql security definer set search_path = public as $$
declare v_email text; v_confirmed timestamptz;
begin
  if exists (select 1 from profiles p join roles r on r.id = p.role_id
             where r.code = 'admin' and p.is_active and p.deleted_at is null) then
    raise exception 'An active admin already exists';
  end if;
  select email, email_confirmed_at into v_email, v_confirmed from auth.users where id = target_user;
  if not found then raise exception 'No auth user %', target_user; end if;
  if v_confirmed is null then raise exception 'The user''s email must be confirmed before bootstrap'; end if;
  update profiles
     set role_id = (select id from roles where code = 'admin'), is_active = true, deleted_at = null
   where id = target_user;
  if not found then raise exception 'No profile for user %', target_user; end if;
  insert into audit_logs(actor_id, actor_context, action, entity_table, entity_id, new_values)
  values (null, 'bootstrap', 'bootstrap_admin', 'security', target_user::text,
          jsonb_build_object('email', v_email));
end $$;

-- 5. Profile privilege guard now also covers soft-delete ------------------
create or replace function app.guard_profile_privileges() returns trigger
language plpgsql as $$
begin
  if auth.uid() is null then return new; end if;            -- server / SQL-editor context
  if (new.role_id is distinct from old.role_id
      or new.is_active is distinct from old.is_active
      or new.deleted_at is distinct from old.deleted_at)
     and not app.can('users.manage') then
    raise exception 'permission denied: users.manage required to change role, activation or deletion'
      using errcode = '42501';
  end if;
  return new;
end $$;

-- 6. The last active admin can never be removed ----------------------------
create or replace function app.protect_last_admin() returns trigger
language plpgsql security definer set search_path = public as $$
declare was_admin boolean; still_admin boolean; others int;
begin
  select (exists (select 1 from roles r where r.id = old.role_id and r.code = 'admin')
          and old.is_active and old.deleted_at is null) into was_admin;
  if tg_op = 'DELETE' then
    still_admin := false;
  else
    select (exists (select 1 from roles r where r.id = new.role_id and r.code = 'admin')
            and new.is_active and new.deleted_at is null) into still_admin;
  end if;
  if was_admin and not still_admin then
    select count(*) into others from profiles p join roles r on r.id = p.role_id
     where r.code = 'admin' and p.is_active and p.deleted_at is null and p.id <> old.id;
    if others = 0 then
      raise exception 'Cannot remove, demote or deactivate the last active admin' using errcode = '55000';
    end if;
  end if;
  if tg_op = 'DELETE' then return old; end if;
  return new;
end $$;
create trigger protect_last_admin before update or delete on profiles
  for each row execute function app.protect_last_admin();

-- 7. System roles and the admin's permissions cannot be deleted -----------
create or replace function app.protect_system_roles() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if old.is_system then
    raise exception 'System roles cannot be deleted' using errcode = '55000';
  end if;
  return old;
end $$;
create trigger protect_system_roles before delete on roles
  for each row execute function app.protect_system_roles();

create or replace function app.protect_admin_permissions() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if exists (select 1 from roles r where r.id = old.role_id and r.code = 'admin') then
    raise exception 'Admin permissions cannot be removed' using errcode = '55000';
  end if;
  return old;
end $$;
create trigger protect_admin_permissions before delete on role_permissions
  for each row execute function app.protect_admin_permissions();

grant execute on all functions in schema app to authenticated, service_role;
revoke execute on function app.bootstrap_first_admin(uuid) from authenticated, service_role;
