-- =====================================================================
-- EstateVanta CRM — 0009_confirmed_decisions.sql
-- Applies the owner-confirmed Phase 1 decisions ON TOP of 0001–0008
-- (originals are left untouched) and adds the API-role grants that the
-- earlier files did not include.  NO business data is inserted.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. GRANTS
-- RLS decides row access, but logged-in users first need schema/table/
-- sequence privileges. Without USAGE on schema "app", every RLS policy
-- and every code default (LD-000001…) would fail with "permission denied".
-- anon receives nothing (it was revoked in 0007 and is not re-granted).
-- ---------------------------------------------------------------------
grant usage on schema app to authenticated, service_role;
grant execute on all functions in schema app to authenticated, service_role;
grant usage, select on all sequences in schema app to authenticated, service_role;

grant select, insert, update, delete on all tables in schema public to authenticated;
grant all on all tables in schema public to service_role;
grant usage, select on all sequences in schema public to authenticated, service_role;

-- audit_logs stays append-only for everyone except the audit trigger
revoke insert, update, delete, truncate on audit_logs from authenticated;

-- the one-time admin bootstrap is callable only from the SQL editor
revoke execute on function app.bootstrap_first_admin(uuid) from authenticated, service_role;

-- ---------------------------------------------------------------------
-- 2. DECISION: viewers must not see financial fields
--    a) viewers lose access to deal rows (final price, token, commission)
--    b) "minimum price" (negotiation floor) moves from properties into
--       property_owner_terms, whose visibility is restricted (see 4).
--       Table is empty at this point, so no data moves.
-- ---------------------------------------------------------------------
delete from role_permissions
where role_id       = (select id from roles       where code = 'viewer')
  and permission_id = (select id from permissions where code = 'deals.read_all');

alter table property_owner_terms
  add column min_price numeric(14,2) check (min_price is null or min_price >= 0);
alter table properties drop column min_price;   -- also drops its check constraints

-- ---------------------------------------------------------------------
-- 3. DECISION: agents can VIEW all active inventory; edit/delete stays
--    assignment- or permission-based.
--    properties.read_active : view available / reserved / under-negotiation
--    properties.write_all   : edit/delete any property
-- ---------------------------------------------------------------------
insert into permissions (code, description) values
  ('properties.read_active', 'View all active property inventory (available, reserved, under negotiation)'),
  ('properties.write_all',   'Edit or delete any property, not only assigned/own ones');

insert into role_permissions (role_id, permission_id)
select r.id, p.id from roles r join permissions p on p.code in ('properties.read_active','properties.write_all')
where r.code in ('admin','manager');

insert into role_permissions (role_id, permission_id)
select r.id, p.id from roles r join permissions p on p.code = 'properties.read_active'
where r.code = 'agent';

-- Can the caller edit this property?  (SECURITY DEFINER so RLS on the
-- lookup itself cannot hide the row from the check.)
create or replace function app.can_edit_property(pid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select app.can('properties.write_all')
      or ( app.can('properties.write')
           and exists (select 1 from properties p
                       where p.id = pid and p.deleted_at is null
                         and (p.assigned_to = auth.uid() or p.created_by = auth.uid())) )
$$;
grant execute on function app.can_edit_property(uuid) to authenticated, service_role;

drop policy properties_select on properties;
drop policy properties_update on properties;

create policy properties_select on properties for select to authenticated using (
  (deleted_at is null or app.is_admin()) and (
       app.can('properties.read_all')
    or (app.can('properties.read_active') and status in ('available','reserved','under_negotiation'))
    or (app.can('properties.read') and (assigned_to = auth.uid() or created_by = auth.uid())) ) );

create policy properties_update on properties for update to authenticated
  using ( app.can('properties.write_all')
          or (app.can('properties.write') and (assigned_to = auth.uid() or created_by = auth.uid())) )
  with check ( app.can('properties.write') );

-- ---------------------------------------------------------------------
-- 4. Property child tables
--    media + amenities : visible wherever the property is visible (policy from
--                        0007 unchanged); WRITES now require edit rights on the property
--    documents         : visible only to editors of the property, or holders of properties.read_all
--    owner terms       : (brokerage, minimum price, ownership-doc status) visible only to
--                        editors of the property or holders of finance.read_all
-- ---------------------------------------------------------------------
do $$
declare t text;
begin
  foreach t in array array['property_media','property_amenities','property_documents','property_owner_terms'] loop
    execute format('drop policy if exists %I on %I', t||'_insert', t);
    execute format('drop policy if exists %I on %I', t||'_update', t);
    execute format('drop policy if exists %I on %I', t||'_delete', t);
    execute format('create policy %I on %I for insert to authenticated with check (app.can_edit_property(property_id))', t||'_insert', t);
    execute format('create policy %I on %I for update to authenticated using (app.can_edit_property(property_id)) with check (app.can_edit_property(property_id))', t||'_update', t);
    execute format('create policy %I on %I for delete to authenticated using (app.can_edit_property(property_id))', t||'_delete', t);
  end loop;
end $$;

drop policy property_documents_select on property_documents;
create policy property_documents_select on property_documents for select to authenticated using (
  (app.can('properties.read_all') or app.can_edit_property(property_id))
  and exists (select 1 from properties par where par.id = property_documents.property_id) );

drop policy property_owner_terms_select on property_owner_terms;
create policy property_owner_terms_select on property_owner_terms for select to authenticated using (
  (app.can('finance.read_all') or app.can_edit_property(property_id))
  and exists (select 1 from properties par where par.id = property_owner_terms.property_id) );

-- ---------------------------------------------------------------------
-- 5. DECISION: settings and units
-- ---------------------------------------------------------------------
update settings set value = '30'::jsonb,
       description = 'Days after which an active listing needs re-verification (configurable in Settings)'
 where key = 'property.reverify_days';

update settings set description = 'Priorities counted as Hot Leads on the dashboard (configurable in Settings)'
 where key = 'leads.hot_priorities';

update area_units set sq_ft_factor = 272.25  where code = 'marla';
update area_units set sq_ft_factor = 5445    where code = 'kanal';
-- bigha intentionally left NULL: the local definition varies; set it in Settings.

-- fallback in the reminder view now matches the new default
create or replace view v_properties_due_verification with (security_invoker = true) as
select p.id, p.code, p.title, p.owner_id, p.assigned_to, p.last_verified_at
from properties p
where p.deleted_at is null
  and p.status in ('available','reserved','under_negotiation')
  and ( p.last_verified_at is null
        or p.last_verified_at < now() - make_interval(
             days => coalesce((select (value #>> '{}')::int from settings where key = 'property.reverify_days'), 30)) );
