-- =====================================================================
-- EstateVanta CRM — 0005_platform.sql
-- settings, notifications, messaging outbox, market intelligence,
-- authorized import system, saved filters.
-- =====================================================================

create table settings (
  key         text primary key,               -- namespaced: 'property.reverify_days'
  value       jsonb not null,
  description text,
  updated_by  uuid references profiles(id),
  updated_at  timestamptz not null default now()
);
create trigger settings_updated_at before update on settings
  for each row execute function app.set_updated_at();

-- Re-verification reminders driven by settings (fallback 90 days only if the
-- setting row is missing; the seeded setting is the source of truth).
create view v_properties_due_verification with (security_invoker = true) as
select p.id, p.code, p.title, p.owner_id, p.assigned_to, p.last_verified_at
from properties p
where p.deleted_at is null
  and p.status in ('available','reserved','under_negotiation')
  and ( p.last_verified_at is null
        or p.last_verified_at < now() - make_interval(
             days => coalesce((select (value #>> '{}')::int from settings where key = 'property.reverify_days'), 90)) );

-- ---------------------------------------------------------------------
-- NOTIFICATIONS (in-app) and provider-agnostic MESSAGE OUTBOX
-- The outbox is the ONLY thing WhatsApp/email/SMS adapters read from.
-- Providers are swappable; only official/authorized APIs are permitted.
-- ---------------------------------------------------------------------
create table notifications (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references profiles(id) on delete cascade,
  type         text not null,                 -- 'lead.new', 'task.overdue', 'property.reverify'...
  title        text not null,
  body         text,
  entity_table text,
  entity_id    uuid,
  read_at      timestamptz,
  created_at   timestamptz not null default now()
);
create index notifications_user_unread_idx on notifications(user_id, created_at desc) where read_at is null;

create table message_outbox (
  id                  uuid primary key default gen_random_uuid(),
  channel             message_channel not null,
  provider            text,                            -- adapter name, set by the sender worker
  to_contact_id       uuid references contacts(id),
  to_address          text not null,                   -- phone/email at send time
  template_key        text,
  payload             jsonb not null default '{}'::jsonb,
  status              message_status not null default 'queued',
  attempts            smallint not null default 0,
  last_error          text,
  provider_message_id text,
  related_lead_id     uuid references leads(id),
  related_property_id uuid references properties(id),
  related_visit_id    uuid references appointments(id),
  scheduled_for       timestamptz,
  sent_at             timestamptz,
  created_by          uuid references profiles(id),
  created_at          timestamptz not null default now()
);
create index message_outbox_queue_idx on message_outbox(status, scheduled_for) where status in ('queued','failed');
create index message_outbox_contact_idx on message_outbox(to_contact_id);

-- ---------------------------------------------------------------------
-- AUTHORIZED IMPORT SYSTEM (CSV / Excel / JSON)
-- Flow: upload → map → validate → duplicate check → confirm → import.
-- No scraper exists anywhere in this schema. Every batch must state, in
-- writing, why EstateVanta is authorized to use the data.
-- ---------------------------------------------------------------------
create table import_batches (
  id                  uuid primary key default gen_random_uuid(),
  entity              import_entity not null,
  format              import_format not null,
  file_name           text not null,
  storage_path        text not null,                   -- private bucket
  source_name         text not null,                   -- who supplied the data
  source_url          text,
  source_date         date,
  authorization_note  text not null check (length(btrim(authorization_note)) >= 10),
  status              import_status not null default 'uploaded',
  field_mapping       jsonb,
  total_rows          integer not null default 0,
  valid_rows          integer not null default 0,
  error_rows          integer not null default 0,
  duplicate_rows      integer not null default 0,
  imported_rows       integer not null default 0,
  confirmed_by        uuid references profiles(id),
  confirmed_at        timestamptz,
  created_by          uuid references profiles(id),
  created_at          timestamptz not null default now(),
  completed_at        timestamptz,
  check (status not in ('confirmed','importing','completed') or (confirmed_by is not null and confirmed_at is not null))
);
create index import_batches_status_idx on import_batches(status, created_at desc);

alter table properties
  add constraint properties_import_batch_fk foreign key (import_batch_id) references import_batches(id);
create index properties_import_batch_idx on properties(import_batch_id) where import_batch_id is not null;

create table import_rows (
  id                 uuid primary key default gen_random_uuid(),
  batch_id           uuid not null references import_batches(id) on delete cascade,
  row_number         integer not null,
  raw                jsonb not null,                   -- untouched source row
  mapped             jsonb,                            -- after field mapping
  validation_errors  jsonb not null default '[]'::jsonb,
  duplicate_of_table text,
  duplicate_of_id    uuid,
  decision           import_row_decision not null default 'pending',
  created_entity_id  uuid,                             -- set when imported
  unique (batch_id, row_number)
);
create index import_rows_batch_decision_idx on import_rows(batch_id, decision);

-- ---------------------------------------------------------------------
-- MARKET INTELLIGENCE (structure only; starts EMPTY)
-- data_kind keeps asking prices, verified transactions, estimates and
-- third-party data permanently distinguishable.
-- ---------------------------------------------------------------------
create table market_data (
  id                   uuid primary key default gen_random_uuid(),
  locality_id          uuid references localities(id),
  city                 text not null,
  property_type_code   text references property_types(code),
  transaction_type     transaction_type,
  data_kind            market_data_kind not null,
  price                numeric(14,2) check (price is null or price >= 0),
  price_per_sqft       numeric(12,2) check (price_per_sqft is null or price_per_sqft >= 0),
  price_per_gaj        numeric(12,2) check (price_per_gaj  is null or price_per_gaj  >= 0),
  inventory_count      integer check (inventory_count is null or inventory_count >= 0),
  demand               demand_indicator,
  source_name          text not null,
  source_url           text,
  collected_on         date not null,
  verification_status  verification_status not null default 'unverified',
  import_batch_id      uuid references import_batches(id),
  notes                text,
  created_by           uuid references profiles(id),
  created_at           timestamptz not null default now(),
  updated_at           timestamptz not null default now(),
  deleted_at           timestamptz,
  deleted_by           uuid references profiles(id),
  check (price is not null or price_per_sqft is not null or price_per_gaj is not null or inventory_count is not null)
);
create index market_data_lookup_idx on market_data(city, locality_id, property_type_code, collected_on desc) where deleted_at is null;
create index market_data_kind_idx   on market_data(data_kind) where deleted_at is null;
create trigger market_data_updated_at before update on market_data
  for each row execute function app.set_updated_at();

-- ---------------------------------------------------------------------
-- SAVED FILTERS (per-user or shared)
-- ---------------------------------------------------------------------
create table saved_filters (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references profiles(id) on delete cascade,
  module      text not null,                     -- 'leads' | 'properties' | ...
  name        text not null,
  filters     jsonb not null,
  is_shared   boolean not null default false,
  created_at  timestamptz not null default now(),
  unique (user_id, module, name)
);
