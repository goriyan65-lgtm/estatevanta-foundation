-- =====================================================================
-- EstateVanta CRM — 0002_crm_core.sql
-- contacts (person master) → buyers / sellers / leads
-- Person details (name/phone/WhatsApp/email) live ONCE in contacts.
-- =====================================================================

-- ---------------------------------------------------------------------
-- CONTACTS: one row per real person. Buyer/Seller/Lead point here, so no
-- duplicate data entry and duplicate detection has one place to look.
-- phone_key = last 10 digits (ASSUMES Indian numbers; adjust if
-- international numbers become common). Deliberately NOT unique: the
-- spec requires the agent to decide on possible duplicates.
-- ---------------------------------------------------------------------
create table contacts (
  id               uuid primary key default gen_random_uuid(),
  full_name        text not null check (length(btrim(full_name)) > 0),
  phone            text,
  phone_key        text generated always as (
                     nullif(right(regexp_replace(coalesce(phone,''), '\D', '', 'g'), 10), '')
                   ) stored,
  whatsapp         text,
  whatsapp_key     text generated always as (
                     nullif(right(regexp_replace(coalesce(whatsapp,''), '\D', '', 'g'), 10), '')
                   ) stored,
  email            citext check (email is null or email::text ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  address          text,
  notes            text,
  merged_into_id   uuid references contacts(id),       -- set when two records are confirmed same person
  created_by       uuid references profiles(id),
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  deleted_at       timestamptz,
  deleted_by       uuid references profiles(id),
  check (phone is not null or whatsapp is not null or email is not null),
  check (merged_into_id is null or merged_into_id <> id)
);
create index contacts_phone_key_idx    on contacts(phone_key)    where phone_key is not null and deleted_at is null;
create index contacts_whatsapp_key_idx on contacts(whatsapp_key) where whatsapp_key is not null and deleted_at is null;
create index contacts_email_idx        on contacts(email)        where email is not null and deleted_at is null;
create index contacts_name_trgm        on contacts using gin (full_name gin_trgm_ops);
create trigger contacts_updated_at before update on contacts
  for each row execute function app.set_updated_at();

-- Possible duplicates awaiting a human decision (agent confirms or rejects).
create table duplicate_candidates (
  id             uuid primary key default gen_random_uuid(),
  contact_a_id   uuid not null references contacts(id),
  contact_b_id   uuid not null references contacts(id),
  matched_on     text[] not null,                        -- {'phone','whatsapp','email'}
  status         duplicate_status not null default 'pending',
  resolved_by    uuid references profiles(id),
  resolved_at    timestamptz,
  created_at     timestamptz not null default now(),
  check (contact_a_id < contact_b_id),                   -- store each pair once
  unique (contact_a_id, contact_b_id)
);
create index duplicate_candidates_pending_idx on duplicate_candidates(status) where status = 'pending';

-- Read-only helper used by the API/lead-capture service.
create or replace function find_contact_matches(p_phone text, p_whatsapp text, p_email text)
returns table (contact_id uuid, matched_on text[])
language sql stable security invoker as $$
  with keys as (
    select nullif(right(regexp_replace(coalesce(p_phone,''), '\D','','g'),10),'')    as pk,
           nullif(right(regexp_replace(coalesce(p_whatsapp,''), '\D','','g'),10),'') as wk,
           nullif(btrim(p_email),'')::citext                                        as em
  )
  select c.id,
         array_remove(array[
           case when k.pk is not null and (c.phone_key = k.pk or c.whatsapp_key = k.pk) then 'phone' end,
           case when k.wk is not null and (c.phone_key = k.wk or c.whatsapp_key = k.wk) then 'whatsapp' end,
           case when k.em is not null and c.email = k.em then 'email' end
         ], null)
  from contacts c, keys k
  where c.deleted_at is null and c.merged_into_id is null
    and ( (k.pk is not null and (c.phone_key = k.pk or c.whatsapp_key = k.pk))
       or (k.wk is not null and (c.phone_key = k.wk or c.whatsapp_key = k.wk))
       or (k.em is not null and c.email = k.em) )
$$;

-- ---------------------------------------------------------------------
-- BUYERS  (profile-level facts only; budget/locations/BHK live in
-- buyer_requirements so a buyer can hold several — see 0004)
-- ---------------------------------------------------------------------
create table buyers (
  id                 uuid primary key default gen_random_uuid(),
  code               text not null unique default app.next_code('BY','app.buyer_code_seq'),
  contact_id         uuid not null references contacts(id),
  financing_status   financing_status not null default 'undecided',
  purchase_timeline  purchase_timeline not null default 'undecided',
  purpose            purpose_type,
  is_active          boolean not null default true,
  assigned_to        uuid references profiles(id),
  last_contact_at    timestamptz,
  notes              text,
  created_by         uuid references profiles(id),
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now(),
  deleted_at         timestamptz,
  deleted_by         uuid references profiles(id)
);
create unique index buyers_contact_uq on buyers(contact_id) where deleted_at is null;
create index buyers_assigned_idx on buyers(assigned_to) where deleted_at is null;
create index buyers_active_idx   on buyers(is_active)   where deleted_at is null;
create trigger buyers_updated_at before update on buyers
  for each row execute function app.set_updated_at();

-- ---------------------------------------------------------------------
-- SELLERS / OWNERS  (number_of_properties is derived: see v_seller_summary)
-- ---------------------------------------------------------------------
create table sellers (
  id                    uuid primary key default gen_random_uuid(),
  code                  text not null unique default app.next_code('SL','app.seller_code_seq'),
  contact_id            uuid not null references contacts(id),
  relationship_status   seller_relationship not null default 'new',
  assigned_to           uuid references profiles(id),
  last_contact_at       timestamptz,
  notes                 text,
  created_by            uuid references profiles(id),
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now(),
  deleted_at            timestamptz,
  deleted_by            uuid references profiles(id)
);
create unique index sellers_contact_uq on sellers(contact_id) where deleted_at is null;
create index sellers_assigned_idx on sellers(assigned_to) where deleted_at is null;
create index sellers_rel_idx      on sellers(relationship_status) where deleted_at is null;
create trigger sellers_updated_at before update on sellers
  for each row execute function app.set_updated_at();

-- ---------------------------------------------------------------------
-- LEADS  (Lead → Buyer/Seller via buyer_id / seller_id once qualified)
-- ---------------------------------------------------------------------
create table leads (
  id                  uuid primary key default gen_random_uuid(),
  code                text not null unique default app.next_code('LD','app.lead_code_seq'),
  contact_id          uuid not null references contacts(id),
  lead_type           lead_type not null,
  source_code         text not null references lead_sources(code),
  status_code         text not null references lead_statuses(code),
  priority            priority_level not null default 'medium',
  property_type_code  text references property_types(code),
  budget_min          numeric(14,2) check (budget_min is null or budget_min >= 0),
  budget_max          numeric(14,2) check (budget_max is null or budget_max >= 0),
  preferred_location  text,
  requirement         text,
  assigned_to         uuid references profiles(id),
  buyer_id            uuid references buyers(id),
  seller_id           uuid references sellers(id),
  last_contact_at     timestamptz,
  next_follow_up_at   timestamptz,
  lost_reason         text,
  notes               text,
  source_meta         jsonb not null default '{}'::jsonb,   -- UTM, form id, page URL (website leads)
  created_by          uuid references profiles(id),         -- NULL = created by system/API
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  deleted_at          timestamptz,
  deleted_by          uuid references profiles(id),
  check (budget_max is null or budget_min is null or budget_max >= budget_min)
);
create index leads_contact_idx    on leads(contact_id);
create index leads_status_idx     on leads(status_code)   where deleted_at is null;
create index leads_source_idx     on leads(source_code)   where deleted_at is null;
create index leads_type_idx       on leads(lead_type)     where deleted_at is null;
create index leads_assigned_idx   on leads(assigned_to)   where deleted_at is null;
create index leads_priority_idx   on leads(priority)      where deleted_at is null;
create index leads_followup_idx   on leads(next_follow_up_at) where next_follow_up_at is not null and deleted_at is null;
create index leads_created_idx    on leads(created_at desc);
create index leads_buyer_idx      on leads(buyer_id)  where buyer_id  is not null;
create index leads_seller_idx     on leads(seller_id) where seller_id is not null;
create trigger leads_updated_at before update on leads
  for each row execute function app.set_updated_at();
