-- =====================================================================
-- EstateVanta CRM — 0011a_phase3_step0_function_hardening.sql
-- Phase 3 / Step 3.0.  STATUS: **NOT APPLIED** (proposal; waiting for the owner's explicit approval).
--
-- WHAT IT DOES
--   A. pins search_path = public, extensions, pg_temp on 10 non-SECURITY-DEFINER functions
--      (the 10 findings of the Supabase advisor "function_search_path_mutable");
--   B. removes EXECUTE on the 3 migration-only helpers apply_*_policies from every API role (and PUBLIC).
-- No table, policy, trigger, data or function body is touched. Rollback: rollback/0011a_rollback.sql
--
-- SAFETY
--   * ONE statement (a DO block) => one transaction, no matter how the file is submitted
--     (SQL Editor, apply_migration, psql). Any exception undoes every change.
--   * PRECONDITIONS: every expected signature must exist, its body hash must equal the one reviewed,
--     and it must have no function-level settings yet. Otherwise it stops before changing anything.
--   * POSTCONDITIONS (inside the same transaction): configuration, EXECUTE grants, bodies, the ACL of the
--     7 functions whose grants must NOT change, policy count and trigger count are re-checked; any mismatch
--     raises and rolls everything back.
--   * lock_timeout 5s: if another session holds a conflicting lock it fails fast instead of waiting.
-- NOTE: a later CREATE OR REPLACE of any of these functions without its own SET search_path clause
--       silently drops the setting again; future migrations must repeat the SET clause.
-- =====================================================================
do $m$
declare
  r         record;
  cfg       constant text[] := array['search_path=public, extensions, pg_temp'];
  acl_pre   jsonb := '{}'::jsonb;
  acl_now   text;
  pol_pre   bigint;
  trg_pre   bigint;
begin
  perform set_config('lock_timeout', '5s', true);

  -- ---------------- 1. PRECONDITIONS (nothing has been changed yet) ----------------
  for r in
    select * from (values
      ('app.guard_profile_privileges()',                     '1d1722337140c38e7ba77a02f755fe3e', false),
      ('app.guard_soft_delete()',                            '36e5a160fcf2eed72254297490bfae50', false),
      ('app.set_updated_at()',                               '2087ee763cae5a840d5f9851ac4e1eb8', false),
      ('app.enforce_active_weights()',                       '70ef85b21720c89c9ad9080f24c98cd3', false),
      ('app.next_code(text,regclass)',                       'f7a1c9e917fa28a6483f9f5f2d823c5f', false),
      ('app.bootstrap_first_admin(uuid)',                    '2ec02e307d3c37277870b1af096765f2', false),
      ('public.find_contact_matches(text,text,text)',        'a4f8e9b45e98e08f0ad6ddf3cd2c1496', false),
      ('app.apply_child_policies(text,text,text,text,text)', '8e1fd5c87ff5ec295868d5dd4866c881', true),
      ('app.apply_global_policies(text,text)',               'd391c0d1c068d31b52c60c8aa9039438', true),
      ('app.apply_scoped_policies(text,text,text)',          'e39efbb74f1cf88b7ce632e47bc7a870', true)
    ) as t(sig, body_md5, revoke_exec)
  loop
    if to_regprocedure(r.sig) is null then
      raise exception 'Phase 3.0 precondition failed: function % does not exist', r.sig using errcode = '55000';
    end if;
    if (select md5(prosrc) from pg_proc where oid = to_regprocedure(r.sig)) is distinct from r.body_md5 then
      raise exception 'Phase 3.0 precondition failed: body of % differs from the reviewed version', r.sig using errcode = '55000';
    end if;
    if (select proconfig from pg_proc where oid = to_regprocedure(r.sig)) is not null then
      raise exception 'Phase 3.0 precondition failed: % already has function-level settings', r.sig using errcode = '55000';
    end if;
    if not r.revoke_exec then
      select coalesce(string_agg(coalesce(g.rolname, 'PUBLIC') || ':' || a.privilege_type, ','
                                 order by coalesce(g.rolname, 'PUBLIC') collate "C", a.privilege_type collate "C"), '<null>')
        into acl_now
        from pg_proc p left join lateral aclexplode(p.proacl) a on true left join pg_roles g on g.oid = a.grantee
       where p.oid = to_regprocedure(r.sig);
      acl_pre := acl_pre || jsonb_build_object(r.sig, acl_now);
    end if;
  end loop;
  select count(*) into pol_pre from pg_policy;
  select count(*) into trg_pre from pg_trigger where not tgisinternal;

  -- ---------------- 2. CHANGES ----------------
  alter function app.guard_profile_privileges()                         set search_path = public, extensions, pg_temp;
  alter function app.guard_soft_delete()                                set search_path = public, extensions, pg_temp;
  alter function app.set_updated_at()                                   set search_path = public, extensions, pg_temp;
  alter function app.enforce_active_weights()                           set search_path = public, extensions, pg_temp;
  alter function app.next_code(text, regclass)                          set search_path = public, extensions, pg_temp;
  alter function app.bootstrap_first_admin(uuid)                        set search_path = public, extensions, pg_temp;
  alter function public.find_contact_matches(text, text, text)          set search_path = public, extensions, pg_temp;
  alter function app.apply_child_policies(text, text, text, text, text) set search_path = public, extensions, pg_temp;
  alter function app.apply_global_policies(text, text)                  set search_path = public, extensions, pg_temp;
  alter function app.apply_scoped_policies(text, text, text)            set search_path = public, extensions, pg_temp;

  revoke execute on function app.apply_child_policies(text, text, text, text, text) from public, anon, authenticated, service_role;
  revoke execute on function app.apply_global_policies(text, text)                  from public, anon, authenticated, service_role;
  revoke execute on function app.apply_scoped_policies(text, text, text)            from public, anon, authenticated, service_role;

  -- ---------------- 3. POSTCONDITIONS (configuration AND grants) ----------------
  for r in
    select * from (values
      ('app.guard_profile_privileges()', false), ('app.guard_soft_delete()', false), ('app.set_updated_at()', false),
      ('app.enforce_active_weights()', false), ('app.next_code(text,regclass)', false), ('app.bootstrap_first_admin(uuid)', false),
      ('public.find_contact_matches(text,text,text)', false),
      ('app.apply_child_policies(text,text,text,text,text)', true), ('app.apply_global_policies(text,text)', true),
      ('app.apply_scoped_policies(text,text,text)', true)
    ) as t(sig, revoke_exec)
  loop
    if (select proconfig from pg_proc where oid = to_regprocedure(r.sig)) is distinct from cfg then
      raise exception 'Phase 3.0 postcondition failed: search_path of % is not pinned', r.sig using errcode = '55000';
    end if;
    select coalesce(string_agg(coalesce(g.rolname, 'PUBLIC') || ':' || a.privilege_type, ','
                               order by coalesce(g.rolname, 'PUBLIC') collate "C", a.privilege_type collate "C"), '<null>')
      into acl_now
      from pg_proc p left join lateral aclexplode(p.proacl) a on true left join pg_roles g on g.oid = a.grantee
     where p.oid = to_regprocedure(r.sig);
    if r.revoke_exec then
      if acl_now is distinct from 'postgres:EXECUTE'
         or has_function_privilege('anon', to_regprocedure(r.sig), 'execute')
         or has_function_privilege('authenticated', to_regprocedure(r.sig), 'execute')
         or has_function_privilege('service_role', to_regprocedure(r.sig), 'execute') then
        raise exception 'Phase 3.0 postcondition failed: EXECUTE on % is not owner-only (acl=%)', r.sig, acl_now using errcode = '55000';
      end if;
    elsif acl_now is distinct from acl_pre ->> r.sig then
      raise exception 'Phase 3.0 postcondition failed: EXECUTE grants of % changed (% -> %)', r.sig, acl_pre ->> r.sig, acl_now using errcode = '55000';
    end if;
  end loop;
  if (select count(*) from pg_policy) <> pol_pre or (select count(*) from pg_trigger where not tgisinternal) <> trg_pre then
    raise exception 'Phase 3.0 postcondition failed: policy or trigger count changed' using errcode = '55000';
  end if;
  raise notice 'Phase 3.0 hardening applied and verified: 10 functions pinned, 3 helpers owner-only';
end
$m$;
