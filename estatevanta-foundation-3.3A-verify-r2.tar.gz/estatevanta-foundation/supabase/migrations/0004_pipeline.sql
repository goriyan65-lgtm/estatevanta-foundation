-- =====================================================================
-- EstateVanta CRM — 0004_pipeline.sql
-- Buyer → Requirements → Matches → Site Visits → Deals → Payments/Commission
-- =====================================================================

-- ---------------------------------------------------------------------
-- BUYER REQUIREMENTS (a buyer may hold many active requirements)
-- ---------------------------------------------------------------------
create table buyer_requirements (
  id                uuid primary key default gen_random_uuid(),
  code              text not null unique default app.next_code('RQ','app.requirement_code_seq'),
  buyer_id          uuid not null references buyers(id),
  lead_id           uuid references leads(id),
  transaction_type  transaction_type not null,
  budget_min        numeric(14,2) check (budget_min is null or budget_min >= 0),
  budget_max        numeric(14,2) check (budget_max is null or budget_max >= 0),
  bhk_min           smallint check (bhk_min is null or bhk_min >= 0),
  bhk_max           smallint check (bhk_max is null or bhk_max >= 0),
  area_min          numeric(12,2) check (area_min is null or area_min > 0),
  area_max          numeric(12,2) check (area_max is null or area_max > 0),
  area_unit         text references area_units(code),
  purpose           purpose_type,
  timeline          purchase_timeline not null default 'undecided',
  status            requirement_status not null default 'active',
  notes             text,
  created_by        uuid references profiles(id),
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  deleted_at        timestamptz,
  deleted_by        uuid references profiles(id),
  check (budget_max is null or budget_min is null or budget_max >= budget_min),
  check (bhk_max is null or bhk_min is null or bhk_max >= bhk_min),
  check (area_max is null or area_min is null or area_max >= area_min),
  check ((area_min is null and area_max is null) or area_unit is not null)
);
create index buyer_requirements_buyer_idx  on buyer_requirements(buyer_id) where deleted_at is null;
create index buyer_requirements_active_idx on buyer_requirements(status, transaction_type) where deleted_at is null;
create index buyer_requirements_lead_idx   on buyer_requirements(lead_id) where lead_id is not null;
create trigger buyer_requirements_updated_at before update on buyer_requirements
  for each row execute function app.set_updated_at();

create table requirement_property_types (
  requirement_id      uuid not null references buyer_requirements(id) on delete cascade,
  property_type_code  text not null references property_types(code),
  primary key (requirement_id, property_type_code)
);
create table requirement_localities (
  requirement_id uuid not null references buyer_requirements(id) on delete cascade,
  locality_id    uuid not null references localities(id),
  primary key (requirement_id, locality_id)
);
create index requirement_localities_loc_idx on requirement_localities(locality_id);

-- Free-form preferences (must-have vs nice-to-have). amenity_id when the
-- preference maps to a known amenity; otherwise key/value (e.g. facing=east).
create table requirement_preferences (
  id              uuid primary key default gen_random_uuid(),
  requirement_id  uuid not null references buyer_requirements(id) on delete cascade,
  importance      importance_level not null,
  amenity_id      uuid references amenities(id),
  pref_key        text,
  pref_value      text,
  check (amenity_id is not null or pref_key is not null)
);
create index requirement_preferences_req_idx on requirement_preferences(requirement_id);

-- ---------------------------------------------------------------------
-- MATCHING CONFIGURATION (weights are DATA, not code/SQL logic)
-- Exactly one active config. Editing = create a new version, so old
-- match scores stay explainable.
-- ---------------------------------------------------------------------
create table matching_configs (
  id                  uuid primary key default gen_random_uuid(),
  name                text not null,
  version             integer not null default 1,
  is_active           boolean not null default false,
  min_score_to_store  numeric(5,2) not null default 0 check (min_score_to_store between 0 and 100),
  budget_tolerance_pct numeric(5,2) not null default 0 check (budget_tolerance_pct >= 0),
  notes               text,
  created_by          uuid references profiles(id),
  created_at          timestamptz not null default now(),
  unique (name, version)
);
create unique index matching_configs_one_active_uq on matching_configs(is_active) where is_active;

create table matching_weights (
  config_id  uuid not null references matching_configs(id) on delete cascade,
  criterion  match_criterion not null,
  weight     numeric(5,2) not null check (weight >= 0 and weight <= 100),
  primary key (config_id, criterion)
);

-- Weights of a config must total 100 (checked when a config is activated).
create or replace function app.enforce_active_weights() returns trigger
language plpgsql as $$
declare total numeric;
begin
  if new.is_active then
    select coalesce(sum(weight),0) into total from matching_weights where config_id = new.id;
    if total <> 100 then
      raise exception 'Matching weights must total 100 to activate (got %)', total;
    end if;
  end if;
  return new;
end $$;
create trigger matching_configs_weights_ck before insert or update of is_active on matching_configs
  for each row execute function app.enforce_active_weights();

-- Match results. Hard filters (transaction type, available status) are applied
-- by the engine before scoring; the score is an INTERNAL rule-based number,
-- never presented as objective truth.
create table property_matches (
  id               uuid primary key default gen_random_uuid(),
  requirement_id   uuid not null references buyer_requirements(id) on delete cascade,
  property_id      uuid not null references properties(id) on delete cascade,
  config_id        uuid not null references matching_configs(id),
  score            numeric(5,2) not null check (score between 0 and 100),
  criteria_results jsonb not null,           -- {criterion:{weight, earned, matched:bool, detail}}
  status           match_status not null default 'suggested',
  computed_at      timestamptz not null default now(),
  shared_at        timestamptz,
  status_changed_by uuid references profiles(id),
  updated_at       timestamptz not null default now(),
  unique (requirement_id, property_id, config_id)
);
create index property_matches_req_score_idx on property_matches(requirement_id, score desc);
create index property_matches_property_idx  on property_matches(property_id);
create index property_matches_status_idx    on property_matches(status);
create trigger property_matches_updated_at before update on property_matches
  for each row execute function app.set_updated_at();

-- ---------------------------------------------------------------------
-- APPOINTMENTS (calls, meetings, follow-ups, site visits) + SITE VISITS
-- Site visit = appointment (type 'site_visit') + 1:1 detail row.
-- Owner is derived: site_visits → properties.owner_id.
-- ---------------------------------------------------------------------
create table appointments (
  id            uuid primary key default gen_random_uuid(),
  type          appointment_type not null,
  status        appointment_status not null default 'scheduled',
  title         text,
  starts_at     timestamptz not null,
  ends_at       timestamptz,
  location      text,
  assigned_to   uuid references profiles(id),
  lead_id       uuid references leads(id),
  buyer_id      uuid references buyers(id),
  seller_id     uuid references sellers(id),
  notes         text,
  created_by    uuid references profiles(id),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  deleted_at    timestamptz,
  deleted_by    uuid references profiles(id),
  check (ends_at is null or ends_at >= starts_at)
);
create index appointments_start_idx    on appointments(starts_at) where deleted_at is null;
create index appointments_assigned_idx on appointments(assigned_to, starts_at) where deleted_at is null;
create index appointments_type_status_idx on appointments(type, status) where deleted_at is null;
create index appointments_buyer_idx    on appointments(buyer_id) where buyer_id is not null;
create trigger appointments_updated_at before update on appointments
  for each row execute function app.set_updated_at();

create table site_visits (
  appointment_id    uuid primary key references appointments(id) on delete cascade,
  buyer_id          uuid not null references buyers(id),
  property_id       uuid not null references properties(id),
  requirement_id    uuid references buyer_requirements(id),
  match_id          uuid references property_matches(id),
  buyer_feedback    text,
  interest_level    interest_level,
  next_action       text,
  next_follow_up_at timestamptz,
  updated_at        timestamptz not null default now()
);
create index site_visits_buyer_idx    on site_visits(buyer_id);
create index site_visits_property_idx on site_visits(property_id);
create trigger site_visits_updated_at before update on site_visits
  for each row execute function app.set_updated_at();

-- ---------------------------------------------------------------------
-- DEALS (Buyer + Seller + Property) — created before tasks/activities
-- so they can reference deal_id.
-- ---------------------------------------------------------------------
create table deals (
  id                 uuid primary key default gen_random_uuid(),
  code               text not null unique default app.next_code('DL','app.deal_code_seq'),
  lead_id            uuid references leads(id),
  buyer_id           uuid not null references buyers(id),
  seller_id          uuid not null references sellers(id),
  property_id        uuid not null references properties(id),
  requirement_id     uuid references buyer_requirements(id),
  status             deal_status not null default 'negotiation',
  final_price        numeric(14,2) check (final_price is null or final_price >= 0),
  token_amount       numeric(14,2) check (token_amount is null or token_amount >= 0),
  agreement_date     date,
  registration_date  date,
  commission_pct     numeric(5,2) check (commission_pct is null or commission_pct between 0 and 100),
  -- calculated from the real deal record; NULL until both inputs exist
  commission_amount  numeric(14,2) generated always as (round(final_price * commission_pct / 100, 2)) stored,
  payment_status     deal_payment_status not null default 'unpaid',
  closed_at          timestamptz,
  cancelled_reason   text,
  assigned_to        uuid references profiles(id),
  notes              text,
  created_by         uuid references profiles(id),
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now(),
  deleted_at         timestamptz,
  deleted_by         uuid references profiles(id),
  check (registration_date is null or agreement_date is null or registration_date >= agreement_date),
  check (status <> 'closed' or (final_price is not null and closed_at is not null)),
  check (status <> 'cancelled' or cancelled_reason is not null)
);
-- one live deal per buyer+property pair
create unique index deals_live_pair_uq on deals(buyer_id, property_id)
  where status <> 'cancelled' and deleted_at is null;
create index deals_status_idx   on deals(status)      where deleted_at is null;
create index deals_property_idx on deals(property_id) where deleted_at is null;
create index deals_seller_idx   on deals(seller_id)   where deleted_at is null;
create index deals_assigned_idx on deals(assigned_to) where deleted_at is null;
create trigger deals_updated_at before update on deals
  for each row execute function app.set_updated_at();

create table deal_documents (
  id            uuid primary key default gen_random_uuid(),
  deal_id       uuid not null references deals(id) on delete cascade,
  category      document_category not null,
  title         text not null,
  storage_path  text not null unique,
  mime_type     text,
  size_bytes    bigint check (size_bytes is null or size_bytes >= 0),
  uploaded_by   uuid references profiles(id),
  created_at    timestamptz not null default now(),
  deleted_at    timestamptz
);
create index deal_documents_deal_idx on deal_documents(deal_id) where deleted_at is null;

-- ---------------------------------------------------------------------
-- COMMISSIONS: expected commission per party (buyer side / seller side)
-- PAYMENTS: every money movement actually recorded.
-- Received = sum(payments where commission_id = X and status = 'received').
-- ---------------------------------------------------------------------
create table commissions (
  id               uuid primary key default gen_random_uuid(),
  deal_id          uuid not null references deals(id),
  party            commission_party not null,
  expected_amount  numeric(14,2) not null check (expected_amount >= 0),
  status           commission_status not null default 'expected',
  due_date         date,
  notes            text,
  created_by       uuid references profiles(id),
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  unique (deal_id, party)
);
create index commissions_status_idx on commissions(status);
create trigger commissions_updated_at before update on commissions
  for each row execute function app.set_updated_at();

create table payments (
  id            uuid primary key default gen_random_uuid(),
  deal_id       uuid not null references deals(id),
  commission_id uuid references commissions(id),
  purpose       payment_purpose not null,
  status        payment_record_status not null default 'pending',
  amount        numeric(14,2) not null check (amount > 0),
  paid_on       date,
  method        payment_method,
  reference_no  text,
  received_by   uuid references profiles(id),
  notes         text,
  created_by    uuid references profiles(id),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  check (purpose <> 'commission' or commission_id is not null),
  check (status <> 'received' or paid_on is not null)
);
create index payments_deal_idx       on payments(deal_id);
create index payments_commission_idx on payments(commission_id) where commission_id is not null;
create index payments_status_idx     on payments(status, paid_on);
create trigger payments_updated_at before update on payments
  for each row execute function app.set_updated_at();

-- Money view: Expected / Received / Pending — computed only from real rows.
create view v_commission_summary with (security_invoker = true) as
select c.id as commission_id, c.deal_id, c.party, c.expected_amount,
       coalesce(sum(p.amount) filter (where p.status = 'received'), 0) as received_amount,
       c.expected_amount - coalesce(sum(p.amount) filter (where p.status = 'received'), 0) as pending_amount
from commissions c
left join payments p on p.commission_id = c.id and p.purpose = 'commission'
where c.status <> 'waived'
group by c.id;

-- ---------------------------------------------------------------------
-- TASKS & ACTIVITIES (Lead → Activities/Tasks)
-- ---------------------------------------------------------------------
create table tasks (
  id           uuid primary key default gen_random_uuid(),
  title        text not null check (length(btrim(title)) > 0),
  status       task_status not null default 'pending',
  priority     priority_level not null default 'medium',
  due_at       timestamptz,
  assigned_to  uuid references profiles(id),
  lead_id      uuid references leads(id),
  buyer_id     uuid references buyers(id),
  seller_id    uuid references sellers(id),
  property_id  uuid references properties(id),
  deal_id      uuid references deals(id),
  notes        text,
  system_key   text,                          -- e.g. 'reverify:<property_id>' to avoid duplicate auto-tasks
  completed_at timestamptz,
  created_by   uuid references profiles(id),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  deleted_at   timestamptz,
  deleted_by   uuid references profiles(id),
  check (status <> 'completed' or completed_at is not null)
);
create index tasks_assigned_due_idx on tasks(assigned_to, due_at) where status in ('pending','in_progress') and deleted_at is null;
create index tasks_lead_idx     on tasks(lead_id)     where lead_id     is not null;
create index tasks_buyer_idx    on tasks(buyer_id)    where buyer_id    is not null;
create index tasks_seller_idx   on tasks(seller_id)   where seller_id   is not null;
create index tasks_property_idx on tasks(property_id) where property_id is not null;
create index tasks_deal_idx     on tasks(deal_id)     where deal_id     is not null;
create unique index tasks_system_key_uq on tasks(system_key)
  where system_key is not null and status in ('pending','in_progress') and deleted_at is null;
create trigger tasks_updated_at before update on tasks
  for each row execute function app.set_updated_at();

create view v_overdue_tasks with (security_invoker = true) as
select * from tasks
where deleted_at is null and status in ('pending','in_progress') and due_at < now();

create table activities (
  id           uuid primary key default gen_random_uuid(),
  type         activity_type not null,
  summary      text not null,
  details      jsonb not null default '{}'::jsonb,
  occurred_at  timestamptz not null default now(),
  contact_id   uuid references contacts(id),
  lead_id      uuid references leads(id),
  buyer_id     uuid references buyers(id),
  seller_id    uuid references sellers(id),
  property_id  uuid references properties(id),
  deal_id      uuid references deals(id),
  created_by   uuid references profiles(id),
  created_at   timestamptz not null default now(),
  check (num_nonnulls(contact_id, lead_id, buyer_id, seller_id, property_id, deal_id) >= 1)
);
create index activities_lead_idx     on activities(lead_id, occurred_at desc)     where lead_id     is not null;
create index activities_buyer_idx    on activities(buyer_id, occurred_at desc)    where buyer_id    is not null;
create index activities_seller_idx   on activities(seller_id, occurred_at desc)   where seller_id   is not null;
create index activities_property_idx on activities(property_id, occurred_at desc) where property_id is not null;
create index activities_deal_idx     on activities(deal_id, occurred_at desc)     where deal_id     is not null;
