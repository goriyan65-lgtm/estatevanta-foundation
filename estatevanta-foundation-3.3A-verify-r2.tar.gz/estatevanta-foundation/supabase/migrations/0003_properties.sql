-- =====================================================================
-- EstateVanta CRM — 0003_properties.sql
-- Seller/Owner → Properties (1:N). Owner phone is NOT stored on the
-- property; it is read through sellers → contacts (no duplicate entry).
-- =====================================================================

create table properties (
  id                   uuid primary key default gen_random_uuid(),
  code                 text not null unique default app.next_code('PR','app.property_code_seq'),
  title                text not null check (length(btrim(title)) > 0),
  property_type_code   text not null references property_types(code),
  transaction_type     transaction_type not null,
  price                numeric(14,2) check (price is null or price >= 0),   -- asking price
  min_price            numeric(14,2) check (min_price is null or min_price >= 0),
  area_value           numeric(12,2) check (area_value is null or area_value > 0),
  area_unit            text references area_units(code),
  bhk                  smallint check (bhk is null or bhk between 0 and 20),
  bathrooms            smallint check (bathrooms is null or bathrooms >= 0),
  floor_no             smallint,
  total_floors         smallint check (total_floors is null or total_floors >= 0),
  facing               facing_direction,
  furnishing           furnishing_type,
  construction_status  construction_status,
  status               property_status not null default 'available',
  city                 text not null,
  locality_id          uuid references localities(id),
  address              text,
  latitude             numeric(9,6) check (latitude  is null or latitude  between -90  and 90),
  longitude            numeric(9,6) check (longitude is null or longitude between -180 and 180),
  owner_id             uuid references sellers(id),                          -- nullable: broker/developer/import inventory
  description          text,
  -- provenance (mandatory for externally sourced records)
  source               inventory_source not null,
  source_name          text,                                                 -- e.g. broker/developer name or authorized provider
  source_url           text,
  source_date          date,
  import_batch_id      uuid,                                                 -- FK added in 0005 (import_batches)
  -- verification
  verification_status  verification_status not null default 'unverified',
  last_verified_at     timestamptz,
  verified_by          uuid references profiles(id),
  assigned_to          uuid references profiles(id),
  created_by           uuid references profiles(id),
  created_at           timestamptz not null default now(),
  updated_at           timestamptz not null default now(),
  deleted_at           timestamptz,
  deleted_by           uuid references profiles(id),
  check (min_price is null or price is null or min_price <= price),
  check ((area_value is null) = (area_unit is null)),
  check (floor_no is null or total_floors is null or floor_no <= total_floors),
  check (source <> 'owner_direct' or owner_id is not null),                  -- owner-direct must name an owner
  check (source not in ('external_authorized_import') or (source_name is not null and source_date is not null)),
  check (verification_status <> 'verified' or last_verified_at is not null)
);
create index properties_status_idx    on properties(status)               where deleted_at is null;
create index properties_type_idx      on properties(property_type_code)   where deleted_at is null;
create index properties_txn_idx       on properties(transaction_type)     where deleted_at is null;
create index properties_price_idx     on properties(price)                where deleted_at is null;
create index properties_city_loc_idx  on properties(city, locality_id)    where deleted_at is null;
create index properties_owner_idx     on properties(owner_id)             where deleted_at is null;
create index properties_source_idx    on properties(source)               where deleted_at is null;
create index properties_verif_idx     on properties(verification_status, last_verified_at) where deleted_at is null;
create index properties_bhk_idx       on properties(bhk)                  where deleted_at is null;
create index properties_title_trgm    on properties using gin (title gin_trgm_ops);
create index properties_address_trgm  on properties using gin (address gin_trgm_ops);
create index properties_geo_idx       on properties(latitude, longitude)  where latitude is not null;
-- Prevent re-importing the same external listing twice.
create unique index properties_source_url_uq on properties(source_url)
  where source_url is not null and deleted_at is null;
create trigger properties_updated_at before update on properties
  for each row execute function app.set_updated_at();

-- Owner-direct commercial terms (1:1, only for properties that need them)
create table property_owner_terms (
  property_id           uuid primary key references properties(id) on delete cascade,
  is_negotiable         boolean,
  ownership_doc_status  ownership_doc_status not null default 'not_collected',
  exclusivity           exclusivity_type,
  brokerage_kind        brokerage_type not null default 'none',
  brokerage_value       numeric(12,2) check (brokerage_value is null or brokerage_value >= 0),
  owner_verified        boolean not null default false,
  owner_verified_at     timestamptz,
  owner_verified_by     uuid references profiles(id),
  updated_at            timestamptz not null default now(),
  check (brokerage_kind = 'none' or brokerage_value is not null),
  check (not owner_verified or owner_verified_at is not null)
);
create trigger property_owner_terms_updated_at before update on property_owner_terms
  for each row execute function app.set_updated_at();

create table property_amenities (
  property_id uuid not null references properties(id) on delete cascade,
  amenity_id  uuid not null references amenities(id),
  primary key (property_id, amenity_id)
);
create index property_amenities_amenity_idx on property_amenities(amenity_id);

-- Media: files live in a PRIVATE Supabase Storage bucket; this table stores
-- only the object path. Access is via short-lived signed URLs.
create table property_media (
  id            uuid primary key default gen_random_uuid(),
  property_id   uuid not null references properties(id) on delete cascade,
  kind          media_kind not null,
  storage_path  text not null unique,
  file_name     text,
  mime_type     text,
  size_bytes    bigint check (size_bytes is null or size_bytes >= 0),
  sort_order    integer not null default 0,
  is_primary    boolean not null default false,
  caption       text,
  uploaded_by   uuid references profiles(id),
  created_at    timestamptz not null default now(),
  deleted_at    timestamptz,
  check (not is_primary or kind = 'image')
);
create index property_media_property_idx on property_media(property_id, kind, sort_order) where deleted_at is null;
-- exactly one primary image per property
create unique index property_media_one_primary_uq on property_media(property_id)
  where is_primary and deleted_at is null;

create table property_documents (
  id            uuid primary key default gen_random_uuid(),
  property_id   uuid not null references properties(id) on delete cascade,
  category      document_category not null,
  title         text not null,
  storage_path  text not null unique,
  mime_type     text,
  size_bytes    bigint check (size_bytes is null or size_bytes >= 0),
  is_verified   boolean not null default false,
  uploaded_by   uuid references profiles(id),
  created_at    timestamptz not null default now(),
  deleted_at    timestamptz
);
create index property_documents_property_idx on property_documents(property_id) where deleted_at is null;

-- Derived views (security_invoker => the caller's RLS still applies)
create view v_seller_summary with (security_invoker = true) as
select s.id as seller_id,
       count(p.id) filter (where p.deleted_at is null) as number_of_properties
from sellers s
left join properties p on p.owner_id = s.id
group by s.id;

-- NOTE: v_properties_due_verification is defined in 0005 (needs the settings table).
