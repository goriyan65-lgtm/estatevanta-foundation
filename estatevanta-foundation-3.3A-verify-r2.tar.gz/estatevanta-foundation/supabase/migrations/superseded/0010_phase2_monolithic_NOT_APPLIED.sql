-- SUPERSEDED. This single-file Phase 2 plan was never applied. Phase 2 was split into
-- 0010a (applied), 0010b (applied) and 0010c (NOT applied). Kept for history only; do not run.
-- =====================================================================
-- EstateVanta CRM — 0010_phase2_auth_security.sql  (revision 2)
-- Phase 2: authentication hardening, one-time bootstrap, security audit.
-- Additive on top of 0001–0009. NO business data. NO RLS policy changes.
-- Rollback: supabase/migrations/rollback/0010_rollback.sql
-- =====================================================================

-- 1. Audit vocabulary ---------------------------------------------------
alter table audit_logs drop constraint audit_logs_action_check;
alter table audit_logs add constraint audit_logs_action_check check (action in (
  'insert','update','delete','soft_delete','restore',
  'login','logout','login_failed','access_denied','invite','bootstrap_admin'));

-- 2. Server-only security logger (service_role ONLY) ---------------------
-- Browsers/anon/authenticated cannot execute it, so they cannot forge events.
-- The server passes the actor id it has verified from the session; the function
-- re-validates event type, actor existence/state, and the shape of the detail.
create or replace function public.security_log_event(
  p_action text, p_actor uuid default null, p_detail jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if p_action is null or p_action not in ('login','logout','login_failed','access_denied','invite') then
    raise exception 'unsupported security event %', p_action using errcode = '22023';
  end if;
  if p_detail is null or jsonb_typeof(p_detail) <> 'object' or length(p_detail::text) > 2000 then
    raise exception 'event detail must be a JSON object under 2000 characters' using errcode = '22023';
  end if;
  if exists (select 1 from jsonb_object_keys(p_detail) k
             where k <> all (array['ip','user_agent','email','path','reason','request_id','method'])) then
    raise exception 'event detail contains unsupported keys' using errcode = '22023';
  end if;
  if p_action = 'login_failed' and p_actor is not null then
    raise exception 'login_failed events cannot carry an actor identity' using errcode = '22023';
  end if;
  if p_action in ('login','logout','invite') and p_actor is null then
    raise exception '% events require an actor', p_action using errcode = '22023';
  end if;
  if p_actor is not null and not exists
       (select 1 from profiles where id = p_actor and deleted_at is null) then
    raise exception 'unknown actor' using errcode = '22023';
  end if;
  if p_action in ('login','invite') and not exists
       (select 1 from profiles where id = p_actor and is_active) then
    raise exception 'actor is not an active user' using errcode = '22023';
  end if;
  if p_action = 'login' and not exists (
       select 1 from auth.users where id = p_actor and last_sign_in_at > now() - interval '5 minutes') then
    raise exception 'no recent sign-in recorded for this actor' using errcode = '22023';
  end if;
  if p_action = 'invite' and not exists (
       select 1 from profiles p join role_permissions rp on rp.role_id = p.role_id
       join permissions pm on pm.id = rp.permission_id
       where p.id = p_actor and pm.code = 'users.manage') then
    raise exception 'actor may not invite users' using errcode = '22023';
  end if;
  insert into audit_logs(actor_id, actor_context, action, entity_table, entity_id, new_values)
  values (p_actor, 'api', p_action, 'security', coalesce(p_actor::text, 'anonymous'), p_detail);
end $$;
revoke all on function public.security_log_event(text, uuid, jsonb) from public, anon, authenticated;
grant execute on function public.security_log_event(text, uuid, jsonb) to service_role;

-- 3. my_access(): SECURITY INVOKER => RLS applies; no parameters => caller's own data only
create or replace function public.my_access() returns jsonb
language sql stable security invoker set search_path = public as $$
  select jsonb_build_object(
    'user_id', p.id, 'full_name', p.full_name, 'role', r.code, 'is_active', p.is_active,
    'permissions', coalesce((select jsonb_agg(pm.code order by pm.code)
                             from role_permissions rp join permissions pm on pm.id = rp.permission_id
                             where rp.role_id = p.role_id and p.is_active), '[]'::jsonb))
  from profiles p left join roles r on r.id = p.role_id
  where p.id = auth.uid() and p.deleted_at is null
$$;
revoke all on function public.my_access() from public, anon, authenticated, service_role;
grant execute on function public.my_access() to authenticated;

-- 4. find_contact_matches: authenticated (admin UI) + service_role (website intake) only
revoke all on function public.find_contact_matches(text, text, text) from public, anon, authenticated, service_role;
grant execute on function public.find_contact_matches(text, text, text) to authenticated, service_role;

-- 5. ONE-TIME, TWO-STEP FIRST-ADMIN BOOTSTRAP ------------------------------
-- Step A (project owner, SQL editor): app.arm_bootstrap(secret, expected_email, minutes)
-- Step B (project owner, SQL editor): app.bootstrap_first_admin(user_uuid, secret)
-- Requirements for B: armed, unexpired, not consumed, no admin exists, secret matches,
-- the user's confirmed email equals the armed email. Serialised by an advisory lock
-- plus a row lock on the single-row state table. Lives in schema "app" (not exposed
-- through the Data API) and is executable by the database owner only.
create table app.bootstrap_setup (
  singleton    boolean primary key default true check (singleton),
  secret_hash  text not null,
  target_email citext not null,
  armed_at     timestamptz not null default now(),
  expires_at   timestamptz not null,
  consumed_at  timestamptz,
  consumed_by  uuid
);
alter table app.bootstrap_setup enable row level security;      -- no policies: nobody but the owner
revoke all on app.bootstrap_setup from public, anon, authenticated, service_role;

drop function app.bootstrap_first_admin(uuid);                   -- the old, secret-less version

create function app.arm_bootstrap(p_secret text, p_target_email text, p_valid_minutes int default 60)
returns timestamptz language plpgsql security definer set search_path = public as $$
declare st app.bootstrap_setup; v_exp timestamptz;
begin
  perform pg_advisory_xact_lock(hashtext('estatevanta.bootstrap'));
  if p_secret is null or length(p_secret) < 20 then
    raise exception 'Setup secret must be at least 20 characters' using errcode = '22023';
  end if;
  if p_target_email is null or position('@' in p_target_email) = 0 then
    raise exception 'A valid expected email is required' using errcode = '22023';
  end if;
  if p_valid_minutes is null or p_valid_minutes not between 5 and 1440 then
    raise exception 'Validity must be between 5 and 1440 minutes' using errcode = '22023';
  end if;
  if exists (select 1 from profiles p join roles r on r.id = p.role_id
             where r.code = 'admin' and p.is_active and p.deleted_at is null) then
    raise exception 'An active admin already exists' using errcode = '55000';
  end if;
  select * into st from app.bootstrap_setup where singleton for update;
  if found and st.consumed_at is not null then
    raise exception 'Bootstrap has already been completed' using errcode = '55000';
  end if;
  v_exp := now() + make_interval(mins => p_valid_minutes);
  insert into app.bootstrap_setup(singleton, secret_hash, target_email, armed_at, expires_at)
  values (true, encode(sha256(convert_to(p_secret, 'UTF8')), 'hex'), p_target_email, now(), v_exp)
  on conflict (singleton) do update
     set secret_hash = excluded.secret_hash, target_email = excluded.target_email,
         armed_at = excluded.armed_at, expires_at = excluded.expires_at;
  return v_exp;
end $$;

create function app.bootstrap_first_admin(target_user uuid, p_secret text) returns void
language plpgsql security definer set search_path = public as $$
declare st app.bootstrap_setup; v_email text; v_confirmed timestamptz;
begin
  perform pg_advisory_xact_lock(hashtext('estatevanta.bootstrap'));
  select * into st from app.bootstrap_setup where singleton for update;
  if not found then raise exception 'Bootstrap is not armed' using errcode = '55000'; end if;
  if st.consumed_at is not null then raise exception 'Bootstrap has already been completed' using errcode = '55000'; end if;
  if exists (select 1 from profiles p join roles r on r.id = p.role_id
             where r.code = 'admin' and p.is_active and p.deleted_at is null) then
    raise exception 'An active admin already exists' using errcode = '55000';
  end if;
  if st.expires_at < now() then raise exception 'Bootstrap window has expired' using errcode = '55000'; end if;
  if p_secret is null or st.secret_hash <> encode(sha256(convert_to(p_secret, 'UTF8')), 'hex') then
    raise exception 'Invalid setup secret' using errcode = '28000';
  end if;
  select email, email_confirmed_at into v_email, v_confirmed from auth.users where id = target_user;
  if not found then raise exception 'No auth user %', target_user using errcode = '55000'; end if;
  if v_email is null or lower(v_email) <> lower(st.target_email::text) then
    raise exception 'User email does not match the armed email' using errcode = '55000';
  end if;
  if v_confirmed is null then raise exception 'The user''s email must be confirmed' using errcode = '55000'; end if;
  update profiles
     set role_id = (select id from roles where code = 'admin'), is_active = true, deleted_at = null
   where id = target_user;
  if not found then raise exception 'No profile for user %', target_user using errcode = '55000'; end if;
  update app.bootstrap_setup
     set consumed_at = now(), consumed_by = target_user, secret_hash = repeat('0', 64)
   where singleton;
  insert into audit_logs(actor_id, actor_context, action, entity_table, entity_id, new_values)
  values (null, 'bootstrap', 'bootstrap_admin', 'security', target_user::text,
          jsonb_build_object('email', v_email));
end $$;
revoke all on function app.arm_bootstrap(text, text, int) from public, anon, authenticated, service_role;
revoke all on function app.bootstrap_first_admin(uuid, text) from public, anon, authenticated, service_role;

-- 6. Profile privilege guard now also covers soft-delete ---------------------
create or replace function app.guard_profile_privileges() returns trigger
language plpgsql as $$
begin
  if auth.uid() is null then return new; end if;            -- server / SQL-editor context
  if (new.role_id is distinct from old.role_id
      or new.is_active is distinct from old.is_active
      or new.deleted_at is distinct from old.deleted_at)
     and not app.can('users.manage') then
    raise exception 'permission denied: users.manage required to change role, activation or deletion'
      using errcode = '42501';
  end if;
  return new;
end $$;

-- 7. LAST-ADMIN PROTECTION, enforced in the database ---------------------------
-- Any change that would take an active admin out of the admin set (demote,
-- deactivate, soft-delete, delete) first takes a global advisory lock, then
-- counts the remaining admins with a fresh READ COMMITTED snapshot. Two
-- concurrent transactions therefore queue up and the second sees the first's
-- committed result. Other isolation levels are refused (stale snapshots).
create or replace function app.protect_last_admin() returns trigger
language plpgsql security definer set search_path = public as $$
declare was_admin boolean; still_admin boolean; others int;
begin
  select (exists (select 1 from roles r where r.id = old.role_id and r.code = 'admin')
          and old.is_active and old.deleted_at is null) into was_admin;
  if tg_op = 'DELETE' then
    still_admin := false;
  else
    select (exists (select 1 from roles r where r.id = new.role_id and r.code = 'admin')
            and new.is_active and new.deleted_at is null) into still_admin;
  end if;
  if was_admin and not still_admin then
    perform pg_advisory_xact_lock(hashtext('estatevanta.admin_set'));
    if current_setting('transaction_isolation') <> 'read committed' then
      raise exception 'Admin changes require READ COMMITTED isolation' using errcode = '55000';
    end if;
    select count(*) into others from profiles p join roles r on r.id = p.role_id
     where r.code = 'admin' and p.is_active and p.deleted_at is null and p.id <> old.id;
    if others = 0 then
      raise exception 'Cannot remove, demote or deactivate the last active admin' using errcode = '55000';
    end if;
  end if;
  if tg_op = 'DELETE' then return old; end if;
  return new;
end $$;
create trigger protect_last_admin before update or delete on profiles
  for each row execute function app.protect_last_admin();

-- 8. System roles and the admin's permissions are immutable ---------------------
create or replace function app.protect_system_roles() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'DELETE' and old.is_system then
    raise exception 'System roles cannot be deleted' using errcode = '55000';
  end if;
  if tg_op = 'UPDATE' and old.is_system
     and (new.code is distinct from old.code or new.is_system is distinct from old.is_system) then
    raise exception 'System role code/flag cannot be changed' using errcode = '55000';
  end if;
  if tg_op = 'DELETE' then return old; end if;
  return new;
end $$;
create trigger protect_system_roles before update or delete on roles
  for each row execute function app.protect_system_roles();

create or replace function app.protect_admin_permissions() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if exists (select 1 from roles r where r.id = old.role_id and r.code = 'admin') then
    if tg_op = 'UPDATE' and new.role_id = old.role_id and new.permission_id = old.permission_id then
      return new;
    end if;
    raise exception 'Admin permissions cannot be removed or reassigned' using errcode = '55000';
  end if;
  if tg_op = 'DELETE' then return old; end if;
  return new;
end $$;
create trigger protect_admin_permissions before update or delete on role_permissions
  for each row execute function app.protect_admin_permissions();

revoke all on function app.protect_last_admin()        from public, anon, authenticated, service_role;
revoke all on function app.protect_system_roles()      from public, anon, authenticated, service_role;
revoke all on function app.protect_admin_permissions() from public, anon, authenticated, service_role;
