-- SUPERSEDED. Rollback for the never-applied monolithic 0010. Use rollback/0010a|b|c_rollback.sql instead. Do not run.
-- =====================================================================
-- ROLLBACK for 0010_phase2_auth_security.sql  (restores the post-0009 state)
-- Run ONLY if Phase 2 must be undone. Single script = single implicit transaction.
-- BEFORE RUNNING: export any audit_logs rows with the new action types if you want
-- to keep them (they must be deleted for the old CHECK constraint to be restorable):
--   select * from audit_logs where action in
--   ('login','logout','login_failed','access_denied','invite','bootstrap_admin');
-- NOTE: the original find_contact_matches grants (PUBLIC + anon execute) were
-- weaker; they are restored below only for a faithful rollback. Prefer NOT to.
-- Original definitions below were captured from the live database on 2026-10-03
-- BEFORE applying 0010.
-- =====================================================================
drop trigger if exists protect_admin_permissions on role_permissions;
drop trigger if exists protect_system_roles      on roles;
drop trigger if exists protect_last_admin        on profiles;
drop function if exists app.protect_admin_permissions();
drop function if exists app.protect_system_roles();
drop function if exists app.protect_last_admin();

drop function if exists app.bootstrap_first_admin(uuid, text);
drop function if exists app.arm_bootstrap(text, text, int);
drop table    if exists app.bootstrap_setup;

CREATE OR REPLACE FUNCTION app.guard_profile_privileges()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
begin
  if auth.uid() is null then return new; end if;
  if (new.role_id is distinct from old.role_id or new.is_active is distinct from old.is_active)
     and not app.can('users.manage') then
    raise exception 'permission denied: users.manage required to change role or activation' using errcode='42501';
  end if;
  return new;
end $function$;

CREATE OR REPLACE FUNCTION app.bootstrap_first_admin(target_user uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if exists (select 1 from profiles p join roles r on r.id = p.role_id
             where r.code = 'admin' and p.is_active) then
    raise exception 'An active admin already exists';
  end if;
  update profiles
     set role_id = (select id from roles where code = 'admin'), is_active = true
   where id = target_user;
  if not found then raise exception 'No profile for user %', target_user; end if;
end $function$;
revoke all on function app.bootstrap_first_admin(uuid) from public, anon, authenticated, service_role;

drop function if exists public.security_log_event(text, uuid, jsonb);
drop function if exists public.my_access();

-- original ACL of find_contact_matches: {=X/postgres, anon, authenticated, service_role}
grant execute on function public.find_contact_matches(text, text, text) to public, anon, authenticated, service_role;

delete from audit_logs where action in ('login','logout','login_failed','access_denied','invite','bootstrap_admin');
alter table audit_logs drop constraint audit_logs_action_check;
alter table audit_logs add constraint audit_logs_action_check
  check (action = any (array['insert','update','delete','soft_delete','restore']));
