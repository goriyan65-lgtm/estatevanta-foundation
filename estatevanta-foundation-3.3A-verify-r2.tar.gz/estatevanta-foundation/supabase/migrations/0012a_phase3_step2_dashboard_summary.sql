-- =====================================================================
-- EstateVanta CRM — 0012a_phase3_step2_dashboard_summary.sql
-- Phase 3.2: public.dashboard_summary()  — 13 operational dashboard counts.
--
-- STATUS: DESIGNED + TESTED LOCALLY ONLY. NOT APPLIED to Supabase. Apply only after explicit approval.
--
-- What it adds : ONE function. Nothing else.
-- What it does NOT touch: tables, columns, indexes, views, RLS policies, triggers, roles, permissions,
--                         settings, grants on any existing object, or any Phase 2 / 3.0 migration.
-- Data         : writes nothing, inserts nothing. No demo data.
--
-- SECURITY MODEL
--  * SECURITY INVOKER (explicit). Every count runs as the calling user, so the EXISTING row-level
--    security on each table decides which rows are counted. This function creates no parallel
--    authorization system and cannot broaden access beyond RLS.
--  * Each card is gated by app.can(<module>.read_all | <module>.read ...) BEFORE any count query runs.
--    A caller without the permission gets {available:false, value:null} — never a misleading 0.
--    The deals query is not executed at all for a caller without deals.read / deals.read_all (viewer).
--  * Admin RLS also returns soft-deleted rows, so every counted business row filters deleted_at IS NULL.
--  * search_path pinned to public, extensions, pg_temp. No dynamic SQL. No arguments at all
--    (no client-supplied table, column, filter or SQL). No service-role key. STABLE (read-only).
--  * EXECUTE: authenticated only. Revoked from PUBLIC, anon and service_role (Supabase default
--    privileges would otherwise grant new public functions to anon + service_role).
--  * Returns counts only. No amounts, prices, commissions, payments, names or ids.
--
-- Atomicity: no BEGIN/COMMIT on purpose (same convention as 0000 / 0011a): the SQL Editor runs a
-- multi-statement script as one implicit transaction, so any failed assertion rolls everything back.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 0. PRE-CONDITIONS — fail loudly (and roll back) if the database is not what this was designed against.
-- ---------------------------------------------------------------------
do $pre$
declare
  missing text[] := '{}';
  t text;
begin
  foreach t in array array['properties','leads','lead_statuses','buyers','buyer_requirements','sellers',
                           'property_matches','appointments','tasks','deals','settings'] loop
    if to_regclass('public.' || t) is null then missing := missing || ('table ' || t); end if;
  end loop;
  if to_regprocedure('app.can(text)') is null then missing := missing || 'app.can(text)'; end if;
  if to_regprocedure('app.current_role_code()') is null then missing := missing || 'app.current_role_code()'; end if;
  if to_regtype('public.priority_level') is null then missing := missing || 'type priority_level'; end if;
  if cardinality(missing) > 0 then
    raise exception 'dashboard_summary pre-condition failed, missing: %', array_to_string(missing, ', ');
  end if;
  if to_regprocedure('public.dashboard_summary()') is not null then
    raise exception 'dashboard_summary() already exists — this migration is create-only; investigate before re-running';
  end if;
end
$pre$;

-- ---------------------------------------------------------------------
-- 1. THE FUNCTION
-- ---------------------------------------------------------------------
create function public.dashboard_summary()
returns jsonb
language plpgsql
stable
security invoker
set search_path = public, extensions, pg_temp
as $fn$
declare
  c_tz_default   constant text   := 'Asia/Kolkata';
  c_hot_default  constant text[] := array['high', 'urgent'];
  c_days_default constant int    := 30;

  v_uid       uuid;
  v_role      text;
  v_now       timestamptz := now();
  v_raw       jsonb;
  v_tz        text;
  v_hot       text[];
  v_days      int;
  v_warn      text[] := '{}';
  v_day_start timestamptz;
  v_day_end   timestamptz;
  v_prop_all  boolean;
  v_cards     jsonb := '{}'::jsonb;

  a boolean;   -- card available to this caller
  n integer;   -- card value
  s text;      -- card scope: 'all' | 'assigned'
begin
  -- ---- identity: signed-in AND an active profile with a role -------------------------------
  v_uid  := auth.uid();                       -- a malformed JWT subject raises 22P02 here (no data returned)
  v_role := app.current_role_code();
  if v_uid is null or v_role is null then
    raise exception 'dashboard_summary: no active profile for this user' using errcode = '42501';
  end if;

  -- ---- settings (read under the caller's own RLS; each is validated, never trusted) ----------
  -- app.timezone
  select value into v_raw from settings where key = 'app.timezone';
  if v_raw is not null and jsonb_typeof(v_raw) = 'string'
     and exists (select 1 from pg_timezone_names z where z.name = (v_raw #>> '{}')) then
    v_tz := v_raw #>> '{}';
  else
    v_tz := c_tz_default;
    v_warn := array_append(v_warn, 'app_timezone_fallback');
  end if;

  -- leads.hot_priorities : must be an array of valid priority_level labels (an empty array is valid = none)
  select value into v_raw from settings where key = 'leads.hot_priorities';
  if v_raw is not null and jsonb_typeof(v_raw) = 'array'
     and not exists (select 1 from jsonb_array_elements(v_raw) e
                     where jsonb_typeof(e) <> 'string'
                        or (e #>> '{}') <> all (enum_range(null::priority_level)::text[])) then
    v_hot := array(select jsonb_array_elements_text(v_raw));
  else
    v_hot := c_hot_default;
    v_warn := array_append(v_warn, 'leads_hot_priorities_fallback');
  end if;

  -- property.reverify_days : whole number 1..3650
  select value into v_raw from settings where key = 'property.reverify_days';
  if v_raw is not null and jsonb_typeof(v_raw) = 'number' and (v_raw #>> '{}') ~ '^[0-9]{1,4}$'
     and (v_raw #>> '{}')::int between 1 and 3650 then
    v_days := (v_raw #>> '{}')::int;
  else
    v_days := c_days_default;
    v_warn := array_append(v_warn, 'property_reverify_days_fallback');
  end if;

  -- local calendar day in app.timezone, as absolute instants (DST-safe)
  v_day_start := date_trunc('day', v_now at time zone v_tz) at time zone v_tz;
  v_day_end   := (date_trunc('day', v_now at time zone v_tz) + interval '1 day') at time zone v_tz;

  v_prop_all := app.can('properties.read_all');

  -- ===== 1. active_inventory ================================================================
  a := app.can('properties.read_all') or app.can('properties.read_active') or app.can('properties.read');
  n := null; s := null;
  if a then
    s := case when app.can('properties.read_all') or app.can('properties.read_active') then 'all' else 'assigned' end;
    select count(*) into n from properties p
     where p.deleted_at is null
       and p.status in ('available', 'reserved', 'under_negotiation');
  end if;
  v_cards := v_cards || jsonb_build_object('active_inventory',
             jsonb_build_object('available', a, 'value', n, 'scope', s));

  -- ===== 2. listings_due_verification (agent: only listings they are assigned to / created) ===
  a := v_prop_all or app.can('properties.read');
  n := null; s := null;
  if a then
    s := case when v_prop_all then 'all' else 'assigned' end;
    select count(*) into n from properties p
     where p.deleted_at is null
       and p.status in ('available', 'reserved', 'under_negotiation')
       and (p.last_verified_at is null or p.last_verified_at < v_now - make_interval(days => v_days))
       and (v_prop_all or p.assigned_to = v_uid or p.created_by = v_uid);
  end if;
  v_cards := v_cards || jsonb_build_object('listings_due_verification',
             jsonb_build_object('available', a, 'value', n, 'scope', s));

  -- ===== 3-6. leads =========================================================================
  a := app.can('leads.read_all') or app.can('leads.read');
  s := case when app.can('leads.read_all') then 'all' else 'assigned' end;

  -- 3. open_leads : status is not terminal
  n := null;
  if a then
    select count(*) into n from leads l
     where l.deleted_at is null
       and not exists (select 1 from lead_statuses ls where ls.code = l.status_code and ls.is_terminal);
  end if;
  v_cards := v_cards || jsonb_build_object('open_leads',
             jsonb_build_object('available', a, 'value', n, 'scope', case when a then s end));

  -- 4. new_leads_uncontacted : status 'new' and never contacted
  n := null;
  if a then
    select count(*) into n from leads l
     where l.deleted_at is null and l.status_code = 'new' and l.last_contact_at is null;
  end if;
  v_cards := v_cards || jsonb_build_object('new_leads_uncontacted',
             jsonb_build_object('available', a, 'value', n, 'scope', case when a then s end));

  -- 5. hot_leads : open + priority in leads.hot_priorities
  n := null;
  if a then
    select count(*) into n from leads l
     where l.deleted_at is null
       and not exists (select 1 from lead_statuses ls where ls.code = l.status_code and ls.is_terminal)
       and l.priority::text = any (v_hot);
  end if;
  v_cards := v_cards || jsonb_build_object('hot_leads',
             jsonb_build_object('available', a, 'value', n, 'scope', case when a then s end));

  -- 6. overdue_followups : open + follow-up date passed
  n := null;
  if a then
    select count(*) into n from leads l
     where l.deleted_at is null
       and not exists (select 1 from lead_statuses ls where ls.code = l.status_code and ls.is_terminal)
       and l.next_follow_up_at is not null and l.next_follow_up_at < v_now;
  end if;
  v_cards := v_cards || jsonb_build_object('overdue_followups',
             jsonb_build_object('available', a, 'value', n, 'scope', case when a then s end));

  -- ===== 7. buyers_active_requirements ======================================================
  a := app.can('buyers.read_all') or app.can('buyers.read');
  n := null; s := null;
  if a then
    s := case when app.can('buyers.read_all') then 'all' else 'assigned' end;
    select count(*) into n from buyers b
     where b.deleted_at is null and b.is_active
       and exists (select 1 from buyer_requirements r
                    where r.buyer_id = b.id and r.deleted_at is null and r.status = 'active');
  end if;
  v_cards := v_cards || jsonb_build_object('buyers_active_requirements',
             jsonb_build_object('available', a, 'value', n, 'scope', s));

  -- ===== 8. sellers_awaiting_contact ========================================================
  a := app.can('sellers.read_all') or app.can('sellers.read');
  n := null; s := null;
  if a then
    s := case when app.can('sellers.read_all') then 'all' else 'assigned' end;
    select count(*) into n from sellers sl
     where sl.deleted_at is null and sl.relationship_status = 'new';
  end if;
  v_cards := v_cards || jsonb_build_object('sellers_awaiting_contact',
             jsonb_build_object('available', a, 'value', n, 'scope', s));

  -- ===== 9. matches_ready_to_share ==========================================================
  -- property_matches has no deleted_at column: the soft-delete / active filters apply to its parents.
  -- The joins run under the caller's RLS on buyer_requirements, buyers and properties as well.
  a := app.can('matching.read_all') or app.can('matching.read');
  n := null; s := null;
  if a then
    s := case when app.can('matching.read_all') then 'all' else 'assigned' end;
    select count(*) into n
      from property_matches m
      join buyer_requirements r on r.id = m.requirement_id
      join buyers b             on b.id = r.buyer_id
      join properties p         on p.id = m.property_id
     where m.status = 'suggested'
       and r.deleted_at is null and r.status = 'active'
       and b.deleted_at is null and b.is_active
       and p.deleted_at is null and p.status in ('available', 'reserved', 'under_negotiation');
  end if;
  v_cards := v_cards || jsonb_build_object('matches_ready_to_share',
             jsonb_build_object('available', a, 'value', n, 'scope', s));

  -- ===== 10-11. appointments (only scheduled + confirmed; 'rescheduled' is deliberately excluded) ===
  a := app.can('appointments.read_all') or app.can('appointments.read');
  s := case when app.can('appointments.read_all') then 'all' else 'assigned' end;

  n := null;
  if a then
    select count(*) into n from appointments ap
     where ap.deleted_at is null and ap.status in ('scheduled', 'confirmed')
       and ap.starts_at >= v_day_start and ap.starts_at < v_day_end;
  end if;
  v_cards := v_cards || jsonb_build_object('appointments_today',
             jsonb_build_object('available', a, 'value', n, 'scope', case when a then s end));

  n := null;
  if a then
    select count(*) into n from appointments ap
     where ap.deleted_at is null and ap.status in ('scheduled', 'confirmed')
       and ap.starts_at < v_now;
  end if;
  v_cards := v_cards || jsonb_build_object('appointments_awaiting_outcome',
             jsonb_build_object('available', a, 'value', n, 'scope', case when a then s end));

  -- ===== 12. overdue_tasks ==================================================================
  a := app.can('tasks.read_all') or app.can('tasks.read');
  n := null; s := null;
  if a then
    s := case when app.can('tasks.read_all') then 'all' else 'assigned' end;
    select count(*) into n from tasks t
     where t.deleted_at is null and t.status in ('pending', 'in_progress') and t.due_at < v_now;
  end if;
  v_cards := v_cards || jsonb_build_object('overdue_tasks',
             jsonb_build_object('available', a, 'value', n, 'scope', s));

  -- ===== 13. open_deals — DEAL DATA, count only. Not executed at all without deals.read / read_all ====
  a := app.can('deals.read_all') or app.can('deals.read');
  n := null; s := null;
  if a then
    s := case when app.can('deals.read_all') then 'all' else 'assigned' end;
    select count(*) into n from deals d
     where d.deleted_at is null and d.status not in ('closed', 'cancelled');
  end if;
  v_cards := v_cards || jsonb_build_object('open_deals',
             jsonb_build_object('available', a, 'value', n, 'scope', s));

  return jsonb_build_object(
    'schema_version', 1,
    'generated_at',   v_now,
    'timezone',       v_tz,
    'warnings',       to_jsonb(v_warn),
    'cards',          v_cards);
end
$fn$;

comment on function public.dashboard_summary() is
  'Phase 3.2 dashboard: 13 operational counts. SECURITY INVOKER (RLS decides scope); per-card permission gate; '
  'unavailable cards return value null; counts only, no amounts. No arguments.';

-- ---------------------------------------------------------------------
-- 2. PRIVILEGES — authenticated only (anon + service_role + PUBLIC explicitly revoked)
-- ---------------------------------------------------------------------
revoke all on function public.dashboard_summary() from public, anon, authenticated, service_role;
grant execute on function public.dashboard_summary() to authenticated;

-- ---------------------------------------------------------------------
-- 3. POST-CONDITIONS — verify what was just created; any failure rolls the whole script back
-- ---------------------------------------------------------------------
do $post$
declare
  r record;
  acl text;
begin
  select p.prosecdef, p.provolatile, p.proconfig, p.prorettype::regtype::text as ret, p.pronargs, p.prosrc
    into r
    from pg_proc p where p.oid = to_regprocedure('public.dashboard_summary()');

  if r.prosecdef then raise exception 'post-check: dashboard_summary must be SECURITY INVOKER'; end if;
  if r.provolatile <> 's' then raise exception 'post-check: dashboard_summary must be STABLE'; end if;
  if r.pronargs <> 0 then raise exception 'post-check: dashboard_summary must take no arguments'; end if;
  if r.ret <> 'jsonb' then raise exception 'post-check: unexpected return type %', r.ret; end if;
  if r.proconfig is distinct from array['search_path=public, extensions, pg_temp'] then
    raise exception 'post-check: search_path not pinned as required: %', r.proconfig;
  end if;
  if r.prosrc ~* '\mexecute\M' then raise exception 'post-check: dynamic SQL found in function body'; end if;

  select coalesce(string_agg(coalesce(g.rolname, 'PUBLIC') || ':' || x.privilege_type, ','
                             order by coalesce(g.rolname, 'PUBLIC') collate "C"), '<null>')
    into acl
    from pg_proc p, aclexplode(p.proacl) x left join pg_roles g on g.oid = x.grantee
   where p.oid = to_regprocedure('public.dashboard_summary()');
  if acl <> 'authenticated:EXECUTE,postgres:EXECUTE' then
    raise exception 'post-check: unexpected EXECUTE ACL: %', acl;
  end if;
  if has_function_privilege('anon', 'public.dashboard_summary()', 'execute')
     or has_function_privilege('service_role', 'public.dashboard_summary()', 'execute') then
    raise exception 'post-check: anon / service_role must not have EXECUTE';
  end if;
  raise notice 'Phase 3.2 dashboard_summary() created and verified: INVOKER, STABLE, search_path pinned, EXECUTE = authenticated only';
end
$post$;
