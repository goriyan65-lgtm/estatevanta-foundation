-- =====================================================================
-- EstateVanta CRM — 0008_system_config.sql
-- MINIMUM SYSTEM CONFIGURATION ONLY. No leads, buyers, sellers, properties,
-- deals, payments, market data, users or analytics are inserted here.
-- Everything below is editable later from Settings (is_system rows can be
-- deactivated but not deleted).
-- =====================================================================

-- ---------------------------------------------------------------------
-- Roles
-- ---------------------------------------------------------------------
insert into roles (code, label, is_system) values
  ('admin',   'Admin',   true),
  ('manager', 'Manager', true),
  ('agent',   'Agent',   true),
  ('viewer',  'Viewer',  true);

-- ---------------------------------------------------------------------
-- Permissions  (<module>.<action>)
--   read      = rows assigned to / created by the caller
--   read_all  = every row in the module
-- ---------------------------------------------------------------------
insert into permissions (code, description)
select m || '.' || a, initcap(replace(a,'_',' ')) || ' — ' || m
from unnest(array['leads','buyers','sellers','contacts','properties','appointments',
                  'tasks','deals','finance','matching','market','imports','messaging'])  as m,
     unnest(array['read','read_all','write','delete']) as a;

insert into permissions (code, description) values
  ('activities.read_all', 'Read every activity/timeline entry'),
  ('activities.write',    'Log activities'),
  ('analytics.read',      'View analytics'),
  ('audit.read',          'View the audit log'),
  ('users.manage',        'Manage users, roles and role permissions'),
  ('settings.manage',     'Manage settings and reference lists');

-- ---------------------------------------------------------------------
-- Default role → permission grants (configurable later in Settings)
-- ---------------------------------------------------------------------
-- Admin: everything
insert into role_permissions (role_id, permission_id)
select r.id, p.id from roles r cross join permissions p where r.code = 'admin';

-- Manager: CRM, properties, appointments, tasks, deals, finance, matching,
-- market, imports, messaging, analytics (no users/settings/audit)
insert into role_permissions (role_id, permission_id)
select r.id, p.id from roles r join permissions p
  on p.code ~ '^(leads|buyers|sellers|contacts|properties|appointments|tasks|deals|finance|matching|market|imports|messaging)\.'
  or p.code in ('activities.read_all','activities.write','analytics.read')
where r.code = 'manager';

-- Agent: assigned records only (no *_all), no finance/imports/settings
insert into role_permissions (role_id, permission_id)
select r.id, p.id from roles r join permissions p on p.code in (
  'leads.read','leads.write','buyers.read','buyers.write','sellers.read','sellers.write',
  'contacts.read','contacts.write','properties.read','properties.write',
  'appointments.read','appointments.write','tasks.read','tasks.write',
  'deals.read','matching.read','activities.write')
where r.code = 'agent';

-- Viewer: read-only across operational modules (no finance, imports, messaging, audit)
insert into role_permissions (role_id, permission_id)
select r.id, p.id from roles r join permissions p on p.code in (
  'leads.read_all','buyers.read_all','sellers.read_all','contacts.read_all',
  'properties.read_all','appointments.read_all','tasks.read_all','deals.read_all',
  'matching.read_all','market.read_all','market.read','activities.read_all','analytics.read')
where r.code = 'viewer';

-- ---------------------------------------------------------------------
-- Lead statuses (from the specification)
-- ---------------------------------------------------------------------
insert into lead_statuses (code, label, sort_order, is_terminal, is_system) values
  ('new',                    'New',                     10, false, true),
  ('contacted',              'Contacted',               20, false, true),
  ('qualified',              'Qualified',               30, false, true),
  ('requirement_captured',   'Requirement Captured',    40, false, true),
  ('property_matched',       'Property Matched',        50, false, true),
  ('site_visit_scheduled',   'Site Visit Scheduled',    60, false, true),
  ('site_visit_completed',   'Site Visit Completed',    70, false, true),
  ('negotiation',            'Negotiation',             80, false, true),
  ('deal_won',               'Deal Won',                90, true,  true),
  ('deal_lost',              'Deal Lost',              100, true,  true),
  ('follow_up',              'Follow-up',               85, false, true);

-- Lead sources
insert into lead_sources (code, label, sort_order, is_system) values
  ('website','Website',10,true), ('phone_call','Phone Call',20,true), ('walk_in','Walk-in',30,true),
  ('owner_direct','Owner Direct',40,true), ('whatsapp','WhatsApp',50,true), ('instagram','Instagram',60,true),
  ('facebook','Facebook',70,true), ('google','Google',80,true), ('referral','Referral',90,true),
  ('99acres','99acres',100,true), ('magicbricks','MagicBricks',110,true), ('housing_com','Housing.com',120,true),
  ('other','Other',999,true);

-- Property types
insert into property_types (code, label, sort_order, is_system) values
  ('independent_house','Independent House',10,true), ('villa','Villa',20,true),
  ('flat_apartment','Flat / Apartment',30,true), ('plot','Plot',40,true),
  ('commercial_shop','Commercial Shop',50,true), ('office','Office',60,true),
  ('showroom','Showroom',70,true), ('warehouse','Warehouse',80,true),
  ('industrial_property','Industrial Property',90,true), ('agricultural_land','Agricultural Land',100,true),
  ('farm_house','Farm House',110,true), ('other','Other',999,true);

-- Area units. Universal conversions only. Regional units (marla, kanal, bigha)
-- are created WITHOUT a factor: the owner must enter the correct local value
-- in Settings before area-based matching can use them.
insert into area_units (code, label, sq_ft_factor, is_system) values
  ('sq_ft','Square Feet',1,true),
  ('sq_yd','Square Yard (Gaj)',9,true),
  ('sq_m','Square Metre',10.763910,true),
  ('acre','Acre',43560,true),
  ('marla','Marla',null,true),
  ('kanal','Kanal',null,true),
  ('bigha','Bigha',null,true);

-- ---------------------------------------------------------------------
-- Default matching configuration (editable; weights total 100)
-- ---------------------------------------------------------------------
with cfg as (
  insert into matching_configs (name, version, is_active, notes)
  values ('Default rule-based matching', 1, false,
          'Internal rule-based score. Not an objective valuation. Edit by creating a new version.')
  returning id
)
insert into matching_weights (config_id, criterion, weight)
select cfg.id, w.criterion::match_criterion, w.weight
from cfg, (values ('budget',30),('location',25),('property_type',15),
                  ('area',10),('bhk',10),('preferences',10)) as w(criterion, weight);

update matching_configs set is_active = true where name = 'Default rule-based matching' and version = 1;

-- ---------------------------------------------------------------------
-- Settings (defaults; owner can change)
-- ---------------------------------------------------------------------
insert into settings (key, value, description) values
  ('app.timezone',               '"Asia/Kolkata"'::jsonb, 'Display timezone'),
  ('app.currency',               '"INR"'::jsonb,          'Currency code'),
  ('property.reverify_days',     '90'::jsonb,             'Days after which an active listing needs re-verification (default; change as needed)'),
  ('duplicates.match_fields',    '["phone","whatsapp","email"]'::jsonb, 'Fields checked for duplicate people'),
  ('leads.hot_priorities',       '["high","urgent"]'::jsonb, 'Priorities counted as Hot Leads on the dashboard (to be confirmed by owner)'),
  ('company.name',               '"EstateVanta"'::jsonb,  'Business name'),
  ('company.tagline',            '"Find Your Place. Build Your Future."'::jsonb, 'Tagline');
