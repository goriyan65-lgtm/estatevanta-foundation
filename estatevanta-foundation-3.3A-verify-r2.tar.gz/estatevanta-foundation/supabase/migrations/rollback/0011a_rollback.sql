-- Rollback for 0011a_phase3_step0_function_hardening.sql (never run live; validated on scratch copies only).
-- ONE statement (DO block) => atomic. Stops without changes if any of the 10 functions is missing.
-- Restores the exact pre-3.0 state captured on the live project on 2026-10-04:
--   * no function-level search_path on the 10 functions
--   * apply_*: EXECUTE for PUBLIC, authenticated, service_role (+ owner postgres)
do $m$
declare r record; acl_now text;
begin
  perform set_config('lock_timeout', '5s', true);
  for r in select unnest(array[
      'app.guard_profile_privileges()', 'app.guard_soft_delete()', 'app.set_updated_at()', 'app.enforce_active_weights()',
      'app.next_code(text,regclass)', 'app.bootstrap_first_admin(uuid)', 'public.find_contact_matches(text,text,text)',
      'app.apply_child_policies(text,text,text,text,text)', 'app.apply_global_policies(text,text)', 'app.apply_scoped_policies(text,text,text)']) as sig
  loop
    if to_regprocedure(r.sig) is null then
      raise exception 'Rollback precondition failed: function % does not exist', r.sig using errcode = '55000';
    end if;
  end loop;

  alter function app.guard_profile_privileges()                         reset search_path;
  alter function app.guard_soft_delete()                                reset search_path;
  alter function app.set_updated_at()                                   reset search_path;
  alter function app.enforce_active_weights()                           reset search_path;
  alter function app.next_code(text, regclass)                          reset search_path;
  alter function app.bootstrap_first_admin(uuid)                        reset search_path;
  alter function public.find_contact_matches(text, text, text)          reset search_path;
  alter function app.apply_child_policies(text, text, text, text, text) reset search_path;
  alter function app.apply_global_policies(text, text)                  reset search_path;
  alter function app.apply_scoped_policies(text, text, text)            reset search_path;

  grant execute on function app.apply_child_policies(text, text, text, text, text) to public, authenticated, service_role;
  grant execute on function app.apply_global_policies(text, text)                  to public, authenticated, service_role;
  grant execute on function app.apply_scoped_policies(text, text, text)            to public, authenticated, service_role;

  for r in select unnest(array[
      'app.apply_child_policies(text,text,text,text,text)', 'app.apply_global_policies(text,text)', 'app.apply_scoped_policies(text,text,text)']) as sig
  loop
    select string_agg(coalesce(g.rolname, 'PUBLIC') || ':' || a.privilege_type, ','
                      order by coalesce(g.rolname, 'PUBLIC') collate "C", a.privilege_type collate "C")
      into acl_now
      from pg_proc p left join lateral aclexplode(p.proacl) a on true left join pg_roles g on g.oid = a.grantee
     where p.oid = to_regprocedure(r.sig);
    if acl_now is distinct from 'PUBLIC:EXECUTE,authenticated:EXECUTE,postgres:EXECUTE,service_role:EXECUTE' then
      raise exception 'Rollback postcondition failed: ACL of % is %', r.sig, acl_now using errcode = '55000';
    end if;
  end loop;
  if exists (select 1 from pg_proc where oid in (
        to_regprocedure('app.guard_profile_privileges()'), to_regprocedure('app.guard_soft_delete()'), to_regprocedure('app.set_updated_at()'),
        to_regprocedure('app.enforce_active_weights()'), to_regprocedure('app.next_code(text,regclass)'), to_regprocedure('app.bootstrap_first_admin(uuid)'),
        to_regprocedure('public.find_contact_matches(text,text,text)'), to_regprocedure('app.apply_child_policies(text,text,text,text,text)'),
        to_regprocedure('app.apply_global_policies(text,text)'), to_regprocedure('app.apply_scoped_policies(text,text,text)'))
      and proconfig is not null) then
    raise exception 'Rollback postcondition failed: a function still has settings' using errcode = '55000';
  end if;
  raise notice 'Phase 3.0 rolled back and verified';
end
$m$;
