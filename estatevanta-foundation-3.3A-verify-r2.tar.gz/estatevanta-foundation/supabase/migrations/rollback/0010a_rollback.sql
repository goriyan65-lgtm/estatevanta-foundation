-- =====================================================================
-- ROLLBACK for 0010a (Step 1).  DO NOT RUN unless the owner decides to undo Step 1.
-- Single script = single implicit transaction.
-- Before running, export audit rows with the new action types if you want to keep them:
--   select * from audit_logs where action in ('login','logout','login_failed','access_denied','invite','bootstrap_admin');
-- NOTE: roll back 0010c and 0010b first if they were applied (reverse order).
-- =====================================================================
drop function if exists public.security_log_event(text, uuid, jsonb);
drop function if exists public.my_access();

-- Original ACL of find_contact_matches was {=X/postgres, anon, authenticated, service_role} (weaker).
-- Restored only for a faithful rollback. PREFER NOT to run this line.
grant execute on function public.find_contact_matches(text, text, text) to public, anon, authenticated, service_role;

delete from audit_logs where action in ('login','logout','login_failed','access_denied','invite','bootstrap_admin');
alter table audit_logs drop constraint audit_logs_action_check;
alter table audit_logs add constraint audit_logs_action_check
  check (action = any (array['insert','update','delete','soft_delete','restore']));
