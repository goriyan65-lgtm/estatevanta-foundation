-- =====================================================================
-- ROLLBACK for 0010b (Step 2).  DO NOT RUN unless the owner decides to undo Step 2.
-- Removes the secure bootstrap and restores the ORIGINAL one-argument function body
-- (captured live on 2026-10-03 before Phase 2).  The original function is SECURITY DEFINER and
-- has no secret: after this rollback, keep it revoked from every API role (done below).
-- If bootstrap was already consumed, the audit row ('bootstrap_admin') stays in audit_logs.
-- =====================================================================
drop function if exists app.bootstrap_first_admin(uuid, text);
drop function if exists app.arm_bootstrap(text, text, int);
drop table    if exists app.bootstrap_setup;

CREATE OR REPLACE FUNCTION app.bootstrap_first_admin(target_user uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if exists (select 1 from profiles p join roles r on r.id = p.role_id
             where r.code = 'admin' and p.is_active) then
    raise exception 'An active admin already exists';
  end if;
  update profiles
     set role_id = (select id from roles where code = 'admin'), is_active = true
   where id = target_user;
  if not found then raise exception 'No profile for user %', target_user; end if;
end $function$;
revoke all on function app.bootstrap_first_admin(uuid) from public, anon, authenticated, service_role;
