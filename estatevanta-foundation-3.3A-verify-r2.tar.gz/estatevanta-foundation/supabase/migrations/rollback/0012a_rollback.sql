-- =====================================================================
-- Rollback for 0012a_phase3_step2_dashboard_summary.sql
-- Drops ONLY public.dashboard_summary(). Nothing else was changed by 0012a, so nothing else is touched.
-- Do not run automatically; run only on explicit instruction.
-- =====================================================================
drop function if exists public.dashboard_summary();

do $chk$
begin
  if to_regprocedure('public.dashboard_summary()') is not null then
    raise exception 'rollback failed: dashboard_summary() still exists';
  end if;
  raise notice 'dashboard_summary() removed; database is back to the Phase 3.0 state';
end
$chk$;
