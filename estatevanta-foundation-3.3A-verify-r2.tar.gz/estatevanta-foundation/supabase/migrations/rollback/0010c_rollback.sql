-- =====================================================================
-- ROLLBACK for 0010c (Step 3).  Only relevant AFTER Step 3 has been applied (it has NOT been).
-- Lockout recovery without a rollback: alter table profiles disable trigger protect_last_admin; (fix row);
-- alter table profiles enable trigger protect_last_admin;
-- =====================================================================
drop trigger if exists protect_admin_permissions on role_permissions;
drop trigger if exists protect_system_roles      on roles;
drop trigger if exists protect_last_admin        on profiles;
drop function if exists app.protect_admin_permissions();
drop function if exists app.protect_system_roles();
drop function if exists app.protect_last_admin();

-- original guard (captured live before Phase 2)
CREATE OR REPLACE FUNCTION app.guard_profile_privileges()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
begin
  if auth.uid() is null then return new; end if;
  if (new.role_id is distinct from old.role_id or new.is_active is distinct from old.is_active)
     and not app.can('users.manage') then
    raise exception 'permission denied: users.manage required to change role or activation' using errcode='42501';
  end if;
  return new;
end $function$;
