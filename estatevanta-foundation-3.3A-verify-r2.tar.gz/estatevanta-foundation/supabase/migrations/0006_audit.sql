-- =====================================================================
-- EstateVanta CRM — 0006_audit.sql
-- One generic trigger writes to audit_logs for every audited table.
-- Append-only: no UPDATE/DELETE grants; RLS limits reads to admin/manager.
-- =====================================================================

create table audit_logs (
  id             bigint generated always as identity primary key,
  occurred_at    timestamptz not null default now(),
  actor_id       uuid,                          -- auth.uid(); NULL = system / service role
  actor_context  text,                          -- 'api' | 'import' | 'job:<name>' (set via app.actor_context)
  action         text not null check (action in ('insert','update','delete','soft_delete','restore')),
  entity_table   text not null,
  entity_id      text,                          -- text so composite/text keys (settings.key) fit
  changed_fields text[],                        -- for updates: which columns changed
  old_values     jsonb,
  new_values     jsonb,
  request_id     text                           -- correlation id from the API layer (optional)
);
create index audit_logs_entity_idx  on audit_logs(entity_table, entity_id, occurred_at desc);
create index audit_logs_actor_idx   on audit_logs(actor_id, occurred_at desc);
create index audit_logs_time_brin   on audit_logs using brin (occurred_at);
create index audit_logs_fields_idx  on audit_logs using gin (changed_fields);
-- Growth note: if volume warrants, convert to monthly range partitions later.

create or replace function app.audit_row() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  pk_col   text := coalesce(tg_argv[0], 'id');
  old_j    jsonb;
  new_j    jsonb;
  changed  text[];
  act      text;
  noise    text[] := array['updated_at'];
  eid      text;
begin
  if tg_op = 'INSERT' then
    new_j := to_jsonb(new); act := 'insert'; eid := new_j ->> pk_col;
  elsif tg_op = 'DELETE' then
    old_j := to_jsonb(old); act := 'delete'; eid := old_j ->> pk_col;
  else
    old_j := to_jsonb(old); new_j := to_jsonb(new); eid := new_j ->> pk_col;
    select array_agg(k order by k) into changed
    from jsonb_object_keys(new_j) k
    where k <> all (noise) and (old_j -> k) is distinct from (new_j -> k);
    if changed is null then return null; end if;      -- nothing meaningful changed
    act := case
      when old_j ? 'deleted_at' and old_j->>'deleted_at' is null and new_j->>'deleted_at' is not null then 'soft_delete'
      when old_j ? 'deleted_at' and old_j->>'deleted_at' is not null and new_j->>'deleted_at' is null then 'restore'
      else 'update' end;
    -- store only the changed columns to keep the log small
    old_j := (select jsonb_object_agg(k, old_j -> k) from unnest(changed) k);
    new_j := (select jsonb_object_agg(k, new_j -> k) from unnest(changed) k);
  end if;

  insert into audit_logs(actor_id, actor_context, action, entity_table, entity_id,
                         changed_fields, old_values, new_values, request_id)
  values (auth.uid(),
          nullif(current_setting('app.actor_context', true), ''),
          act, tg_table_name,
          eid,
          changed, old_j, new_j,
          nullif(current_setting('app.request_id', true), ''));
  return null;
end $$;

-- Attach to every table whose changes matter. Second arg = primary-key column.
do $$
declare
  t record;
begin
  for t in
    select * from (values
      ('profiles','id'),('roles','id'),('role_permissions','role_id'),
      ('contacts','id'),('duplicate_candidates','id'),
      ('leads','id'),('buyers','id'),('sellers','id'),
      ('properties','id'),('property_owner_terms','property_id'),
      ('property_media','id'),('property_documents','id'),
      ('buyer_requirements','id'),
      ('matching_configs','id'),('matching_weights','config_id'),
      ('appointments','id'),('site_visits','appointment_id'),
      ('tasks','id'),
      ('deals','id'),('deal_documents','id'),('commissions','id'),('payments','id'),
      ('market_data','id'),('import_batches','id'),('settings','key')
    ) as v(tbl, pk)
  loop
    execute format(
      'create trigger audit_%1$s after insert or update or delete on %1$I
         for each row execute function app.audit_row(%2$L)', t.tbl, t.pk);
  end loop;
end $$;

-- Append-only enforcement (belt and braces on top of RLS)
revoke update, delete, truncate on audit_logs from public, anon, authenticated;
