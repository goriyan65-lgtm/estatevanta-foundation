-- =====================================================================
-- EstateVanta CRM — 0010c_phase2_step3_admin_protection.sql
-- Phase 2 / Step 3.  STATUS: approved by the owner 2026-10-04; applied to "Estate vanta crm"
-- (bmvozgfjrvdrfdhvfray) only, as migration estatevanta_p2_step3_admin_protection.
-- Adds: soft-delete guard on profiles, last-admin protection (database-level, concurrency
-- safe), system-role and admin-permission immutability.
-- Rollback: rollback/0010c_rollback.sql
-- =====================================================================
-- 6. Profile privilege guard now also covers soft-delete ---------------------
create or replace function app.guard_profile_privileges() returns trigger
language plpgsql as $$
begin
  if auth.uid() is null then return new; end if;            -- server / SQL-editor context
  if (new.role_id is distinct from old.role_id
      or new.is_active is distinct from old.is_active
      or new.deleted_at is distinct from old.deleted_at)
     and not app.can('users.manage') then
    raise exception 'permission denied: users.manage required to change role, activation or deletion'
      using errcode = '42501';
  end if;
  return new;
end $$;

-- 7. LAST-ADMIN PROTECTION, enforced in the database ---------------------------
-- Any change that would take an active admin out of the admin set (demote,
-- deactivate, soft-delete, delete) first takes a global advisory lock, then
-- counts the remaining admins with a fresh READ COMMITTED snapshot. Two
-- concurrent transactions therefore queue up and the second sees the first's
-- committed result. Other isolation levels are refused (stale snapshots).
create or replace function app.protect_last_admin() returns trigger
language plpgsql security definer set search_path = public as $$
declare was_admin boolean; still_admin boolean; others int;
begin
  select (exists (select 1 from roles r where r.id = old.role_id and r.code = 'admin')
          and old.is_active and old.deleted_at is null) into was_admin;
  if tg_op = 'DELETE' then
    still_admin := false;
  else
    select (exists (select 1 from roles r where r.id = new.role_id and r.code = 'admin')
            and new.is_active and new.deleted_at is null) into still_admin;
  end if;
  if was_admin and not still_admin then
    perform pg_advisory_xact_lock(hashtext('estatevanta.admin_set'));
    if current_setting('transaction_isolation') <> 'read committed' then
      raise exception 'Admin changes require READ COMMITTED isolation' using errcode = '55000';
    end if;
    select count(*) into others from profiles p join roles r on r.id = p.role_id
     where r.code = 'admin' and p.is_active and p.deleted_at is null and p.id <> old.id;
    if others = 0 then
      raise exception 'Cannot remove, demote or deactivate the last active admin' using errcode = '55000';
    end if;
  end if;
  if tg_op = 'DELETE' then return old; end if;
  return new;
end $$;
create trigger protect_last_admin before update or delete on profiles
  for each row execute function app.protect_last_admin();

-- 8. System roles and the admin's permissions are immutable ---------------------
create or replace function app.protect_system_roles() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'DELETE' and old.is_system then
    raise exception 'System roles cannot be deleted' using errcode = '55000';
  end if;
  if tg_op = 'UPDATE' and old.is_system
     and (new.code is distinct from old.code or new.is_system is distinct from old.is_system) then
    raise exception 'System role code/flag cannot be changed' using errcode = '55000';
  end if;
  if tg_op = 'DELETE' then return old; end if;
  return new;
end $$;
create trigger protect_system_roles before update or delete on roles
  for each row execute function app.protect_system_roles();

create or replace function app.protect_admin_permissions() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if exists (select 1 from roles r where r.id = old.role_id and r.code = 'admin') then
    if tg_op = 'UPDATE' and new.role_id = old.role_id and new.permission_id = old.permission_id then
      return new;
    end if;
    raise exception 'Admin permissions cannot be removed or reassigned' using errcode = '55000';
  end if;
  if tg_op = 'DELETE' then return old; end if;
  return new;
end $$;
create trigger protect_admin_permissions before update or delete on role_permissions
  for each row execute function app.protect_admin_permissions();

revoke all on function app.protect_last_admin()        from public, anon, authenticated, service_role;
revoke all on function app.protect_system_roles()      from public, anon, authenticated, service_role;
revoke all on function app.protect_admin_permissions() from public, anon, authenticated, service_role;
