-- =====================================================================
-- Phase 2 / Step 2 — disable the old bootstrap, then create the secure one.
-- STATUS: APPLIED to "Estate vanta crm" exactly as written (migration estatevanta_p2_step2_bootstrap).
-- Rollback: rollback/0010b_rollback.sql
-- Contains NO DROP statements. Single atomic migration.
-- Applies on top of Step 1 (already applied). Does not touch Phase 1 data.
-- =====================================================================

-- A. DISABLE the old secret-less function (same signature, body replaced).
--    SECURITY INVOKER, so it can never act with owner rights; it only raises.
create or replace function app.bootstrap_first_admin(target_user uuid) returns void
language plpgsql security invoker as $$
begin
  raise exception 'Disabled: use app.arm_bootstrap() and app.bootstrap_first_admin(uuid, text)'
    using errcode = '55000';
end $$;

-- B. REVOKE every non-owner privilege on it.
revoke all on function app.bootstrap_first_admin(uuid) from public, anon, authenticated, service_role;

-- C. ASSERT the old function is really disabled BEFORE creating the new mechanism.
--    If any check fails the whole migration aborts and nothing is created.
do $$
declare f oid := 'app.bootstrap_first_admin(uuid)'::regprocedure;
begin
  if (select prosecdef from pg_proc where oid = f) then
    raise exception 'old bootstrap is still SECURITY DEFINER';
  end if;
  if has_function_privilege('anon', f, 'EXECUTE')
     or has_function_privilege('authenticated', f, 'EXECUTE')
     or has_function_privilege('service_role', f, 'EXECUTE') then
    raise exception 'old bootstrap is still executable by an API role';
  end if;
  if pg_get_functiondef(f) not like '%Disabled: use app.arm_bootstrap%' then
    raise exception 'old bootstrap body was not replaced';
  end if;
  if exists (select 1 from aclexplode(coalesce((select proacl from pg_proc where oid = f),
                                               acldefault('f', (select proowner from pg_proc where oid = f)))) a
             where a.grantee = 0) then
    raise exception 'old bootstrap is still executable by PUBLIC';
  end if;
end $$;

-- D. New one-time setup state (single row). RLS on, no policies, no grants.
create table app.bootstrap_setup (
  singleton    boolean primary key default true check (singleton),
  secret_hash  text not null,
  target_email citext not null,
  armed_at     timestamptz not null default now(),
  expires_at   timestamptz not null,
  consumed_at  timestamptz,
  consumed_by  uuid
);
alter table app.bootstrap_setup enable row level security;
revoke all on app.bootstrap_setup from public, anon, authenticated, service_role;

-- E. Step A of setup: arm (owner only). Needs a secret (>= 20 chars), the exact
--    email expected, and a validity window. Only the SHA-256 of the secret is stored.
create function app.arm_bootstrap(p_secret text, p_target_email text, p_valid_minutes int default 60)
returns timestamptz language plpgsql security definer set search_path = public as $$
declare st app.bootstrap_setup; v_exp timestamptz;
begin
  perform pg_advisory_xact_lock(hashtext('estatevanta.bootstrap'));
  if p_secret is null or length(p_secret) < 20 then
    raise exception 'Setup secret must be at least 20 characters' using errcode = '22023';
  end if;
  if p_target_email is null or position('@' in p_target_email) = 0 then
    raise exception 'A valid expected email is required' using errcode = '22023';
  end if;
  if p_valid_minutes is null or p_valid_minutes not between 5 and 1440 then
    raise exception 'Validity must be between 5 and 1440 minutes' using errcode = '22023';
  end if;
  if exists (select 1 from profiles p join roles r on r.id = p.role_id
             where r.code = 'admin' and p.is_active and p.deleted_at is null) then
    raise exception 'An active admin already exists' using errcode = '55000';
  end if;
  select * into st from app.bootstrap_setup where singleton for update;
  if found and st.consumed_at is not null then
    raise exception 'Bootstrap has already been completed' using errcode = '55000';
  end if;
  v_exp := now() + make_interval(mins => p_valid_minutes);
  insert into app.bootstrap_setup(singleton, secret_hash, target_email, armed_at, expires_at)
  values (true, encode(sha256(convert_to(p_secret, 'UTF8')), 'hex'), p_target_email, now(), v_exp)
  on conflict (singleton) do update
     set secret_hash = excluded.secret_hash, target_email = excluded.target_email,
         armed_at = excluded.armed_at, expires_at = excluded.expires_at;
  return v_exp;
end $$;

-- F. Step B of setup: consume (owner only). Requires armed + unexpired + unconsumed +
--    no admin yet + correct secret + confirmed email equal to the armed email.
--    Serialised by an advisory lock and a row lock; the first success consumes the
--    window and wipes the secret hash, so a concurrent or later call always fails.
create function app.bootstrap_first_admin(target_user uuid, p_secret text) returns void
language plpgsql security definer set search_path = public as $$
declare st app.bootstrap_setup; v_email text; v_confirmed timestamptz;
begin
  perform pg_advisory_xact_lock(hashtext('estatevanta.bootstrap'));
  select * into st from app.bootstrap_setup where singleton for update;
  if not found then raise exception 'Bootstrap is not armed' using errcode = '55000'; end if;
  if st.consumed_at is not null then raise exception 'Bootstrap has already been completed' using errcode = '55000'; end if;
  if exists (select 1 from profiles p join roles r on r.id = p.role_id
             where r.code = 'admin' and p.is_active and p.deleted_at is null) then
    raise exception 'An active admin already exists' using errcode = '55000';
  end if;
  if st.expires_at < now() then raise exception 'Bootstrap window has expired' using errcode = '55000'; end if;
  if p_secret is null or st.secret_hash <> encode(sha256(convert_to(p_secret, 'UTF8')), 'hex') then
    raise exception 'Invalid setup secret' using errcode = '28000';
  end if;
  select email, email_confirmed_at into v_email, v_confirmed from auth.users where id = target_user;
  if not found then raise exception 'No auth user %', target_user using errcode = '55000'; end if;
  if v_email is null or lower(v_email) <> lower(st.target_email::text) then
    raise exception 'User email does not match the armed email' using errcode = '55000';
  end if;
  if v_confirmed is null then raise exception 'The user''s email must be confirmed' using errcode = '55000'; end if;
  update profiles
     set role_id = (select id from roles where code = 'admin'), is_active = true, deleted_at = null
   where id = target_user;
  if not found then raise exception 'No profile for user %', target_user using errcode = '55000'; end if;
  update app.bootstrap_setup
     set consumed_at = now(), consumed_by = target_user, secret_hash = repeat('0', 64)
   where singleton;
  insert into audit_logs(actor_id, actor_context, action, entity_table, entity_id, new_values)
  values (null, 'bootstrap', 'bootstrap_admin', 'security', target_user::text,
          jsonb_build_object('email', v_email));
end $$;

-- G. Owner-only: no API role can execute either new function.
revoke all on function app.arm_bootstrap(text, text, int)       from public, anon, authenticated, service_role;
revoke all on function app.bootstrap_first_admin(uuid, text)    from public, anon, authenticated, service_role;
