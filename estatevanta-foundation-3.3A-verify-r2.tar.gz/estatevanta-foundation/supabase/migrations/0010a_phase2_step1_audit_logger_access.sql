-- =====================================================================
-- EstateVanta CRM — 0010a_phase2_step1_audit_logger_access.sql
-- Phase 2 / Step 1.  STATUS: APPLIED to "Estate vanta crm" (migration
-- estatevanta_p2_step1_audit_logger_access).  Additive; no policies/tables changed.
-- Rollback: rollback/0010a_rollback.sql
-- =====================================================================
-- 1. Audit vocabulary ---------------------------------------------------
alter table audit_logs drop constraint audit_logs_action_check;
alter table audit_logs add constraint audit_logs_action_check check (action in (
  'insert','update','delete','soft_delete','restore',
  'login','logout','login_failed','access_denied','invite','bootstrap_admin'));

-- 2. Server-only security logger (service_role ONLY) ---------------------
-- Browsers/anon/authenticated cannot execute it, so they cannot forge events.
-- The server passes the actor id it has verified from the session; the function
-- re-validates event type, actor existence/state, and the shape of the detail.
create or replace function public.security_log_event(
  p_action text, p_actor uuid default null, p_detail jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if p_action is null or p_action not in ('login','logout','login_failed','access_denied','invite') then
    raise exception 'unsupported security event %', p_action using errcode = '22023';
  end if;
  if p_detail is null or jsonb_typeof(p_detail) <> 'object' or length(p_detail::text) > 2000 then
    raise exception 'event detail must be a JSON object under 2000 characters' using errcode = '22023';
  end if;
  if exists (select 1 from jsonb_object_keys(p_detail) k
             where k <> all (array['ip','user_agent','email','path','reason','request_id','method'])) then
    raise exception 'event detail contains unsupported keys' using errcode = '22023';
  end if;
  if p_action = 'login_failed' and p_actor is not null then
    raise exception 'login_failed events cannot carry an actor identity' using errcode = '22023';
  end if;
  if p_action in ('login','logout','invite') and p_actor is null then
    raise exception '% events require an actor', p_action using errcode = '22023';
  end if;
  if p_actor is not null and not exists
       (select 1 from profiles where id = p_actor and deleted_at is null) then
    raise exception 'unknown actor' using errcode = '22023';
  end if;
  if p_action in ('login','invite') and not exists
       (select 1 from profiles where id = p_actor and is_active) then
    raise exception 'actor is not an active user' using errcode = '22023';
  end if;
  if p_action = 'login' and not exists (
       select 1 from auth.users where id = p_actor and last_sign_in_at > now() - interval '5 minutes') then
    raise exception 'no recent sign-in recorded for this actor' using errcode = '22023';
  end if;
  if p_action = 'invite' and not exists (
       select 1 from profiles p join role_permissions rp on rp.role_id = p.role_id
       join permissions pm on pm.id = rp.permission_id
       where p.id = p_actor and pm.code = 'users.manage') then
    raise exception 'actor may not invite users' using errcode = '22023';
  end if;
  insert into audit_logs(actor_id, actor_context, action, entity_table, entity_id, new_values)
  values (p_actor, 'api', p_action, 'security', coalesce(p_actor::text, 'anonymous'), p_detail);
end $$;
revoke all on function public.security_log_event(text, uuid, jsonb) from public, anon, authenticated;
grant execute on function public.security_log_event(text, uuid, jsonb) to service_role;

-- 3. my_access(): SECURITY INVOKER => RLS applies; no parameters => caller's own data only
create or replace function public.my_access() returns jsonb
language sql stable security invoker set search_path = public as $$
  select jsonb_build_object(
    'user_id', p.id, 'full_name', p.full_name, 'role', r.code, 'is_active', p.is_active,
    'permissions', coalesce((select jsonb_agg(pm.code order by pm.code)
                             from role_permissions rp join permissions pm on pm.id = rp.permission_id
                             where rp.role_id = p.role_id and p.is_active), '[]'::jsonb))
  from profiles p left join roles r on r.id = p.role_id
  where p.id = auth.uid() and p.deleted_at is null
$$;
revoke all on function public.my_access() from public, anon, authenticated, service_role;
grant execute on function public.my_access() to authenticated;

-- 4. find_contact_matches: authenticated (admin UI) + service_role (website intake) only
revoke all on function public.find_contact_matches(text, text, text) from public, anon, authenticated, service_role;
grant execute on function public.find_contact_matches(text, text, text) to authenticated, service_role;
