-- =====================================================================
-- EstateVanta CRM — 0001_foundation.sql
-- Extensions, enums, helpers, reference tables, auth profile + RBAC.
-- NO DEMO DATA. System configuration lives in 0008_system_config.sql.
-- Target: PostgreSQL 15+ (Supabase). Not yet executed against a live DB.
-- =====================================================================

create extension if not exists pgcrypto;
create extension if not exists citext;
create extension if not exists pg_trgm;

create schema if not exists app;      -- helper functions, sequences (not exposed via API)

-- ---------------------------------------------------------------------
-- ENUM STRATEGY
-- Postgres ENUMs  = stable lifecycle states the code branches on.
-- Reference tables = business-configurable lists (statuses, sources,
--                    property types, area units, amenities).
-- ---------------------------------------------------------------------
create type lead_type            as enum ('buy','sell','rent','invest');
create type priority_level       as enum ('low','medium','high','urgent');
create type transaction_type     as enum ('sale','rent','lease');
create type property_status      as enum ('available','reserved','under_negotiation','sold','rented','inactive');
create type furnishing_type      as enum ('unfurnished','semi_furnished','furnished');
create type facing_direction     as enum ('north','south','east','west','north_east','north_west','south_east','south_west');
create type construction_status  as enum ('ready_to_move','under_construction','not_applicable');
create type inventory_source     as enum ('owner_direct','broker','developer','existing_database','external_authorized_import','other');
create type verification_status  as enum ('unverified','pending','verified','rejected');
create type ownership_doc_status as enum ('not_collected','collected','under_review','verified','disputed');
create type exclusivity_type     as enum ('exclusive','non_exclusive');
create type brokerage_type       as enum ('percentage','fixed','none');
create type media_kind           as enum ('image','video','floor_plan');
create type document_category    as enum ('ownership','identity','agreement','tax','utility','other');
create type seller_relationship  as enum ('new','contacted','active_client','repeat_client','inactive','blacklisted');
create type financing_status     as enum ('cash','loan_approved','loan_in_process','loan_needed','undecided');
create type purchase_timeline    as enum ('immediate','within_1_month','one_to_three_months','three_to_six_months','over_six_months','undecided');
create type purpose_type         as enum ('self_use','investment','both');
create type requirement_status   as enum ('active','on_hold','fulfilled','closed');
create type importance_level     as enum ('must_have','nice_to_have');
create type match_status         as enum ('suggested','shared','interested','rejected','visited','dismissed');
create type match_criterion      as enum ('budget','location','property_type','area','bhk','preferences');
create type appointment_type     as enum ('site_visit','call','meeting','follow_up');
create type appointment_status   as enum ('scheduled','confirmed','completed','rescheduled','cancelled','no_show');
create type interest_level       as enum ('low','medium','high','very_high');
create type task_status          as enum ('pending','in_progress','completed','cancelled');
create type activity_type        as enum ('note','call','whatsapp','email','meeting','site_visit','status_change','system');
create type deal_status          as enum ('negotiation','token','documentation','agreement','registration','closed','cancelled');
create type deal_payment_status  as enum ('unpaid','partial','paid');
create type payment_purpose      as enum ('token','part_payment','final_payment','commission','refund','other');
create type payment_method       as enum ('cash','bank_transfer','upi','cheque','other');
create type payment_record_status as enum ('pending','received','failed','refunded');
create type commission_party     as enum ('buyer','seller');
create type commission_status    as enum ('expected','partially_received','received','waived');
create type market_data_kind     as enum ('asking_price','verified_transaction','estimate','third_party');
create type demand_indicator     as enum ('low','medium','high');
create type import_entity        as enum ('properties','leads','buyers','sellers','market_data');
create type import_format        as enum ('csv','xlsx','json');
create type import_status        as enum ('uploaded','mapped','validated','confirmed','importing','completed','failed','cancelled');
create type import_row_decision  as enum ('pending','import','skip','merge');
create type message_channel      as enum ('in_app','email','whatsapp','sms');
create type message_status       as enum ('queued','sending','sent','delivered','failed','cancelled');
create type duplicate_status     as enum ('pending','same_person','different_person');

-- ---------------------------------------------------------------------
-- HELPERS
-- ---------------------------------------------------------------------
create or replace function app.set_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

-- Human-readable codes (LD-000001, PR-000001 ...). Gaps are acceptable.
create sequence app.lead_code_seq;
create sequence app.buyer_code_seq;
create sequence app.seller_code_seq;
create sequence app.property_code_seq;
create sequence app.deal_code_seq;
create sequence app.requirement_code_seq;

create or replace function app.next_code(prefix text, seq regclass) returns text
language sql volatile as $$
  select prefix || '-' || lpad(nextval(seq)::text, 6, '0')
$$;

-- ---------------------------------------------------------------------
-- REFERENCE TABLES (business-configurable; text code PK = stable FK target)
-- is_system = seeded by the application, cannot be deleted (only deactivated)
-- ---------------------------------------------------------------------
create table lead_statuses (
  code        text primary key,
  label       text not null,
  sort_order  smallint not null default 0,
  is_terminal boolean not null default false,
  is_active   boolean not null default true,
  is_system   boolean not null default false,
  created_at  timestamptz not null default now()
);

create table lead_sources (
  code       text primary key,
  label      text not null,
  sort_order smallint not null default 0,
  is_active  boolean not null default true,
  is_system  boolean not null default false,
  created_at timestamptz not null default now()
);

create table property_types (
  code       text primary key,
  label      text not null,
  sort_order smallint not null default 0,
  is_active  boolean not null default true,
  is_system  boolean not null default false,
  created_at timestamptz not null default now()
);

-- sq_ft_factor is NULL when not configured. Regional units (marla, kanal,
-- bigha) vary by state/locale, so the owner must set them; nothing is assumed.
create table area_units (
  code         text primary key,
  label        text not null,
  sq_ft_factor numeric(14,6) check (sq_ft_factor is null or sq_ft_factor > 0),
  is_active    boolean not null default true,
  is_system    boolean not null default false
);

create table amenities (
  id         uuid primary key default gen_random_uuid(),
  name       citext not null unique,
  is_active  boolean not null default true,
  created_at timestamptz not null default now()
);

create table localities (
  id         uuid primary key default gen_random_uuid(),
  city       text not null,
  name       text not null,
  is_active  boolean not null default true,
  created_at timestamptz not null default now(),
  unique (city, name)
);
create index localities_name_trgm on localities using gin (name gin_trgm_ops);

-- ---------------------------------------------------------------------
-- AUTH: roles, permissions, profiles
-- Passwords/sessions live in Supabase auth.users. Never duplicated here.
-- ---------------------------------------------------------------------
create table roles (
  id          smallint generated always as identity primary key,
  code        text not null unique,          -- admin | manager | agent | viewer (+ custom)
  label       text not null,
  is_system   boolean not null default false,
  created_at  timestamptz not null default now()
);

create table permissions (
  id          smallint generated always as identity primary key,
  code        text not null unique,          -- '<module>.<action>' e.g. leads.read_all
  description text
);

create table role_permissions (
  role_id       smallint not null references roles(id) on delete cascade,
  permission_id smallint not null references permissions(id) on delete cascade,
  primary key (role_id, permission_id)
);

-- A row is created automatically for each auth user (trigger below) but
-- is INACTIVE with NO role until an admin approves it. Public signup can
-- therefore never grant access by itself.
create table profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  full_name   text,
  phone       text,
  role_id     smallint references roles(id),
  is_active   boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  deleted_at  timestamptz
);
create index profiles_role_idx on profiles(role_id) where deleted_at is null;
create trigger profiles_updated_at before update on profiles
  for each row execute function app.set_updated_at();

create or replace function app.handle_new_auth_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', new.email));
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function app.handle_new_auth_user();

-- Permission helpers used by every RLS policy. SECURITY DEFINER so they can
-- read profiles/role_permissions regardless of the caller's own RLS.
create or replace function app.current_role_code() returns text
language sql stable security definer set search_path = public as $$
  select r.code from profiles p join roles r on r.id = p.role_id
  where p.id = auth.uid() and p.is_active and p.deleted_at is null
$$;

create or replace function app.can(perm text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1
    from profiles p
    join role_permissions rp on rp.role_id = p.role_id
    join permissions pm on pm.id = rp.permission_id
    where p.id = auth.uid() and p.is_active and p.deleted_at is null
      and pm.code = perm
  )
$$;

create or replace function app.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(app.current_role_code() = 'admin', false)
$$;

-- One-time bootstrap: promotes the FIRST auth user to admin, only if no
-- active admin exists. Run manually once from the SQL editor.
create or replace function app.bootstrap_first_admin(target_user uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if exists (select 1 from profiles p join roles r on r.id = p.role_id
             where r.code = 'admin' and p.is_active) then
    raise exception 'An active admin already exists';
  end if;
  update profiles
     set role_id = (select id from roles where code = 'admin'), is_active = true
   where id = target_user;
  if not found then raise exception 'No profile for user %', target_user; end if;
end $$;
revoke all on function app.bootstrap_first_admin(uuid) from public, anon, authenticated;
