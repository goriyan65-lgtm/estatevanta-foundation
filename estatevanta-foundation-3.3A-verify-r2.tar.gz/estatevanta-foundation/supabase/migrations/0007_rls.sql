-- =====================================================================
-- EstateVanta CRM — 0007_rls.sql
-- RLS on EVERY table. Default = deny. Access is granted by permission
-- codes (roles → role_permissions → permissions), never by role names
-- hard-coded in policies, so permissions stay configurable.
--
-- Permission naming:  <module>.read | read_all | write | delete
--   read      = see rows assigned to me (or created by me)
--   read_all  = see every row in the module
-- Service-role connections (server jobs) bypass RLS by design and are used
-- only in server-only code; never shipped to the browser.
-- =====================================================================

-- ---------------------------------------------------------------------
-- Generators
-- ---------------------------------------------------------------------
-- Rows scoped to an assignee (agent sees own; manager sees all via read_all)
create or replace function app.apply_scoped_policies(tbl text, module text, assign_col text)
returns void language plpgsql as $$
begin
  execute format('alter table %I enable row level security', tbl);
  execute format($p$create policy %1$s_select on %1$I for select to authenticated using (
      (deleted_at is null or app.is_admin())
      and ( app.can(%2$L) or (app.can(%3$L) and (%4$I = auth.uid() or created_by = auth.uid())) ) )$p$,
      tbl, module||'.read_all', module||'.read', assign_col);
  execute format($p$create policy %1$s_insert on %1$I for insert to authenticated
      with check (app.can(%2$L))$p$, tbl, module||'.write');
  execute format($p$create policy %1$s_update on %1$I for update to authenticated
      using ( app.can(%2$L) and ( app.can(%3$L) or %4$I = auth.uid() or created_by = auth.uid() ) )
      with check ( app.can(%2$L) )$p$, tbl, module||'.write', module||'.read_all', assign_col);
  execute format($p$create policy %1$s_delete on %1$I for delete to authenticated
      using (app.is_admin())$p$, tbl);
end $$;

-- Unscoped module tables (permission only)
create or replace function app.apply_global_policies(tbl text, module text)
returns void language plpgsql as $$
begin
  execute format('alter table %I enable row level security', tbl);
  execute format($p$create policy %1$s_select on %1$I for select to authenticated
      using (app.can(%2$L))$p$, tbl, module||'.read');
  execute format($p$create policy %1$s_insert on %1$I for insert to authenticated
      with check (app.can(%2$L))$p$, tbl, module||'.write');
  execute format($p$create policy %1$s_update on %1$I for update to authenticated
      using (app.can(%2$L)) with check (app.can(%2$L))$p$, tbl, module||'.write');
  execute format($p$create policy %1$s_delete on %1$I for delete to authenticated
      using (app.is_admin())$p$, tbl);
end $$;

-- Child tables: visible/writable only if the parent row is visible to the caller
-- (the EXISTS subquery is itself filtered by the parent's RLS).
create or replace function app.apply_child_policies(tbl text, module text, parent text, fk text, parent_pk text default 'id')
returns void language plpgsql as $$
begin
  execute format('alter table %I enable row level security', tbl);
  execute format($p$create policy %1$s_select on %1$I for select to authenticated
      using ( (app.can(%2$L) or app.can(%3$L)) and exists (select 1 from %4$I par where par.%5$I = %1$I.%6$I) )$p$,
      tbl, module||'.read', module||'.read_all', parent, parent_pk, fk);
  execute format($p$create policy %1$s_insert on %1$I for insert to authenticated
      with check ( app.can(%2$L) and exists (select 1 from %3$I par where par.%4$I = %1$I.%5$I) )$p$,
      tbl, module||'.write', parent, parent_pk, fk);
  execute format($p$create policy %1$s_update on %1$I for update to authenticated
      using ( app.can(%2$L) and exists (select 1 from %3$I par where par.%4$I = %1$I.%5$I) )
      with check ( app.can(%2$L) )$p$, tbl, module||'.write', parent, parent_pk, fk);
  execute format($p$create policy %1$s_delete on %1$I for delete to authenticated
      using ( app.can(%2$L) and exists (select 1 from %3$I par where par.%4$I = %1$I.%5$I) )$p$,
      tbl, module||'.write', parent, parent_pk, fk);
end $$;
-- ---------------------------------------------------------------------
-- Soft-delete guard: setting deleted_at requires <module>.delete
-- ---------------------------------------------------------------------
create or replace function app.guard_soft_delete() returns trigger
language plpgsql as $$
begin
  if auth.uid() is null then return new; end if;           -- server/system context
  if old.deleted_at is null and new.deleted_at is not null
     and not app.can(tg_argv[0] || '.delete') then
    raise exception 'permission denied: % required', tg_argv[0] || '.delete' using errcode = '42501';
  end if;
  if new.deleted_at is not null and new.deleted_by is null then
    new.deleted_by := auth.uid();
  end if;
  return new;
end $$;

-- ---------------------------------------------------------------------
-- Apply: scoped modules
-- ---------------------------------------------------------------------
select app.apply_scoped_policies('leads',        'leads',        'assigned_to');
select app.apply_scoped_policies('buyers',       'buyers',       'assigned_to');
select app.apply_scoped_policies('sellers',      'sellers',      'assigned_to');
select app.apply_scoped_policies('properties',   'properties',   'assigned_to');
select app.apply_scoped_policies('appointments', 'appointments', 'assigned_to');
select app.apply_scoped_policies('tasks',        'tasks',        'assigned_to');
select app.apply_scoped_policies('deals',        'deals',        'assigned_to');

do $$
declare r record;
begin
  for r in select * from (values
    ('leads','leads'),('buyers','buyers'),('sellers','sellers'),('properties','properties'),
    ('appointments','appointments'),('tasks','tasks'),('deals','deals'),
    ('buyer_requirements','buyers'),('contacts','contacts'),('market_data','market')
  ) v(tbl,module)
  loop
    execute format('create trigger guard_soft_delete_%1$s before update of deleted_at on %1$I
                    for each row execute function app.guard_soft_delete(%2$L)', r.tbl, r.module);
  end loop;
end $$;

-- ---------------------------------------------------------------------
-- Apply: child tables (inherit visibility from parent)
-- ---------------------------------------------------------------------
select app.apply_child_policies('buyer_requirements',       'buyers',       'buyers',             'buyer_id');
select app.apply_child_policies('requirement_property_types','buyers',      'buyer_requirements', 'requirement_id');
select app.apply_child_policies('requirement_localities',   'buyers',       'buyer_requirements', 'requirement_id');
select app.apply_child_policies('requirement_preferences',  'buyers',       'buyer_requirements', 'requirement_id');
select app.apply_child_policies('property_matches',         'matching',     'buyer_requirements', 'requirement_id');
select app.apply_child_policies('property_owner_terms',     'properties',   'properties',         'property_id');
select app.apply_child_policies('property_amenities',       'properties',   'properties',         'property_id');
select app.apply_child_policies('property_media',           'properties',   'properties',         'property_id');
select app.apply_child_policies('property_documents',       'properties',   'properties',         'property_id');
select app.apply_child_policies('site_visits',              'appointments', 'appointments',       'appointment_id');
select app.apply_child_policies('deal_documents',           'deals',        'deals',              'deal_id');
select app.apply_child_policies('commissions',              'finance',      'deals',              'deal_id');
select app.apply_child_policies('payments',                 'finance',      'deals',              'deal_id');

-- ---------------------------------------------------------------------
-- Apply: global (permission-only) tables
-- ---------------------------------------------------------------------
select app.apply_global_policies('market_data',          'market');
select app.apply_global_policies('matching_configs',     'matching');
select app.apply_global_policies('matching_weights',     'matching');
select app.apply_global_policies('message_outbox',       'messaging');
select app.apply_global_policies('import_batches',       'imports');
select app.apply_global_policies('duplicate_candidates', 'contacts');

-- import_rows follow their batch
select app.apply_child_policies('import_rows', 'imports', 'import_batches', 'batch_id');

-- ---------------------------------------------------------------------
-- Special cases
-- ---------------------------------------------------------------------
-- contacts: visible when the person is attached to a lead/buyer/seller the caller can see
alter table contacts enable row level security;
create policy contacts_select on contacts for select to authenticated using (
  (deleted_at is null or app.is_admin()) and (
    app.can('contacts.read_all') or created_by = auth.uid()
    or exists (select 1 from leads   l where l.contact_id = contacts.id)
    or exists (select 1 from buyers  b where b.contact_id = contacts.id)
    or exists (select 1 from sellers s where s.contact_id = contacts.id) ) );
create policy contacts_insert on contacts for insert to authenticated with check (app.can('contacts.write'));
create policy contacts_update on contacts for update to authenticated
  using (app.can('contacts.write') and (app.can('contacts.read_all') or created_by = auth.uid()
     or exists (select 1 from leads l where l.contact_id = contacts.id)
     or exists (select 1 from buyers b where b.contact_id = contacts.id)
     or exists (select 1 from sellers s where s.contact_id = contacts.id)))
  with check (app.can('contacts.write'));
create policy contacts_delete on contacts for delete to authenticated using (app.is_admin());

-- activities: timeline visible if any parent entity is visible
alter table activities enable row level security;
create policy activities_select on activities for select to authenticated using (
  app.can('activities.read_all') or created_by = auth.uid()
  or (lead_id     is not null and exists (select 1 from leads      x where x.id = activities.lead_id))
  or (buyer_id    is not null and exists (select 1 from buyers     x where x.id = activities.buyer_id))
  or (seller_id   is not null and exists (select 1 from sellers    x where x.id = activities.seller_id))
  or (property_id is not null and exists (select 1 from properties x where x.id = activities.property_id))
  or (deal_id     is not null and exists (select 1 from deals      x where x.id = activities.deal_id)) );
create policy activities_insert on activities for insert to authenticated
  with check (app.can('activities.write') and created_by = auth.uid());
-- activities are a history: no update/delete policy => immutable for users

-- audit log: read-only for holders of audit.read; no write policies at all
alter table audit_logs enable row level security;
create policy audit_logs_select on audit_logs for select to authenticated using (app.can('audit.read'));

-- profiles: everyone active can see colleagues (names for assignment dropdowns);
-- editing others / changing role or activation needs users.manage
alter table profiles enable row level security;
create policy profiles_select on profiles for select to authenticated
  using ( id = auth.uid() or app.current_role_code() is not null );
create policy profiles_update on profiles for update to authenticated
  using ( id = auth.uid() or app.can('users.manage') )
  with check ( id = auth.uid() or app.can('users.manage') );

create or replace function app.guard_profile_privileges() returns trigger
language plpgsql as $$
begin
  if auth.uid() is null then return new; end if;
  if (new.role_id is distinct from old.role_id or new.is_active is distinct from old.is_active)
     and not app.can('users.manage') then
    raise exception 'permission denied: users.manage required to change role or activation' using errcode='42501';
  end if;
  return new;
end $$;
create trigger guard_profile_privileges before update on profiles
  for each row execute function app.guard_profile_privileges();

-- roles / permissions: readable by active users, changed only with users.manage
alter table roles enable row level security;
alter table permissions enable row level security;
alter table role_permissions enable row level security;
create policy roles_select on roles for select to authenticated using (app.current_role_code() is not null);
create policy permissions_select on permissions for select to authenticated using (app.current_role_code() is not null);
create policy role_permissions_select on role_permissions for select to authenticated using (app.current_role_code() is not null);
create policy roles_write on roles for all to authenticated using (app.can('users.manage')) with check (app.can('users.manage'));
create policy role_permissions_write on role_permissions for all to authenticated using (app.can('users.manage')) with check (app.can('users.manage'));
-- permissions rows are defined by migrations only (no user write policy)

-- reference tables + settings: read by any active user, write with settings.manage
do $$
declare t text;
begin
  foreach t in array array['lead_statuses','lead_sources','property_types','area_units','amenities','localities'] loop
    execute format('alter table %I enable row level security', t);
    execute format('create policy %1$s_select on %1$I for select to authenticated using (app.current_role_code() is not null)', t);
    execute format('create policy %1$s_write on %1$I for all to authenticated using (app.can(%2$L)) with check (app.can(%2$L))', t, 'settings.manage');
  end loop;
end $$;

alter table settings enable row level security;
create policy settings_select on settings for select to authenticated using (app.current_role_code() is not null);
create policy settings_write  on settings for all to authenticated using (app.can('settings.manage')) with check (app.can('settings.manage'));

-- personal tables
alter table notifications enable row level security;
create policy notifications_own on notifications for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

alter table saved_filters enable row level security;
create policy saved_filters_select on saved_filters for select to authenticated
  using (user_id = auth.uid() or is_shared);
create policy saved_filters_write on saved_filters for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ---------------------------------------------------------------------
-- STORAGE: private buckets; object access is derived from table visibility.
-- Path convention: <bucket>/<entity_id>/<uuid>.<ext>
-- The public site NEVER reads these buckets directly; it receives short-lived
-- signed URLs from a server route for properties that are published.
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public) values
  ('property-media','property-media', false),
  ('property-documents','property-documents', false),
  ('deal-documents','deal-documents', false),
  ('imports','imports', false)
on conflict (id) do nothing;

create policy storage_property_media_read on storage.objects for select to authenticated
  using (bucket_id = 'property-media'
         and exists (select 1 from property_media m where m.storage_path = storage.objects.name));
create policy storage_property_media_write on storage.objects for insert to authenticated
  with check (bucket_id = 'property-media' and app.can('properties.write'));
create policy storage_property_documents_read on storage.objects for select to authenticated
  using (bucket_id = 'property-documents'
         and exists (select 1 from property_documents d where d.storage_path = storage.objects.name));
create policy storage_property_documents_write on storage.objects for insert to authenticated
  with check (bucket_id = 'property-documents' and app.can('properties.write'));
create policy storage_deal_documents_read on storage.objects for select to authenticated
  using (bucket_id = 'deal-documents'
         and exists (select 1 from deal_documents d where d.storage_path = storage.objects.name));
create policy storage_deal_documents_write on storage.objects for insert to authenticated
  with check (bucket_id = 'deal-documents' and app.can('deals.write'));
create policy storage_imports_all on storage.objects for all to authenticated
  using (bucket_id = 'imports' and app.can('imports.write'))
  with check (bucket_id = 'imports' and app.can('imports.write'));

-- ---------------------------------------------------------------------
-- SAFETY NET: no table in public may exist without RLS, and the anonymous
-- role gets no table access at all (the public website talks to the CRM
-- only through server-side API routes, never straight to the database).
-- ---------------------------------------------------------------------
revoke all on all tables in schema public from anon;
revoke all on all sequences in schema public from anon;

do $$
declare missing text;
begin
  select string_agg(c.relname, ', ') into missing
  from pg_class c join pg_namespace n on n.oid = c.relnamespace
  where n.nspname = 'public' and c.relkind = 'r' and not c.relrowsecurity;
  if missing is not null then
    raise exception 'RLS is not enabled on: %', missing;
  end if;
end $$;
