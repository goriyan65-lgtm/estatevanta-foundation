import type { ReactNode, SVGProps } from "react";

// Small hand-drawn line icons (24 x 24 grid). No icon package is needed.
const PATHS: Record<string, ReactNode> = {
  dashboard: (<><rect x="3" y="3" width="7" height="9" rx="1.5" /><rect x="14" y="3" width="7" height="5" rx="1.5" /><rect x="14" y="12" width="7" height="9" rx="1.5" /><rect x="3" y="16" width="7" height="5" rx="1.5" /></>),
  properties: (<><path d="M4 21V7l8-4 8 4v14" /><path d="M9 21v-6h6v6" /><path d="M9 10h.01M15 10h.01" /></>),
  buyers: (<><circle cx="9" cy="8" r="3.5" /><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6" /><path d="M18 8v6M15 11h6" /></>),
  sellers: (<><path d="M12 3v18" /><path d="M12 5h7l2 2.5-2 2.5h-7" /><path d="M12 12H5l-2 2.5L5 17h7" /></>),
  leads: (<path d="M3 5h18l-7 8v6l-4 2v-8z" />),
  matching: (<><circle cx="9" cy="12" r="5.5" /><circle cx="15" cy="12" r="5.5" /></>),
  appointments: (<><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M3 10h18M8 3v4M16 3v4" /></>),
  deals: (<><path d="M6 3h9l4 4v14H6z" /><path d="M15 3v4h4" /><path d="m9 14 2 2 4-4" /></>),
  analytics: (<path d="M5 20v-8M12 20V5M19 20V8" />),
  market: (<><path d="M12 21s7-6.2 7-11a7 7 0 0 0-14 0c0 4.8 7 11 7 11z" /><circle cx="12" cy="10" r="2.5" /></>),
  settings: (<><path d="M4 7h10M18 7h2M4 17h2M10 17h10" /><circle cx="16" cy="7" r="2" /><circle cx="8" cy="17" r="2" /></>),
  menu: (<path d="M4 7h16M4 12h16M4 17h16" />),
  close: (<path d="M6 6l12 12M18 6 6 18" />),
  signout: (<><path d="M9 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h3" /><path d="M16 8l4 4-4 4" /><path d="M20 12H9" /></>),
  lock: (<><rect x="5" y="11" width="14" height="10" rx="2" /><path d="M8 11V8a4 4 0 0 1 8 0v3" /></>),
  alert: (<><path d="M12 3 22 21H2z" /><path d="M12 10v5M12 18h.01" /></>),
  plug: (<><path d="M9 3v5M15 3v5" /><path d="M6 8h12v3a6 6 0 0 1-12 0z" /><path d="M12 17v4" /></>),
};

export type IconName = keyof typeof PATHS;

export function Icon({ name, ...props }: { name: IconName } & SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75}
         strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false" {...props}>
      {PATHS[name]}
    </svg>
  );
}
