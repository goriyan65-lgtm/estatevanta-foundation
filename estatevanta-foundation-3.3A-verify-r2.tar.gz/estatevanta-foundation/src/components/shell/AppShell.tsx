"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState, type MouseEvent, type ReactNode } from "react";
import { cn } from "@/lib/cn";
import { MOBILE_PRIMARY, type ModuleId } from "@/lib/nav";
import { Icon } from "./icons";

export type ShellNavItem = { id: ModuleId; label: string; href: string };
export type ShellUser = { name: string; role: string | null };
/** A Server Action passed down from the server layout; submitting the form signs the user out. */
export type SignOutAction = () => Promise<void>;

function isActive(pathname: string, href: string) {
  return pathname === href || pathname.startsWith(`${href}/`);
}

function Brand() {
  return (
    <div className="flex items-center gap-2.5">
      <svg viewBox="0 0 24 24" className="size-7 shrink-0" fill="none" stroke="var(--accent)" strokeWidth="2" strokeLinejoin="round" aria-hidden="true">
        <path d="M3 5 17 3l4 6-1 12H4z" />
        <path d="M3 13h17" />
      </svg>
      <div className="leading-tight">
        <div className="text-[1.0625rem] font-semibold tracking-tight text-white">EstateVanta</div>
        <div className="text-xs text-rail-muted">CRM</div>
      </div>
    </div>
  );
}

function NavList({ items, pathname, onNavigate }: { items: ShellNavItem[]; pathname: string; onNavigate?: () => void }) {
  return (
    <ul className="flex flex-col gap-0.5">
      {items.map((item) => {
        const active = isActive(pathname, item.href);
        return (
          <li key={item.id}>
            <Link
              href={item.href}
              onClick={onNavigate}
              aria-current={active ? "page" : undefined}
              className={cn(
                "relative flex min-h-11 items-center gap-3 rounded-md px-3 text-[0.9375rem] font-medium transition-colors",
                active ? "bg-white/10 text-white" : "text-rail-ink/80 hover:bg-white/5 hover:text-white",
              )}
            >
              <span aria-hidden="true" className={cn("absolute inset-y-2 left-0 w-0.5 rounded-full", active ? "bg-accent" : "bg-transparent")} />
              <Icon name={item.id} className="size-5 shrink-0" />
              {item.label}
            </Link>
          </li>
        );
      })}
    </ul>
  );
}

function RailContent({ items, user, pathname, signOut, onNavigate }: { items: ShellNavItem[]; user: ShellUser; pathname: string; signOut: SignOutAction; onNavigate?: () => void }) {
  const main = items.filter((i) => i.id !== "settings");
  const settings = items.filter((i) => i.id === "settings");
  return (
    <>
      <div className="px-5 pb-4 pt-5"><Brand /></div>
      <nav aria-label="Main" className="flex-1 overflow-y-auto px-3 py-2">
        <NavList items={main} pathname={pathname} onNavigate={onNavigate} />
      </nav>
      <div className="border-t border-white/10 px-3 py-3">
        {settings.length > 0 ? <NavList items={settings} pathname={pathname} onNavigate={onNavigate} /> : null}
        <div className="mt-2 px-3 py-2 text-sm">
          <div className="truncate font-medium text-white">{user.name}</div>
          <div className="truncate text-xs text-rail-muted">{user.role ?? "No role"}</div>
        </div>
        <form action={signOut}>
          <button type="submit" className="flex min-h-11 w-full items-center gap-3 rounded-md px-3 text-[0.9375rem] font-medium text-rail-ink/80 transition-colors hover:bg-white/5 hover:text-white">
            <Icon name="signout" className="size-5 shrink-0" />
            Sign out
          </button>
        </form>
      </div>
    </>
  );
}

export function AppShell({ items, user, signOut, children }: { items: ShellNavItem[]; user: ShellUser; signOut: SignOutAction; children: ReactNode }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  // Whichever button opened the menu (top-bar menu or bottom-bar "More"); focus returns to it on close.
  const triggerRef = useRef<HTMLElement | null>(null);
  const closeRef = useRef<HTMLButtonElement>(null);

  // Close the drawer after navigating.
  useEffect(() => { setOpen(false); }, [pathname]);

  const openMenu = (e: MouseEvent<HTMLElement>) => {
    triggerRef.current = e.currentTarget;
    setOpen(true);
  };

  // While the menu is open: Escape closes it, the page behind does not scroll, focus moves inside, and the
  // rest of the page is `inert` (cannot be focused or clicked). The menu is phone/tablet only, so growing the
  // window to desktop width closes it; otherwise the inert page would stay locked behind a hidden menu.
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    const desktop = window.matchMedia("(min-width: 1024px)");
    const onWide = () => { if (desktop.matches) setOpen(false); };
    document.addEventListener("keydown", onKey);
    desktop.addEventListener("change", onWide);
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    const trigger = triggerRef.current;
    return () => {
      document.removeEventListener("keydown", onKey);
      desktop.removeEventListener("change", onWide);
      document.body.style.overflow = previous;
      trigger?.focus(); // runs after the page is no longer inert
    };
  }, [open]);

  const current = items.find((i) => isActive(pathname, i.href));
  const primary = MOBILE_PRIMARY.map((id) => items.find((i) => i.id === id)).filter((i): i is ShellNavItem => Boolean(i));

  return (
    <div className="min-h-dvh lg:grid lg:grid-cols-[16.5rem_minmax(0,1fr)]">
      <a href="#main" className="skip-link" inert={open}>Skip to content</a>

      {/* Desktop and tablet-landscape rail */}
      <aside inert={open} className="on-rail sticky top-0 hidden h-dvh flex-col bg-rail text-rail-ink lg:flex">
        <RailContent items={items} user={user} pathname={pathname} signOut={signOut} />
      </aside>

      <div inert={open} className="flex min-h-dvh min-w-0 flex-col">
        {/* Phone and tablet-portrait top bar */}
        <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-line bg-surface px-3 lg:hidden">
          <button type="button" onClick={openMenu} aria-label="Open navigation" aria-expanded={open}
                  className="grid size-11 place-items-center rounded-md text-ink hover:bg-paper">
            <Icon name="menu" className="size-6" />
          </button>
          <div className="truncate text-base font-semibold text-ink">{current?.label ?? "EstateVanta CRM"}</div>
        </header>

        <main id="main" tabIndex={-1} className="mx-auto w-full max-w-6xl flex-1 px-4 pb-28 pt-6 outline-none sm:px-6 lg:px-10 lg:pb-12 lg:pt-10">
          {children}
        </main>
      </div>

      {/* Phone bottom bar: the four most used sections plus the full menu */}
      <nav inert={open} aria-label="Quick navigation" className="safe-bottom fixed inset-x-0 bottom-0 z-30 border-t border-line bg-surface lg:hidden">
        <ul className="mx-auto flex max-w-xl">
          {primary.map((item) => {
            const active = isActive(pathname, item.href);
            return (
              <li key={item.id} className="min-w-0 flex-1">
                <Link href={item.href} aria-current={active ? "page" : undefined}
                      className={cn("flex h-14 min-w-0 flex-col items-center justify-center gap-0.5 text-[0.625rem] font-medium tracking-tight min-[375px]:text-[0.6875rem] min-[375px]:tracking-normal", active ? "text-brand" : "text-muted")}>
                  <Icon name={item.id} className="size-5 shrink-0" />
                  <span className="max-w-full truncate">{item.label}</span>
                </Link>
              </li>
            );
          })}
          <li className="min-w-0 flex-1">
            <button type="button" onClick={openMenu} aria-label="More sections"
                    className="flex h-14 w-full min-w-0 flex-col items-center justify-center gap-0.5 text-[0.625rem] font-medium tracking-tight text-muted min-[375px]:text-[0.6875rem] min-[375px]:tracking-normal">
              <Icon name="menu" className="size-5 shrink-0" />
              <span className="max-w-full truncate">More</span>
            </button>
          </li>
        </ul>
      </nav>

      {open ? (
        <div className="fixed inset-0 z-40 lg:hidden" role="dialog" aria-modal="true" aria-label="Navigation">
          <button type="button" aria-label="Close navigation" tabIndex={-1} onClick={() => setOpen(false)} className="absolute inset-0 bg-black/50" />
          <div className="drawer-panel on-rail absolute inset-y-0 left-0 flex w-[19rem] max-w-[85vw] flex-col bg-rail text-rail-ink shadow-2xl">
            <button ref={closeRef} type="button" onClick={() => setOpen(false)} aria-label="Close navigation"
                    className="absolute right-2 top-2 grid size-11 place-items-center rounded-md text-rail-ink hover:bg-white/10">
              <Icon name="close" className="size-6" />
            </button>
            <RailContent items={items} user={user} pathname={pathname} signOut={signOut} onNavigate={() => setOpen(false)} />
          </div>
        </div>
      ) : null}
    </div>
  );
}
