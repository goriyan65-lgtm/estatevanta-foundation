import { canAccess } from "@/lib/access";
import { MODULES, type ModuleId } from "@/lib/nav";
import { getAccessState } from "@/server/auth/session";
import { PageHeader } from "@/components/ui/PageHeader";
import { EmptyState } from "@/components/states/EmptyState";
import { AccessDenied } from "@/components/states/AccessDenied";

/**
 * Standard screen for a CRM section: checks the session and the permission rule, then shows the section's
 * empty state. It loads no data. Later phases replace the empty state with the real screen for that
 * section and keep the permission check.
 */
export async function ModulePage({ id }: { id: ModuleId }) {
  const mod = MODULES[id];
  const state = await getAccessState();

  if (!canAccess(state, mod.anyOf)) return <AccessDenied state={state} sectionLabel={mod.label} />;

  return (
    <>
      <PageHeader title={mod.title} description={mod.description} />
      <EmptyState title={mod.emptyTitle} body={mod.emptyBody} />
      {mod.planned.length > 0 ? (
        <section className="mt-6 rounded-lg border border-line bg-surface p-5" aria-labelledby={`planned-${mod.id}`}>
          <h2 id={`planned-${mod.id}`} className="text-base font-semibold text-ink">What this section will cover</h2>
          <ul className="mt-3 grid gap-x-8 gap-y-1.5 text-[0.9375rem] text-muted sm:grid-cols-2">
            {mod.planned.map((item) => (<li key={item} className="list-inside list-disc">{item}</li>))}
          </ul>
          <p className="mt-4 text-sm text-muted">Connected to data in {mod.builtIn}.</p>
        </section>
      ) : null}
    </>
  );
}
