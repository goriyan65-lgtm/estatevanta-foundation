import type { ReactNode } from "react";
import { Icon } from "@/components/shell/icons";
import { ErrorState } from "@/components/states/ErrorState";
import { UnauthorizedState } from "@/components/states/UnauthorizedState";
import { cn } from "@/lib/cn";
import { CARD_GROUPS } from "@/lib/dashboard/cards";
import { formatGeneratedAt } from "@/lib/dashboard/format";
import type { DashboardResult } from "@/lib/dashboard/load";
import { describeWarning, notLoadedCards, type ResolvedCard } from "@/lib/dashboard/summary";
import type { ModuleId } from "@/lib/nav";
import { RetryButton } from "./RetryButton";
import { StatCard } from "./StatCard";

function Notice({ tone = "info", title, children }: { tone?: "info" | "warn"; title: string; children?: ReactNode }) {
  return (
    <div
      role="status"
      className={cn(
        "flex gap-3 rounded-lg border p-4",
        tone === "warn" ? "border-warn/40 bg-warn-bg text-warn" : "border-line bg-surface text-ink",
      )}
    >
      <Icon name={tone === "warn" ? "alert" : "plug"} className="mt-0.5 size-5 shrink-0" />
      <div className="min-w-0">
        <p className="font-semibold">{title}</p>
        {children ? <div className={cn("mt-1 text-[0.9375rem]", tone === "warn" ? "text-ink" : "text-muted")}>{children}</div> : null}
      </div>
    </div>
  );
}

/**
 * The dashboard body. Pure: it draws whatever DashboardResult it is given and never fetches anything.
 * `openable` lists the sections this user may open, so a card links only to somewhere the user can go.
 */
export function DashboardView({ result, openable }: { result: DashboardResult; openable: readonly ModuleId[] }) {
  if (result.kind === "unauthorized") {
    return <UnauthorizedState variant={result.reason} />;
  }

  if (result.kind === "error") {
    return (
      <ErrorState
        title="The dashboard couldn't load"
        body="The figures couldn't be loaded just now. Try again. If it keeps happening, tell the admin and quote the reference below."
        detail={`Reference: ${result.code}`}
        action={<RetryButton />}
      />
    );
  }

  const cards: ResolvedCard[] = result.kind === "ok" ? result.cards : notLoadedCards();
  const anyAssigned = cards.some((c) => c.state === "loaded" && c.scope === "assigned");

  return (
    <div className="space-y-6">
      {result.kind === "not_connected" ? (
        <Notice title="Figures aren’t connected yet">
          The database connection isn’t configured on this server, so the dashboard can’t load any figures. The cards below show what
          is counted. No numbers are shown until the connection is in place.
        </Notice>
      ) : null}

      {result.kind === "ok" && result.empty ? (
        <Notice title="Nothing to count yet">
          Every figure is zero because no records have been added yet. The cards fill in as properties, leads, buyers and appointments are added.
        </Notice>
      ) : null}

      {result.kind === "ok" && result.warnings.length > 0 ? (
        <Notice tone="warn" title="Some dashboard settings need attention">
          <ul className="list-inside list-disc space-y-0.5">
            {result.warnings.map((code) => (<li key={code}>{describeWarning(code)}</li>))}
          </ul>
        </Notice>
      ) : null}

      {result.kind === "ok" ? (
        <p className="text-sm text-muted">
          {anyAssigned ? "Cards marked “Your records” count only records assigned to or created by you. " : ""}
          Updated {formatGeneratedAt(result.summary.generatedAt, result.summary.timezone)}.
        </p>
      ) : null}

      {CARD_GROUPS.map((group) => {
        const groupCards = cards.filter((c) => c.def.group === group.id);
        return (
          <section key={group.id} aria-labelledby={`group-${group.id}`}>
            <h2 id={`group-${group.id}`} className="text-lg font-semibold text-ink">{group.title}</h2>
            <p className="mb-3 text-sm text-muted">{group.description}</p>
            <ul className="grid grid-cols-[minmax(0,1fr)] gap-3 min-[560px]:grid-cols-2 xl:grid-cols-3">
              {groupCards.map((card) => (
                <StatCard key={card.def.key} card={card} canOpen={openable.includes(card.def.module)} />
              ))}
            </ul>
          </section>
        );
      })}
    </div>
  );
}
