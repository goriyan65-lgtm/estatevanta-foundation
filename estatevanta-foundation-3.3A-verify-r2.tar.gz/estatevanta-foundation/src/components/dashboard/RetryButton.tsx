"use client";

import { useRouter } from "next/navigation";
import { useTransition } from "react";
import { Button } from "@/components/ui/buttons";

/** Re-runs the server page (and the dashboard_summary() call) without a full browser reload. */
export function RetryButton() {
  const router = useRouter();
  const [pending, start] = useTransition();
  return (
    <Button onClick={() => start(() => router.refresh())} disabled={pending} aria-busy={pending}>
      {pending ? "Trying again…" : "Try again"}
    </Button>
  );
}
