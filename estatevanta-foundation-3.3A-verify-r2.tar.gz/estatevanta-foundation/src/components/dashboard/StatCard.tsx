import Link from "next/link";
import { Icon } from "@/components/shell/icons";
import { cn } from "@/lib/cn";
import { formatCount } from "@/lib/dashboard/format";
import type { ResolvedCard } from "@/lib/dashboard/summary";
import { MODULES } from "@/lib/nav";

/**
 * One dashboard card. Three honest states, drawn differently so they can never be confused:
 *   loaded       the figure from dashboard_summary()
 *   unavailable  the signed-in role may not see this figure (text only; the number 0 is never drawn)
 *   not_loaded   no data connection exists yet (text only; the number 0 is never drawn)
 * An "unavailable" or "not_loaded" card has no value to draw (see ResolvedCard), so it cannot show 0 by accident.
 */
export function StatCard({ card, canOpen }: { card: ResolvedCard; canOpen: boolean }) {
  const { def } = card;
  const titleId = `card-${def.key}`;
  const needsAction = card.state === "loaded" && def.attention && card.value > 0;
  const noMatchesYet = card.state === "loaded" && def.key === "matches_ready_to_share" && card.value === 0;
  const target = MODULES[def.module];

  return (
    <li className="min-w-0">
      <article
        aria-labelledby={titleId}
        data-card={def.key}
        data-state={card.state}
        className={cn(
          "flex h-full flex-col rounded-lg border bg-surface p-4",
          card.state === "loaded" ? "border-line" : "border-dashed border-line",
          needsAction && "border-l-4 border-l-warn",
        )}
      >
        <p className="text-xs font-medium uppercase tracking-wide text-muted">{def.area}</p>
        <h3 id={titleId} className="mt-0.5 text-[0.9375rem] font-semibold leading-snug text-ink">{def.label}</h3>

        <div className="mt-3 min-h-14">
          {card.state === "loaded" && !noMatchesYet ? (
            <p className="text-4xl font-semibold leading-none tracking-tight text-ink tabular-nums" data-figure>
              <span className="sr-only">{def.label}: </span>
              {formatCount(card.value)}
            </p>
          ) : null}

          {noMatchesYet ? (
            <>
              <p className="text-xl font-semibold leading-snug text-ink" data-figure-text>
                <span className="sr-only">0 matches. </span>No ready matches yet
              </p>
              <p className="mt-1 text-sm text-muted">
                Suggested matches will appear here once the matching engine is running. It isn’t built yet.
              </p>
            </>
          ) : null}

          {card.state === "unavailable" ? (
            <p className="flex items-start gap-2 text-sm text-muted" data-unavailable>
              <Icon name="lock" className="mt-0.5 size-4 shrink-0" />
              <span>Not available for your role.</span>
            </p>
          ) : null}

          {card.state === "not_loaded" ? (
            <p className="flex items-start gap-2 text-sm text-muted" data-not-loaded>
              <Icon name="plug" className="mt-0.5 size-4 shrink-0" />
              <span>Not loaded. The data connection isn’t available yet.</span>
            </p>
          ) : null}
        </div>

        <p className="mt-2 text-[0.8125rem] leading-snug text-muted">{def.help}</p>

        <div className="mt-auto flex flex-wrap items-center gap-x-3 gap-y-1 pt-3 text-xs">
          {needsAction ? (
            <span className="inline-flex items-center gap-1 rounded-full bg-warn-bg px-2 py-0.5 font-medium text-warn">
              <Icon name="alert" className="size-3.5" />Needs attention
            </span>
          ) : null}
          {card.state === "loaded" ? (
            <span className="text-muted">{card.scope === "assigned" ? "Your records" : "All records"}</span>
          ) : null}
          {canOpen ? (
            <Link href={target.href} className="ml-auto inline-flex min-h-11 items-center font-medium text-brand underline-offset-2 hover:underline">
              Open {target.label}
            </Link>
          ) : null}
        </div>
      </article>
    </li>
  );
}
