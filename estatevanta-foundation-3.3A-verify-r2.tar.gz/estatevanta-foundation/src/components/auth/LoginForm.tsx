"use client";

import { useActionState } from "react";
import { SIGN_IN_INITIAL, type SignInState } from "@/lib/auth/credentials";

/**
 * Email and password form. The action is a Server Action passed in from the page, so this file holds no secret and
 * imports nothing server-side. The password is never put back into the page: after a failed attempt only the
 * (email-shaped) address is shown again.
 */
export function LoginForm({ action }: { action: (previous: SignInState, formData: FormData) => Promise<SignInState> }) {
  const [state, formAction, pending] = useActionState(action, SIGN_IN_INITIAL);
  const errorId = "login-error";

  return (
    <form action={formAction} noValidate className="space-y-4">
      {state.error ? (
        <p id={errorId} role="alert" className="rounded-md border border-danger/40 bg-danger-bg px-3 py-2 text-[0.9375rem] text-ink">
          {state.error}
        </p>
      ) : null}

      <div>
        <label htmlFor="email" className="mb-1 block text-sm font-medium text-ink">Email</label>
        <input
          id="email" name="email" type="email" inputMode="email" autoComplete="username" autoCapitalize="none" autoCorrect="off" spellCheck={false}
          required defaultValue={state.email} aria-describedby={state.error ? errorId : undefined}
          className="block min-h-11 w-full rounded-md border border-line bg-surface px-3 text-base text-ink"
        />
      </div>

      <div>
        <label htmlFor="password" className="mb-1 block text-sm font-medium text-ink">Password</label>
        <input
          id="password" name="password" type="password" autoComplete="current-password"
          required aria-describedby={state.error ? errorId : undefined}
          className="block min-h-11 w-full rounded-md border border-line bg-surface px-3 text-base text-ink"
        />
      </div>

      <button
        type="submit" disabled={pending} aria-busy={pending}
        className="inline-flex min-h-11 w-full items-center justify-center rounded-md bg-brand px-4 text-[0.9375rem] font-medium text-on-brand transition-colors hover:opacity-90 disabled:opacity-60"
      >
        {pending ? "Signing in…" : "Sign in"}
      </button>
    </form>
  );
}
