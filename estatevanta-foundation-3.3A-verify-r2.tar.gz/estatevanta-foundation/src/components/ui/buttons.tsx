import Link from "next/link";
import type { ComponentProps } from "react";
import { cn } from "@/lib/cn";

const base =
  "inline-flex min-h-11 items-center justify-center rounded-md px-4 text-[0.9375rem] font-medium transition-colors";
const primary = "bg-brand text-on-brand hover:opacity-90";
const secondary = "border border-line bg-surface text-ink hover:bg-paper";

export function LinkButton({ variant = "primary", className, ...props }: ComponentProps<typeof Link> & { variant?: "primary" | "secondary" }) {
  return <Link className={cn(base, variant === "primary" ? primary : secondary, className)} {...props} />;
}

export function Button({ variant = "primary", className, type = "button", ...props }: ComponentProps<"button"> & { variant?: "primary" | "secondary" }) {
  return <button type={type} className={cn(base, variant === "primary" ? primary : secondary, className)} {...props} />;
}
