import { Icon } from "@/components/shell/icons";
import { Button, LinkButton } from "@/components/ui/buttons";
import { signOut } from "@/server/auth/actions";

export type UnauthorizedVariant = "signed_out" | "forbidden" | "inactive";

export function UnauthorizedState({ variant, sectionLabel }: { variant: UnauthorizedVariant; sectionLabel?: string }) {
  const copy = {
    signed_out: {
      title: "Sign in to continue",
      body: "You're not signed in, or your session has ended.",
      action: <LinkButton href="/login">Sign in</LinkButton>,
    },
    forbidden: {
      title: "You don't have access to this section",
      body: `Your role doesn't include ${sectionLabel ?? "this section"}. Ask an admin to change your role if you need it.`,
      action: <LinkButton href="/dashboard" variant="secondary">Back to dashboard</LinkButton>,
    },
    inactive: {
      title: "Your account isn't active",
      body: "An admin must activate your account before you can use the CRM.",
      // The person IS signed in (the account just isn't active), so the useful action is to sign out.
      action: <form action={signOut}><Button type="submit" variant="secondary">Sign out</Button></form>,
    },
  }[variant];

  return (
    <section role="alert" className="flex flex-col items-center rounded-lg border border-line bg-surface px-6 py-12 text-center">
      <Icon name="lock" className="mb-3 size-9 text-muted" />
      <h2 className="text-lg font-semibold text-ink">{copy.title}</h2>
      <p className="mt-2 max-w-md text-[0.9375rem] text-muted">{copy.body}</p>
      {copy.action ? <div className="mt-5">{copy.action}</div> : null}
    </section>
  );
}
