// Skeleton shown while a section loads. Pure placeholders: no text values, no fake numbers.
export function LoadingState({ label = "Loading" }: { label?: string }) {
  return (
    <div role="status" aria-busy="true" aria-live="polite">
      <span className="sr-only">{label}</span>
      <div className="skeleton mb-2 h-8 w-56" />
      <div className="skeleton mb-6 h-4 w-80 max-w-full" />
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {[0, 1, 2].map((i) => (
          <div key={i} className="rounded-lg border border-line bg-surface p-4">
            <div className="skeleton mb-3 h-4 w-24" />
            <div className="skeleton h-16 w-full" />
          </div>
        ))}
      </div>
    </div>
  );
}
