// Original line drawing of a subdivided plot, used in empty states. One lot is dashed: "nothing here yet".
export function PlotDrawing({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 160 100" className={className} fill="none" stroke="currentColor" strokeWidth="1.5"
         strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
      <path d="M8 12 L112 6 L152 38 L140 92 L20 94 Z" />
      <path d="M8 53 L146 62" />
      <path d="M60 9 L66 93" />
      <path d="M104 8 L108 78" />
      <path d="M66 62 L66 93" />
      <rect x="68" y="20" width="34" height="30" rx="1" strokeDasharray="4 4" style={{ stroke: "var(--accent)" }} />
    </svg>
  );
}
