import type { ReactNode } from "react";
import { Icon } from "@/components/shell/icons";

export function ErrorState({ title, body, detail, action }: { title: string; body: string; detail?: string; action?: ReactNode }) {
  return (
    <section role="alert" className="flex flex-col items-center rounded-lg border border-danger/40 bg-danger-bg px-6 py-10 text-center">
      <Icon name="alert" className="mb-3 size-9 text-danger" />
      <h2 className="text-lg font-semibold text-ink">{title}</h2>
      <p className="mt-2 max-w-md text-[0.9375rem] text-ink [overflow-wrap:anywhere]">{body}</p>
      {detail ? <p className="mt-3 max-w-md font-mono text-xs text-muted [overflow-wrap:anywhere]">{detail}</p> : null}
      {action ? <div className="mt-5">{action}</div> : null}
    </section>
  );
}
