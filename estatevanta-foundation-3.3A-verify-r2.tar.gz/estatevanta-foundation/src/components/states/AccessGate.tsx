import type { AccessState } from "@/lib/access";
import { RetryButton } from "@/components/dashboard/RetryButton";
import { ErrorState } from "./ErrorState";
import { UnauthorizedState } from "./UnauthorizedState";

/** Full-page message for any access state that must not render the app. Fails closed. */
export function AccessGate({ state }: { state: AccessState }) {
  switch (state.status) {
    case "signed_out":
      return <UnauthorizedState variant="signed_out" />;
    case "inactive":
      return <UnauthorizedState variant="inactive" />;
    case "unconfigured":
      return (
        <ErrorState
          title="Supabase isn't configured"
          body="NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY must be set to the project URL and its public (anon) key, then the server restarted. A secret or service-role key is refused here."
        />
      );
    case "error":
      return <ErrorState title="Access couldn't be checked" body="The server couldn't confirm who you are. Try again in a moment." detail={`Reference: ${state.message}`} action={<RetryButton />} />;
    default:
      // Any state this switch does not recognise is treated as "no access".
      return <UnauthorizedState variant="signed_out" />;
  }
}
