import { redirect } from "next/navigation";
import type { AccessState } from "@/lib/access";
import { AccessGate } from "./AccessGate";
import { UnauthorizedState } from "./UnauthorizedState";

/**
 * What a page shows when canAccess() is false. Used by every page, because a layout is not re-run when a signed-in
 * user moves between pages, so the session can end between two page views.
 *   signed out -> sent to /login
 *   ready      -> "you don't have access to this section" (a role problem, not a session problem)
 *   otherwise  -> the same full-page gate the layout uses (inactive, unconfigured, error)
 */
export function AccessDenied({ state, sectionLabel }: { state: AccessState; sectionLabel: string }) {
  if (state.status === "signed_out") redirect("/login");
  if (state.status === "ready") return <UnauthorizedState variant="forbidden" sectionLabel={sectionLabel} />;
  return <AccessGate state={state} />;
}
