import type { ReactNode } from "react";
import { PlotDrawing } from "./PlotDrawing";

export function EmptyState({ title, body, action }: { title: string; body: string; action?: ReactNode }) {
  return (
    <section className="flex flex-col items-center rounded-lg border border-dashed border-line bg-surface px-6 py-12 text-center">
      <PlotDrawing className="mb-5 h-24 w-40 text-muted" />
      <h2 className="text-lg font-semibold text-ink">{title}</h2>
      <p className="mt-2 max-w-md text-[0.9375rem] text-muted">{body}</p>
      {action ? <div className="mt-5">{action}</div> : null}
    </section>
  );
}
