// Session refresh for the proxy (Next.js 16 `proxy.ts`; `middleware.ts` before 16). No `server-only` import: the
// proxy runs outside the normal app bundle.
//
// IMPORTANT: this only keeps the session cookie fresh. It does NOT decide who may see what and it never redirects.
// Authorization happens in the server layout and pages (src/server/auth/session.ts) on every request, so if this
// file were skipped (a wrong matcher, an older Next version) nobody would gain access: sessions would simply expire
// sooner and the user would be asked to sign in again.
import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";
import { hardenCookieOptions } from "./cookies";
import { getSupabasePublicEnv } from "./env";

export async function updateSession(request: NextRequest): Promise<NextResponse> {
  let response = NextResponse.next({ request });

  const env = getSupabasePublicEnv();
  if (!env) return response; // the pages report "Supabase isn't configured"

  const supabase = createServerClient(env.url, env.anonKey, {
    cookies: {
      getAll: () => request.cookies.getAll(),
      setAll: (list, headers?: Record<string, string>) => {
        // Write the refreshed tokens to the request (so this render sees them) and to the response (so the browser keeps them).
        list.forEach(({ name, value }) => request.cookies.set(name, value));
        response = NextResponse.next({ request });
        list.forEach(({ name, value, options }) => response.cookies.set(name, value, hardenCookieOptions(options)));
        if (headers) Object.entries(headers).forEach(([key, value]) => response.headers.set(key, value));
      },
    },
  });

  try {
    // Verifies the token signature and refreshes it when it is close to expiry. The result is deliberately not used.
    await supabase.auth.getClaims();
  } catch {
    // An Auth outage or a malformed cookie must not break the request. The page-level check will fail closed.
  }
  return response;
}
