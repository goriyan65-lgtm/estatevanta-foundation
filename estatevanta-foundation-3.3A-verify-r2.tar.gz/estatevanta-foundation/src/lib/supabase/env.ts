// Reads and validates the two PUBLIC Supabase settings. Safe to import from the proxy and from server code.
// It never reads the service-role key and never returns or logs a key or URL in any message.
//
// ALLOW-LIST, fail closed. Anything missing, malformed, unexpected or suspicious returns null, and the app then shows
// "Supabase isn't configured" instead of attempting a connection.
//
//   URL  hosted:  https://<20 lowercase letters/digits>.supabase.co   (no port, path, query, fragment or credentials)
//        local:   http(s)://localhost[:port] or http(s)://127.0.0.1[:port]   (plain http is allowed ONLY here)
//   KEY  one of:  sb_publishable_<chars>                               (new-style publishable key)
//                 a three-part JWT whose payload role is exactly "anon" (legacy anon key)
//
// Everything else is refused: service-role JWTs, sb_secret_ keys, personal access tokens (sbp_), JWTs of any other role
// (authenticated, supabase_admin, ...), wrong-case variants, quoted values, values with whitespace or invisible characters
// inside them, random strings. A custom domain for the project is NOT accepted; it would need an explicit, reviewed change
// to this file.
// A refused secret key is also named in looksLikeSecretKey() as a second, independent line of defence.
//
// WHITESPACE POLICY (deliberate, tested): whitespace AROUND a value (spaces, tabs, CR/LF, and anything else that
// String.prototype.trim() removes) is trimmed once, in parseSupabasePublicEnv, because env files and hosting dashboards
// routinely add a trailing newline. The trimmed value is what is validated, returned and used. Whitespace INSIDE a value
// is never repaired and is refused. matchesPublicKeyAllowList() does not trim at all: it is strict by itself.

export type SupabasePublicEnv = { url: string; anonKey: string };

const HOSTED_HOST = /^[a-z0-9]{20}\.supabase\.co$/;
const PUBLISHABLE_KEY = /^sb_publishable_[A-Za-z0-9_-]{16,128}$/;
const BASE64URL = /^[A-Za-z0-9_-]+$/;
const MAX_LENGTH = 2048;

function decodeSegment(segment: string): Record<string, unknown> | null {
  if (!BASE64URL.test(segment)) return null;
  try {
    const b64 = segment.replace(/-/g, "+").replace(/_/g, "/");
    const padded = b64.padEnd(Math.ceil(b64.length / 4) * 4, "=");
    const json = typeof atob === "function" ? atob(padded) : Buffer.from(padded, "base64").toString("utf8");
    const value: unknown = JSON.parse(json);
    return value !== null && typeof value === "object" && !Array.isArray(value) ? (value as Record<string, unknown>) : null;
  } catch {
    return null;
  }
}

/** Header and payload of a three-part JWT-shaped string, or null. The signature is never verified here. */
function decodeJwt(key: string): { header: Record<string, unknown>; payload: Record<string, unknown> } | null {
  const parts = key.split(".");
  if (parts.length !== 3 || !parts[2] || !BASE64URL.test(parts[2])) return null;
  const header = decodeSegment(parts[0] ?? "");
  const payload = decodeSegment(parts[1] ?? "");
  return header && payload ? { header, payload } : null;
}

/**
 * Defence in depth, used by tests and by anything that wants a yes/no. True for a key that must never be used in the
 * browser-facing configuration: sb_secret_ keys, personal access tokens, and JWTs whose role is service_role or
 * supabase_admin. Comparison is case-insensitive so a case change cannot slip past it.
 * The allow-list in parseSupabasePublicEnv is the real gate; this is not what makes a key acceptable.
 */
export function looksLikeSecretKey(key: string): boolean {
  const lower = key.trim().toLowerCase();
  if (lower.startsWith("sb_secret_") || lower.startsWith("sbp_")) return true;
  const jwt = decodeJwt(key.trim());
  const role = typeof jwt?.payload.role === "string" ? jwt.payload.role.trim().toLowerCase() : "";
  return role === "service_role" || role === "supabase_admin";
}

type ParsedUrl = { origin: string; hostname: string; hosted: boolean };

function parseUrl(raw: string): ParsedUrl | null {
  if (raw.length === 0 || raw.length > MAX_LENGTH || /[\s\\]/.test(raw)) return null;
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    return null;
  }
  if (url.username || url.password) return null; // credentials in a URL are never valid here
  if (url.search || url.hash) return null;
  if (url.pathname !== "/") return null;

  if (url.hostname === "localhost" || url.hostname === "127.0.0.1") {
    if (url.protocol !== "http:" && url.protocol !== "https:") return null;
    return { origin: url.origin, hostname: url.hostname, hosted: false };
  }
  if (url.protocol !== "https:" || url.port !== "") return null;
  if (!HOSTED_HOST.test(url.hostname)) return null;
  return { origin: url.origin, hostname: url.hostname, hosted: true };
}

/**
 * The allow-list on its own: true only for a publishable key or a legacy anon JWT. It does not consult
 * looksLikeSecretKey, so it is an independent line of defence (a test proves it refuses every secret sample by itself).
 * `projectRef` is the hosted project reference from the URL, or null for a local URL.
 */
export function matchesPublicKeyAllowList(key: string, projectRef: string | null): boolean {
  if (key.length < 20 || key.length > MAX_LENGTH || /\s/.test(key)) return false;

  if (key.startsWith("sb_publishable_")) return PUBLISHABLE_KEY.test(key);

  const jwt = decodeJwt(key);
  if (!jwt) return false;
  if (typeof jwt.header.alg !== "string") return false;
  if (jwt.payload.role !== "anon") return false; // exact, case-sensitive: "Anon", "ANON", "authenticated" all fail
  // A legacy anon key names its project. For a hosted URL the two must agree, so a key for another project fails closed.
  if ("ref" in jwt.payload) {
    if (typeof jwt.payload.ref !== "string") return false;
    if (projectRef !== null && projectRef !== jwt.payload.ref) return false;
  }
  return true;
}

function isAllowedKey(key: string, url: ParsedUrl): boolean {
  // Layer 1: the explicit refusal of secret keys. Layer 2: the allow-list. Today layer 2 refuses everything layer 1 does
  // (see the layer test in tests/auth.test.ts), so removing layer 1 changes no observable result; it is kept on purpose
  // so that a future loosening of the allow-list cannot, by itself, let a secret key through.
  if (looksLikeSecretKey(key)) return false;
  return matchesPublicKeyAllowList(key, url.hosted ? (url.hostname.split(".")[0] ?? null) : null);
}

export function parseSupabasePublicEnv(env: { url?: string | undefined; anonKey?: string | undefined }): SupabasePublicEnv | null {
  const rawUrl = env.url?.trim();
  const anonKey = env.anonKey?.trim();
  if (!rawUrl || !anonKey) return null;

  const url = parseUrl(rawUrl);
  if (!url) return null; // the URL is validated on its own, before the key is even looked at
  if (!isAllowedKey(anonKey, url)) return null;

  return { url: url.origin, anonKey };
}

/** The configuration from the process environment. NEXT_PUBLIC_* values are the only ones read here. */
export function getSupabasePublicEnv(): SupabasePublicEnv | null {
  return parseSupabasePublicEnv({
    url: process.env.NEXT_PUBLIC_SUPABASE_URL,
    anonKey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
  });
}
