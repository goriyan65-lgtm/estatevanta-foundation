// One place that decides how Supabase session cookies are written, used by both the server client and the proxy.
//
// The app has NO browser-side Supabase client: every auth and data call runs on the server. So the session
// cookies can be HttpOnly, which keeps the tokens out of reach of any script running in the page.
// If a browser Supabase client is ever added, this must be revisited (it could no longer read the cookie).

export type CookieOptions = {
  path?: string;
  domain?: string;
  maxAge?: number;
  expires?: Date;
  httpOnly?: boolean;
  secure?: boolean;
  sameSite?: boolean | "lax" | "strict" | "none";
  [key: string]: unknown;
};

/** Cookie name prefix used by @supabase/ssr for the session (sb-<project>-auth-token, plus .0 .1 chunks). */
export const SESSION_COOKIE_PREFIX = "sb-";

export function hardenCookieOptions(options: CookieOptions | undefined, production: boolean = process.env.NODE_ENV === "production"): CookieOptions {
  return {
    ...(options ?? {}),
    path: "/",
    httpOnly: true,
    sameSite: "lax",
    secure: production,
  };
}

export function isSessionCookieName(name: string): boolean {
  return name.startsWith(SESSION_COOKIE_PREFIX);
}
