// Shared (client + server safe) description of "who is looking at the app and what may they do".
// The real value is produced on the server by src/server/auth/session.ts from a verified Supabase session and
// public.my_access(). The browser never decides access; the database (Row Level Security) is the final authority.
// This only shapes the UI. There is no development-only state: development fails closed exactly like production.

export type Access = {
  userId: string;
  fullName: string | null;
  role: string | null; // roles.code: admin | manager | agent | viewer
  permissions: readonly string[]; // permissions.code values returned by public.my_access()
};

export type AccessState =
  | { status: "ready"; access: Access }
  | { status: "signed_out" }
  | { status: "inactive" } // signed in but profile missing, inactive or deleted
  | { status: "unconfigured" } // Supabase environment variables are missing
  // `message` is a short reference code (letters, digits, underscore). It is never a raw error message.
  | { status: "error"; message: string };

/** True when the state may see a section that needs ANY of the listed permissions ([] = any active user). */
export function canAccess(state: AccessState, anyOf: readonly string[]): boolean {
  if (state.status !== "ready") return false;
  if (anyOf.length === 0) return true;
  return anyOf.some((code) => state.access.permissions.includes(code));
}
