// Turns "who is calling" into an AccessState. Pure and dependency-free so it can be tested with a stand-in client.
// No Supabase import, no cookies, no environment access: the caller supplies a narrow client.
//
// Order of checks (each one fails closed):
//   1. auth.getUser()      asks Supabase Auth to verify the token. getSession() is never used for access decisions.
//   2. rpc("my_access")    the caller's own profile and permissions, read with the caller's JWT so RLS applies.
//   3. strict parsing, and the profile must belong to the verified user.
import type { Access, AccessState } from "@/lib/access";

type RpcError = { code?: string | null; message?: string | null };
type AuthErrorLike = { name?: string | null; status?: number | null; code?: string | null };

export type AccessClient = {
  auth: {
    getUser(): PromiseLike<{ data: { user: { id: string } | null } | null; error: AuthErrorLike | null }>;
  };
  rpc(fn: "my_access"): PromiseLike<{ data: unknown; error: RpcError | null }>;
};

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const ROLE = /^[a-z][a-z0-9_]{0,40}$/;
const PERMISSION = /^[a-z_]{1,40}\.[a-z_]{1,40}$/;
const MAX_PERMISSIONS = 300;

export type MyAccess = { userId: string; fullName: string | null; role: string | null; isActive: boolean; permissions: string[] };
export type MyAccessParse = { ok: true; value: MyAccess } | { ok: false; reason: string };

/** Short, safe reference for the screen. Never a message from the server. */
export function safeRef(value: unknown): string {
  const text = typeof value === "number" ? String(value) : typeof value === "string" ? value : "";
  return /^[A-Za-z0-9_]{1,24}$/.test(text) ? text : "unknown";
}

export function parseMyAccess(input: unknown): MyAccessParse {
  if (typeof input !== "object" || input === null || Array.isArray(input)) return { ok: false, reason: "not an object" };
  const o = input as Record<string, unknown>;
  const allowed = new Set(["user_id", "full_name", "role", "is_active", "permissions"]);
  for (const key of Object.keys(o)) if (!allowed.has(key)) return { ok: false, reason: `unknown field ${safeRef(key)}` };

  if (typeof o.user_id !== "string" || !UUID.test(o.user_id)) return { ok: false, reason: "user_id" };
  if (o.full_name !== null && o.full_name !== undefined && (typeof o.full_name !== "string" || o.full_name.length > 200)) return { ok: false, reason: "full_name" };
  if (o.role !== null && o.role !== undefined && (typeof o.role !== "string" || !ROLE.test(o.role))) return { ok: false, reason: "role" };
  if (typeof o.is_active !== "boolean") return { ok: false, reason: "is_active" };
  if (!Array.isArray(o.permissions) || o.permissions.length > MAX_PERMISSIONS) return { ok: false, reason: "permissions" };

  const permissions: string[] = [];
  for (const p of o.permissions) {
    if (typeof p !== "string" || !PERMISSION.test(p)) return { ok: false, reason: "permission code" };
    if (!permissions.includes(p)) permissions.push(p);
  }
  return {
    ok: true,
    value: {
      userId: o.user_id.toLowerCase(),
      fullName: typeof o.full_name === "string" && o.full_name.trim() !== "" ? o.full_name : null,
      role: typeof o.role === "string" ? o.role : null,
      isActive: o.is_active,
      permissions,
    },
  };
}

/** A missing, expired, invalid or revoked session (a client error from Auth), as opposed to Auth being unreachable. */
function isNoSession(err: AuthErrorLike): boolean {
  if (err.name === "AuthSessionMissingError") return true;
  const s = err.status;
  return typeof s === "number" && s >= 400 && s < 500 && s !== 408 && s !== 429;
}

export async function resolveAccessState(client: AccessClient): Promise<AccessState> {
  // 1. Verified identity.
  let userResponse: Awaited<ReturnType<AccessClient["auth"]["getUser"]>>;
  try {
    userResponse = await client.auth.getUser();
  } catch {
    return { status: "error", message: "auth_unavailable" };
  }
  if (userResponse.error) {
    return isNoSession(userResponse.error)
      ? { status: "signed_out" }
      : { status: "error", message: `auth_${safeRef(userResponse.error.code ?? userResponse.error.status)}` };
  }
  const user = userResponse.data?.user;
  if (!user || typeof user.id !== "string" || !UUID.test(user.id)) return { status: "signed_out" };

  // 2. Profile and permissions, with the caller's own JWT.
  let response: Awaited<ReturnType<AccessClient["rpc"]>>;
  try {
    response = await client.rpc("my_access");
  } catch {
    return { status: "error", message: "profile_unavailable" };
  }
  if (response.error) {
    const code = response.error.code ?? "";
    if (code === "PGRST301" || code === "PGRST302") return { status: "signed_out" };
    return { status: "error", message: `profile_${safeRef(code)}` };
  }
  if (response.data === null || response.data === undefined) return { status: "inactive" }; // no live profile row

  // 3. Strict parse; the profile must be the verified user's own.
  const parsed = parseMyAccess(response.data);
  if (!parsed.ok) return { status: "error", message: "profile_bad_response" };
  if (parsed.value.userId !== user.id.toLowerCase()) return { status: "error", message: "profile_mismatch" };

  // An account needs to be active AND have a role. Anything less is "inactive" (fail closed).
  if (!parsed.value.isActive || parsed.value.role === null) return { status: "inactive" };

  const access: Access = {
    userId: parsed.value.userId,
    fullName: parsed.value.fullName,
    role: parsed.value.role,
    permissions: parsed.value.permissions,
  };
  return { status: "ready", access };
}
