// Input checks and user-facing messages for sign-in. Pure; shared by the server action and the tests.
// Messages are deliberately generic: they never say whether an email exists, and never echo a password.

export type SignInState = { error: string | null; email: string };

export const SIGN_IN_INITIAL: SignInState = { error: null, email: "" };

export const MESSAGES = {
  missing: "Enter your email address and password.",
  invalid: "The email or password is incorrect.",
  rateLimited: "Too many attempts. Wait a few minutes and try again.",
  unavailable: "Sign-in isn't available right now. Try again in a moment.",
  notConfigured: "Sign-in isn't set up on this server yet.",
} as const;

const EMAIL = /^[^\s@]{1,64}@[^\s@]{1,255}\.[^\s@]{2,63}$/;
const MAX_EMAIL = 254;
const MAX_PASSWORD = 1024; // far above any real password; stops oversized bodies

export type CredentialCheck = { ok: true; email: string; password: string } | { ok: false; email: string };

/** Trims and lower-cases the email. The password is passed through untouched (spaces can be part of it). */
export function checkCredentials(emailInput: unknown, passwordInput: unknown): CredentialCheck {
  const email = typeof emailInput === "string" ? emailInput.trim().toLowerCase().slice(0, MAX_EMAIL + 1) : "";
  const password = typeof passwordInput === "string" ? passwordInput : "";
  const emailOk = email.length > 0 && email.length <= MAX_EMAIL && EMAIL.test(email);
  const passwordOk = password.length > 0 && password.length <= MAX_PASSWORD;
  // Only an email-shaped string is handed back for the form to show again; anything else is dropped.
  return emailOk && passwordOk ? { ok: true, email, password } : { ok: false, email: emailOk ? email : "" };
}

type AuthErrorLike = { name?: string | null; status?: number | null; code?: string | null };

/** Maps an Auth error to one safe message. */
export function signInMessage(err: AuthErrorLike | null | undefined): string {
  if (!err) return MESSAGES.unavailable;
  if (err.status === 429 || err.code === "over_request_rate_limit" || err.code === "over_email_send_rate_limit") return MESSAGES.rateLimited;
  const s = err.status;
  if (typeof s === "number" && s >= 400 && s < 500) return MESSAGES.invalid; // wrong password, unknown email, unconfirmed: all the same
  return MESSAGES.unavailable; // network failure or a server error
}
