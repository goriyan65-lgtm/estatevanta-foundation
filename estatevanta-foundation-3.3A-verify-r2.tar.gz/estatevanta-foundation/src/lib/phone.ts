// Mirrors the database's phone_key: last 10 digits (assumes Indian numbers).
export function phoneKey(input?: string | null): string | null {
  const digits = (input ?? "").replace(/\D/g, "");
  return digits.length > 0 ? digits.slice(-10) : null;
}
