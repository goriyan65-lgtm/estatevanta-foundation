// The 13 approved dashboard cards (Phase 3.2, Step 1 proposal, approved with F1-F6).
// STRUCTURE ONLY: names, wording, permission rules. There are no numbers in this file.
// The figures come exclusively from public.dashboard_summary(); nothing here is a default or a sample.
import type { ModuleId } from "@/lib/nav";

export const CARD_KEYS = [
  "appointments_today",
  "appointments_awaiting_outcome",
  "overdue_followups",
  "overdue_tasks",
  "new_leads_uncontacted",
  "listings_due_verification",
  "open_leads",
  "hot_leads",
  "buyers_active_requirements",
  "sellers_awaiting_contact",
  "matches_ready_to_share",
  "active_inventory",
  "open_deals",
] as const;

export type CardKey = (typeof CARD_KEYS)[number];
export type CardGroupId = "attention" | "pipeline";

export type CardDef = {
  key: CardKey;
  group: CardGroupId;
  /** Approved card name. */
  label: string;
  /** Small area tag shown above the name. */
  area: string;
  /** One line: what is counted. No figures. */
  help: string;
  /** True when a count above zero means somebody has something to do. */
  attention: boolean;
  /**
   * The user needs ANY of these permission codes to see the figure. Mirrors the rule inside
   * dashboard_summary(). The database stays the authority; this is a second, UI-side check so a
   * figure the role must not see is never drawn even if a response were ever wrong.
   */
  anyOf: readonly string[];
  /** Section the card links to (shown only when the user may open that section). */
  module: ModuleId;
  /** Deal data: counts of deals. Never shown to a role without deals.read / deals.read_all. */
  dealData: boolean;
};

export const CARD_GROUPS: readonly { id: CardGroupId; title: string; description: string }[] = [
  { id: "attention", title: "Today and needs attention", description: "Things to act on now." },
  { id: "pipeline", title: "Pipeline and inventory", description: "Where the business stands." },
];

const P = ["properties.read_all", "properties.read_active", "properties.read"] as const;
const L = ["leads.read_all", "leads.read"] as const;
const B = ["buyers.read_all", "buyers.read"] as const;
const S = ["sellers.read_all", "sellers.read"] as const;
const M = ["matching.read_all", "matching.read"] as const;
const A = ["appointments.read_all", "appointments.read"] as const;
const T = ["tasks.read_all", "tasks.read"] as const;
const D = ["deals.read_all", "deals.read"] as const;

export const CARDS: readonly CardDef[] = [
  { key: "appointments_today", group: "attention", label: "Appointments today", area: "Appointments", attention: false, anyOf: A, module: "appointments", dealData: false,
    help: "Scheduled and confirmed appointments that start today." },
  { key: "appointments_awaiting_outcome", group: "attention", label: "Appointments awaiting outcome", area: "Appointments", attention: true, anyOf: A, module: "appointments", dealData: false,
    help: "Scheduled or confirmed appointments whose time has passed and whose result is not recorded." },
  { key: "overdue_followups", group: "attention", label: "Overdue lead follow-ups", area: "Leads", attention: true, anyOf: L, module: "leads", dealData: false,
    help: "Open leads whose next follow-up date has passed." },
  { key: "overdue_tasks", group: "attention", label: "Overdue tasks", area: "Tasks", attention: true, anyOf: T, module: "appointments", dealData: false,
    help: "Pending or in-progress tasks past their due time." },
  { key: "new_leads_uncontacted", group: "attention", label: "New leads awaiting first contact", area: "Leads", attention: true, anyOf: L, module: "leads", dealData: false,
    help: "Leads still marked New that nobody has contacted." },
  { key: "listings_due_verification", group: "attention", label: "Listings due for re-verification", area: "Properties", attention: true, anyOf: ["properties.read_all", "properties.read"], module: "properties", dealData: false,
    help: "Active listings never verified, or not verified within the re-verification period set in Settings." },

  { key: "open_leads", group: "pipeline", label: "Open leads", area: "Leads", attention: false, anyOf: L, module: "leads", dealData: false,
    help: "Leads that have not reached a final status (won or lost)." },
  { key: "hot_leads", group: "pipeline", label: "Hot leads", area: "Leads", attention: false, anyOf: L, module: "leads", dealData: false,
    help: "Open leads at a priority that Settings counts as hot." },
  { key: "buyers_active_requirements", group: "pipeline", label: "Buyers with active requirements", area: "Buyers", attention: false, anyOf: B, module: "buyers", dealData: false,
    help: "Active buyers who have at least one active requirement." },
  { key: "sellers_awaiting_contact", group: "pipeline", label: "Sellers awaiting first contact", area: "Sellers", attention: false, anyOf: S, module: "sellers", dealData: false,
    help: "Sellers and owners still marked New." },
  { key: "matches_ready_to_share", group: "pipeline", label: "Matches ready to share", area: "Matching", attention: false, anyOf: M, module: "matching", dealData: false,
    help: "Suggested property matches for active buyer requirements that have not been shared yet." },
  { key: "active_inventory", group: "pipeline", label: "Active inventory", area: "Properties", attention: false, anyOf: P, module: "properties", dealData: false,
    help: "Listings that are available, reserved or under negotiation." },
  { key: "open_deals", group: "pipeline", label: "Open deals", area: "Deals", attention: false, anyOf: D, module: "deals", dealData: true,
    help: "Deals still in progress, from negotiation to registration. A count only, with no money figures." },
];

export function cardDef(key: CardKey): CardDef {
  const def = CARDS.find((c) => c.key === key);
  if (!def) throw new Error(`Unknown dashboard card: ${key}`);
  return def;
}
