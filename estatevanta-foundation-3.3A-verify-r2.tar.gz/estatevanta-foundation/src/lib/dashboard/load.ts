// The data-fetching boundary for the dashboard. Shared + dependency-free so it can be tested with a stand-in
// client; the real server entry point is src/server/dashboard/summary.ts.
//
// It calls exactly ONE thing: the database function public.dashboard_summary(), with no arguments, through a
// client that carries the signed-in user's own JWT (so Row Level Security applies). It never receives or builds
// a table name, column, filter or SQL, and it has no way to reach the service-role key.
import type { Access } from "@/lib/access";
import { isEmptyCrm, parseDashboardSummary, resolveCards, type DashboardSummary, type ResolvedCard } from "./summary";

/** The one method of the Supabase client this module needs. Anything else is out of reach by construction. */
export type DashboardRpcClient = {
  rpc(fn: "dashboard_summary"): PromiseLike<{ data: unknown; error: { code?: string | null; message?: string | null } | null }>;
};

export type DashboardResult =
  /** No data connection exists (development preview, sign-in not built). No call was made. */
  | { kind: "not_connected" }
  | { kind: "ok"; summary: DashboardSummary; cards: ResolvedCard[]; empty: boolean; warnings: readonly string[] }
  /** The server refused the call because the user has no active account (inactive) or the session is no longer valid. */
  | { kind: "unauthorized"; reason: "inactive" | "signed_out" }
  /** Anything else. `code` is a short, safe reference. Raw messages are never passed to the page. */
  | { kind: "error"; code: string };

// PostgREST / Postgres codes. NOTE: how these arrive through a real PostgREST + JWT is not yet verified live.
const INACTIVE_CODES = new Set(["42501"]); // raised by dashboard_summary() when there is no active profile
const SESSION_CODES = new Set(["PGRST301", "PGRST302"]); // JWT expired / missing

function safeCode(code: unknown): string {
  return typeof code === "string" && /^[A-Za-z0-9_]{1,12}$/.test(code) ? code : "unknown";
}

export async function loadDashboard(client: DashboardRpcClient, access: Access): Promise<DashboardResult> {
  let response: Awaited<ReturnType<DashboardRpcClient["rpc"]>>;
  try {
    response = await client.rpc("dashboard_summary");
  } catch {
    return { kind: "error", code: "network" };
  }

  const { data, error } = response;
  if (error) {
    const code = safeCode(error.code);
    if (INACTIVE_CODES.has(code)) return { kind: "unauthorized", reason: "inactive" };
    if (SESSION_CODES.has(code)) return { kind: "unauthorized", reason: "signed_out" };
    return { kind: "error", code };
  }

  const parsed = parseDashboardSummary(data);
  if (!parsed.ok) return { kind: "error", code: "bad_response" }; // reason deliberately not shown to the user

  const cards = resolveCards(parsed.summary, access.permissions);
  return { kind: "ok", summary: parsed.summary, cards, empty: isEmptyCrm(cards), warnings: parsed.summary.warnings };
}
