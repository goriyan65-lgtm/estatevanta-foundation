// Shared (client + server safe), dependency-free: the shape of public.dashboard_summary(), a STRICT parser
// for it, and the step that turns a validated response into the cards the page draws.
//
// Design rules this file enforces:
//  * The parser fails CLOSED. Any unknown field, wrong type or broken invariant rejects the WHOLE response, so
//    a financial field (price, amount, commission...) can never reach the UI even if the function changed.
//  * A card that is not available carries NO value at all (type-level), so the UI cannot print "0" for it.
//  * UI-side permission check: even when a response says "available", a figure the signed-in role has no
//    permission for is dropped. The database stays the authority; this is defence in depth.
import { CARDS, CARD_KEYS, type CardDef, type CardKey } from "./cards";

export type Scope = "all" | "assigned";

export type CardPayload = { available: boolean; value: number | null; scope: Scope | null };

export type DashboardSummary = {
  schemaVersion: 1;
  generatedAt: string;
  timezone: string;
  warnings: readonly string[];
  cards: Readonly<Record<CardKey, CardPayload>>;
};

export type ParseResult = { ok: true; summary: DashboardSummary } | { ok: false; reason: string };

const TOP_KEYS = ["cards", "generated_at", "schema_version", "timezone", "warnings"];
const CARD_FIELDS = ["available", "scope", "value"];
const MAX_VALUE = 1_000_000_000;

function isObject(x: unknown): x is Record<string, unknown> {
  return typeof x === "object" && x !== null && !Array.isArray(x);
}
function sameKeys(obj: Record<string, unknown>, expected: readonly string[]): boolean {
  const have = Object.keys(obj).sort();
  const want = [...expected].sort();
  return have.length === want.length && have.every((k, i) => k === want[i]);
}

export function parseDashboardSummary(input: unknown): ParseResult {
  if (!isObject(input)) return { ok: false, reason: "not_an_object" };
  if (!sameKeys(input, TOP_KEYS)) return { ok: false, reason: "unexpected_top_level_fields" };
  if (input.schema_version !== 1) return { ok: false, reason: "unsupported_schema_version" };

  const generatedAt = input.generated_at;
  if (typeof generatedAt !== "string" || Number.isNaN(Date.parse(generatedAt))) return { ok: false, reason: "bad_generated_at" };
  const timezone = input.timezone;
  if (typeof timezone !== "string" || timezone.length === 0 || timezone.length > 64) return { ok: false, reason: "bad_timezone" };

  const warnings = input.warnings;
  if (!Array.isArray(warnings) || warnings.length > 10) return { ok: false, reason: "bad_warnings" };
  for (const w of warnings) if (typeof w !== "string" || !/^[a-z_]{1,64}$/.test(w)) return { ok: false, reason: "bad_warnings" };

  const rawCards = input.cards;
  if (!isObject(rawCards) || !sameKeys(rawCards, CARD_KEYS)) return { ok: false, reason: "unexpected_card_set" };

  const cards = {} as Record<CardKey, CardPayload>;
  for (const key of CARD_KEYS) {
    const c = rawCards[key];
    if (!isObject(c) || !sameKeys(c, CARD_FIELDS)) return { ok: false, reason: `bad_card_shape:${key}` };
    const { available, value, scope } = c;
    if (typeof available !== "boolean") return { ok: false, reason: `bad_available:${key}` };
    if (available) {
      if (typeof value !== "number" || !Number.isInteger(value) || value < 0 || value > MAX_VALUE) return { ok: false, reason: `bad_value:${key}` };
      if (scope !== "all" && scope !== "assigned") return { ok: false, reason: `bad_scope:${key}` };
      cards[key] = { available: true, value, scope };
    } else {
      if (value !== null || scope !== null) return { ok: false, reason: `unavailable_card_carries_data:${key}` };
      cards[key] = { available: false, value: null, scope: null };
    }
  }

  return { ok: true, summary: { schemaVersion: 1, generatedAt, timezone, warnings: warnings as string[], cards } };
}

// ---------------------------------------------------------------------------------------------
// What the page draws
// ---------------------------------------------------------------------------------------------

export type ResolvedCard =
  | { def: CardDef; state: "loaded"; value: number; scope: Scope }
  | { def: CardDef; state: "unavailable" } // the role may not see this figure. NEVER shown as 0.
  | { def: CardDef; state: "not_loaded" }; // no data connection yet (sign-in not built). NEVER shown as 0.

/** True when ANY of the card's permission codes is held. */
export function permits(def: CardDef, permissions: readonly string[]): boolean {
  return def.anyOf.some((code) => permissions.includes(code));
}

/** Turn a validated response into the 13 cards, in display order. */
export function resolveCards(summary: DashboardSummary, permissions: readonly string[]): ResolvedCard[] {
  return CARDS.map((def): ResolvedCard => {
    const payload = summary.cards[def.key];
    if (!payload.available || payload.value === null || payload.scope === null) return { def, state: "unavailable" };
    if (!permits(def, permissions)) return { def, state: "unavailable" }; // second, UI-side gate
    return { def, state: "loaded", value: payload.value, scope: payload.scope };
  });
}

/** All 13 cards with no figures: used while no data connection exists. */
export function notLoadedCards(): ResolvedCard[] {
  return CARDS.map((def): ResolvedCard => ({ def, state: "not_loaded" }));
}

/** "Empty CRM": at least one figure is shown and every shown figure is zero. */
export function isEmptyCrm(cards: readonly ResolvedCard[]): boolean {
  const loaded = cards.filter((c): c is Extract<ResolvedCard, { state: "loaded" }> => c.state === "loaded");
  return loaded.length > 0 && loaded.every((c) => c.value === 0);
}

/** Human wording for the warning codes dashboard_summary() can return. Unknown codes get a generic line. */
export function describeWarning(code: string): string {
  switch (code) {
    case "app_timezone_fallback":
      return "The timezone setting is missing or invalid, so Asia/Kolkata is used for “today”.";
    case "leads_hot_priorities_fallback":
      return "The hot-lead priorities setting is missing or invalid, so High and Urgent are used.";
    case "property_reverify_days_fallback":
      return "The re-verification period setting is missing or invalid, so 30 days is used.";
    default:
      return "A dashboard setting is missing or invalid, so a default is used.";
  }
}
