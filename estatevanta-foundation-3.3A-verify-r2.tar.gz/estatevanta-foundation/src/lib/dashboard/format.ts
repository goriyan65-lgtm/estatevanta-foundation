// Display helpers for the dashboard. Pure; no data.

const COUNT = new Intl.NumberFormat("en-IN");

/** 12345 -> "12,345" (Indian grouping: 1,23,456). */
export function formatCount(n: number): string {
  return COUNT.format(n);
}

/** "9 Oct, 12:15 pm IST" in the dashboard's own timezone; falls back to the server's zone if the name is rejected. */
export function formatGeneratedAt(iso: string, timeZone: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  const opts: Intl.DateTimeFormatOptions = { day: "numeric", month: "short", hour: "numeric", minute: "2-digit", timeZoneName: "short" };
  try {
    return new Intl.DateTimeFormat("en-IN", { ...opts, timeZone }).format(date);
  } catch {
    return new Intl.DateTimeFormat("en-IN", opts).format(date);
  }
}
