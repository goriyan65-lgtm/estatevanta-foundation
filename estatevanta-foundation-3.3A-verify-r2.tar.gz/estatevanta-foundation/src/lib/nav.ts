// Single source of truth for the CRM sections: route, label, permission rule and what each will contain.
// Permission codes are the ones seeded in the database (roles -> role_permissions -> permissions).
// Nothing here is data; it is structure only.

export type ModuleId =
  | "dashboard" | "properties" | "buyers" | "sellers" | "leads" | "matching"
  | "appointments" | "deals" | "analytics" | "market" | "settings";

export type NavModule = {
  id: ModuleId;
  label: string;
  href: `/${string}`;
  /** User needs ANY of these permission codes. Empty = any active signed-in user. */
  anyOf: readonly string[];
  title: string;
  description: string;
  emptyTitle: string;
  emptyBody: string;
  builtIn: string; // which build phase fills this screen with real data
  planned: readonly string[];
};

export const MODULES: Record<ModuleId, NavModule> = {
  dashboard: {
    id: "dashboard", label: "Dashboard", href: "/dashboard", anyOf: [],
    title: "Dashboard",
    description: "A summary of what needs attention across the business.",
    emptyTitle: "Nothing to count yet",
    emptyBody: "Every figure is zero because no records have been added yet. The cards fill in as properties, leads, buyers and appointments are added.",
    builtIn: "Phase 3.2",
    planned: [],
  },
  properties: {
    id: "properties", label: "Properties", href: "/properties",
    anyOf: ["properties.read", "properties.read_all", "properties.read_active"],
    title: "Properties",
    description: "Listings, owner inventory, photos, videos and documents.",
    emptyTitle: "No properties yet",
    emptyBody: "Properties you add or import from an authorised file will be listed here.",
    builtIn: "Phase 5",
    planned: ["All properties", "Add property", "Owner inventory and verification", "Photos and videos", "Documents"],
  },
  buyers: {
    id: "buyers", label: "Buyers", href: "/buyers",
    anyOf: ["buyers.read", "buyers.read_all"],
    title: "Buyers",
    description: "Buyer profiles and what each buyer is looking for.",
    emptyTitle: "No buyers yet",
    emptyBody: "Buyers will appear here once they are added or converted from leads.",
    builtIn: "Phase 4",
    planned: ["Buyer profiles", "Budget, locations and property types", "Multiple requirements per buyer"],
  },
  sellers: {
    id: "sellers", label: "Sellers", href: "/sellers",
    anyOf: ["sellers.read", "sellers.read_all"],
    title: "Sellers and owners",
    description: "Property owners and the properties each one holds.",
    emptyTitle: "No sellers yet",
    emptyBody: "Sellers and owners will appear here once they are added. One owner can hold many properties.",
    builtIn: "Phase 4",
    planned: ["Owner profiles", "Relationship status", "Properties per owner"],
  },
  leads: {
    id: "leads", label: "Leads", href: "/leads",
    anyOf: ["leads.read", "leads.read_all"],
    title: "Leads",
    description: "Enquiries from every source and where each one stands.",
    emptyTitle: "No leads yet",
    emptyBody: "Leads from calls, walk-ins, WhatsApp and the website will appear here. Duplicates are checked by phone, WhatsApp and email.",
    builtIn: "Phase 4",
    planned: ["Lead list with search and filters", "Status, priority and assigned agent", "Next follow-up", "Contacts"],
  },
  matching: {
    id: "matching", label: "Matching engine", href: "/matching",
    anyOf: ["matching.read", "matching.read_all"],
    title: "Matching engine",
    description: "Buyer requirements matched against available properties.",
    emptyTitle: "No requirements or matches yet",
    emptyBody: "Add a buyer requirement and the engine scores it against properties. The weights are set in Settings.",
    builtIn: "Phase 6",
    planned: ["Buyer requirements", "Property matches with score and reasons", "Match history"],
  },
  appointments: {
    id: "appointments", label: "Appointments", href: "/appointments",
    anyOf: ["appointments.read", "appointments.read_all"],
    title: "Appointments",
    description: "Site visits, calls, meetings and follow-ups.",
    emptyTitle: "Nothing scheduled",
    emptyBody: "Site visits, calls, meetings and follow-up tasks will appear here.",
    builtIn: "Phase 7",
    planned: ["Site visits", "Calls", "Meetings", "Follow-ups and tasks"],
  },
  deals: {
    id: "deals", label: "Deals", href: "/deals",
    anyOf: ["deals.read", "deals.read_all"],
    title: "Deals",
    description: "Negotiations, closed deals, commission and payments.",
    emptyTitle: "No deals yet",
    emptyBody: "Deals appear here once a negotiation starts. Commission is calculated from real deals only.",
    builtIn: "Phase 8",
    planned: ["Negotiations", "Closed deals", "Commission", "Payments"],
  },
  analytics: {
    id: "analytics", label: "Analytics", href: "/analytics",
    anyOf: ["analytics.read"],
    title: "Analytics",
    description: "Trends and performance across leads, properties and deals.",
    emptyTitle: "No data to analyse yet",
    emptyBody: "Charts appear once there are real records to measure. Nothing is estimated or filled in.",
    builtIn: "Phase 10",
    planned: ["Lead sources and conversion", "Pipeline by stage", "Agent performance"],
  },
  market: {
    id: "market", label: "Market intel", href: "/market",
    anyOf: ["market.read", "market.read_all"],
    title: "Market intel",
    description: "Price and demand information you have collected or imported.",
    emptyTitle: "No market data yet",
    emptyBody: "Market data comes from files you are allowed to import, with the source and date stored on every row.",
    builtIn: "Phase 10",
    planned: ["Price records by locality", "Imported listings with source and date", "Verification status"],
  },
  settings: {
    id: "settings", label: "Settings", href: "/settings",
    anyOf: ["settings.manage", "users.manage"],
    title: "Settings",
    description: "Users, roles, lists, matching weights and imports.",
    emptyTitle: "Settings are not connected yet",
    emptyBody: "Each settings area is added together with the feature it controls.",
    builtIn: "Phases 4 to 11",
    planned: ["Users and roles", "Reference lists", "Matching weights", "Import files", "General"],
  },
};

/** Sidebar order requested for the app. */
export const NAV_ORDER: readonly ModuleId[] = [
  "dashboard", "properties", "buyers", "sellers", "leads", "matching",
  "appointments", "deals", "analytics", "market", "settings",
];

/** Shown in the phone bottom bar when the user can see them; everything else sits under "More". */
export const MOBILE_PRIMARY: readonly ModuleId[] = ["dashboard", "leads", "properties", "appointments"];
