"use client";

// Last-resort boundary for errors in the root layout. It replaces the whole document, so it carries
// its own html/body and plain inline styles (the stylesheet may be the thing that failed).
export default function GlobalError({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <html lang="en-IN">
      <body style={{ fontFamily: "system-ui, sans-serif", margin: 0, display: "grid", minHeight: "100vh", placeItems: "center", padding: 24 }}>
        <div style={{ maxWidth: 420, textAlign: "center" }}>
          <h1 style={{ fontSize: 22 }}>The app couldn't load</h1>
          <p style={{ color: "#566774" }}>Something went wrong while starting the CRM. Reload the page. If it keeps happening, tell the admin.</p>
          <button type="button" onClick={reset} style={{ minHeight: 44, padding: "0 16px", fontSize: 16 }}>Reload</button>
        </div>
      </body>
    </html>
  );
}
