import { notFound } from "next/navigation";
import { PageHeader } from "@/components/ui/PageHeader";
import { EmptyState } from "@/components/states/EmptyState";
import { ErrorState } from "@/components/states/ErrorState";
import { LoadingState } from "@/components/states/LoadingState";
import { UnauthorizedState } from "@/components/states/UnauthorizedState";

// Development-only gallery of the shared states so they can be reviewed on a phone and a desktop.
// It contains no records. In production the route does not exist.
export default function StatesGallery() {
  if (process.env.NODE_ENV === "production") notFound();
  return (
    <>
      <PageHeader title="Shared states" description="Development preview of loading, empty, error and unauthorized screens." />
      <div className="grid grid-cols-[minmax(0,1fr)] gap-6">
        <LoadingState label="Loading preview" />
        <EmptyState title="No records yet" body="This is how an empty list looks." />
        <ErrorState title="This section couldn't load" body="This is how an error looks." detail="Reference: example" />
        <UnauthorizedState variant="signed_out" />
        <UnauthorizedState variant="forbidden" sectionLabel="Deals" />
        <UnauthorizedState variant="inactive" />
      </div>
    </>
  );
}
