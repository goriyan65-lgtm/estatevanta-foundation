"use client";

import { ErrorState } from "@/components/states/ErrorState";
import { Button } from "@/components/ui/buttons";

export default function SectionError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <ErrorState
      title="This section couldn't load"
      body="Something went wrong while loading this page. Try again. If it keeps happening, tell the admin and quote the reference below."
      detail={error.digest ? `Reference: ${error.digest}` : undefined}
      action={<Button onClick={reset}>Try again</Button>}
    />
  );
}
