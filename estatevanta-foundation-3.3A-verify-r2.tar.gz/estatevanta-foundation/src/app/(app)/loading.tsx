import { LoadingState } from "@/components/states/LoadingState";

export default function Loading() {
  return <LoadingState label="Loading this section" />;
}
