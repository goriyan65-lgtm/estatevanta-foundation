import type { Metadata } from "next";
import { ModulePage } from "@/components/modules/ModulePage";
import { MODULES } from "@/lib/nav";

export const metadata: Metadata = { title: MODULES.analytics.label };

export default function Page() {
  return <ModulePage id="analytics" />;
}
