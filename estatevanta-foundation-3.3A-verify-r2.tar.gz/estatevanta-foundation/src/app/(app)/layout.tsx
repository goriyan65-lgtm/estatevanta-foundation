import type { ReactNode } from "react";
import { redirect } from "next/navigation";
import { canAccess } from "@/lib/access";
import { MODULES, NAV_ORDER } from "@/lib/nav";
import { getAccessState } from "@/server/auth/session";
import { signOut } from "@/server/auth/actions";
import { AppShell } from "@/components/shell/AppShell";
import { AccessGate } from "@/components/states/AccessGate";

// Every page under (app) is rendered inside this layout, and it renders `children` ONLY for a verified, active user.
// Any other state (signed out, inactive, unconfigured, error, or anything unexpected) never reaches the page content.
// Session-dependent: never cached, never shared between users.
//
// A layout is NOT re-run when a signed-in user moves between pages, so this check alone is not enough: every page
// ALSO calls getAccessState() itself (directly or through ModulePage). tests/auth.test.ts enforces that.
export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: ReactNode }) {
  const state = await getAccessState();

  if (state.status === "signed_out") redirect("/login");

  if (state.status !== "ready") {
    return (
      <main className="mx-auto grid min-h-dvh max-w-xl place-items-center p-6">
        <AccessGate state={state} />
      </main>
    );
  }

  const items = NAV_ORDER.map((id) => MODULES[id])
    .filter((m) => canAccess(state, m.anyOf))
    .map(({ id, label, href }) => ({ id, label, href }));

  const user = { name: state.access.fullName ?? "Signed in", role: state.access.role };

  return <AppShell items={items} user={user} signOut={signOut}>{children}</AppShell>;
}
