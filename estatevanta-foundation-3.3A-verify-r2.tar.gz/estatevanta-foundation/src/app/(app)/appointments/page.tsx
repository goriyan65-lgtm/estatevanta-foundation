import type { Metadata } from "next";
import { ModulePage } from "@/components/modules/ModulePage";
import { MODULES } from "@/lib/nav";

export const metadata: Metadata = { title: MODULES.appointments.label };

export default function Page() {
  return <ModulePage id="appointments" />;
}
