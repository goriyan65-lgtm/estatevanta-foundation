import type { Metadata } from "next";
import { DashboardView } from "@/components/dashboard/DashboardView";
import { AccessDenied } from "@/components/states/AccessDenied";
import { PageHeader } from "@/components/ui/PageHeader";
import { canAccess } from "@/lib/access";
import { MODULES, NAV_ORDER } from "@/lib/nav";
import { getAccessState } from "@/server/auth/session";
import { getDashboard } from "@/server/dashboard/summary";

export const metadata: Metadata = { title: MODULES.dashboard.label };

// Always rendered per request: the figures depend on who is signed in and must never be cached or shared.
export const dynamic = "force-dynamic";

export default async function Page() {
  const mod = MODULES.dashboard;
  // Checked here as well as in the layout: the layout does not re-run when a signed-in user moves between pages.
  const state = await getAccessState();

  if (!canAccess(state, mod.anyOf)) return <AccessDenied state={state} sectionLabel={mod.label} />;

  const result = await getDashboard(state);
  const openable = NAV_ORDER.filter((id) => canAccess(state, MODULES[id].anyOf));

  return (
    <>
      <PageHeader title={mod.title} description={mod.description} />
      <DashboardView result={result} openable={openable} />
    </>
  );
}
