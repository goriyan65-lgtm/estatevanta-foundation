import { CARD_GROUPS, CARDS } from "@/lib/dashboard/cards";

// Skeleton for the dashboard while dashboard_summary() is running. Placeholders only: no text values, no numbers.
export default function Loading() {
  return (
    <div role="status" aria-busy="true" aria-live="polite">
      <span className="sr-only">Loading dashboard figures</span>
      <div className="skeleton mb-2 h-8 w-48" />
      <div className="skeleton mb-6 h-4 w-72 max-w-full" />
      <div className="space-y-6">
        {CARD_GROUPS.map((group) => (
          <div key={group.id}>
            <div className="skeleton mb-3 h-5 w-52 max-w-full" />
            <div className="grid grid-cols-[minmax(0,1fr)] gap-3 min-[560px]:grid-cols-2 xl:grid-cols-3">
              {CARDS.filter((c) => c.group === group.id).map((c) => (
                <div key={c.key} className="rounded-lg border border-line bg-surface p-4">
                  <div className="skeleton mb-2 h-3 w-20" />
                  <div className="skeleton mb-4 h-4 w-40 max-w-full" />
                  <div className="skeleton h-10 w-16" />
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
