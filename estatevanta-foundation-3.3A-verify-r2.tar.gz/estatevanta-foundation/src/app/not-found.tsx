import { EmptyState } from "@/components/states/EmptyState";
import { LinkButton } from "@/components/ui/buttons";

export default function NotFound() {
  return (
    <main className="mx-auto grid min-h-dvh max-w-xl place-items-center p-6">
      <EmptyState title="Page not found" body="This address doesn't match any section of the CRM." action={<LinkButton href="/dashboard">Go to dashboard</LinkButton>} />
    </main>
  );
}
