import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { LoginForm } from "@/components/auth/LoginForm";
import { ErrorState } from "@/components/states/ErrorState";
import { UnauthorizedState } from "@/components/states/UnauthorizedState";
import { getAccessState } from "@/server/auth/session";
import { signIn } from "@/server/auth/actions";

export const metadata: Metadata = { title: "Sign in" };

// Session-dependent: never cached.
export const dynamic = "force-dynamic";

// There is no sign-up, no "forgot password" and no magic link here. Accounts are created by an admin and an
// account only works once it has been activated and given a role (the app checks that after sign-in).
export default async function LoginPage() {
  const state = await getAccessState();

  // Already signed in with an active account: nothing to do here.
  if (state.status === "ready") redirect("/dashboard");

  return (
    <main className="mx-auto grid min-h-dvh max-w-md place-items-center p-6">
      <div className="w-full">
        <div className="mb-6 text-center">
          <h1 className="text-2xl font-semibold tracking-tight text-ink">EstateVanta CRM</h1>
          <p className="mt-1 text-[0.9375rem] text-muted">Sign in to continue.</p>
        </div>

        {state.status === "unconfigured" ? (
          <ErrorState
            title="Supabase isn't configured"
            body="Sign-in can't work until the project URL and its public (anon) key are set on the server."
          />
        ) : state.status === "inactive" ? (
          // Signed in, but the account has no active profile or role. Offer to sign out (so someone else can sign in).
          <UnauthorizedState variant="inactive" />
        ) : (
          <div className="rounded-lg border border-line bg-surface p-5 shadow-sm sm:p-6">
            {state.status === "error" ? (
              <p role="status" className="mb-4 rounded-md border border-warn/40 bg-warn-bg px-3 py-2 text-sm text-ink">
                Your session couldn't be checked just now (reference: {state.message}). You can still try to sign in.
              </p>
            ) : null}
            <LoginForm action={signIn} />
          </div>
        )}
      </div>
    </main>
  );
}
