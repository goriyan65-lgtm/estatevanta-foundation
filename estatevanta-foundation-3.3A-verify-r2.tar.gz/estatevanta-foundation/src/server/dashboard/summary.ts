import "server-only"; // the build fails if this is ever imported from client code
import type { AccessState } from "@/lib/access";
import { loadDashboard, type DashboardResult, type DashboardRpcClient } from "@/lib/dashboard/load";
import { createUserClient } from "@/server/supabase/user-client";

/**
 * Server-side entry point for the dashboard figures.
 *
 *  - ready        -> public.dashboard_summary() through the USER client (anon key + the user's own verified session
 *    cookie), so Row Level Security applies. This is the ONLY Supabase client used here; the service-role client
 *    (admin-client.ts) is not imported by any dashboard file.
 *  - unconfigured -> { kind: "not_connected" }. No client is created and nothing is faked.
 *  - any other state (signed out, inactive, error) -> unauthorized (fails closed). No call is made.
 *
 * A "ready" state can only come from getAccessState(), which has verified the session with Supabase Auth and read the
 * user's active profile. The permissions it carries are used only to decide what the UI draws; the figures themselves
 * come from the database function, which applies its own permission checks and RLS.
 */
export async function getDashboard(state: AccessState): Promise<DashboardResult> {
  if (state.status === "unconfigured") return { kind: "not_connected" };
  if (state.status !== "ready") return { kind: "unauthorized", reason: "signed_out" };

  let client: Awaited<ReturnType<typeof createUserClient>>;
  try {
    client = await createUserClient();
  } catch {
    return { kind: "error", code: "config" };
  }
  // Narrow adapter: exposes ONLY rpc("dashboard_summary") with no arguments, and passes back just data + error.
  const supabase = client;
  const rpcClient: DashboardRpcClient = {
    rpc: async (fn) => {
      const { data, error } = await supabase.rpc(fn);
      return { data, error: error ? { code: error.code, message: error.message } : null };
    },
  };
  return loadDashboard(rpcClient, state.access);
}
