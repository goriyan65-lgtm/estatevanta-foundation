import "server-only";
import { cache } from "react";
import type { AccessState } from "@/lib/access";
import { resolveAccessState, type AccessClient } from "@/lib/auth/resolve";
import { getSupabasePublicEnv } from "@/lib/supabase/env";
import { createUserClient } from "@/server/supabase/user-client";

/**
 * Who is making this request, and what may they do. The ONLY place the app decides that.
 *
 *   env missing or invalid          -> { status: "unconfigured" }
 *   no / invalid / revoked session  -> { status: "signed_out" }   (verified with Supabase Auth via getUser(), never getSession())
 *   no profile, inactive, no role   -> { status: "inactive" }
 *   Auth or database unreachable    -> { status: "error", message: <short reference code> }
 *   verified, active, with a role   -> { status: "ready", access }  (permissions from public.my_access(), read with the user's own JWT)
 *
 * There is no development shortcut: development behaves exactly like production. Every request is checked; nothing
 * is trusted from a previous request. React cache() only makes the layout and the page share ONE check per request.
 * The database (RLS) remains the final authority; this decides what the UI shows.
 */
export const getAccessState = cache(async (): Promise<AccessState> => {
  if (!getSupabasePublicEnv()) return { status: "unconfigured" };

  let supabase: Awaited<ReturnType<typeof createUserClient>>;
  try {
    supabase = await createUserClient();
  } catch {
    return { status: "error", message: "client_unavailable" };
  }

  // Narrow adapter: only getUser() and rpc("my_access") with no arguments, and only plain data comes back.
  const client: AccessClient = {
    auth: {
      getUser: async () => {
        const { data, error } = await supabase.auth.getUser();
        return {
          data: data?.user ? { user: { id: data.user.id } } : { user: null },
          error: error ? { name: error.name, status: error.status ?? null, code: error.code ?? null } : null,
        };
      },
    },
    rpc: async (fn) => {
      const { data, error } = await supabase.rpc(fn);
      return { data, error: error ? { code: error.code, message: error.message } : null };
    },
  };

  try {
    return await resolveAccessState(client);
  } catch {
    return { status: "error", message: "auth_unexpected" };
  }
});
