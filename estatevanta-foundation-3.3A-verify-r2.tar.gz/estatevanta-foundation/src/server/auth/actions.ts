"use server";

import { revalidatePath } from "next/cache";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { checkCredentials, MESSAGES, signInMessage, type SignInState } from "@/lib/auth/credentials";
import { isSessionCookieName } from "@/lib/supabase/cookies";
import { getSupabasePublicEnv } from "@/lib/supabase/env";
import { createUserClient } from "@/server/supabase/user-client";

// Server Actions are POST-only and Next.js checks the request Origin against the Host, which is the CSRF protection.
// Each action does its own work and does not rely on the proxy.
//
// Uses the public anon key only. There is no sign-up, no password reset and no magic link in this phase: the app can
// only sign an existing, admin-created user in or out.

export async function signIn(_previous: SignInState, formData: FormData): Promise<SignInState> {
  const checked = checkCredentials(formData.get("email"), formData.get("password"));
  if (!checked.ok) return { error: MESSAGES.missing, email: checked.email };

  if (!getSupabasePublicEnv()) return { error: MESSAGES.notConfigured, email: checked.email };

  let failure: string | null = null;
  try {
    const supabase = await createUserClient();
    const { data, error } = await supabase.auth.signInWithPassword({ email: checked.email, password: checked.password });
    if (error) failure = signInMessage({ name: error.name, status: error.status ?? null, code: error.code ?? null });
    else if (!data?.session) failure = MESSAGES.unavailable;
  } catch {
    failure = MESSAGES.unavailable;
  }
  if (failure) return { error: failure, email: checked.email };

  // The session cookie is set. The layout now verifies the account (active, has a role) on the next request.
  revalidatePath("/", "layout");
  redirect("/dashboard");
}

export async function signOut(): Promise<void> {
  try {
    const supabase = await createUserClient();
    await supabase.auth.signOut(); // revokes the session with Supabase and asks the client to clear its cookies
  } catch {
    // Auth unreachable or not configured: fall through and still clear the cookies here.
  }
  try {
    // Belt and braces: whatever happened above, this browser no longer holds a session.
    const store = await cookies();
    for (const { name } of store.getAll()) if (isSessionCookieName(name)) store.delete(name);
  } catch {
    /* nothing more can be done */
  }
  revalidatePath("/", "layout");
  redirect("/login");
}
