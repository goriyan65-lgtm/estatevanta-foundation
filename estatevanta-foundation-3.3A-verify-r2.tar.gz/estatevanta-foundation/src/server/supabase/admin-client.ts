import "server-only"; // build fails if this is ever imported from client code
import { createClient } from "@supabase/supabase-js";

// Service-role client: bypasses RLS. Use ONLY for public enquiry intake,
// matching runs and scheduled jobs, after the caller has been authorised.
export function createAdminClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error("Supabase server environment is not configured");
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
}
