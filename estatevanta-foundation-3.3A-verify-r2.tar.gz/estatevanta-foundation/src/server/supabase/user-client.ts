import "server-only";
import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";
import { hardenCookieOptions } from "@/lib/supabase/cookies";
import { getSupabasePublicEnv } from "@/lib/supabase/env";

export class SupabaseNotConfiguredError extends Error {
  constructor() {
    super("Supabase public environment is missing or invalid");
    this.name = "SupabaseNotConfiguredError";
  }
}

// User-context client: carries the logged-in user's JWT (from the HttpOnly session cookie), so Postgres RLS applies.
// Uses ONLY the public anon key. The service-role client lives in admin-client.ts and is not used for sign-in or
// for reading anything on behalf of a user.
export async function createUserClient() {
  const env = getSupabasePublicEnv();
  if (!env) throw new SupabaseNotConfiguredError();
  const store = await cookies();
  return createServerClient(env.url, env.anonKey, {
    cookies: {
      getAll: () => store.getAll(),
      setAll: (list) => {
        try {
          list.forEach(({ name, value, options }) => store.set(name, value, hardenCookieOptions(options)));
        } catch {
          // Called from a Server Component, which cannot write cookies. The proxy refreshes the session instead.
        }
      },
    },
  });
}
