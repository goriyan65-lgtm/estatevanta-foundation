# Phase 3.3A audit follow-up: fixes F1 and F2 (PROPOSED, NOT APPLIED)

Status: written and tested on a throwaway LOCAL PostgreSQL 16 replica only. Nothing was applied to the live Supabase
project, nothing was committed, and Firebase and the website were not touched. Applying needs separate owner approval.

## F1: viewers could read deal-linked activity rows

Cause: `activities_select` (0007) allows any holder of `activities.read_all` to read every activity row. Viewers hold it.
A row with a `deal_id` can carry deal figures in `summary` / `details`.

Fix: `supabase/migrations/0013a_phase3_3_activities_deal_gate.sql` adds ONE restrictive SELECT policy
`activities_select_deal_gate`: a row with a `deal_id` is returned only if the caller can also see that deal under the
deals table's own RLS. Restrictive policies are AND-ed with the existing permissive ones, so this also closes the path
where a deal-linked row carries a visible `lead_id` / `buyer_id` / `property_id`. Rows without a `deal_id` are unaffected.
Rollback: `supabase/migrations/rollback/0013a_rollback.sql` (drops only that policy).

| Role | Before | After |
|---|---|---|
| Viewer | all activity rows | rows without a deal only |
| Agent | rows of parents they can see | unchanged (own/assigned deals still visible) |
| Manager | all rows | all rows except those of a soft-deleted deal |
| Admin | all rows | unchanged |

Tests: `supabase/tests/phase3_3_activities_deal_gate_tests.sql` (27 checks, fully rolled back) and
`supabase/tests/phase3_3_local_run.sh` (red/green/rollback lifecycle on the local replica).

## F2: test permission fixtures did not match the SQL grants

Cause: `PERMS` in `tests/auth.test.ts` was a short hand-written list for three roles and differed from the SQL
(for example the viewer fixture held `properties.read_active`, which the SQL gives only to admin, manager and agent).

Fix: `tests/fixtures/role-permissions.ts` holds the full lists for all four roles (admin 60, manager 57, agent 18,
viewer 12), generated from the replayed SQL migrations, with a fingerprint. `tests/auth.test.ts` now uses it.
`tests/roles.test.ts` checks counts, the fingerprint, the permission universe against the SQL seed text, per-role rules,
and sidebar visibility per role. `supabase/tests/phase3_3_role_grants_readonly.sql` (pure SELECT) returns the same
fingerprint from a real database, so the live grants can be compared later with owner approval.

## Not covered (unchanged, still open)

- Live database not queried: whether the live grants equal the fixture is NOT VERIFIED until the read-only query is run.
- Free text in non-deal activities is not inspected.
- An agent with `activities.write` can insert an activity naming a deal they cannot see (the INSERT policy does not check
  the deal; read from the policy, not tested). Low severity; a separate, later decision.

## Apply checklist (only after explicit approval)

1. Run `supabase/tests/phase3_3_role_grants_readonly.sql` on the live project (read-only) and compare the fingerprint.
2. Apply `0013a`; change its header line from PROPOSED to APPLIED with the date.
3. Run `phase3_3_activities_deal_gate_tests.sql` (rolled back; refuses to run if business tables have rows).
4. `npm test` in a real install.
