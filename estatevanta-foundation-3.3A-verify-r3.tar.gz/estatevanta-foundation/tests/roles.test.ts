// Phase 3.3 — role / permission fixture tests (node:test; run with `node tests/run.mjs`).
//
// WHAT THESE PROVE: the permission lists used by the tests are the SAME as the SQL grants for all four roles (admin,
// manager, agent, viewer), the viewer is kept away from deal and finance permissions, and the sidebar rules in
// src/lib/nav.ts behave as the owner's decisions require for each role.
// WHAT THEY DO NOT PROVE: that the LIVE database holds these grants (it was not queried), or that RLS blocks a row.
// Row-level behaviour is tested in SQL: supabase/tests/phase3_3_activities_deal_gate_tests.sql and the Phase 2/3 SQL suites.
// To compare a real database with this fixture, run supabase/tests/phase3_3_role_grants_readonly.sql and compare the
// fingerprint it prints with ROLE_PERMISSIONS_FINGERPRINT.
//
// Nothing here is real data: the lists are system configuration, not business records.
import test from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";

import { canAccess, type AccessState } from "@/lib/access";
import { MODULES, NAV_ORDER, type ModuleId } from "@/lib/nav";
import { ALL_PERMISSIONS, ROLE_CODES, ROLE_PERMISSIONS, ROLE_PERMISSIONS_FINGERPRINT, type RoleCode } from "./fixtures/role-permissions";

// tests/run.mjs sets the working directory to the project root, so paths are relative to it (as in auth.test.ts).
const read = (rel: string) => readFileSync(rel, "utf8");
const has = (role: RoleCode, code: string) => ROLE_PERMISSIONS[role].includes(code);
const holds = (role: RoleCode, prefix: string) => ROLE_PERMISSIONS[role].filter((c) => c.startsWith(prefix));

test("fixture: four roles, 60 permissions, no duplicates, counts match the SQL seeds", () => {
  assert.deepEqual([...ROLE_CODES], ["admin", "manager", "agent", "viewer"]);
  assert.equal(ALL_PERMISSIONS.length, 60);
  assert.equal(new Set(ALL_PERMISSIONS).size, 60, "permission codes are unique");
  const counts = Object.fromEntries(ROLE_CODES.map((r) => [r, ROLE_PERMISSIONS[r].length]));
  assert.deepEqual(counts, { admin: 60, manager: 57, agent: 18, viewer: 12 });
  assert.equal(Object.values(counts).reduce((a, b) => a + b, 0), 147, "147 grants: the number of role_permissions rows read from the live project earlier");
  for (const r of ROLE_CODES) {
    assert.equal(new Set(ROLE_PERMISSIONS[r]).size, ROLE_PERMISSIONS[r].length, `${r}: no duplicate grants`);
    for (const code of ROLE_PERMISSIONS[r]) assert.ok(ALL_PERMISSIONS.includes(code), `${r}: ${code} is a seeded permission`);
  }
});

test("fixture: the fingerprint is recomputed from the lists, so a hand edit is caught", () => {
  const lines = [...ROLE_CODES]
    .sort()
    .flatMap((r) => [...ROLE_PERMISSIONS[r]].sort().map((p) => `${r}:${p}`))
    .join("\n");
  assert.equal(createHash("md5").update(lines).digest("hex"), ROLE_PERMISSIONS_FINGERPRINT);
});

test("fixture: the permission universe equals the SQL seed (module x action grid + the explicit extras)", () => {
  const sql8 = read("supabase/migrations/0008_system_config.sql");
  const sql9 = read("supabase/migrations/0009_confirmed_decisions.sql");
  const modules = /unnest\(array\[([^\]]+)\]\)\s+as m/.exec(sql8)?.[1]?.match(/'([a-z_]+)'/g)?.map((s) => s.slice(1, -1)) ?? [];
  const actions = /unnest\(array\[('read'[^\]]+)\]\)\s+as a/.exec(sql8)?.[1]?.match(/'([a-z_]+)'/g)?.map((s) => s.slice(1, -1)) ?? [];
  assert.equal(modules.length, 13);
  assert.deepEqual(actions, ["read", "read_all", "write", "delete"]);
  const extras8 = [...(/insert into permissions \(code, description\) values([\s\S]*?);/.exec(sql8)?.[1] ?? "").matchAll(/\('([a-z_.]+)'/g)].map((m) => m[1]);
  const extras9 = [...(/insert into permissions \(code, description\) values([\s\S]*?);/.exec(sql9)?.[1] ?? "").matchAll(/\('([a-z_.]+)'/g)].map((m) => m[1]);
  const expected = [...modules.flatMap((m) => actions.map((a) => `${m}.${a}`)), ...extras8, ...extras9].sort();
  assert.equal(expected.length, 60);
  assert.deepEqual([...ALL_PERMISSIONS].sort(), expected);
});

test("admin holds every permission", () => {
  assert.deepEqual([...ROLE_PERMISSIONS.admin].sort(), [...ALL_PERMISSIONS].sort());
});

test("manager: all CRM modules, finance and deals, but no user, settings or audit administration", () => {
  for (const c of ["deals.read_all", "deals.write", "finance.read_all", "finance.write", "imports.write", "messaging.write", "analytics.read", "activities.read_all", "properties.write_all"]) assert.ok(has("manager", c), c);
  for (const c of ["users.manage", "settings.manage", "audit.read"]) assert.ok(!has("manager", c), `manager must not hold ${c}`);
});

test("agent: own records plus active inventory; deals only as 'assigned'; never *_all, finance, imports or admin", () => {
  assert.ok(has("agent", "deals.read") && !has("agent", "deals.read_all") && !has("agent", "deals.write"));
  assert.ok(has("agent", "properties.read_active") && has("agent", "properties.write") && !has("agent", "properties.write_all"));
  assert.ok(has("agent", "activities.write") && !has("agent", "activities.read_all"));
  assert.deepEqual(ROLE_PERMISSIONS.agent.filter((c) => c.endsWith(".read_all")), [], "an agent holds no read_all permission");
  for (const p of ["finance.", "imports.", "messaging.", "market.", "users.", "settings.", "audit.", "analytics."]) assert.deepEqual(holds("agent", p), [], `agent: no ${p}*`);
});

test("viewer: read-only, and no deal, finance, import, messaging or admin permission (owner decision)", () => {
  for (const p of ["deals.", "finance.", "imports.", "messaging.", "users.", "settings.", "audit."]) assert.deepEqual(holds("viewer", p), [], `viewer: no ${p}*`);
  const writes = ROLE_PERMISSIONS.viewer.filter((c) => /\.(write|write_all|delete|manage)$/.test(c));
  assert.deepEqual(writes, [], "viewer holds no write, delete or manage permission");
  assert.deepEqual([...ROLE_PERMISSIONS.viewer].sort(), [
    "activities.read_all", "analytics.read", "appointments.read_all", "buyers.read_all", "contacts.read_all", "leads.read_all",
    "market.read", "market.read_all", "matching.read_all", "properties.read_all", "sellers.read_all", "tasks.read_all",
  ]);
  // Not granted to the viewer: it already has properties.read_all; read_active is for agents, managers and admins only.
  assert.ok(!has("viewer", "properties.read_active"));
});

test("viewer keeps activities.read_all, so deal-linked activity rows are protected by the 0013a gate, not by the grant", () => {
  assert.ok(has("viewer", "activities.read_all"));
  const gate = read("supabase/migrations/0013a_phase3_3_activities_deal_gate.sql");
  assert.match(gate, /create policy activities_select_deal_gate on activities\s+as restrictive\s+for select\s+to authenticated/i);
  assert.match(gate, /deal_id is null\s+or exists \(select 1 from deals d where d\.id = activities\.deal_id\)/i);
  const rollback = read("supabase/migrations/rollback/0013a_rollback.sql");
  assert.match(rollback, /drop policy if exists activities_select_deal_gate on activities/i);
  const sqlTest = read("supabase/tests/phase3_3_activities_deal_gate_tests.sql");
  for (const label of ["F1a VIEWER", "F1c VIEWER", "F1d VIEWER", "R2 MANAGER", "R3 AGENT"]) assert.ok(sqlTest.includes(label), `SQL test ${label} present`);
});

// ---- sidebar visibility per role (uses the real canAccess + MODULES rules) ----
const ready = (role: RoleCode): AccessState => ({ status: "ready", access: { userId: "u", fullName: null, role, permissions: ROLE_PERMISSIONS[role] } });
const visible = (role: RoleCode): ModuleId[] => NAV_ORDER.filter((id) => canAccess(ready(role), MODULES[id].anyOf));

test("sidebar: every permission named by nav.ts is a seeded permission", () => {
  for (const id of NAV_ORDER) for (const code of MODULES[id].anyOf) assert.ok(ALL_PERMISSIONS.includes(code), `${id}: ${code}`);
});

test("sidebar: what each role sees", () => {
  assert.deepEqual(visible("admin"), ["dashboard", "properties", "buyers", "sellers", "leads", "matching", "appointments", "deals", "analytics", "market", "settings"]);
  assert.deepEqual(visible("manager"), ["dashboard", "properties", "buyers", "sellers", "leads", "matching", "appointments", "deals", "analytics", "market"]);
  assert.deepEqual(visible("agent"), ["dashboard", "properties", "buyers", "sellers", "leads", "matching", "appointments", "deals"]);
  assert.deepEqual(visible("viewer"), ["dashboard", "properties", "buyers", "sellers", "leads", "matching", "appointments", "analytics", "market"]);
});

test("sidebar: a viewer never sees Deals or Settings, whatever else changes", () => {
  assert.ok(!visible("viewer").includes("deals") && !visible("viewer").includes("settings"));
  assert.ok(!canAccess(ready("viewer"), MODULES.deals.anyOf));
});
