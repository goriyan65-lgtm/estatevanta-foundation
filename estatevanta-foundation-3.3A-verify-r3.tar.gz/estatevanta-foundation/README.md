# EstateVanta CRM (foundation)

Independent, custom CRM + Admin Panel for EstateVanta. Not connected to, and does not modify, the existing website.

- `docs/ARCHITECTURE.md` – observed vs new vs needs-source, design, API, security
- `docs/ROADMAP.md` – 12 phases with test gates
- `supabase/migrations/` – SQL source of truth: `0001`–`0009` (schema and system configuration), then `0010a`, `0010b`, `0010c` (Phase 2 security), `0011a` (Phase 3 function hardening) and `0012a` (dashboard summary), then `0013a` (activities deal gate, finding F1) which is **PROPOSED — NOT APPLIED**: it has been tested only on a throwaway local replica, is not in the live database, and needs separate owner approval (see `docs/PHASE3_3A_F1_F2_PROPOSAL.md`). `superseded/` is never applied; `rollback/` holds the rollback scripts, including `rollback/0013a_rollback.sql`.
- `migrations/0000_estatevanta_all.sql` – `0001`–`0009` as one installer for a fresh Supabase project
- `docs/SUPABASE_SETUP.md` – step-by-step setup + verification queries
- `src/server/` – server-only Supabase clients (scaffold)

**Live database status** (checked read-only against the Supabase project "Estate vanta crm" on 2026-10-11): 6 migrations are recorded as applied, in this order: `estatevanta_phase1_installer` (`0000`, which is `0001`–`0009`), `estatevanta_p2_step1_audit_logger_access` (`0010a`), `estatevanta_p2_step2_bootstrap` (`0010b`), `estatevanta_p2_step3_admin_protection` (`0010c`), `estatevanta_p3_step0_function_hardening` (`0011a`) and `estatevanta_p3_2_dashboard_summary` (`0012a`). That is the schema and its system configuration only. The database holds no Auth user, no profile and no business data (it holds system configuration and 170 audit-log rows), bootstrap has not been armed, and the app has never been installed, built or run against it. **This is not a production-ready system.** Re-check the live state before relying on this paragraph; it records one moment.

## Data policy
The database starts empty. Migrations 0008–0009 insert system configuration only (roles, permissions, status/source/type lists, default matching weights, settings). No demo data exists or will be added.

## Apply the schema (Phase 2)
1. Create a Supabase project.
2. Follow `docs/SUPABASE_SETUP.md` (run `migrations/0000_estatevanta_all.sql` once).
3. Phase 2 (Steps 1–3 applied; see `docs/PHASE2_ROLLBACK.md`). **The app has no sign-up page, by design.** The first administrator is not created by this README or by the app: the one Auth user is created by the project owner in the Supabase dashboard (Authentication, Users, Add user, e-mail confirmed), and then the **two-step** bootstrap is run in the SQL editor with a strong one-time secret that only the owner knows:
   `select app.arm_bootstrap('<your secret>', '<your email>', 30);`
   `select app.bootstrap_first_admin('<your-auth-user-uuid>', '<your secret>');`
   The old one-argument function is disabled. This ceremony needs its own approval and has **not** been run. The full ordered plan is in `docs/PHASE3_3A_AUTH.md`; security tests: `docs/PHASE2_TESTING.md`.


## App (Phases 3.1 to 3.3A, code only)

Code-only app: 11 sections, responsive shell, dashboard cards (Phase 3.2), and a real Supabase Auth sign-in with a server-verified session (Phase 3.3A). **None of it has been installed, built or run against real Supabase yet**, and no Auth user or profile exists, so nobody can sign in today. Without a verified, active user every page fails closed. There is no sign-up, password reset, magic link or OAuth. See `docs/PHASE3_1_APP_SHELL.md`, `docs/PHASE3_2_DASHBOARD_UI.md` and `docs/PHASE3_3A_AUTH.md`.

Requires Node 22 or later (`engines.node`, approved as the project minimum). The exact, ordered verification procedure with what to check at each step is in `docs/PHASE3_3A_AUTH.md` ("Verification procedure on an internet-connected machine"). On a machine with internet access:

```bash
node --version               # 22 or later
npm install                  # creates package-lock.json; review it, then commit it only with approval
npm ls --depth=0 > versions-installed.txt    # record the versions that were actually installed
npm run typecheck
npx tsc -p tests/tsconfig.json --noEmit
npm test                     # logic and static tests against stand-ins (they do not talk to Supabase)
npm run build
```

Only after that, and only with approval: `cp .env.example .env.local` (fill `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` only; never the service-role key), `npm run dev`, and check that `/dashboard` redirects to `/login`.

`NEXT_PUBLIC_SUPABASE_URL` must be `https://<project-ref>.supabase.co` (plain http only for localhost). `NEXT_PUBLIC_SUPABASE_ANON_KEY` must be the project's public key (`sb_publishable_...` or the legacy `anon` JWT). Anything else, including any secret or service-role key, is refused and the app shows "not configured".
