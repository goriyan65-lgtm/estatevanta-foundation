-- =====================================================================
-- EstateVanta CRM — 0013a_phase3_3_activities_deal_gate.sql
--
-- STATUS: PROPOSED — NOT APPLIED. Reviewed on a throwaway local replica only. Do not run on the live
-- project without separate explicit owner approval. When it is applied, change this line to
-- "APPLIED <date>" in the same change (the 0011a header went stale because that step was missed).
--
-- FINDING F1 (Phase 3.3A audit): the activities SELECT policy (0007) lets anyone holding
-- activities.read_all read EVERY activity row. The Viewer role holds activities.read_all, so a viewer could read
-- activity rows that are linked to a deal (activities.deal_id), whose summary/details text may carry price, token or
-- negotiation notes. Owner decision (confirmed): viewers must not see activity rows linked to deals.
--
-- THE FIX (one additive RESTRICTIVE policy; nothing else changes):
--   A restrictive policy is AND-ed with the existing permissive policies. Whatever activities_select allows, a row
--   with a deal_id is returned ONLY IF the caller can also see that deal under the deals table's own RLS
--   (the EXISTS subquery on deals is itself filtered by deals RLS, the same pattern the child-table policies use).
--     * Viewer: no deals.read / deals.read_all  -> deals RLS returns nothing -> every deal-linked row is hidden,
--       even when the row ALSO carries a lead_id / buyer_id / property_id that the viewer may see.
--     * Agent:  deals.read (own/assigned deals)  -> only activities of deals they can see.
--     * Manager / Admin: deals.read_all           -> unchanged (see "behaviour notes" below).
--   Rows with deal_id IS NULL are not affected at all.
--
-- WHY NOT just remove activities.read_all from the viewer? Because a deal-linked row that also has a lead_id
-- would still be visible through the existing "parent lead is visible" branch. The gate closes that path too, and
-- it keeps the viewer's read-only timeline for leads, buyers, sellers and properties.
--
-- Behaviour notes (intentional, minimal):
--   * Admin sees all deals (including soft-deleted) -> sees all deal-linked activities, as before.
--   * Manager sees non-deleted deals only (deals RLS) -> activities of a SOFT-DELETED deal are now hidden from a
--     manager, consistent with the deal itself being hidden.
--   * activities has no UPDATE/DELETE policy (history is immutable), so only SELECT needs a gate.
--   * service_role bypasses RLS by design and is unaffected (server-only code).
--   * Free text in summary/details of rows WITHOUT a deal_id is not inspected; staff must not put deal figures into
--     non-deal activities. This is a data-entry rule, not something RLS can enforce.
--
-- Rollback: rollback/0013a_rollback.sql (drops only this policy). No data is read, written or moved.
-- =====================================================================

drop policy if exists activities_select_deal_gate on activities;

create policy activities_select_deal_gate on activities
  as restrictive
  for select
  to authenticated
  using (
    deal_id is null
    or exists (select 1 from deals d where d.id = activities.deal_id)
  );

-- Self-check: fail (and roll the whole migration back) unless exactly the expected policy set exists.
do $chk$
declare n_restrictive int; n_permissive int;
begin
  if not (select relrowsecurity from pg_class where oid = 'public.activities'::regclass) then
    raise exception '0013a: RLS is not enabled on activities';
  end if;
  select count(*) filter (where not polpermissive), count(*) filter (where polpermissive)
    into n_restrictive, n_permissive from pg_policy where polrelid = 'public.activities'::regclass;
  if n_restrictive <> 1 then raise exception '0013a: expected exactly 1 restrictive policy on activities, found %', n_restrictive; end if;
  if n_permissive <> 2 then raise exception '0013a: expected the 2 original permissive policies (select, insert), found %', n_permissive; end if;
  raise notice '0013a OK: activities_select_deal_gate in place';
end
$chk$;
