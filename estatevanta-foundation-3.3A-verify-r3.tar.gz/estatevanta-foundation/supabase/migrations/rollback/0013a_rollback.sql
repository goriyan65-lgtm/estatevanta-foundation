-- =====================================================================
-- Rollback for 0013a_phase3_3_activities_deal_gate.sql
-- Drops ONLY the restrictive policy activities_select_deal_gate. Nothing else was changed by 0013a.
-- Do not run automatically; run only on explicit instruction.
-- NOTE: rolling back re-opens finding F1 (viewers can read deal-linked activity rows).
-- =====================================================================
drop policy if exists activities_select_deal_gate on activities;

do $chk$
begin
  if exists (select 1 from pg_policy where polrelid = 'public.activities'::regclass and polname = 'activities_select_deal_gate') then
    raise exception 'rollback failed: activities_select_deal_gate still exists';
  end if;
  raise notice 'activities_select_deal_gate removed; activities policies are back to the 0007 state';
end
$chk$;
