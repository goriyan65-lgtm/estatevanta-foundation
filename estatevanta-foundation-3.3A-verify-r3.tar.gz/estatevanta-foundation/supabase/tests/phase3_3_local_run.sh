#!/usr/bin/env bash
# Phase 3.3 LOCAL gate for migration 0013a (activities deal gate). Runs ONLY against a throwaway local Postgres replica
# that already has migrations 0001..0012a replayed — NEVER against Supabase.
# Usage: PSQL="psql -h <sock> -p <port> -U postgres -d ev -X" bash phase3_3_local_run.sh
# Lifecycle: baseline fingerprint -> tests on the OLD policies (must FAIL: proves the tests see bug F1) -> apply 0013a ->
#            fingerprint (only 'policies' may change) -> tests (must be 0 FAIL) -> fingerprint (must equal previous) ->
#            rollback -> fingerprint (must equal baseline) -> re-apply (leaves the replica in the post-migration state).
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"; MIG="$HERE/../migrations"
: "${PSQL:?set PSQL}"
fp() { $PSQL -AtF' | ' -f "$HERE/phase3_2_fingerprint_readonly.sql"; }
report() { $PSQL -f "$HERE/phase3_3_activities_deal_gate_tests.sql" 2>&1 | grep -E 'TEST REPORT|^FAIL'; }
ok=1; chk() { if [ "$2" = "$3" ]; then echo "PASS $1"; else echo "FAIL $1"; ok=0; fi; }

$PSQL -q -f "$MIG/rollback/0013a_rollback.sql" >/dev/null 2>&1          # make sure we start from the 0007 policy set
F0="$(fp)"
echo "--- tests against the OLD policies (expected: FAILS, they must detect finding F1):"
RED="$(report)"; echo "$RED" | head -1
echo "$RED" | grep -q 'TEST REPORT: [0-9]* PASS, 0 FAIL' && { echo "FAIL tests did not detect F1 on the old policies"; ok=0; } || echo "PASS tests detect F1 on the old policies"

$PSQL -q -v ON_ERROR_STOP=1 -1 -f "$MIG/0013a_phase3_3_activities_deal_gate.sql" >/dev/null 2>&1 && echo "PASS migration applied" || { echo "FAIL migration apply"; ok=0; }
F1="$(fp)"
echo "--- fingerprint rows that changed after migration (expect ONLY 'policies'):"
diff <(echo "$F0") <(echo "$F1") | grep '^[<>]' | cut -c1-60
CHANGED="$(diff <(echo "$F0") <(echo "$F1") | grep '^>' | cut -d'|' -f1 | tr -d '> ' | tr '\n' ',')"
chk "only the policies row changed" "$CHANGED" "policies,"
RES="$(report)"; echo "$RES"
echo "$RES" | grep -q 'TEST REPORT: [0-9]* PASS, 0 FAIL' && echo "PASS test suite: 0 FAIL" || { echo "FAIL test suite"; ok=0; }
F2="$(fp)"; chk "state identical after tests (rollback + sequences restored)" "$F1" "$F2"
$PSQL -q -v ON_ERROR_STOP=1 -1 -f "$MIG/rollback/0013a_rollback.sql" >/dev/null 2>&1 && echo "PASS rollback ran" || { echo "FAIL rollback"; ok=0; }
F3="$(fp)"; chk "rollback restores baseline fingerprint exactly" "$F0" "$F3"
$PSQL -q -v ON_ERROR_STOP=1 -1 -f "$MIG/0013a_phase3_3_activities_deal_gate.sql" >/dev/null 2>&1
[ $ok = 1 ] && echo "LOCAL GATE: ALL PASS" || echo "LOCAL GATE: FAILURES"
