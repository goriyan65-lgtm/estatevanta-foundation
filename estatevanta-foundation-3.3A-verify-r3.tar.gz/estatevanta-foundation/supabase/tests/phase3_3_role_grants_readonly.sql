-- READ-ONLY. Pure SELECT; changes nothing. Safe on the live project and on a local replica.
-- Lists the role -> permission grants and a fingerprint, to be compared with tests/fixtures/role-permissions.ts
-- (ROLE_PERMISSIONS_FINGERPRINT). Fingerprint = md5 of the lines "<role>:<permission>" joined by newline, sorted by role
-- then permission in plain byte order (COLLATE "C"), over ALL roles in role_permissions.
-- Expected today: admin 60, manager 57, agent 18, viewer 12 (147 grants) and 60 permissions.
select 'permissions_total' as k, count(*)::text as v from permissions
union all
select 'grants_' || r.code, count(*)::text
  from roles r join role_permissions rp on rp.role_id = r.id group by r.code
union all
select 'grants_fingerprint', md5(string_agg(r.code || ':' || p.code, E'\n' order by r.code collate "C", p.code collate "C"))
  from role_permissions rp join roles r on r.id = rp.role_id join permissions p on p.id = rp.permission_id
order by 1;
