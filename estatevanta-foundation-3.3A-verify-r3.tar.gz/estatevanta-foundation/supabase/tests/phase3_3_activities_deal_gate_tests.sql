-- =====================================================================
-- EstateVanta CRM — Phase 3.3 activities deal-gate tests (FULLY ROLLED BACK)
-- Proves finding F1 is closed: a Viewer (and anyone without access to a deal) cannot read activity rows that are
-- linked to that deal, including rows that ALSO carry a lead / buyer / property link the caller may see.
-- Run AFTER 0013a is installed (local replica first; the live project only after you approve it).
-- Run BEFORE 0013a on the local replica to watch the F1 tests FAIL (that is the proof the tests detect the bug).
--
-- Same safety model as phase3_2_dashboard_tests.sql:
--   * ONE DO statement. Throwaway @example.invalid users and fixture rows exist only inside it.
--   * Every change is thrown away by a final deliberate error. SQLSTATE P0001 "P3.3 TEST REPORT" is the NORMAL
--     outcome; the report is the error message. Any other error = the harness itself broke.
--   * Sequences are restored with setval (sequences are not transactional).
--   * It refuses to run if any business table already has rows (so it can never mix with real data).
--   * Never reads real data, never uses a real secret, never touches anything outside this transaction.
-- =====================================================================
do $p33$
declare
  u_admin uuid := gen_random_uuid(); u_mgr uuid := gen_random_uuid(); u_agent uuid := gen_random_uuid();
  u_agent2 uuid := gen_random_uuid(); u_viewer uuid := gen_random_uuid(); u_inactive uuid := gen_random_uuid();
  u_norole uuid := gen_random_uuid();
  rpt text := ''; n_pass int; n_fail int; rec record; seq0 jsonb;
  gate_present boolean;
begin
  -- ------------------------------------------------------------------ helpers
  create temp table tr(n serial, ok boolean, label text, got text, want text) on commit drop;
  create temp table fx(k text primary key, id uuid not null default gen_random_uuid()) on commit drop;

  create function pg_temp.rec(p_label text, p_got text, p_want text) returns void language sql as
  $f$ insert into tr(ok, label, got, want) values (p_got is not distinct from p_want, p_label, p_got, p_want) $f$;

  create function pg_temp.f(p_k text) returns uuid language plpgsql as
  $f$ declare r uuid; begin
        select id into r from fx where k = p_k;
        if r is null then insert into fx(k) values (p_k) returning id into r; end if;
        return r; end $f$;

  -- run one SQL statement (single text value) as <role> with JWT subject <uid>; errors come back as 'ERR <sqlstate>'
  create function pg_temp.q(p_role text, p_uid text, p_sql text) returns text language plpgsql as $f$
  declare r text;
  begin
    perform set_config('request.jwt.claims',
      case when p_uid is null then json_build_object('role', p_role)::text
           else json_build_object('sub', p_uid, 'role', p_role, 'aud', 'authenticated')::text end, true);
    perform set_config('request.jwt.claim.sub', coalesce(p_uid, ''), true);
    perform set_config('request.jwt.claim.role', p_role, true);
    execute format('set local role %I', p_role);
    begin
      execute p_sql into r; r := coalesce(r, '(none)');
    exception when others then r := 'ERR ' || sqlstate;
    end;
    execute 'reset role';
    perform set_config('request.jwt.claims', '', true);
    perform set_config('request.jwt.claim.sub', '', true);
    perform set_config('request.jwt.claim.role', '', true);
    return r;
  end $f$;

  -- the activity summaries the caller can see, e.g. 'A1,A3'. Fixture summaries are all 'A<n>'.
  create function pg_temp.seen(p_uid uuid) returns text language sql as $f$
    select pg_temp.q('authenticated', p_uid::text,
      'select string_agg(summary, '','' order by summary) from public.activities where summary like ''A%''') $f$;

  create function pg_temp.seqs() returns jsonb language plpgsql as $f$
  declare r record; j jsonb := '{}'; lv bigint; ic boolean;
  begin
    for r in select n.nspname, c.relname from pg_class c join pg_namespace n on n.oid = c.relnamespace
             where c.relkind = 'S' and n.nspname in ('public', 'app', 'auth') order by 1, 2
    loop
      begin
        execute format('select last_value, is_called from %I.%I', r.nspname, r.relname) into lv, ic;
        j := j || jsonb_build_object(r.nspname || '.' || r.relname, jsonb_build_array(lv, ic));
      exception when others then null; end;
    end loop;
    return j;
  end $f$;

  create function pg_temp.restore_seqs(p_seqs jsonb) returns void language plpgsql as $f$
  declare r record;
  begin
    for r in select key, value from jsonb_each(p_seqs) loop
      begin perform setval(r.key::regclass, (r.value ->> 0)::bigint, (r.value ->> 1)::boolean);
      exception when others then null; end;
    end loop;
  end $f$;

  create function pg_temp.mk_contact(p_name text) returns uuid language plpgsql as $f$
  declare r uuid; begin insert into contacts(full_name, email) values (p_name, lower(replace(p_name, ' ', '-')) || '@example.invalid') returning id into r; return r; end $f$;

  seq0 := pg_temp.seqs();

  -- ------------------------------------------------------------------ 0. refuse to run on a database with business rows
  if exists (select 1 from properties) or exists (select 1 from leads) or exists (select 1 from buyers)
     or exists (select 1 from sellers) or exists (select 1 from deals) or exists (select 1 from appointments)
     or exists (select 1 from tasks) or exists (select 1 from property_matches) or exists (select 1 from contacts)
     or exists (select 1 from activities) then
    raise exception 'ABORT: business tables are not empty — this test only runs on an empty CRM database';
  end if;

  -- ------------------------------------------------------------------ 1. static catalog checks
  select exists (select 1 from pg_policy where polrelid = 'public.activities'::regclass and polname = 'activities_select_deal_gate')
    into gate_present;
  perform pg_temp.rec('S1 gate policy exists (FAILS on a database without 0013a)', gate_present::text, 'true');
  perform pg_temp.rec('S2 gate is RESTRICTIVE, SELECT-only, authenticated-only',
    (select coalesce(string_agg((not polpermissive)::text || '/' || polcmd::text || '/' ||
        (select string_agg(rolname, ',') from pg_roles where oid = any (polroles)), ';'), '<none>')
       from pg_policy where polrelid = 'public.activities'::regclass and polname = 'activities_select_deal_gate'),
    'true/r/authenticated');
  perform pg_temp.rec('S3 original permissive policies untouched (select + insert)',
    (select string_agg(polname || ':' || polcmd::text, ',' order by polname) from pg_policy
      where polrelid = 'public.activities'::regclass and polpermissive),
    'activities_insert:a,activities_select:r');
  perform pg_temp.rec('S4 RLS enabled on activities',
    (select relrowsecurity::text from pg_class where oid = 'public.activities'::regclass), 'true');
  perform pg_temp.rec('S5 anon has no privilege on activities',
    (has_table_privilege('anon', 'public.activities', 'select'))::text, 'false');
  perform pg_temp.rec('S6 viewer role still holds activities.read_all (the gate, not the grant, is what protects deals)',
    (select exists (select 1 from role_permissions rp join roles r on r.id = rp.role_id join permissions p on p.id = rp.permission_id
                    where r.code = 'viewer' and p.code = 'activities.read_all')::text), 'true');
  perform pg_temp.rec('S7 viewer holds no deals.* and no finance.* permission',
    (select count(*)::text from role_permissions rp join roles r on r.id = rp.role_id join permissions p on p.id = rp.permission_id
      where r.code = 'viewer' and (p.code like 'deals.%' or p.code like 'finance.%')), '0');

  -- ------------------------------------------------------------------ 2. users (throwaway)
  insert into auth.users(id, aud, role, email, email_confirmed_at, last_sign_in_at) values
    (u_admin, 'authenticated', 'authenticated', 'p33-admin@example.invalid', now(), now()),
    (u_mgr, 'authenticated', 'authenticated', 'p33-mgr@example.invalid', now(), now()),
    (u_agent, 'authenticated', 'authenticated', 'p33-agent@example.invalid', now(), now()),
    (u_agent2, 'authenticated', 'authenticated', 'p33-agent2@example.invalid', now(), now()),
    (u_viewer, 'authenticated', 'authenticated', 'p33-viewer@example.invalid', now(), now()),
    (u_inactive, 'authenticated', 'authenticated', 'p33-inactive@example.invalid', now(), now()),
    (u_norole, 'authenticated', 'authenticated', 'p33-norole@example.invalid', now(), now());
  update profiles set role_id = (select id from roles where code = 'admin'),   is_active = true where id = u_admin;
  update profiles set role_id = (select id from roles where code = 'manager'), is_active = true where id = u_mgr;
  update profiles set role_id = (select id from roles where code = 'agent'),   is_active = true where id in (u_agent, u_agent2);
  update profiles set role_id = (select id from roles where code = 'viewer'),  is_active = true where id = u_viewer;
  update profiles set role_id = (select id from roles where code = 'agent'),   is_active = false where id = u_inactive;
  -- u_norole: active = false, no role (as created by the signup trigger)

  -- ------------------------------------------------------------------ 3. fixtures (rolled back; never persisted)
  insert into properties(id, title, property_type_code, transaction_type, city, source, status, assigned_to, created_by) values
    (pg_temp.f('p1'), 'P33 p1', 'flat_apartment', 'sale', 'P33CITY', 'other', 'available', u_agent,  u_agent),
    (pg_temp.f('p2'), 'P33 p2', 'flat_apartment', 'sale', 'P33CITY', 'other', 'available', u_agent2, u_agent2);
  insert into leads(id, contact_id, lead_type, source_code, status_code, priority, assigned_to, created_by) values
    (pg_temp.f('l1'), pg_temp.mk_contact('P33 c-l1'), 'buy', 'website', 'new', 'high', u_agent, u_agent);
  insert into buyers(id, contact_id, is_active, assigned_to, created_by) values
    (pg_temp.f('b1'), pg_temp.mk_contact('P33 c-b1'), true, u_agent,  u_agent),
    (pg_temp.f('b2'), pg_temp.mk_contact('P33 c-b2'), true, u_agent2, u_agent2),
    (pg_temp.f('b3'), pg_temp.mk_contact('P33 c-b3'), true, u_mgr,    u_mgr);
  insert into sellers(id, contact_id, relationship_status, assigned_to, created_by) values
    (pg_temp.f('s1'), pg_temp.mk_contact('P33 c-s1'), 'new', u_agent, u_agent);
  -- d1 = the agent's deal, d2 = agent2's deal, d3 = a soft-deleted deal
  insert into deals(id, buyer_id, seller_id, property_id, status, assigned_to, created_by) values
    (pg_temp.f('d1'), pg_temp.f('b1'), pg_temp.f('s1'), pg_temp.f('p1'), 'negotiation', u_agent,  u_agent),
    (pg_temp.f('d2'), pg_temp.f('b2'), pg_temp.f('s1'), pg_temp.f('p2'), 'negotiation', u_agent2, u_agent2),
    (pg_temp.f('d3'), pg_temp.f('b3'), pg_temp.f('s1'), pg_temp.f('p1'), 'negotiation', u_mgr,    u_mgr);
  update deals set deleted_at = now() where id = pg_temp.f('d3');

  -- Seven activity rows, all created_by the admin so that nobody reads them through "created by me".
  insert into activities(type, summary, details, lead_id, buyer_id, property_id, contact_id, deal_id, created_by) values
    ('note', 'A1', '{"price":"SECRET-DEAL-FIGURE"}', null,              null, null,              null,              pg_temp.f('d1'), u_admin), -- deal only (agent's deal)
    ('note', 'A2', '{"price":"SECRET-DEAL-FIGURE"}', pg_temp.f('l1'),   null, null,              null,              pg_temp.f('d1'), u_admin), -- deal + lead  (the bypass path)
    ('note', 'A3', '{"price":"SECRET-DEAL-FIGURE"}', null,              null, null,              null,              pg_temp.f('d2'), u_admin), -- deal only (agent2's deal)
    ('note', 'A4', '{}',                             pg_temp.f('l1'),   null, null,              null,              null,            u_admin), -- lead only
    ('note', 'A5', '{}',                             null,              null, pg_temp.f('p1'),   null,              null,            u_admin), -- property only
    ('note', 'A6', '{"price":"SECRET-DEAL-FIGURE"}', null,              null, null,              null,              pg_temp.f('d3'), u_admin), -- deal only (soft-deleted deal)
    ('note', 'A7', '{}',                             null,              null, null,              pg_temp.mk_contact('P33 c-a7'), null,   u_admin); -- contact only

  -- ------------------------------------------------------------------ 4. F1: what each role can read
  -- BEFORE 0013a these rows are visible to every read_all holder; AFTER it, deal-linked rows need deal access.
  perform pg_temp.rec('F1a VIEWER sees only non-deal rows: A4 A5 A7 (deal-linked A1 A2 A3 A6 hidden)',
                      pg_temp.seen(u_viewer), 'A4,A5,A7');
  perform pg_temp.rec('F1b VIEWER cannot read a deal-linked row by its id (A1)',
                      pg_temp.q('authenticated', u_viewer::text, 'select count(*)::text from public.activities where summary = ''A1'''), '0');
  perform pg_temp.rec('F1c VIEWER cannot read a row linked to BOTH a visible lead and a deal (A2 bypass path)',
                      pg_temp.q('authenticated', u_viewer::text, 'select count(*)::text from public.activities where summary = ''A2'''), '0');
  perform pg_temp.rec('F1d VIEWER sees zero rows with a deal_id',
                      pg_temp.q('authenticated', u_viewer::text, 'select count(*)::text from public.activities where deal_id is not null'), '0');
  perform pg_temp.rec('F1e VIEWER cannot read the deal figure out of details',
                      pg_temp.q('authenticated', u_viewer::text, 'select count(*)::text from public.activities where details::text like ''%SECRET-DEAL-FIGURE%'''), '0');
  perform pg_temp.rec('F1f VIEWER cannot filter on deal_id to probe which deals have activity',
                      pg_temp.q('authenticated', u_viewer::text, format('select count(*)::text from public.activities where deal_id = %L', pg_temp.f('d1'))), '0');
  perform pg_temp.rec('F1g VIEWER still sees the deals table as empty (unchanged)',
                      pg_temp.q('authenticated', u_viewer::text, 'select count(*)::text from public.deals'), '0');
  perform pg_temp.rec('F1h VIEWER cannot insert an activity (no activities.write)',
                      pg_temp.q('authenticated', u_viewer::text, format('insert into public.activities(type, summary, lead_id, created_by) values (''note'', ''A-viewer'', %L, %L)', pg_temp.f('l1'), u_viewer)), 'ERR 42501');

  -- ------------------------------------------------------------------ 5. other roles
  perform pg_temp.rec('R1 ADMIN sees everything incl. the soft-deleted deal row: A1..A7',
                      pg_temp.seen(u_admin), 'A1,A2,A3,A4,A5,A6,A7');
  perform pg_temp.rec('R2 MANAGER sees all non-deleted-deal rows; A6 (soft-deleted deal) hidden, like the deal itself',
                      pg_temp.seen(u_mgr), 'A1,A2,A3,A4,A5,A7');
  perform pg_temp.rec('R3 AGENT (own deal d1, own lead l1, own property p1) sees A1 A2 A4 A5, not agent2''s deal row A3',
                      pg_temp.seen(u_agent), 'A1,A2,A4,A5');
  perform pg_temp.rec('R4 AGENT2 (own deal d2, active inventory p1) sees A3 A5 only',
                      pg_temp.seen(u_agent2), 'A3,A5');
  perform pg_temp.rec('R5 INACTIVE user sees nothing',  pg_temp.seen(u_inactive), '(none)');
  perform pg_temp.rec('R6 NO-ROLE user sees nothing',   pg_temp.seen(u_norole),   '(none)');
  perform pg_temp.rec('R7 ANON has no access (permission denied)',
                      pg_temp.q('anon', null, 'select count(*)::text from public.activities'), 'ERR 42501');

  -- ------------------------------------------------------------------ 6. writes still work for people allowed to log activities
  perform pg_temp.rec('W1 AGENT can still log an activity on their own lead',
                      pg_temp.q('authenticated', u_agent::text, format('insert into public.activities(type, summary, lead_id, created_by) values (''note'', ''A-w1'', %L, %L) returning ''ok''', pg_temp.f('l1'), u_agent)), 'ok');
  perform pg_temp.rec('W2 AGENT can read back what they logged (non-deal row)',
                      pg_temp.q('authenticated', u_agent::text, 'select count(*)::text from public.activities where summary = ''A-w1'''), '1');
  perform pg_temp.rec('W3 ADMIN can still log a deal-linked activity and read it back',
                      pg_temp.q('authenticated', u_admin::text, format('insert into public.activities(type, summary, deal_id, created_by) values (''note'', ''A-w3'', %L, %L) returning ''ok''', pg_temp.f('d1'), u_admin)), 'ok');
  perform pg_temp.rec('W4 the viewer still cannot see that new deal-linked row',
                      pg_temp.q('authenticated', u_viewer::text, 'select count(*)::text from public.activities where summary = ''A-w3'''), '0');
  perform pg_temp.rec('W5 activities remain immutable for users (no update)',
                      pg_temp.q('authenticated', u_admin::text, 'update public.activities set summary = summary where summary = ''A1'' returning ''ok'''), '(none)');

  -- ------------------------------------------------------------------ 7. REPORT (the error below is the intentional rollback)
  perform pg_temp.restore_seqs(seq0);
  select count(*) filter (where ok), count(*) filter (where not ok) into n_pass, n_fail from tr;
  for rec in select * from tr order by n loop
    rpt := rpt || E'\n' || case when rec.ok then 'PASS ' else 'FAIL ' end || rec.label
           || case when rec.ok then '' else '   got=[' || coalesce(rec.got, 'NULL') || '] want=[' || coalesce(rec.want, 'NULL') || ']' end;
  end loop;
  raise exception 'P3.3 TEST REPORT: % PASS, % FAIL%', n_pass, n_fail, rpt using errcode = 'P0001';
end
$p33$;
