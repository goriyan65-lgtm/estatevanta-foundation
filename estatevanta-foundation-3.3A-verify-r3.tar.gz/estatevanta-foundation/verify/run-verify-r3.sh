#!/usr/bin/env bash
# EstateVanta Phase 3.3A r3 verification (F1/F2 proposal). Run from anywhere: bash verify/run-verify-r3.sh
#
# What it does: install, real TypeScript typecheck, tests typecheck, npm test, production build. Each is reported
# SEPARATELY; one failure does not hide the others (a failed install skips the steps that need it).
# What it never does: connect to Supabase or Firebase, read or write any database, create users, commit, push, deploy,
# create a lockfile, or print a secret. The Supabase variables are removed from the environment of every step.
# Output: verify-result-r3.txt (short, one line per step) and verify-logs/ (full logs), both in the project root.
set -u
cd "$(dirname "$0")/.." || exit 2
ROOT="$(pwd)"
LOGS="$ROOT/verify-logs"; RES="$ROOT/verify-result-r3.txt"
rm -rf "$LOGS" "$RES"; mkdir -p "$LOGS"
export NEXT_TELEMETRY_DISABLED=1 CI=1
CLEAN=(env -u NEXT_PUBLIC_SUPABASE_URL -u NEXT_PUBLIC_SUPABASE_ANON_KEY -u SUPABASE_SERVICE_ROLE_KEY -u SUPABASE_URL -u SUPABASE_ANON_KEY -u SUPABASE_ACCESS_TOKEN)

LINES=(); FAILS=0
add() { LINES+=("$1"); }           # add "<label>: PASS|FAIL|SKIPPED (detail)"
res() { # res <label> <PASS|FAIL|SKIPPED> [detail]
  add "$1: $2${3:+ ($3)}"; [ "$2" = FAIL ] && FAILS=$((FAILS+1)); return 0; }

# ---- 1. Node version (needs >= 22) -------------------------------------------------------------
NODE_V="$(node -v 2>/dev/null || echo none)"; NPM_V="$(npm -v 2>/dev/null || echo none)"
NODE_MAJOR="${NODE_V#v}"; NODE_MAJOR="${NODE_MAJOR%%.*}"
if [ "$NODE_V" != none ] && [ "${NODE_MAJOR:-0}" -ge 22 ] 2>/dev/null; then res "1 Node >= 22" PASS "node $NODE_V, npm $NPM_V"; else res "1 Node >= 22" FAIL "node $NODE_V"; fi

# ---- 2. the proposal files are present and marked correctly --------------------------------------
missing=""
for f in supabase/migrations/0013a_phase3_3_activities_deal_gate.sql supabase/migrations/rollback/0013a_rollback.sql \
         supabase/tests/phase3_3_activities_deal_gate_tests.sql supabase/tests/phase3_3_local_run.sh \
         supabase/tests/phase3_3_role_grants_readonly.sql tests/fixtures/role-permissions.ts tests/roles.test.ts \
         docs/PHASE3_3A_F1_F2_PROPOSAL.md tests/auth.test.ts README.md package.json; do [ -s "$f" ] || missing="$missing $f"; done
hdr=yes; grep -q "PROPOSED — NOT APPLIED" supabase/migrations/0013a_phase3_3_activities_deal_gate.sql 2>/dev/null || hdr=no
rdm=yes; grep -q "0013a.*PROPOSED — NOT APPLIED" README.md 2>/dev/null || rdm=no
rb=yes;  grep -q "drop policy if exists activities_select_deal_gate" supabase/migrations/rollback/0013a_rollback.sql 2>/dev/null || rb=no
envf="$(find . -path ./node_modules -prune -o -name '.env*' ! -name '.env.example' -print 2>/dev/null | head -1)"
lock="$(ls package-lock.json yarn.lock pnpm-lock.yaml bun.lockb bun.lock npm-shrinkwrap.json 2>/dev/null | head -1)"
if [ -z "$missing" ] && [ $hdr = yes ] && [ $rdm = yes ] && [ $rb = yes ] && [ -z "$envf" ] && [ -z "$lock" ]; then
  res "2 files present, migration marked PROPOSED — NOT APPLIED, rollback present, no .env or lockfile" PASS
else
  res "2 files present, migration marked PROPOSED — NOT APPLIED, rollback present, no .env or lockfile" FAIL "missing:[${missing# }] header:$hdr readme:$rdm rollback:$rb env:[${envf:-none}] lockfile:[${lock:-none}]"
fi
set_vars=""; for v in NEXT_PUBLIC_SUPABASE_URL NEXT_PUBLIC_SUPABASE_ANON_KEY SUPABASE_SERVICE_ROLE_KEY; do [ -n "${!v:-}" ] && set_vars="$set_vars $v"; done
add "note: Supabase variables set in this shell (names only, removed from every step):${set_vars:- none}"

# ---- 3. install (no lockfile is created) ---------------------------------------------------------
INSTALL=FAIL
if [ "${NODE_MAJOR:-0}" -ge 22 ] 2>/dev/null; then
  "${CLEAN[@]}" npm install --no-package-lock --no-audit --no-fund >"$LOGS/3-install.log" 2>&1 && INSTALL=PASS
fi
if [ $INSTALL = PASS ]; then res "3 npm install (no lockfile)" PASS; else res "3 npm install (no lockfile)" FAIL "see verify-logs/3-install.log"; fi

ver() { node -e 'try{console.log(require("fs").readFileSync(process.argv[1],"utf8").match(/"version":\s*"([^"]+)"/)[1])}catch(e){console.log("n/a")}' "node_modules/$1/package.json" 2>/dev/null; }
{ for p in next react react-dom @supabase/ssr @supabase/supabase-js esbuild typescript; do echo "$p $(ver $p)"; done; } >"$LOGS/versions-installed.txt" 2>/dev/null
add "versions: $(tr '\n' ';' <"$LOGS/versions-installed.txt" | sed 's/;/; /g')"
[ -n "$(ls package-lock.json 2>/dev/null)" ] && add "note: a package-lock.json appeared (it was NOT requested); do not commit it" || add "note: no lockfile was created"

step() { # step <label> <log> <command...> ; skipped when install failed
  local label="$1" log="$2"; shift 2
  if [ $INSTALL != PASS ]; then res "$label" SKIPPED "install failed"; return 1; fi
  "${CLEAN[@]}" "$@" >"$LOGS/$log" 2>&1; local rc=$?
  echo "exit code: $rc" >>"$LOGS/$log"
  if [ $rc -eq 0 ]; then res "$label" PASS; return 0; else res "$label" FAIL "exit $rc, see verify-logs/$log"; return 1; fi
}

# ---- 4/5. real TypeScript typechecks ---------------------------------------------------------------
step "4 TypeScript typecheck (npm run typecheck)" 4-typecheck.log npm run typecheck
step "5 TypeScript typecheck of tests (tsc -p tests/tsconfig.json)" 5-typecheck-tests.log npx tsc -p tests/tsconfig.json --noEmit

# ---- 6. npm test (totals parsed from BOTH the TAP and the spec reporter formats) -----------------------
if step "6 npm test" 6-test.log npm test; then T_OK=1; else T_OK=0; fi
if [ $INSTALL = PASS ]; then
  tot() { grep -Eh "^(#|ℹ) $1 [0-9]+" "$LOGS/6-test.log" | tail -1 | grep -Eo '[0-9]+$'; }
  T_TESTS="$(tot tests)"; T_PASS="$(tot pass)"; T_FAIL="$(tot fail)"
  add "6 test totals: tests=${T_TESTS:-?} pass=${T_PASS:-?} fail=${T_FAIL:-?} (expected 94 tests, 0 fail in the sandbox run)"
  if [ "$T_OK" = 1 ] && [ -n "${T_TESTS:-}" ] && [ "${T_TESTS:-0}" -lt 94 ] 2>/dev/null; then add "6 WARNING: fewer than 94 tests ran"; FAILS=$((FAILS+1)); fi
fi

# ---- 7. production build ----------------------------------------------------------------------------
step "7 production build (npm run build)" 7-build.log npm run build
if [ $INSTALL = PASS ]; then
  # The exact route-list line ("ƒ Proxy (Middleware)"). A bare word match could also hit a deprecation warning.
  if grep -Eq "Proxy \(Middleware\)" "$LOGS/7-build.log" 2>/dev/null; then add "7 Proxy (Middleware) line in the build route list: yes"; else add "7 Proxy (Middleware) line in the build route list: NOT FOUND"; fi
fi

# ---- 8. secret scan of everything this script wrote (counts only; values are never printed) -------------
hits="$(grep -rEil 'sb_secret_|sbp_[A-Za-z0-9]{20,}|eyJ[A-Za-z0-9_-]{30,}\.[A-Za-z0-9_-]{30,}|service_role' "$LOGS" 2>/dev/null | wc -l | tr -d ' ')"
if [ "$hits" = 0 ]; then res "8 secret scan of the logs" PASS "0 files matched"; else res "8 secret scan of the logs" FAIL "$hits log file(s) matched a secret-like pattern; do not share them"; fi

# ---- result file -----------------------------------------------------------------------------------------
{
  echo "ESTATEVANTA PHASE 3.3A r3 VERIFICATION RESULT"
  echo "(real install, real TypeScript, real Next build; nothing here touches Supabase, Firebase or the website)"
  echo
  for l in "${LINES[@]}"; do echo "$l"; done
  echo
  if [ $FAILS -eq 0 ]; then echo "OVERALL: ALL PASS"; else echo "OVERALL: $FAILS FAILURE(S)"; fi
  if [ $FAILS -ne 0 ]; then
    echo; echo "---- last lines of each failed step's log ----"
    for f in "$LOGS"/[3-7]-*.log; do
      [ -f "$f" ] || continue
      if grep -q '^exit code: [1-9]' "$f" 2>/dev/null || { [ "$(basename "$f")" = 3-install.log ] && [ $INSTALL != PASS ]; }; then
        echo; echo "== $(basename "$f")"; tail -n 25 "$f" | cut -c1-200
      fi
    done
  fi
} >"$RES"
cat "$RES"
echo; echo "Result file: $RES"; echo "Full logs:   $LOGS"
[ $FAILS -eq 0 ]
